# BlockChat MF — dibangun ulang dengan Azalea

Klien Minecraft tanpa grafis untuk AFK di HP. Kotlin/Compose (UI) + inti Azalea (Rust).

- `rust/` : program `blockchat-azalea`, satu koneksi = satu proses. Dibangun jadi `libazalea.so`.
- `Core.kt` : menjalankan proses itu, bicara lewat pipa stdin/stdout (baris JSON), sambung ulang otomatis (jeda 5 -> 60 dtk, berhenti bila kena ban).
- `BotService.kt` : foreground service + wake lock selama ada koneksi.
- Akun punya password opsional: dikirim sebagai `/login` otomatis 2 detik setelah masuk. Disimpan di HP (SharedPreferences), tidak masuk log.
- `arsip-mineflayer/` : kode Node lama, tidak ikut build (bahan untuk mesin script nanti).
- Belum ada: script, pindah server lewat menu, resource pack lobby.
