// BlockChat MF - inti Azalea.
// Satu koneksi = satu proses. Aplikasi (Kotlin) menjalankan program ini, lalu berbicara lewat pipa:
//   stdin  (baris JSON): baris pertama = konfigurasi {"host","port","username","password"};
//                        berikutnya {"t":"chat","v":"teks atau /perintah"} atau {"t":"quit"}
//   stdout (baris JSON): {"t":"status","v":"connecting|online|offline"}, {"t":"log","v":"..."}, {"t":"chat","v":"..."}
// Teks lain di stdout/stderr (log azalea, panic) diteruskan aplikasi apa adanya ke Log.
// Tidak ada port jaringan. Kalau stdin ditutup (aplikasi mati), program ikut berhenti.

use std::sync::{Mutex, OnceLock};
use std::time::Duration;

use azalea::prelude::*;
use serde_json::{json, Value};
use tokio::io::{AsyncBufReadExt, BufReader};

static BOT: Mutex<Option<Client>> = Mutex::new(None);
static PASSWORD: OnceLock<String> = OnceLock::new();

fn out(v: Value) {
    println!("{v}");
}
fn status(s: &str) {
    out(json!({"t": "status", "v": s}));
}
fn log(t: impl AsRef<str>) {
    out(json!({"t": "log", "v": t.as_ref()}));
}

fn clean(s: &str) -> String {
    // buang karakter glyph font kustom (private-use) dan karakter rusak
    s.chars().filter(|c| !('\u{E000}'..='\u{F8FF}').contains(c) && *c != '\u{FFFD}').collect()
}

#[derive(Default, Clone, Component)]
pub struct State;

async fn handle(bot: Client, event: Event, _state: State) -> anyhow::Result<()> {
    match event {
        Event::Login => {
            *BOT.lock().unwrap() = Some(bot.clone());
            status("online");
            log("masuk ke server");
            if let Some(pw) = PASSWORD.get() {
                if !pw.is_empty() {
                    tokio::time::sleep(Duration::from_millis(2000)).await;
                    bot.chat(format!("/login {pw}").as_str());
                    log("perintah /login dikirim");
                }
            }
        }
        Event::Chat(m) => {
            let t = clean(&m.message().to_string());
            if !t.trim().is_empty() {
                out(json!({"t": "chat", "v": t}));
            }
        }
        Event::Disconnect(reason) => {
            let r = reason.map(|r| clean(&r.to_string())).unwrap_or_else(|| "tanpa alasan".into());
            log(format!("terputus: {r}"));
            status("offline");
            tokio::time::sleep(Duration::from_millis(300)).await;
            std::process::exit(0);
        }
        _ => {}
    }
    Ok(())
}

fn main() {
    let rt = tokio::runtime::Runtime::new().expect("tokio runtime");
    rt.block_on(run());
}

async fn run() {
    let mut lines = BufReader::new(tokio::io::stdin()).lines();
    let cfg: Value = match lines.next_line().await {
        Ok(Some(l)) => serde_json::from_str(&l).unwrap_or(Value::Null),
        _ => std::process::exit(2),
    };
    let host = cfg["host"].as_str().unwrap_or("").trim().to_string();
    let port = cfg["port"].as_u64().unwrap_or(25565);
    let user = cfg["username"].as_str().unwrap_or("").trim().to_string();
    let _ = PASSWORD.set(cfg["password"].as_str().unwrap_or("").to_string());
    if host.is_empty() || user.is_empty() {
        log("konfigurasi kosong (host/username)");
        std::process::exit(2);
    }

    // perintah dari aplikasi
    tokio::spawn(async move {
        while let Ok(Some(l)) = lines.next_line().await {
            let v: Value = match serde_json::from_str(&l) {
                Ok(v) => v,
                Err(_) => continue,
            };
            match v["t"].as_str() {
                Some("chat") => {
                    let text = v["v"].as_str().unwrap_or("").to_string();
                    let b = BOT.lock().unwrap().clone();
                    if let (Some(b), false) = (b, text.is_empty()) {
                        b.chat(text.as_str());
                    }
                }
                Some("quit") => std::process::exit(0),
                _ => {}
            }
        }
        std::process::exit(0); // stdin tertutup = aplikasi sudah tidak ada
    });

    status("connecting");
    // Port bawaan: kirim host saja supaya azalea ikut mencari SRV record.
    let addr = if port == 25565 { host.clone() } else { format!("{host}:{port}") };
    let account = Account::offline(&user);
    let r = ClientBuilder::new().set_handler(handle).start(account, addr).await;
    log(format!("azalea berhenti: {r:?}"));
    status("offline");
    tokio::time::sleep(Duration::from_millis(300)).await;
    std::process::exit(1);
}
