# BlockChat MF (versi Mineflayer) — Konteks Proyek untuk AI Lain

> **Cara pakai:** tempel seluruh file ini sebagai pesan pertama ke AI, lalu tambahkan masalah/fitur yang diminta (plus log atau screenshot).
> Kalau AI-nya bisa membaca file, upload juga `blockchat-mf-apk.zip`. Terakhir diperbarui: 20 Nov 2026.
> Proyek ini **menggantikan** versi lama berbasis MCProtocolLib (`blockchat.zip`, konteksnya di `BLOCKCHAT_CONTEXT.md`); yang aktif dipakai sekarang adalah versi **MF** ini.

---

## 0. Aturan untuk AI yang melanjutkan (baca dulu)

1. **Pengguna bukan programmer.** Bahasa: Indonesia santai, ringkas, tanpa jargon. Jangan bertele-tele; pengguna cepat kesal kalau jawaban panjang atau berputar-putar. Ucapkan kalau salah, lalu perbaiki.
2. **Pengguna bekerja dari HP** (Android 9). Build lewat **GitHub Actions dengan unggah ZIP** (lihat 9). Pengguna **tidak bisa** mengunggah folder atau file satu per satu dari HP, jadi perubahan kode aplikasi harus dikirim sebagai **satu zip proyek utuh**. Perubahan yang cukup berupa script JavaScript dikirim sebagai file tunggal untuk ditempel di editor aplikasi (tanpa build).
3. **Kamu hampir pasti tidak bisa menjalankan aplikasi atau server.** Uji logika di Node dengan objek tiruan (mock) sebelum mengirim, tapi jangan klaim sudah "teruji di server". Bedakan jelas: *terbukti jalan* (dari log pengguna), *diuji di simulasi*, dan *dugaan*.
4. **Jangan menumpuk banyak perubahan berisiko.** Satu masalah per putaran. Jangan menulis ulang dari nol.
5. **Verifikasi nama API** (mineflayer, prismarine-*, minecraft-protocol) sebelum menulis; versi 1.21.x banyak mengubah bentuk data. Kalau ragu, baca kode asli (pengguna bisa mengunggah file dari `node_modules`) atau cari di web.
6. **Jangan simpan/minta password.** Log aplikasi tidak boleh memuat password.
7. Jangan menawarkan hal yang tidak diminta. Kalau pengguna bilang "jangan build dulu", hanya diskusi/rancang.
8. Hormati batas server: pengguna mining otomatis (AFK) di server yang punya anti-cheat. Jangan membuat perilaku yang jelas-jelas tidak wajar (lihat 8, "Unfair Advantage").

## 1. Ringkasan proyek

Aplikasi Android (Kotlin + Jetpack Compose) yang membungkus **Node.js (nodejs-mobile) + mineflayer** di dalam APK. Fungsinya: klien Minecraft Java **tanpa grafis** untuk chat dan otomatisasi di server, hemat baterai, bisa jalan di latar belakang. Fitur yang bisa diperluas lewat **script JavaScript** yang ditulis/ditempel di aplikasi (tanpa build ulang): login otomatis, sambung ulang, tab chat berwarna, klik otomatis, dan seterusnya.

Alasan memakai mineflayer (bukan MCProtocolLib): proyek matang, ekosistem plugin, bisa ditambah script runtime. Aplikasi lama (MCProtocolLib) tetap ada sebagai arsip dan tidak dikembangkan lagi.

## 2. Pengguna & lingkungan

- HP: **Infinix X650C**, Android 9 (API 28), RAM kecil (aplikasi memakai ±100–200 MB). **Punya akses root** (pengguna bisa menimpa file di `/data/data/com.blockchat.mf/...`).
- Infinix/XOS **agresif membunuh aplikasi di latar belakang** (juga aplikasi lain, bukan hanya ini), biasanya 10 menit–1 jam setelah layar mati. Pengaturan yang relevan: Battery Lab → "Power Saving Management For Apps" (matikan), kunci aplikasi di recent apps, Autostart, Data Saver, Adaptive Battery. Aplikasi sudah punya foreground service + wake lock; ini masalah OEM, bukan RAM.
- Stack runtime: **Node v24.20.0 (arm64)**, **mineflayer 4.39.0** (package.json meminta `^4.37.1`), `minecraft-data` dengan 1.21.11, protokol Minecraft **1.21.11**.

## 3. Server target: `play.crispymc.net:25565` (cracked, Java 1.21.11)

- Di belakang proxy; pesan sistem berawalan **"YUI"** (plugin login/proxy). **Login `/login <pass>` wajib di setiap koneksi baru**; tanpa login ±5 menit → kick `TIMEOUT. Login session expired`. Server kadang auto-login lewat sesi (pesan `WELCOME BACK / Logged in as ...`); `/login` lagi dibalas `ALREADY LOGGED. Session is already active.` (aman).
- Pindah server tanpa command: klik kanan item **Server Selector** (hotbar **slot 5**, index 4) → menu `« Server Selector »` → klik **slot 21** = `survival-slimefun` → antre ("queued") → server mengirim `start_configuration` (re-konfigurasi) + **resource pack** yang **wajib dijawab klien**, kalau tidak server menunggu selamanya (sudah ditangani `guardTransfer`, lihat 5.2).
- Lobby juga mengirim `ResourcePackPush` + dialog di fase play.
- Satu username tidak boleh login ganda (dikick "already online").
- **Anti-cheat**: pernah kena `REDIRECT. Connection moved from survival-slimefun: YUI » Unfair Advantage` saat bot memakai penggalian lewat paket manual (kirim "selesai" berulang dan terlalu cepat, tanpa jeda antar blok, sisi blok asal). Pelajaran: tiru klien asli (satu "selesai" tepat waktu, jeda ±5 tick antar blok, ayunan wajar, blok terlihat).
- Chat server memakai: `translate: "%s"` + `with:[...]`, warna hex gradien per huruf, `underlined/bold` sebagai byte NBT (angka 1), teks polos `{"": " "}`, dan **glyph font kustom** resource pack (karakter private-use yang rusak jadi `U+FFFD` — tidak bisa ditampilkan).
- Pengguna mining **ancient debris** di server skyblock/slimefun dengan beliung **Efficiency 10 + Unbreaking 10**; item yang digali menumpuk dan harus diberi jeda supaya masuk hopper (karena itu skrip mining punya `durasi` gali + `jeda`).

## 4. Arsitektur

```
APK (com.blockchat.mf)
├─ Kotlin/Compose  : beranda, editor script, setelan/storage per script, WebView tab, layar sesi
├─ NodeService     : foreground service + wake lock, menjalankan Node
├─ NodeBridge      : memulai Node (nodejs-mobile) dengan nodejs-project/main.js
└─ nodejs-project/ (Node.js)
   ├─ main.js      : bot mineflayer + mesin script + server HTTP/WebSocket lokal 127.0.0.1:8765 (token acak, parameter ?k=)
   ├─ defaults/    : script bawaan yang disalin ke folder script saat pertama jalan (chat, autologin)
   └─ node_modules/: mineflayer dan dependensinya (dipasang saat build; TIDAK ada di zip)
```

- Kotlin ↔ Node lewat WebSocket lokal (`NodeClient.kt`): daftar script, status, tab, log, storage, setelan. Kotlin hanya menampilkan dan mengirim perintah; semua logika bot ada di Node.
- Layar: beranda punya tab bawah **Akun | Server | Script**. Akun = username (dipilih satu, bisa banyak); Server = nama/alamat/port/**versi (dropdown Auto + daftar dari minecraft-data)**. Sesi (tombol Kembali/Putus) punya tab **Script** lalu tab buatan script (mis. **Chat**, **Monitor**).
- Isi tab buatan script = halaman HTML yang disajikan Node dan ditampilkan di **WebView** (`WebTabs.kt`, objek `TabViews` menyimpan WebView per tab).
- Letak file di HP: script di `Android/data/com.blockchat.mf/files/scripts/<nama>/` (`script.js` + file lain seperti `chat.html`); proyek Node di `/data/data/com.blockchat.mf/files/nodejs-project/` (dibongkar dari aset APK dan **ditimpa saat aplikasi di-update**); crash Java di `filesDir/crash.txt` (lalu muncul di Log Node).
- Peta file zip (`blockchat-mf-apk.zip`): `nodejs-project/{main.js,package.json,defaults/chat/{script.js,chat.html},defaults/autologin/script.js}`, `app/src/main/java/com/blockchat/mf/{MainActivity,NodeBridge,NodeClient,NodeService,Store,ScriptsUi,ScriptSettingsUi,StorageUi,WebTabs}.kt`, `README.md`. Workflow GitHub di dalam zip (`.github/workflows/build.yml`) **tidak dipakai** pengguna (lihat 9).

## 5. Node (main.js) — hal penting

### 5.1 Objek di dalam script
Isi file script = badan fungsi **async**; tersedia `app`, `bot`, `script`, `require`; `await` boleh di paling atas. Panduan lengkap yang dilihat pengguna ada di tombol **Panduan** pada editor (konstanta `API_DOC` di `ScriptsUi.kt`).
- **`bot`** = pembungkus (Proxy) di atas bot mineflayer saat ini. `bot.on/once/off/removeListener/removeAllListeners` **dicatat per script**: dipasang ulang otomatis ke bot baru tiap sambung ulang, dan dilepas otomatis saat script dimatikan/dimuat ulang. `bot.once` yang sudah terpicu **tidak** dipasang ulang. Properti yang di-set (`bot.xxx = ...`) disimpan dan diterapkan lagi ke bot baru. Sebelum online `bot.entity/bot.chat` belum ada.
- **Tidak ikut dibersihkan otomatis:** `bot._client.on(...)` (klien mentah; tiap koneksi klien baru), `setInterval/setTimeout` biasa, plugin yang dimuat lewat `bot.loadPlugin` (sampai bot dibuat ulang). Pakai `app.onUnload(fn)` untuk membersihkan, dan `app.every/app.after` supaya terkelola.
- **`app`** (helper api 2): `app.log(...)`, `app.status` (`offline|connecting|online|reconnecting`), `app.online()`, `app.on('status', fn)`, `app.sleep(ms)` (reject kalau script dihentikan), `app.every(detik, fn)` (minimum 200 ms), `app.after(ms, fn)`, `app.onUnload(fn)`, `app.tab({id, title, file|html})` (tab HTML; `tab.send`, `tab.on('message'|'open')`, `tab.setTitle`, `tab.close`), **`app.config`** (host, port, username, version terakhir; tanpa password), **`app.userStopped`**, **`app.connect([opsi])`**, **`app.disconnect()`**, `app.api` (=2). Awalnya sempat ada APK yang belum punya `config/connect/userStopped` (error `app.connect is not a function`); script harus tahan terhadap itu (`typeof app.connect === 'function'`).
- **`script.settings`**: `create(nama, tipe, awal, pilihan)` (tipe `boolean|text|number|password|choice`; tidak menimpa nilai yang sudah ada), `get(nama, cadangan)`, `set`, `has`, `all`, `remove`. Tampil di halaman setelan script. **`script.storage`**: `get/set/has/delete/keys` (harus JSON), bisa diedit pengguna di tab Storage (Mode JSON).
- Nama script bawaan di kode: `chat`, `autologin`; di HP pengguna nama bisa beda (`auto-login`, `auto-mine`, `test`, `monitor`, dll). Log script berawalan `[nama]`.
- `SEED` di `main.js` (`{ chat: 4, autologin: 1 }`): kalau angkanya dinaikkan, file bawaan disalin ulang dan yang lama disimpan sebagai `.bak`. `chat` sudah dinaikkan ke 4 agar build berikutnya membawa perbaikan warna.

### 5.2 Mengendalikan bot (`startBot`, `guardTransfer`)
- `createBot({ host, port, username, version: <string>|false (Auto), viewDistance?...})`, auth offline.
- **`guardTransfer`** (penting untuk server ini): saat `start_configuration` (pindah server/Velocity) klien masuk fase `configuration`. Mineflayer sendiri belum menanganinya (PR resmi masih terbuka), jadi: (1) paket gameplay/gerak **dibuang** selama fase konfigurasi dan paket gerak ditahan sampai server baru mengirim `position`; (2) `add_resource_pack` di fase konfigurasi **dijawab** (diterima → terunduh → berhasil, kode 3, 4, 0); (3) resource pack di fase play dijawab lewat `bot.acceptResourcePack()`; (4) status jadi `connecting` lalu `online` lagi. Log: `SERVER MINTA PINDAH`, `resource pack (fase konfigurasi) dijawab`, `PINDAH SERVER SELESAI`.
- Daftar versi untuk dropdown dikirim Node lewat pesan `hello.versions` (dari `minecraft-data`); cadangan statis di `NodeClient.FALLBACK_VERSIONS`.
- **Jangan** membuat bot kedua lewat `require('mineflayer').createBot` di script: tidak dikenal aplikasi (tanpa status/chat/inventory di UI) dan username yang sama dikick server.

### 5.3 Catatan startup
`require('mineflayer')` dijalankan di awal `main.js` **sebelum** WebSocket mendengarkan, jadi Node baru "siap" setelah mineflayer termuat (beberapa detik di HP ini); sebelum itu tab Script menampilkan "Menunggu Node...". Ide perbaikan (belum dikerjakan, bukan masalah serius): buka WebSocket dulu lalu muat mineflayer belakangan; dan/atau Kotlin membaca folder script langsung.

## 6. Script yang ada

| Script | Fungsi | Catatan |
|---|---|---|
| `chat` (bawaan) | Tab Chat: pesan berwarna | `script.js` mengubah ChatMessage → string `§` (hex, bungee `§x§r..`, translate `%s`, byte 1/0, kunci `""`, keybind/selector/score; **membuang glyph private-use/U+FFFD**); `chat.html` merender `§`/hex. **Pengguna harus menempel `script.js` DAN `chat.html` terbaru** (versi lama menampilkan kode hex sebagai teks) |
| `autologin` v5 | Login otomatis, sambung ulang, pindah server | Lihat 6.1. Di HP bernama `auto-login`. Bukti: "auto login nya udah jalan" |
| `autoclick` | Auto mining (tahan klik kiri) | Lihat 6.2. Belum terbukti berhasil memecahkan blok |
| `hemat` | `bot.setSettings({viewDistance:'tiny'})` + detak ke Storage `_napas` tiap 30 dtk | Untuk diagnosa mati di latar belakang |
| `dig-test` / `dig-once` | Uji penggalian dengan banyak cara / satu `bot.dig` + catat paket | Alat diagnosa; hasil `dig-once` **belum dikirim** pengguna |
| `chat-debug` | Mencatat JSON mentah chat | Sudah selesai dipakai; boleh dihapus |
| `monitor` | Tab Monitor (ada di HP pengguna, bukan buatan sesi ini) | Isi tidak diketahui |

### 6.1 `autologin` v5 (ringkas)
- **Storage** per server, kunci `alamat:port`: `{ "akun":[{"username","password"}], "pindah":{"aktif","slotHotbar","slotMenu"} }`. Entri dibuat otomatis saat konek (password kosong). **Tanpa preset**; `pindah` default `aktif:false, slotHotbar:1, slotMenu:0`. Untuk crispymc pengguna mengisi sendiri (slot 5, menu 21).
- **Menangkap `/login` / `/register` manual**: membungkus `bot._client.write` (paket `chat_command`/`chat_message`), lalu menyimpan password ke Storage **setelah** server membalas sukses, atau 12 detik tanpa penolakan; kalau balasan "wrong/salah/gagal" tidak disimpan.
- Login terjadwal (`loginDelay`), atau saat server meminta; membaca pesan sukses/ditolak lewat `bot.on('messagestr')`. Pindah server: pilih slot hotbar, `activateItem`, tunggu `windowOpen`, klik slot menu, maksimal 3 percobaan.
- Sambung ulang: `app.on('status')` offline → jadwal `app.connect()` dengan jeda naik bertahap (maks 60 dtk); berhenti kalau `app.userStopped`, kena ban (`/ban|banned|blacklist/`), atau batas percobaan; kick "already online" menambah 20 detik.
- Setelan: `autoLogin, loginDelay, loginCommand, autoSimpan, autoRegister, registerCommand, autoReconnect, reconnectDelay, maxReconnect, autoTransfer, transferDelay`.

### 6.2 `autoclick` (versi sekarang: `bot.dig` + penyesuaian otomatis)
- Setelan: `aktif, blok (default ancient_debris), durasi (20 dtk gali), jeda (4 dtk istirahat), mulaiDelay (15), slot, tambahanMs (100)`.
- Mencari blok target (`blockAtCursor` atau `findBlock` ≤4,5 blok, terlihat lewat raycast), lalu `bot.dig(block, true, 'raycast')`; sesudahnya menunggu ±320 ms dan memeriksa apakah server **mengembalikan** blok. Kalau ya, menaikkan `bot.digTimeScale` ×1,2 (maks ×4) dan mencoba lagi. Status di Storage `_status`.
- Supervisor `app.every(1, ...)` mengikuti saklar `aktif` dan status online; mulai `mulaiDelay` detik setelah status online.

## 7. Patch mineflayer `digging.js` (dipasang pengguna lewat root)

Lokasi: `/data/data/com.blockchat.mf/files/nodejs-project/node_modules/mineflayer/lib/plugins/digging.js` (**tertimpa tiap update APK**; supaya permanen perlu langkah build atau patch di `main.js`). Versi terbaru ada di `digging.js` (hasil dari file milik pengguna `digging__1_.js`).

- **Bug 1 (akar `bot.dig` crash):** di Minecraft 1.21.5+ `item.enchants` berbentuk `{enchantments:[{id, level}]}` (objek; `id` = urutan registry enchantment), bukan array `[{name, lvl}]`. `bot.digTime` memanggil `enchantments.concat(...)` untuk helm → `TypeError: enchantments.concat is not a function`; tanpa helm, `block.digTime` salah baca. Perbaikan: `normalizeEnchants()` + `getEnchants()`; nama diambil dari paket `registry_data` (`minecraft:enchantment`) server, cadangan daftar bawaan 1.21.11 (id 8 = efficiency, 40 = unbreaking; cocok dengan beliung pengguna).
- **Bug 2:** `bot._nextSequence is not a function` (mineflayer terpasang tidak menyediakannya). Pengguna menambah penghitung lokal. Versi sekarang: `ownNextSequence` (naik terus), dipakai juga sebagai `bot._nextSequence` bila belum ada. **Awas:** pernah ada rekursi tak hingga (`Maximum call stack`) karena `nextSequence()` memanggil `bot._nextSequence` yang sama dengan dirinya; sudah diperbaiki. **Nomor urut `block_dig` tidak boleh menurun** (server memutus koneksi bila lebih kecil dari ack terakhir), jadi semua sumber paket harus berbagi satu penghitung.
- **Tambahan:** `bot.digTimeScale` (pengali) dan `bot.digTimeExtra` (ms) dibaca saat menghitung `waitTime`.
- Catatan perilaku file pengguna: setelah mengirim "selesai", `finishDigging` memanggil `updateBlockState(pos, 0)` **secara lokal**, sehingga `bot.dig` selalu dianggap sukses walau server menolak. Karena itu kegagalan hanya terlihat dari blok yang dikembalikan server.

## 8. Masalah terbuka (urut kepentingan)

1. **Mining: blok tidak pecah.** Pengguna melihat (dari akun lain) animasi retak hampir selesai, lalu blok kembali normal dan bot **tetap menggali** — pada tes **satu kali** `bot.dig(bot.blockAtCursor())`, bukan loop. Hipotesis yang belum terbukti: (a) "selesai" terlalu cepat dibanding hitungan server (mining custom/atribut/efek) → sudah ada penyesuaian otomatis di `autoclick`; (b) script lain (auto-mine/autoclick/test) masih menyala dan ikut memanggil `bot.dig`; (c) server me-reset/meregenerasi blok sendiri. **Langkah berikutnya:** matikan semua script lain, jalankan `dig-once.js` (mencatat paket START/SELESAI/ayunan, update blok dari server, dan ayunan setelah selesai), minta pengguna mengirim seluruh barisnya dan apa yang terlihat di game. Kalau perlu, tambahkan juga baris `efek bot`, `atribut bot` dari `dig-test.js`.
2. **Crash saat membuka tab Chat setelah aplikasi lama di latar belakang.** Dugaan kuat: sistem mematikan proses renderer WebView; tanpa `onRenderProcessGone` aplikasi ikut tertutup. Perbaikan sudah ada di zip (`WebTabs.kt`: buang & buat ulang WebView, lepas parent; `MainActivity.kt`: pencatat crash ke `filesDir/crash.txt` → Log Node "CRASH TERAKHIR") tetapi **belum dibangun/diuji pengguna**. Cara mengambil crash di HP berroot: `su -c "ls -t /data/system/dropbox | head"` lalu `cat` file `data_app_crash@*` (gunzip kalau `.gz`); atau `su -c "logcat -b crash -d | tail -80"`. Crash native: `data_app_native_crash@*`/tombstone.
3. **Aplikasi mati di latar belakang (XOS).** Lihat 2. Belum ada solusi dari sisi aplikasi; ide yang butuh build: WifiLock, watchdog, tombol ke pengecualian baterai, log yang bertahan saat proses mati.
4. **Warna chat.** Sudah beres setelah pengguna menempel `chat-script.js` + `chat.html` (bukan file lama). Glyph font kustom sengaja dibuang.
5. Kecil: Node baru siap setelah mineflayer termuat (5.3); patch `digging.js` hilang saat update APK (7).

## 9. Build & rilis

- Pengguna mengunggah **zip** ke GitHub dan workflow **milik pengguna sendiri** (berbeda dari `.github/workflows/build.yml` di dalam zip, yang masuk tanpa sengaja dan tidak dipakai) membongkarnya lalu membangun APK; `node_modules` dipasang saat build (zip tidak memuatnya). APK diambil dari Actions → Artifacts.
- **Tanpa build:** semua script JavaScript (ditempel di editor aplikasi atau file manager), `chat.html`, penimpaan `digging.js` lewat root. **Perlu build:** `main.js`, semua file Kotlin, perubahan `defaults/`.
- Jangan mengirim berkas satu per satu untuk perubahan yang butuh build; kirim zip utuh (`blockchat-mf-apk.zip`).

## 10. Cara melaporkan error

- **Script/Node:** buka Log (di tab Script, "Lihat log") dan kirim baris yang berawalan `[nama-script]` atau `UNHANDLED:`; sebut nama script dan langkahnya. Jangan sertakan password.
- **Aplikasi tertutup paksa:** setelah build berikutnya, buka Log Node → baris `CRASH TERAKHIR`. Sebelum itu, ambil lewat root (lihat 8.2).
- **Build gagal:** salin baris `e:` atau bagian `* What went wrong:` dari log GitHub Actions.
- Storage `_status` (autoclick) dan `_napas` (hemat) berisi ringkasan hidup untuk dilaporkan.

## 11. Pelajaran / jangan diulang

- Jangan mengirim paket `block_dig` "selesai" berulang atau lebih cepat dari waktu gali wajar; jangan menggali blok yang tidak terlihat; beri jeda ±5 tick antar blok → pernah kena "Unfair Advantage".
- Jangan membuat bot kedua di script; gunakan `app.connect()`.
- Jangan memakai `bot._client.on` tanpa `app.onUnload` pembersih.
- Jangan mengandalkan `bot.dig` tanpa patch enchant di 1.21.x.
- Jangan menjelaskan kegagalan dengan asumsi "ada loop" tanpa bukti; tanyakan atau ukur dulu (`dig-once.js`).
- Kesalahan pernah terjadi: rekursi `nextSequence`; skrip debug memakai salinan konverter lama; menyarankan `bidik: blok-terdekat` yang bisa menggali hopper/peti.
- Selalu cek apakah APK pengguna cukup baru untuk fitur yang dipakai script (`app.api`, `typeof app.connect`).

## 12. Ide kerja berikutnya (belum diminta/dikerjakan)

1. Diagnosa mining (8.1), lalu jika terbukti: tiru persis cara klien asli untuk server ini.
2. Bangun ulang dengan perbaikan WebView/crash (8.2) dan patch `digging.js` permanen (salin saat build atau terapkan di `main.js`).
3. Pelan-pelan: muat mineflayer belakangan (5.3), Kotlin membaca folder script langsung, WifiLock/watchdog (8.3).
4. Auto fish untuk server ini (action bar `right click now`, judul jenis ikan, minigame sneak) sebagai script setelah mining beres.
