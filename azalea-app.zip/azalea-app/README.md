# Azalea

Klien Minecraft tanpa grafis untuk AFK di HP. Kotlin/Compose (UI) + inti Azalea (Rust).

- `rust/` : program `azalea-core`, satu koneksi = satu proses. Dibangun jadi `libazalea.so`.
- `Core.kt` : menjalankan proses itu, bicara lewat pipa stdin/stdout (baris JSON), sambung ulang otomatis (jeda 5 -> 60 dtk, berhenti bila kena ban).
- `BotService.kt` : foreground service + wake lock selama ada koneksi.
- Akun hanya username. Fitur dibuat sebagai **modul**: satu file Rust di `rust/src/modules/` (chat, playerlist, monitor, relogin, autoclick, autofish). Menambah modul = file baru + 1 baris `pub mod`, 1 baris di `all()`, 1 baris di `dispatch()` (modules/mod.rs). Aplikasi membaca skema setelan lewat `libazalea.so modules` dan menggambar layar Modul otomatis (tipe: boolean/text/number/password).
- Modul `relogin` = auto login (password per server+akun di Storage, ditangkap dari /login manual) + register + setelan sambung ulang. Login dijalankan di Rust (`relogin.rs`); sambung ulang dijalankan Kotlin (`Core.kt`) karena saat bot keluar prosesnya sudah tidak ada.
- Storage per modul (`storage.rs` / `ModStorage.kt`): JSON bebas, disimpan di HP, sinkron dua arah lewat pipa (`{"t":"storage","m":..,"v":{..}}`), bisa diedit di tab Storage tiap modul.
- Chat berwarna: Rust kirim `to_ansi()`, Kotlin merender (`Ansi.kt`). Sesi punya tab Chat | Pemain | Monitor | Log.
- Modul `monitor` (`monitor.rs` + `main.rs`): inventory/menu server tampil di tab Monitor lengkap dengan status HP/lapar/XP/koordinat, efek aktif, bossbar, action bar/title/subtitle, detail & lore item berwarna, klik kiri/kanan/tengah/shift/drop/offhand, ikon item gaya EMI (`blocksitems.com` + `assets.mcasset.cloud`), pewarnaan potion, dan 3D `player_head` langsung dari `textures.minecraft.net`.
- Pindah server lewat item menu ada di `relogin.rs`: per server di Storage, blok `"pindah": {"aktif": true, "slotHotbar": 1, "slotMenu": 0}` (hotbar 1-9, slot menu mulai 0 kiri atas). Berjalan setelah login berhasil.
- Paket: `com.azalea.app`. Modul lengkap dengan UI Dark Slate + Emerald, PlayerHead pada akun & notifikasi PM, serta info versi protokol inti.

## Tab Monitor (tampilan ala script Monitor lama)
`app/src/main/assets/inventory.html` = halaman Monitor lama yang dipangkas (panel inventory ala Minecraft, ikon dari internet, glint enchant, bar durability, detail + tombol aksi). Dimuat di WebView (`InventoryUi.kt`); jembatan JS `Android.send/copy`. Inti Rust (`monitor.rs`) mengirim `{"t":"inv",...}` dan `{"t":"detail",...}` yang diteruskan Kotlin apa adanya. Setelan modul Monitor: ikon, sumber ikon, sumber skin, ketuk 2x.
Semua fitur monitor (status, efek, bossbar, feed, 3D player_head gaya EMI, dan tombol middle/drop/offhand) sudah diporting ke `monitor.rs`, `InventoryUi.kt`, dan `inventory.html`.
