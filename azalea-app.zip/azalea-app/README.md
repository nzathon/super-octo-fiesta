# Azalea

Klien Minecraft tanpa grafis untuk AFK di HP. Kotlin/Compose (UI) + inti Azalea (Rust).

- `rust/` : program `azalea-core`, satu koneksi = satu proses. Dibangun jadi `libazalea.so`.
- `Core.kt` : menjalankan proses itu, bicara lewat pipa stdin/stdout (baris JSON), sambung ulang otomatis (jeda 5 -> 60 dtk, berhenti bila kena ban).
- `BotService.kt` : foreground service + wake lock selama ada koneksi.
- Akun hanya username. Fitur dibuat sebagai **modul**: satu file Rust di `rust/src/modules/` (chat, playerlist, relogin). Menambah modul = file baru + 1 baris `pub mod`, 1 baris di `all()`, 1 baris di `dispatch()` (modules/mod.rs). Aplikasi membaca skema setelan lewat `libazalea.so modules` dan menggambar layar Modul otomatis (tipe: boolean/text/number/password).
- Modul `relogin` = auto login (password per server+akun di Storage, ditangkap dari /login manual) + register + setelan sambung ulang. Login dijalankan di Rust (`relogin.rs`); sambung ulang dijalankan Kotlin (`Core.kt`) karena saat bot keluar prosesnya sudah tidak ada.
- Storage per modul (`storage.rs` / `ModStorage.kt`): JSON bebas, disimpan di HP, sinkron dua arah lewat pipa (`{"t":"storage","m":..,"v":{..}}`), bisa diedit di tab Storage tiap modul.
- Chat berwarna: Rust kirim `to_ansi()`, Kotlin merender (`Ansi.kt`). Sesi punya tab Chat | Pemain | Log.
- Belum diport dari script lama (butuh API inventory/menu azalea): `monitor` (inventory, HP/lapar, efek, bossbar, title/actionbar) dan pindah server lewat item menu. Script lama referensi ada di `arsip-mineflayer/` dan zip unggahan pengguna.
- `arsip-mineflayer/` : kode Node lama, tidak ikut build.
- Paket: `com.azalea.app`. Belum ada: auto mining dst, pindah server lewat menu, resource pack lobby.
