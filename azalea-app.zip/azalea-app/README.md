# Azalea

Klien Minecraft tanpa grafis untuk AFK di HP. Kotlin/Compose (UI) + inti Azalea (Rust).

- `rust/` : program `azalea-core`, satu koneksi = satu proses. Dibangun jadi `libazalea.so`.
- `Core.kt` : menjalankan proses itu, bicara lewat pipa stdin/stdout (baris JSON), sambung ulang otomatis (jeda 5 -> 60 dtk, berhenti bila kena ban).
- `BotService.kt` : foreground service + wake lock selama ada koneksi.
- Akun hanya username. Fitur dibuat sebagai **modul**: satu file Rust di `rust/src/modules/` (chat, relogin). Menambah modul = file baru + 1 baris `pub mod`, 1 baris di `all()`, 1 baris di `dispatch()` (modules/mod.rs). Aplikasi membaca skema setelan lewat `libazalea.so modules` dan menggambar layar Modul otomatis (tipe: boolean/text/number/password).
- Modul `relogin` = sambung ulang + login otomatis dalam satu kartu. Login dijalankan di Rust (`relogin.rs`); sambung ulang dijalankan Kotlin (`Core.kt`, membaca setelan `relogin`) karena saat bot keluar prosesnya sudah tidak ada. Sambung ulang selalu terjadi bila bot keluar, kecuali pengguna menekan Putus.
- `arsip-mineflayer/` : kode Node lama, tidak ikut build.
- Paket: `com.azalea.app`. Belum ada: auto mining dst, pindah server lewat menu, resource pack lobby.
