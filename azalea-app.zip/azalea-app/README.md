# Azalea

Klien Minecraft tanpa grafis untuk AFK di HP. Kotlin/Compose (UI) + inti Azalea (Rust).

- `rust/` : program `azalea-core`, satu koneksi = satu proses. Dibangun jadi `libazalea.so`.
- `Core.kt` : menjalankan proses itu, bicara lewat pipa stdin/stdout (baris JSON), sambung ulang otomatis (jeda 5 -> 60 dtk, berhenti bila kena ban).
- `BotService.kt` : foreground service + wake lock selama ada koneksi.
- Akun hanya username. Login otomatis nanti dibuat sebagai modul.
- `arsip-mineflayer/` : kode Node lama, tidak ikut build.
- Paket: `com.azalea.app`. Belum ada: modul (auto mining dst), pindah server lewat menu, resource pack lobby.
