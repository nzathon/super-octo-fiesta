# Azalea

Klien Minecraft tanpa grafis untuk AFK di HP. Kotlin/Compose (UI) + inti Azalea (Rust).

- `rust/` : program `azalea-core`, satu koneksi = satu proses. Dibangun jadi `libazalea.so`.
- `Core.kt` : menjalankan proses itu, bicara lewat pipa stdin/stdout (baris JSON), sambung ulang otomatis (jeda 5 -> 60 dtk, berhenti bila kena ban).
- `BotService.kt` : foreground service + wake lock selama ada koneksi.
- Akun hanya username. Fitur dibuat sebagai **modul**: satu file Rust di `rust/src/modules/` (chat, playerlist, monitor, relogin). Menambah modul = file baru + 1 baris `pub mod`, 1 baris di `all()`, 1 baris di `dispatch()` (modules/mod.rs). Aplikasi membaca skema setelan lewat `libazalea.so modules` dan menggambar layar Modul otomatis (tipe: boolean/text/number/password).
- Modul `relogin` = auto login (password per server+akun di Storage, ditangkap dari /login manual) + register + setelan sambung ulang. Login dijalankan di Rust (`relogin.rs`); sambung ulang dijalankan Kotlin (`Core.kt`) karena saat bot keluar prosesnya sudah tidak ada.
- Storage per modul (`storage.rs` / `ModStorage.kt`): JSON bebas, disimpan di HP, sinkron dua arah lewat pipa (`{"t":"storage","m":..,"v":{..}}`), bisa diedit di tab Storage tiap modul.
- Chat berwarna: Rust kirim `to_ansi()`, Kotlin merender (`Ansi.kt`). Sesi punya tab Chat | Pemain | Log.
- Modul `monitor` (`monitor.rs`): inventory/menu server tampil di tab Inventory, bisa klik kiri/kanan/shift, pilih & pakai item hotbar, tutup menu, dan lihat detail mentah item. Belum ada: HP/lapar, efek, bossbar, title/actionbar, ikon item.
- Pindah server lewat item menu ada di `relogin.rs`: per server di Storage, blok `"pindah": {"aktif": true, "slotHotbar": 1, "slotMenu": 0}` (hotbar 1-9, slot menu mulai 0 kiri atas). Berjalan setelah login berhasil.
- Paket: `com.azalea.app`. Belum ada: auto mining dst, pindah server lewat menu, resource pack lobby.
