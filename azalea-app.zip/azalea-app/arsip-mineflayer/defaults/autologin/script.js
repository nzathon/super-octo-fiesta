// Script "autologin" (v5): login otomatis, sambung ulang otomatis, dan pindah server lewat item menu.
// Butuh APK dengan helper app versi 2 (app.config, app.connect, app.userStopped). Cek di Log baris "api=2".
//
// CARA PAKAI: masuk server, lalu login MANUAL sekali (mis. /login passwordmu). Script menangkap perintah itu dan
// menyimpan passwordnya di tab "Storage" setelah server membalas sukses; mulai koneksi berikutnya login dan sambung
// ulang berjalan otomatis. Perintah /register juga ditangkap.
//
// DATA ada di tab "Storage" script ini, satu entri per server (kunci "alamat:port"), dibuat otomatis begitu konek:
//   "alamat:port": {
//     "akun":   [ { "username": "namamu", "password": "..." } ],
//     "pindah": { "aktif": false, "slotHotbar": 1, "slotMenu": 0 }
//   }
// - akun: yang dipakai = yang username-nya sama dengan akun terpilih di beranda.
// - pindah: setelah login, pegang item hotbar nomor slotHotbar (1-9), klik kanan, lalu klik slot nomor slotMenu
//   (mulai dari 0, kiri atas) di menu yang terbuka. Ubah aktif jadi true dan isi nomor slotnya kalau mau dipakai.
// SETELAN umum (tombol dan angka) ada di tab "Setelan".

const S = script.settings
S.create('autoLogin', 'boolean', true)
S.create('loginDelay', 'number', 2)                           // detik setelah masuk dunia sebelum login dikirim
S.create('loginCommand', 'text', '/login {password}')        // {password} dan {username} diganti otomatis
S.create('autoSimpan', 'boolean', true)                       // simpan password dari /login (atau /register) manual ke Storage
S.create('autoRegister', 'boolean', false)                    // kirim register kalau server memintanya
S.create('registerCommand', 'text', '/register {password} {password}')
S.create('autoReconnect', 'boolean', true)
S.create('reconnectDelay', 'number', 5)                       // detik; naik bertahap tiap gagal (maksimal 60)
S.create('maxReconnect', 'number', 0)                         // 0 = tanpa batas
S.create('autoTransfer', 'boolean', true)                     // pindah server lewat item menu
S.create('transferDelay', 'number', 3)                        // detik setelah login sebelum item dipakai

const RX_OK = /(logged in as|welcome back|berhasil (login|masuk)|successfully (logged|authenticated)|login (success|berhasil))/i
const RX_ALREADY = /(already logged|session is already active|sudah login)/i
const RX_LOGIN = /(\/login\b|please (log ?in)|silakan (login|masuk))/i
const RX_REGISTER = /(\/register\b|please register|silakan (daftar|register))/i
const RX_FAIL = /(wrong|incorrect|invalid|salah|gagal|failed|not registered|belum terdaftar|tidak terdaftar)/i
const RX_BAN = /\b(ban|banned|blacklist)/i
const RX_DUP = /(already (online|connected|logged in)|same name|sudah (online|terhubung))/i

const HAS_API = typeof app.connect === 'function' && typeof app.config !== 'undefined'

let sess = 0                  // naik tiap koneksi berakhir; pekerjaan lama berhenti kalau nomornya berubah
let st = fresh()
let attempts = 0
let reconnectTimer = null
let banned = false
let extraWait = 0

function fresh () {
  return { started: false, loginSent: false, registerSent: false, loggedIn: false, transferred: false, transferring: false }
}

// ---------- server & akun yang sedang dipakai ----------

function cfgNow () {
  try { if (app.config && app.config.host) return app.config } catch (_) {}
  try {   // cadangan untuk APK lama: baca dari koneksi bot
    const o = bot._client && bot._client.options
    if (o && o.host) return { host: String(o.host), port: Number(o.port) || 25565, username: String(o.username || bot.username || '') }
  } catch (_) {}
  return null
}

function findEntry () {
  const c = cfgNow()
  if (!c) return null
  for (const k of [`${c.host}:${c.port}`, c.host]) {
    const e = script.storage.get(k)
    if (e && typeof e === 'object') return { key: k, entry: e }
  }
  return null
}

function accountFor (entry) {
  const c = cfgNow()
  if (!c || !entry || !Array.isArray(entry.akun)) return null
  const u = String(c.username).toLowerCase()
  return entry.akun.find(a => a && String(a.username).toLowerCase() === u) || null
}

function ensureEntry () {
  const c = cfgNow()
  if (!c) return null
  let f = findEntry()
  if (!f) {
    const key = `${c.host}:${c.port}`
    const entry = {
      akun: [{ username: c.username, password: '' }],
      pindah: { aktif: false, slotHotbar: 1, slotMenu: 0 }
    }
    script.storage.set(key, entry)
    app.log(`entri baru dibuat di Storage untuk ${key}. Login manual sekali, passwordnya akan tersimpan otomatis.`)
    return { key, entry }
  }
  if (!Array.isArray(f.entry.akun)) f.entry.akun = []
  if (!accountFor(f.entry)) {
    f.entry.akun.push({ username: c.username, password: '' })
    script.storage.set(f.key, f.entry)
    app.log(`username ${c.username} ditambahkan ke Storage ${f.key}. Login manual sekali, passwordnya akan tersimpan otomatis.`)
  }
  return f
}

function prepare () {
  try { ensureEntry() } catch (e) { app.log('gagal menyiapkan Storage: ' + e.message) }
}

const fill = (tpl, acc) => String(tpl).replace(/\{password\}/g, acc.password).replace(/\{username\}/g, acc.username)

// ---------- login ----------

function sendLogin (why) {
  if (st.loginSent || !S.get('autoLogin', true)) return
  const f = ensureEntry()
  const acc = f && accountFor(f.entry)
  if (!acc || !acc.password) { app.log('password belum diisi di Storage, login tidak dikirim'); return }
  st.loginSent = true
  bot.chat(fill(S.get('loginCommand', '/login {password}'), acc))
  app.log(`login dikirim (${why})`)
}

function sendRegister () {
  if (st.registerSent || !S.get('autoRegister', false)) return
  const f = ensureEntry()
  const acc = f && accountFor(f.entry)
  if (!acc || !acc.password) return
  st.registerSent = true
  bot.chat(fill(S.get('registerCommand', '/register {password} {password}'), acc))
  app.log('register dikirim')
}

// ---------- pindah server ----------

function waitWindow (ms) {
  return new Promise((resolve) => {
    let done = false
    const h = (w) => { if (done) return; done = true; try { bot.off('windowOpen', h) } catch (_) {} resolve(w) }
    bot.on('windowOpen', h)
    setTimeout(() => { if (done) return; done = true; try { bot.off('windowOpen', h) } catch (_) {} resolve(null) }, ms)
  })
}
const withTimeout = (p, ms) => Promise.race([p, new Promise(r => setTimeout(() => r('timeout'), ms))])

async function transfer (id) {
  if (!S.get('autoTransfer', true)) return
  const f = findEntry()
  const p = f && f.entry.pindah
  if (!p || !p.aktif) return
  if (st.transferred || st.transferring) return
  st.transferring = true
  await app.sleep(Math.max(0, Number(S.get('transferDelay', 3))) * 1000)
  const idx = Math.max(1, Math.min(9, Number(p.slotHotbar) || 5)) - 1
  const slot = Number(p.slotMenu)
  for (let attempt = 1; attempt <= 3; attempt++) {
    if (id !== sess) return
    const item = bot.inventory && bot.inventory.slots[36 + idx]
    if (!item) { app.log(`slot hotbar ${idx + 1} masih kosong (percobaan ${attempt}), menunggu...`); await app.sleep(2000); continue }
    bot.setQuickBarSlot(idx)
    await app.sleep(300)
    const opened = waitWindow(6000)
    bot.activateItem()
    const w = await opened
    if (id !== sess) return
    if (!w) { app.log(`menu tidak terbuka (percobaan ${attempt})`); await app.sleep(2000); continue }
    let title = ''
    try { title = typeof w.title === 'string' ? w.title : JSON.stringify(w.title) } catch (_) {}
    app.log(`menu terbuka: ${title}`)
    for (let i = 0; i < 20 && !w.slots[slot]; i++) await app.sleep(250)   // tunggu isi menu terkirim
    if (!w.slots[slot]) {
      app.log(`slot ${slot} kosong di menu itu (percobaan ${attempt})`)
      try { bot.closeWindow(w) } catch (_) {}
      await app.sleep(1500)
      continue
    }
    const r = await withTimeout(bot.clickWindow(slot, 0, 0).catch(e => 'error: ' + e.message), 5000)
    app.log(`klik slot ${slot} (${w.slots[slot].displayName || w.slots[slot].name})` + (typeof r === 'string' ? ` -> ${r}` : ''))
    st.transferred = true
    st.transferring = false
    return
  }
  st.transferring = false
  app.log('pindah server gagal setelah 3 percobaan (cek nomor slot di Storage)')
}

async function begin (id) {
  const f = ensureEntry()
  if (!f) return
  await app.sleep(Math.max(0, Number(S.get('loginDelay', 2))) * 1000)
  if (id !== sess) return
  if (S.get('autoLogin', true)) {
    const acc = accountFor(f.entry)
    if (!acc || !acc.password) return app.log('belum ada password tersimpan: login manual sekali (/login ...), nanti disimpan otomatis')
    sendLogin('terjadwal')
    const t0 = Date.now()
    while (!st.loggedIn && Date.now() - t0 < 8000) {      // tunggu hasil login, lanjut apa pun hasilnya
      await app.sleep(250)
      if (id !== sess) return
    }
  }
  await transfer(id)
}


// ---------- tangkap /login manual -> simpan password ----------

const LOGIN_CMDS = new Set(['login', 'l', 'log', 'register', 'reg'])
let pending = null            // { pw, kind } menunggu konfirmasi server
let pendingTimer = null
let sniffActive = true
if (typeof app.onUnload === 'function') app.onUnload(() => { sniffActive = false })

function savePassword (pw, why) {
  const f = ensureEntry()
  const c = cfgNow()
  if (!f || !c) return
  let acc = accountFor(f.entry)
  if (!acc) { acc = { username: c.username, password: '' }; f.entry.akun.push(acc) }
  if (acc.password === pw) return
  acc.password = pw
  script.storage.set(f.key, f.entry)
  app.log(`password untuk ${c.username} disimpan di Storage (${why})`)
}

function settle (why) {
  if (!pending) return
  const p = pending
  pending = null
  if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null }
  if (why === 'gagal') return app.log('server menolak login itu, password tidak disimpan')
  savePassword(p.pw, why)
}

function sniff (name, params) {
  if (!sniffActive || !params || !S.get('autoSimpan', true)) return
  let raw = null
  if (name === 'chat_command' || name === 'chat_command_signed') raw = params.command
  else if ((name === 'chat' || name === 'chat_message') && typeof params.message === 'string' && params.message.startsWith('/')) raw = params.message
  if (typeof raw !== 'string') return
  const parts = raw.replace(/^\//, '').trim().split(/\s+/)
  const cmd = (parts[0] || '').toLowerCase()
  if (!LOGIN_CMDS.has(cmd) || !parts[1]) return
  pending = { pw: parts[1], kind: cmd }
  app.log(`perintah /${cmd} terdeteksi; password disimpan setelah server membalas sukses`)
  if (pendingTimer) clearTimeout(pendingTimer)
  pendingTimer = app.after(12000, () => settle('tanpa balasan gagal'))   // balasan sukses tidak dikenali: simpan kalau tidak ada penolakan
}

const hooked = new WeakSet()
function hookClient () {
  let c = null
  try { c = bot._client } catch (_) {}
  if (!c || hooked.has(c) || typeof c.write !== 'function') return
  hooked.add(c)
  const prev = c.write
  c.write = function (name, params) {
    try { sniff(name, params) } catch (_) {}
    return prev.call(c, name, params)
  }
}
bot.on('login', hookClient)     // klien baru dibuat tiap koneksi
bot.on('spawn', hookClient)     // cadangan

// ---------- event bot ----------

bot.on('spawn', () => {
  if (st.started) return
  st.started = true
  attempts = 0
  app.log('masuk dunia, mulai login/pindah server')
  prepare()
  begin(sess)
})

bot.on('messagestr', (text) => {
  if (!st.started) return
  const t = String(text)
  if (pending) {
    if (RX_FAIL.test(t)) settle('gagal')
    else if (RX_OK.test(t)) settle('login berhasil')
  }
  if (st.loginSent && !st.loggedIn && RX_FAIL.test(t)) app.log('server menolak login dari password tersimpan; periksa password di Storage atau login manual lagi')
  if (RX_ALREADY.test(t) || RX_OK.test(t)) {
    st.loggedIn = true    // sudah login (sesi lama atau login kita berhasil): lanjut pindah server
    transfer(sess).catch(e => app.log('pindah server error: ' + e.message))
    return
  }
  if (RX_LOGIN.test(t)) sendLogin('diminta server')
  else if (RX_REGISTER.test(t)) sendRegister()
})

bot.on('kicked', (reason) => {
  let t = ''
  try { t = typeof reason === 'string' ? reason : JSON.stringify(reason) } catch (_) {}
  if (RX_BAN.test(t)) { banned = true; app.log('kena ban, tidak sambung ulang otomatis') }
  else if (RX_DUP.test(t)) extraWait = 20
})

// ---------- sambung ulang ----------

function scheduleReconnect () {
  if (reconnectTimer || !S.get('autoReconnect', true)) return
  if (!HAS_API) return app.log('APK belum punya app.connect: sambung ulang tidak aktif (update APK)')
  if (app.userStopped) return app.log('diputus oleh pengguna, tidak sambung ulang')
  if (banned) return
  const max = Number(S.get('maxReconnect', 0))
  if (max > 0 && attempts >= max) return app.log('batas sambung ulang tercapai')
  attempts++
  const base = Math.max(1, Number(S.get('reconnectDelay', 5)))
  const wait = Math.min(60, base * attempts) + extraWait
  extraWait = 0
  app.log(`sambung ulang dalam ${wait} detik (percobaan ${attempts})`)
  reconnectTimer = app.after(wait * 1000, () => {
    reconnectTimer = null
    if (app.userStopped || app.status !== 'offline') return
    try { app.connect() } catch (e) { app.log('gagal sambung ulang: ' + e.message) }
  })
}

app.on('status', (s) => {
  if (s === 'offline') {
    sess++
    st = fresh()
    scheduleReconnect()
  } else if (s === 'online') {
    attempts = 0
    banned = false
  } else if (s === 'connecting') {
    if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null }
    prepare()   // entri Storage dibuat begitu mulai konek, jadi password bisa diisi lebih awal
  }
})

// ---------- awal ----------

{
  const c = cfgNow()
  app.log(`autologin v5 dimuat. api=${app.api}, status=${app.status}` + (c ? `, server=${c.host}:${c.port}, akun=${c.username}` : ', server belum diketahui (konek dari beranda)'))
}
prepare()
if (app.online()) hookClient()
// Script dimuat/dinyalakan saat sudah di dalam server: anggap sudah login dan pindah; berlaku mulai koneksi berikutnya.
if (app.online()) {
  st.started = true; st.loggedIn = true; st.transferred = true
  app.log('sudah di dalam server; login/pindah server dilakukan pada koneksi berikutnya')
}
