// Script "chat": tab Chat yang menampilkan chat server dan kotak kirim pesan.
// Tampilannya ada di file chat.html (satu folder dengan script ini).
// Kode mineflayer ditulis biasa (bot.on, bot.chat). Objek: app, bot, script, require.
// Simpan script.js = script dimuat ulang. Simpan chat.html = hanya tab yang dimuat ulang.

const MAX = 300
const lines = []   // riwayat, supaya tab yang dibuka ulang tidak kosong

const tab = app.tab({ id: 'chat', title: 'Chat', file: 'chat.html' })

function push (item) {
  item.t = Date.now()
  lines.push(item)
  if (lines.length > MAX) lines.shift()
  tab.send(Object.assign({ type: 'line' }, item))
}

// ---- komponen chat -> teks berkode warna (§) termasuk warna hex (§#rrggbb) ----
// toMotd() bawaan prismarine-chat hanya mengenal 16 warna bernama, jadi warna hex (gradien, nama berwarna, dll) hilang.
// Fungsi di bawah menelusuri komponen JSON sendiri dan mempertahankan hex.
const NAMED = { black: '0', dark_blue: '1', dark_green: '2', dark_aqua: '3', dark_red: '4', dark_purple: '5', gold: '6', gray: '7',
  grey: '7', dark_gray: '8', dark_grey: '8', blue: '9', green: 'a', aqua: 'b', red: 'c', light_purple: 'd', yellow: 'e', white: 'f' }
const FORMATS = [['bold', 'l'], ['italic', 'o'], ['underlined', 'n'], ['strikethrough', 'm'], ['obfuscated', 'k']]

function colorCode (c) {
  if (!c) return ''
  c = String(c).toLowerCase().replace(/^minecraft:/, '')
  if (NAMED[c]) return '\u00a7' + NAMED[c]
  if (/^#[0-9a-f]{6}$/.test(c)) return '\u00a7' + c
  if (/^#[0-9a-f]{3}$/.test(c)) return '\u00a7#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3]
  return ''
}

function plainOf (node) {
  try { if (typeof node.toString === 'function' && node.toString !== Object.prototype.toString) return String(node.toString()) } catch (_) {}
  return ''
}

function toMotdHex (msg) {
  const parts = []
  const emit = (text, st) => {
    // glyph font kustom resource pack (private-use, atau rusak jadi U+FFFD) tidak bisa digambar di sini: dibuang
    text = String(text || '').replace(/[\uE000-\uF8FF\uFFFD]+/g, '')
    if (!text) return
    let pre = '\u00a7r' + colorCode(st.color)       // warna dulu: kode warna mereset format
    for (const [k, code] of FORMATS) if (st[k]) pre += '\u00a7' + code
    parts.push(pre + text)
  }
  const inherit = (node, st) => {
    const n = Object.assign({}, st)
    if (typeof node.color === 'string' && node.color) n.color = node.color
    for (const [k] of FORMATS) {
      const v = node[k]
      if (v === true || v === 1 || v === '1' || v === 'true') n[k] = true      // NBT mengirim byte 1/0
      else if (v === false || v === 0 || v === '0' || v === 'false') n[k] = false
    }
    return n
  }
  let language = {}
  try { language = (bot.registry && bot.registry.language) || {} } catch (_) {}

  const walkTranslate = (node, st) => {
    // Seperti klien asli: templat = terjemahan, kalau tidak ada pakai "fallback", kalau tidak ada pakai kuncinya sendiri.
    // Plugin sering memakai translate:"%s" supaya seluruh pesan berwarna ada di dalam "with".
    const looked = language[node.translate]
    const tpl = typeof looked === 'string' ? looked : (typeof node.fallback === 'string' ? node.fallback : String(node.translate))
    const args = node.with || node.args || []
    const re = /%(?:(\d+)\$)?s|%%/g
    let idx = 0
    let last = 0
    let m
    while ((m = re.exec(tpl))) {
      emit(tpl.slice(last, m.index), st)
      if (m[0] === '%%') emit('%', st)
      else walk(args[m[1] ? Number(m[1]) - 1 : idx++], st)
      last = re.lastIndex
    }
    emit(tpl.slice(last), st)
  }
  const walk = (node, st) => {
    if (node === null || node === undefined) return
    if (typeof node === 'string' || typeof node === 'number' || typeof node === 'boolean') return emit(String(node), st)
    if (Array.isArray(node)) { node.forEach(n => walk(n, st)); return }
    const cur = inherit(node, st)
    if (node.translate) walkTranslate(node, cur)
    else if (typeof node.text === 'string') emit(node.text, cur)
    else if (typeof node[''] === 'string') emit(node[''], cur)                       // komponen spasi {"": " "} dari NBT
    else if (typeof node.keybind === 'string') emit(node.keybind, cur)
    else if (typeof node.selector === 'string') emit(node.selector, cur)
    else if (node.score && typeof node.score === 'object') emit(String(node.score.value !== undefined ? node.score.value : (node.score.name || '')), cur)
    if (Array.isArray(node.extra)) node.extra.forEach(e => walk(e, cur))
  }
  walk(msg, {})
  return parts.join('')
}

// mineflayer biasa: 'message' = semua chat & pesan sistem
bot.on('message', (jsonMsg, position) => {
  if (position === 'game_info') return   // action bar dilewati
  let text = ''
  let motd = ''
  try { text = jsonMsg.toString() } catch (_) {}
  try { motd = toMotdHex(jsonMsg) } catch (e) { app.log('konversi warna gagal: ' + e.message) }
  const hasColor = (t) => /\u00a7(?!r)[0-9a-fk-o#x]/i.test(t || '')
  let lib = ''
  try { lib = jsonMsg.toMotd() } catch (_) {}
  if (!motd || !motd.replace(/\u00a7(r|[0-9a-fk-o]|#[0-9a-f]{6})/gi, '')) motd = lib || text
  else if (!hasColor(motd) && hasColor(lib)) motd = lib      // konversi kita kehilangan warna, bawaan mineflayer masih punya
  push({ motd: motd || text })
})
bot.on('kicked', (reason) => push({ sys: 'Dikeluarkan: ' + (typeof reason === 'string' ? reason : JSON.stringify(reason)) }))
app.on('status', (s) => push({ sys: 'Status: ' + s }))

tab.on('open', () => tab.send({ type: 'history', lines }))
tab.on('message', (m) => {
  if (m.type === 'send' && m.text && app.online()) bot.chat(m.text)
})
