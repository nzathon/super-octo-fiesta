'use strict'
// BlockChat-MF (Node): bot mineflayer + mesin script + server web lokal untuk tab HTML.
// argv: [2]=folder script, [3]=folder data, [4]=token
const http = require('http')
const fs = require('fs')
const path = require('path')
const dns = require('dns')
const { EventEmitter } = require('events')

const BASE = __dirname
const SCRIPTS = process.argv[2] || path.join(BASE, 'scripts')
const DATA = process.argv[3] || path.join(BASE, 'data')
const TOKEN = process.argv[4] || ''
const PORT = 8765
const STORE_DIR = path.join(DATA, 'scriptdata')
for (const d of [SCRIPTS, DATA, STORE_DIR]) fs.mkdirSync(d, { recursive: true })

// ---------- siaran ke aplikasi (Kotlin) ----------
const apps = new Set()
const logHistory = []
function broadcastApp (obj) {
  const s = JSON.stringify(obj)
  for (const c of apps) { try { c.send(s) } catch (_) {} }
}
function log (...a) {
  const text = a.map(x => typeof x === 'string' ? x : ((x && x.stack) || JSON.stringify(x))).join(' ')
  console.log(text)
  const item = { type: 'log', text, t: Date.now() }
  logHistory.push(item)
  if (logHistory.length > 300) logHistory.shift()
  broadcastApp(item)
}
process.on('uncaughtException', (e) => log('UNCAUGHT:', e))
process.on('unhandledRejection', (e) => log('UNHANDLED:', e))
try { dns.setServers(['1.1.1.1', '8.8.8.8']) } catch (_) {}

// ---------- mineflayer (dimuat aman) ----------
let mineflayer = null
let mfVersion = null
let mfError = null
try {
  mineflayer = require('mineflayer')
  try { mfVersion = require('mineflayer/package.json').version } catch (_) {}
} catch (e) {
  mfError = String((e && e.stack) || e)
}

// ---------- bot ----------
const hub = new EventEmitter()   // event milik aplikasi (bukan mineflayer), saat ini: 'status'
hub.setMaxListeners(200)
const scripts = new Map()        // name -> rec
const tabs = new Map()           // 'script/id' -> tab
let tabRev = 0                   // naik tiap tab dibuat / dimuat ulang; Kotlin memakainya untuk membuat WebView baru

let bot = null
let gen = 0
let attempts = 0
let cfg = null
let status = 'offline'
let timer = null
let userStop = false   // true setelah pengguna menekan Putus (script tidak boleh sambung ulang)

function setStatus (s) {
  status = s
  broadcastApp({ type: 'status', status: s })
  hub.emit('status', s)
}

function stopBot () {
  gen++
  if (timer) { clearTimeout(timer); timer = null }
  if (bot) { try { bot.quit() } catch (_) {} bot = null }
}

// ---------- pindah server (Velocity / konfigurasi ulang, 1.20.2+) ----------
// Saat server mengirim start_configuration klien masuk fase "configuration" lagi. Dua hal yang wajib:
//  1) paket gameplay (posisi, gerak, dll) TIDAK boleh dikirim di fase itu -> dibuang;
//  2) resource pack dari server harus dijawab, kalau tidak server menunggu selamanya.
// Mineflayer sendiri belum melakukan keduanya, jadi dipasang di sini.
const GAMEPLAY_PACKETS = new Set([
  'position', 'position_look', 'look', 'flying', 'abilities', 'entity_action', 'arm_animation', 'held_item_slot',
  'teleport_confirm', 'window_click', 'close_window', 'chat', 'chat_message', 'chat_command', 'chat_command_signed',
  'chat_session_update', 'use_item', 'block_dig', 'block_place', 'use_entity', 'tick_end', 'player_input',
  'player_command', 'steer_vehicle', 'spectate', 'transaction', 'craft_recipe_request', 'set_creative_slot',
  'message_acknowledgement', 'chunk_batch_received'
])
const MOVE_PACKETS = new Set(['position', 'position_look', 'look', 'flying'])

function guardTransfer (b, my) {
  const c = b._client
  if (!c) return
  const origWrite = c.write.bind(c)
  let awaitTeleport = false      // sesudah pindah: jangan kirim posisi lama sebelum server baru mengirim posisi
  let transferring = false
  // Server 26.3+ hanya mengizinkan 1 paket posisi per tick dan baru mereset hitungan saat menerima tick_end
  // (klien asli mengirimnya tiap tick sejak 1.21.2). Mineflayer rilis <= 4.39.0 tidak mengirimnya sehingga
  // dikick invalid_player_movement (PR #4137). Bila mineflayer sudah mengirimnya sendiri, bagian ini diam.
  let noTickEnd = false
  let mfSendsTickEnd = false
  // Nomor urut prediksi blok (block_dig, block_place, use_item). Klien asli menghitungnya per dunia dan mulai lagi
  // dari 1 di dunia baru (login, atau respawn ke dunia lain). Mineflayer tidak mereset (PR #4218), sehingga server
  // dengan pengecekan paket (mis. GrimAC BadPacketsH) membatalkan dig/place pertama di server baru: blok dikembalikan
  // tanpa pesan. Di sini nomornya dihitung ulang seperti klien asli. Nomor 0 (abort) dibiarkan.
  let seq = 0
  let worldKey
  const worldOf = (d) => {
    if (!d) return undefined
    const w = d.worldName || (d.worldState && (d.worldState.name || d.worldState.dimension)) || d.dimension
    return w === undefined ? undefined : JSON.stringify(w)
  }
  c.on('login', (d) => { seq = 0; worldKey = worldOf(d); log('urutan blok mulai dari 1 (login/dunia baru)') })
  c.on('respawn', (d) => {
    const k = worldOf(d)
    if (k !== worldKey) { worldKey = k; seq = 0; log('urutan blok mulai dari 1 (pindah dunia)') }
  })
  const SEQ_PACKETS = new Set(['block_dig', 'block_place', 'use_item', 'use_item_on'])
  c.write = (name, params) => {
    if (name === 'tick_end') mfSendsTickEnd = true
    if (c.state === 'configuration' && GAMEPLAY_PACKETS.has(name)) return
    if (awaitTeleport && MOVE_PACKETS.has(name)) return
    if (SEQ_PACKETS.has(name) && params && typeof params.sequence === 'number' && params.sequence > 0) {
      params = Object.assign({}, params, { sequence: ++seq })
    }
    const r = origWrite(name, params)
    if (MOVE_PACKETS.has(name) && !noTickEnd && !mfSendsTickEnd && c.state === 'play') {
      try { origWrite('tick_end', {}) } catch (_) { noTickEnd = true }   // protokol lama tidak punya paket ini
    }
    return r
  }
  c.prependListener('start_configuration', () => {
    transferring = true
    awaitTeleport = true
    log('SERVER MINTA PINDAH: konfigurasi ulang dimulai')
    if (my === gen) { setStatus('connecting'); hub.emit('transfer', 'start') }
  })
  c.prependListener('position', () => { awaitTeleport = false })
  c.on('login', () => {
    if (!transferring || my !== gen) return
    transferring = false
    setStatus('online')
    log('PINDAH SERVER SELESAI: masuk dunia baru')
    hub.emit('transfer', 'end')
  })
  const answerPack = (uuid) => {
    // urutan seperti klien asli: diterima -> terunduh -> berhasil dimuat
    ;[3, 4, 0].forEach((result, i) => setTimeout(() => {
      try { origWrite('resource_pack_receive', { uuid, result }) } catch (e) { log('balas resource pack gagal:', e) }
    }, 100 + i * 200))
    log('resource pack (fase konfigurasi) dijawab')
  }
  c.prependListener('add_resource_pack', (d) => { if (c.state === 'configuration') answerPack(d.uuid) })
  c.prependListener('resource_pack_send', (d) => { if (c.state === 'configuration' && d.uuid) answerPack(d.uuid) })
  // di fase play: jawab lewat API mineflayer (fase configuration sudah dijawab di atas)
  b.on('resourcePack', () => {
    if (c.state !== 'play') return
    try { b.acceptResourcePack(); log('resource pack (play) diterima') } catch (e) { log('acceptResourcePack gagal:', e) }
  })
}

// Daftar versi untuk dropdown di aplikasi (rilis 1.8 ke atas, terbaru dulu).
function versionList () {
  try {
    const mcd = require('minecraft-data')
    const keys = Object.keys((mcd.versionsByMinecraftVersion && mcd.versionsByMinecraftVersion.pc) || {})
    const num = (v) => v.split('.').map(Number)
    return keys
      .filter(v => /^1\.\d+(\.\d+)?$/.test(v) && num(v)[1] >= 8)
      .sort((a, b) => { const x = num(a); const y = num(b); for (let i = 0; i < 3; i++) { const d = (y[i] || 0) - (x[i] || 0); if (d) return d } return 0 })
  } catch (_) { return [] }
}

function startBot () {
  const my = ++gen
  setStatus('connecting')
  hub.emit('session', my)   // bot baru dibuat (bukan pindah server); script memakai ini untuk mengulang alur masuk
  const wantVersion = (cfg.version && String(cfg.version).toLowerCase() !== 'auto') ? String(cfg.version) : false
  log(`konek ke ${cfg.host}:${cfg.port} sebagai ${cfg.username} (versi ${wantVersion || 'auto'})`)
  let b
  try {
    b = mineflayer.createBot({
      host: cfg.host,
      port: Number(cfg.port) || 25565,
      username: cfg.username,
      version: wantVersion,
      auth: 'offline',
      hideErrors: false
    })
  } catch (e) {
    log('createBot gagal:', e)
    setStatus('offline')
    return
  }
  bot = b
  // pasang ulang semua bot.on / plugin milik script ke bot baru ini
  for (const rec of scripts.values()) attachAll(rec, b)
  let didLogin = false
  guardTransfer(b, my)

  b.once('login', () => log('LOGIN: masuk ke server'))
  b.on('spawn', () => {
    if (my !== gen) return
    attempts = 0
    setStatus('online')
    log('SPAWN: masuk dunia')
    if (!didLogin && cfg.loginCommand) {
      didLogin = true
      setTimeout(() => {
        if (my === gen && bot === b) { b.chat(cfg.loginCommand); log('command login dikirim') }
      }, Number(cfg.loginDelayMs) || 2000)
    }
  })
  b.on('kicked', (r) => log('KICKED:', typeof r === 'string' ? r : JSON.stringify(r)))
  b.on('error', (e) => log('ERROR:', (e && e.message) || String(e)))
  b.on('end', (reason) => {
    if (my !== gen) return
    log('terputus:', reason)
    bot = null
    if (cfg.reconnect) {
      attempts++
      const wait = Math.min(30, 3 + attempts * 3)
      setStatus('reconnecting')
      log(`sambung ulang dalam ${wait} detik...`)
      timer = setTimeout(() => { timer = null; if (my === gen) startBot() }, wait * 1000)
    } else {
      setStatus('offline')
    }
  })
}

// ---------- bot global untuk script ----------
// Script menulis kode mineflayer biasa (bot.on, bot.chat, ...). Objek `bot` di script adalah pembungkus tetap:
// bot.on / bot.once / bot.loadPlugin dicatat lalu dipasang ulang otomatis ke bot baru tiap konek/reconnect.
// Selain itu semua diteruskan ke bot yang sedang aktif (undefined kalau belum konek).
function attachEntry (rec, e, b) {
  if (rec.dead || (e.once && e.fired)) return
  const h = (...args) => {
    if (e.once) { e.fired = true; try { b.off(e.ev, h) } catch (_) {} }
    if (rec.dead) return
    try {
      const r = e.fn(...args)
      if (r && typeof r.catch === 'function') r.catch(err => log(`[${rec.name}] error di bot.on('${e.ev}'):`, err))
    } catch (err) { log(`[${rec.name}] error di bot.on('${e.ev}'):`, err) }
  }
  e.h = h
  e.b = b
  b.on(e.ev, h)
}
function detachEntry (e) {
  if (e.b && e.h) { try { e.b.off(e.ev, e.h) } catch (_) {} }
  e.b = null
  e.h = null
}
function attachAll (rec, b) {
  for (const p of rec.plugins) { try { b.loadPlugin(p) } catch (err) { log(`[${rec.name}] loadPlugin gagal:`, err) } }
  for (const [k, v] of Object.entries(rec.props)) { try { b[k] = v } catch (_) {} }
  for (const e of rec.botEntries) { detachEntry(e); attachEntry(rec, e, b) }
}

function makeBot (rec) {
  const add = (ev, fn, once) => {
    if (rec.dead) return
    const e = { ev: String(ev), fn, once, fired: false, b: null, h: null }
    rec.botEntries.push(e)
    if (bot) attachEntry(rec, e, bot)
  }
  const remove = (ev, fn) => {
    rec.botEntries = rec.botEntries.filter(e => {
      const hit = e.ev === String(ev) && e.fn === fn
      if (hit) detachEntry(e)
      return !hit
    })
  }
  return new Proxy({}, {
    get (_, prop) {
      if (typeof prop === 'symbol') return undefined
      switch (prop) {
        case 'on': case 'addListener': case 'prependListener': return function (ev, fn) { add(ev, fn, false); return this }
        case 'once': return function (ev, fn) { add(ev, fn, true); return this }
        case 'off': case 'removeListener': return function (ev, fn) { remove(ev, fn); return this }
        case 'removeAllListeners': return function (ev) {
          rec.botEntries = rec.botEntries.filter(e => {
            const hit = ev === undefined || e.ev === String(ev)
            if (hit) detachEntry(e)
            return !hit
          })
          return this
        }
        case 'loadPlugin': return (p) => { rec.plugins.push(p); if (bot) bot.loadPlugin(p) }
        case 'loadPlugins': return (ps) => { for (const p of ps) { rec.plugins.push(p); if (bot) bot.loadPlugin(p) } }
      }
      if (!bot) return undefined
      const v = bot[prop]
      return typeof v === 'function' ? v.bind(bot) : v
    },
    set (_, prop, value) {
      rec.props[prop] = value
      if (bot) { try { bot[prop] = value } catch (_) {} }
      return true
    },
    has (_, prop) { return bot ? prop in bot : false }
  })
}

// ---------- setelan & penyimpanan per script ----------
const TYPE_ALIAS = {
  boolean: 'boolean', bool: 'boolean', switch: 'boolean', onoff: 'boolean',
  text: 'text', string: 'text', number: 'number', int: 'number', float: 'number',
  password: 'password', choice: 'choice', select: 'choice'
}
const stores = new Map()
const safeName = (s) => String(s || '').replace(/[^A-Za-z0-9_-]/g, '')

function storeOf (name) {
  let s = stores.get(name)
  if (s) return s
  s = { settings: {}, storage: {}, timer: null }
  try {
    const j = JSON.parse(fs.readFileSync(path.join(STORE_DIR, name + '.json'), 'utf8'))
    if (j.settings) s.settings = j.settings
    if (j.storage) s.storage = j.storage
  } catch (_) {}
  stores.set(name, s)
  return s
}
function persist (name) {
  const s = storeOf(name)
  if (s.timer) return
  s.timer = setTimeout(() => {
    s.timer = null
    try {
      fs.writeFileSync(path.join(STORE_DIR, name + '.json'), JSON.stringify({ settings: s.settings, storage: s.storage }))
    } catch (e) { log('gagal simpan data script', name, e) }
  }, 300)
}
function publishSettings (name) {
  const s = storeOf(name)
  broadcastApp({
    type: 'settings',
    script: name,
    list: Object.entries(s.settings).map(([n, d]) => ({ name: n, type: d.type, value: d.value, options: d.options || [] }))
  })
}
function coerce (type, value, options) {
  switch (type) {
    case 'boolean': return value === true || value === 'true' || value === 1 || value === 'on'
    case 'number': {
      const n = Number(value)
      if (value === '' || value == null || Number.isNaN(n)) throw new Error('nilai harus angka')
      return n
    }
    case 'choice': {
      const s = String(value)
      if (options && options.length && !options.includes(s)) throw new Error('pilihan harus salah satu dari: ' + options.join(', '))
      return s
    }
    default: return value == null ? '' : String(value)
  }
}
function defaultFor (type, options) {
  if (type === 'boolean') return false
  if (type === 'number') return 0
  if (type === 'choice') return (options && options[0]) || ''
  return ''
}
function applySet (name, n, value, strict) {
  const d = storeOf(name).settings[n]
  if (!d) {
    if (strict) throw new Error(`Setelan "${n}" belum dibuat. Pakai script.settings.create(...) dulu.`)
    return
  }
  d.value = coerce(d.type, value, d.options)
  persist(name)
  publishSettings(name)
}
function createSetting (name, n, rawType, value, options, overwrite) {
  const type = TYPE_ALIAS[String(rawType).toLowerCase()]
  if (!type) throw new Error('tipe setelan tidak dikenal. Pakai: boolean, text, number, password, choice')
  const opts = Array.isArray(options) ? options.map(String) : []
  const st = storeOf(name)
  const cur = st.settings[n]
  if (cur && cur.type === type && !overwrite) {
    cur.options = opts   // nilai milik pengguna tidak ditimpa
    persist(name)
    publishSettings(name)
    return cur.value
  }
  const v = value === undefined ? defaultFor(type, opts) : coerce(type, value, opts)
  st.settings[n] = { type, value: v, options: opts }
  persist(name)
  publishSettings(name)
  return v
}

function makeSettings (name) {
  return {
    create: (n, type, value, options) => createSetting(name, String(n), type, value, options, false),
    get: (n, def) => { const d = storeOf(name).settings[String(n)]; return d ? d.value : def },
    has: (n) => !!storeOf(name).settings[String(n)],
    all: () => { const o = {}; for (const [k, d] of Object.entries(storeOf(name).settings)) o[k] = d.value; return o },
    set: (n, value) => applySet(name, String(n), value, true),
    remove: (n) => { delete storeOf(name).settings[String(n)]; persist(name); publishSettings(name) }
  }
}
const storageTimers = new Map()
function publishStorage (name) {
  broadcastApp({ type: 'storage', script: name, data: storeOf(name).storage })
}
function publishStorageSoon (name) {   // script bisa menulis sering; tunda supaya UI tidak dibanjiri
  if (storageTimers.has(name)) return
  storageTimers.set(name, setTimeout(() => { storageTimers.delete(name); publishStorage(name) }, 250))
}
function makeStorage (name) {
  return {
    get: (k, def) => { const v = storeOf(name).storage[String(k)]; return v === undefined ? def : v },
    set: (k, v) => { storeOf(name).storage[String(k)] = v; persist(name); publishStorageSoon(name) },
    has: (k) => String(k) in storeOf(name).storage,
    delete: (k) => { delete storeOf(name).storage[String(k)]; persist(name); publishStorageSoon(name) },
    keys: () => Object.keys(storeOf(name).storage)
  }
}

// Edit storage dari aplikasi lewat path, mis. ["crispymc.net:25565", "akun", 0, "username"]
const BAD_KEYS = new Set(['__proto__', 'constructor', 'prototype'])
function checkPath (p) {
  if (!Array.isArray(p) || p.length === 0) throw new Error('path kosong')
  for (const k of p) if (typeof k === 'string' && BAD_KEYS.has(k)) throw new Error('kunci tidak boleh: ' + k)
}
function pathParent (root, p, create) {
  let cur = root
  for (let i = 0; i < p.length - 1; i++) {
    const k = p[i]
    let next = cur[k]
    if (next === undefined || next === null || typeof next !== 'object') {
      if (!create) return null
      next = typeof p[i + 1] === 'number' ? [] : {}
      cur[k] = next
    }
    cur = next
  }
  return cur
}
function storageSet (name, p, value) {
  checkPath(p)
  const parent = pathParent(storeOf(name).storage, p, true)
  const last = p[p.length - 1]
  if (Array.isArray(parent)) {
    const i = Number(last)
    if (i >= parent.length) parent.push(value); else parent[i] = value
  } else parent[String(last)] = value
  persist(name)
  publishStorage(name)
}
function storageDelete (name, p) {
  checkPath(p)
  const parent = pathParent(storeOf(name).storage, p, false)
  if (!parent) return
  const last = p[p.length - 1]
  if (Array.isArray(parent)) parent.splice(Number(last), 1); else delete parent[String(last)]
  persist(name)
  publishStorage(name)
}

// ---------- status script (on/off) ----------
const stateFile = path.join(DATA, 'scripts.json')
let state = { enabled: {} }
try { state = Object.assign({ enabled: {} }, JSON.parse(fs.readFileSync(stateFile, 'utf8'))) } catch (_) {}
function saveState () { try { fs.writeFileSync(stateFile, JSON.stringify(state)) } catch (e) { log('gagal simpan status script:', e) } }

// Script bawaan: folder defaults/<nama>/ disalin ke scripts/<nama>/.
// Naikkan nomor versi untuk menimpa; file yang sudah ada disimpan sebagai .bak.
const SEED = { chat: 4, autologin: 1 }
function seedDefaults () {
  const f = path.join(DATA, 'seed.json')
  let seeded = {}
  try { seeded = JSON.parse(fs.readFileSync(f, 'utf8')) } catch (_) {}
  let changed = false
  for (const [name, ver] of Object.entries(SEED)) {
    if ((seeded[name] || 0) >= ver) continue
    const src = path.join(BASE, 'defaults', name)
    const dst = path.join(SCRIPTS, name)
    try {
      fs.mkdirSync(dst, { recursive: true })
      for (const file of fs.readdirSync(src)) {
        const target = path.join(dst, file)
        if (fs.existsSync(target)) fs.renameSync(target, target + '.bak')
        fs.copyFileSync(path.join(src, file), target)
      }
      if (state.enabled[name] === undefined) state.enabled[name] = true
      seeded[name] = ver
      changed = true
    } catch (e) { log('seed gagal:', name, e) }
  }
  if (changed) { try { fs.writeFileSync(f, JSON.stringify(seeded)) } catch (_) {} saveState() }
}

// ---------- mesin script ----------
const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor

const MAIN = 'script.js'
function listNames () {
  try {
    return fs.readdirSync(SCRIPTS, { withFileTypes: true })
      .filter(d => d.isDirectory() && fs.existsSync(path.join(SCRIPTS, d.name, MAIN)))
      .map(d => d.name).sort()
  } catch (_) { return [] }
}
// Format lama: scripts/nama.js (satu file) -> scripts/nama/script.js
function migrateFlat () {
  let files = []
  try { files = fs.readdirSync(SCRIPTS) } catch (_) {}
  for (const f of files) {
    if (!f.endsWith('.js')) continue
    const n = f.slice(0, -3)
    const dir = path.join(SCRIPTS, n)
    if (fs.existsSync(dir)) continue
    try {
      fs.mkdirSync(dir)
      fs.renameSync(path.join(SCRIPTS, f), path.join(dir, MAIN))
      log('script dipindah ke folder:', n)
    } catch (e) { log('migrasi gagal:', n, e) }
  }
}
function publishScripts () {
  broadcastApp({
    type: 'scripts',
    list: listNames().map(n => {
      const r = scripts.get(n)
      return { name: n, enabled: !!state.enabled[n], running: !!r, error: r ? r.error : null }
    })
  })
}
function publishTabs () {
  broadcastApp({ type: 'tabs', list: [...tabs.entries()].map(([key, t]) => ({ key, title: t.title, rev: t.rev })) })
}

function removeTab (key) {
  const t = tabs.get(key)
  if (!t) return
  for (const p of t.pages) { try { p.close() } catch (_) {} }
  tabs.delete(key)
}

function stopScript (name) {
  const r = scripts.get(name)
  if (!r) return
  r.dead = true
  scripts.delete(name)
  for (const e of r.botEntries) detachEntry(e)
  r.botEntries = []
  for (const fn of r.cleanups.splice(0)) { try { fn() } catch (_) {} }
  for (const key of [...r.tabs]) removeTab(key)
  r.tabs.clear()
  publishTabs()
}

function makeApp (rec) {
  const name = rec.name
  const alive = () => { if (rec.dead) throw new Error('script sudah dihentikan') }
  const guard = (label, fn) => (...a) => {
    if (rec.dead) return
    try {
      const r = fn(...a)
      if (r && typeof r.catch === 'function') r.catch(e => log(`[${name}] error di ${label}:`, e))
    } catch (e) { log(`[${name}] error di ${label}:`, e) }
  }
  return {
    name,
    log: (...a) => log(`[${name}]`, ...a),
    get status () { return status },
    online: () => status === 'online',
    // server/akun yang terakhir dipakai konek dari beranda (tanpa data rahasia)
    get config () { return cfg ? { host: cfg.host, port: Number(cfg.port) || 25565, username: cfg.username, version: cfg.version || 'auto' } : null },
    // true kalau pengguna menekan Putus: script jangan sambung ulang
    get userStopped () { return userStop },
    // versi helper app. 2 = punya connect/disconnect/config/userStopped (dipakai script untuk cek fitur)
    api: 2,
    // konek ulang ke server terakhir (pengaturan dari beranda). Boleh diberi {host, port, username, version}
    // untuk menimpa sebagian atau seluruhnya, mis. app.connect({ username: 'akun2' }) atau pindah server.
    connect (opts) {
      alive()
      if (!mineflayer) throw new Error('mineflayer tidak termuat')
      if (opts && typeof opts === 'object') cfg = Object.assign({}, cfg || {}, opts)
      if (!cfg || !cfg.host || !cfg.username) throw new Error('belum ada server: konek sekali dari beranda dulu')
      userStop = false
      attempts = 0
      stopBot()
      startBot()
    },
    // putuskan koneksi seperti tombol Putus (script tidak akan menyambung ulang karena userStopped = true)
    disconnect () {
      alive()
      userStop = true
      stopBot()
      setStatus('offline')
      log(`[${name}] diputus oleh script`)
    },
    onUnload (fn) { rec.cleanups.push(fn) },
    sleep: (ms) => new Promise((resolve, reject) => {
      setTimeout(() => (rec.dead ? reject(new Error('script dihentikan')) : resolve()), Number(ms) || 0)
    }),
    on (ev, fn) {   // event milik aplikasi, saat ini: 'status'
      alive()
      const h = guard(`app.on('${ev}')`, fn)
      hub.on(ev, h)
      rec.cleanups.push(() => hub.off(ev, h))
    },
    every (sec, fn) {
      alive()
      const t = setInterval(guard('app.every', fn), Math.max(200, Number(sec) * 1000))
      rec.cleanups.push(() => clearInterval(t))
      return t
    },
    after (ms, fn) {
      alive()
      const t = setTimeout(guard('app.after', fn), Number(ms) || 0)
      rec.cleanups.push(() => clearTimeout(t))
      return t
    },
    tab (opts) {
      alive()
      opts = opts || {}
      const id = String(opts.id || 'main').replace(/[^A-Za-z0-9_-]/g, '') || 'main'
      const key = name + '/' + id
      const t = {
        script: name,
        rev: ++tabRev,
        title: String(opts.title || id),
        html: opts.html != null ? String(opts.html) : null,
        file: opts.file ? String(opts.file) : null,
        pages: new Set(),
        handlers: { message: [], open: [] }
      }
      removeTab(key)
      tabs.set(key, t)
      rec.tabs.add(key)
      publishTabs()
      return {
        send (data) {
          const s = JSON.stringify(data)
          for (const p of t.pages) { try { p.send(s) } catch (_) {} }
        },
        on (ev, fn) { (t.handlers[ev] = t.handlers[ev] || []).push(guard(`tab.on('${ev}')`, fn)) },
        setTitle (x) { t.title = String(x); publishTabs() },
        close () { removeTab(key); rec.tabs.delete(key); publishTabs() }
      }
    }
  }
}

function startScript (name) {
  stopScript(name)
  let code
  try { code = fs.readFileSync(path.join(SCRIPTS, name, MAIN), 'utf8') } catch (e) { return log(`[${name}] gagal baca file:`, e) }
  const rec = { name, error: null, dead: false, cleanups: [], tabs: new Set(), botEntries: [], plugins: [], props: {} }
  scripts.set(name, rec)
  log(`[${name}] mulai`)
  let fn
  try {
    fn = new AsyncFunction('app', 'bot', 'script', 'require', code)
  } catch (e) {
    rec.error = 'Sintaks salah: ' + e.message
    log(`[${name}] ${rec.error}`)
    publishScripts()
    return
  }
  const scriptObj = { name, settings: makeSettings(name), storage: makeStorage(name) }
  Promise.resolve()
    .then(() => fn(makeApp(rec), makeBot(rec), scriptObj, require))
    .catch((e) => {
      if (rec.dead) return
      let msg = String((e && e.message) || e)
      if (!bot && /is not a function/.test(msg)) msg += ' (bot belum konek?)'
      rec.error = msg
      log(`[${name}] ERROR:`, e)
      publishScripts()
    })
  publishScripts()
}

function rescan () {
  const names = listNames()
  for (const n of [...scripts.keys()]) if (!names.includes(n)) stopScript(n)
  publishScripts()
}

// ---------- perintah dari aplikasi ----------
function onCommand (m) {
  switch (m.type) {
    case 'connect':
      if (!mineflayer) return log('mineflayer tidak termuat, tidak bisa konek. Lihat log di atas.')
      cfg = m.cfg || {}
      attempts = 0
      userStop = false
      stopBot()
      startBot()
      break
    case 'disconnect':
      userStop = true
      stopBot()
      setStatus('offline')
      log('diputus oleh pengguna')
      break
    case 'chat':
      if (bot && status === 'online' && m.text) bot.chat(String(m.text))
      break
    case 'script.toggle':
      state.enabled[m.name] = !!m.on
      saveState()
      if (m.on) startScript(m.name); else { stopScript(m.name); log(`[${m.name}] berhenti`) }
      publishScripts()
      break
    case 'script.reload':
      rescan()
      if (state.enabled[m.name] && listNames().includes(m.name)) startScript(m.name)
      publishScripts()
      break
    case 'script.rescan':
      rescan()
      break
    case 'settings.get':
      publishSettings(safeName(m.script))
      break
    case 'setting.set':
      try { applySet(safeName(m.script), String(m.name), m.value, false) } catch (e) { log('setelan ditolak:', e.message) }
      break
    case 'setting.add':
      try { createSetting(safeName(m.script), String(m.name), m.stype, m.value, m.options, true) } catch (e) { log('setelan ditolak:', e.message) }
      break
    case 'tab.reload':   // HTML tab diedit: buat ulang WebView-nya tanpa restart script
      for (const t of tabs.values()) if (t.script === safeName(m.script)) t.rev = ++tabRev
      publishTabs()
      break
    case 'storage.get':
      publishStorage(safeName(m.script))
      break
    case 'storage.set':
      try { storageSet(safeName(m.script), m.path, m.value) } catch (e) { log('storage ditolak:', e.message) }
      break
    case 'storage.delete':
      try { storageDelete(safeName(m.script), m.path) } catch (e) { log('storage ditolak:', e.message) }
      break
    case 'storage.replace': {
      const n = safeName(m.script)
      if (m.data && typeof m.data === 'object' && !Array.isArray(m.data)) { storeOf(n).storage = m.data; persist(n); publishStorage(n) } else log('storage ditolak: data harus objek')
      break
    }
    case 'setting.delete': {
      const n = safeName(m.script)
      delete storeOf(n).settings[String(m.name)]
      persist(n)
      publishSettings(n)
      break
    }
  }
}

// ---------- server web (hanya untuk tab HTML + WebSocket) ----------
const TAB_JS = `(function () {
  var k = new URLSearchParams(location.search).get('k') || '';
  var parts = location.pathname.split('/');
  var key = decodeURIComponent(parts[2] || '') + '/' + decodeURIComponent(parts[3] || '');
  var handlers = [], queue = [], ws = null;
  window.tab = {
    onMessage: function (fn) { handlers.push(fn); },
    send: function (o) {
      var s = JSON.stringify(o);
      if (ws && ws.readyState === 1) ws.send(s); else queue.push(s);
    }
  };
  function open () {
    ws = new WebSocket('ws://' + location.host + '/ws?role=page&k=' + encodeURIComponent(k) + '&tab=' + encodeURIComponent(key));
    ws.onopen = function () { queue.splice(0).forEach(function (s) { ws.send(s); }); };
    ws.onmessage = function (e) { var m = JSON.parse(e.data); handlers.forEach(function (h) { h(m); }); };
    ws.onclose = function () { setTimeout(open, 1500); };
  }
  open();
})();`

function renderTab (t) {
  let html = t.html
  if (html == null && t.file) {
    const base = path.join(SCRIPTS, t.script)
    const p = path.join(base, t.file)
    if (p.startsWith(base + path.sep)) { try { html = fs.readFileSync(p, 'utf8') } catch (_) {} }
  }
  html = String(html || '<p style="font-family:sans-serif">(tab kosong)</p>')
  const tag = '<script src="/_tab.js"></script>'
  return /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, (m) => m + tag) : tag + html
}

const server = http.createServer((req, res) => {
  let p = '/'
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname) } catch (_) {}
  const head = (type) => ({ 'Content-Type': type, 'Cache-Control': 'no-store' })
  if (p === '/_tab.js') { res.writeHead(200, head('text/javascript; charset=utf-8')); return res.end(TAB_JS) }
  const m = /^\/tab\/([^/]+)\/([^/]+)$/.exec(p)
  if (m) {
    const t = tabs.get(m[1] + '/' + m[2])
    if (!t) { res.writeHead(404, head('text/html; charset=utf-8')); return res.end('<body style="background:#141218;color:#ccc;font-family:sans-serif"><p>Tab belum siap atau script mati.</p>') }
    res.writeHead(200, head('text/html; charset=utf-8'))
    return res.end(renderTab(t))
  }
  res.writeHead(404); res.end('tidak ditemukan')
})

const { WebSocketServer } = require('ws')
const wss = new WebSocketServer({ server, path: '/ws' })

function onApp (ws) {
  apps.add(ws)
  ws.on('close', () => apps.delete(ws))
  ws.on('error', () => apps.delete(ws))
  ws.on('message', (data) => {
    let m
    try { m = JSON.parse(String(data)) } catch (_) { return }
    try { onCommand(m) } catch (e) { log('Error perintah:', e) }
  })
  ws.send(JSON.stringify({ type: 'hello', node: process.version, arch: process.arch, mineflayer: mfVersion, mfError, status, versions: versionList() }))
  for (const h of logHistory) ws.send(JSON.stringify(h))
  publishScripts()
  publishTabs()
}

function onPage (ws, key) {
  const t = tabs.get(key)
  if (!t) return ws.close()
  t.pages.add(ws)
  ws.on('close', () => t.pages.delete(ws))
  ws.on('error', () => t.pages.delete(ws))
  ws.on('message', (data) => {
    let m
    try { m = JSON.parse(String(data)) } catch (_) { return }
    for (const h of t.handlers.message) h(m)
  })
  for (const h of t.handlers.open) h()
}

wss.on('connection', (ws, req) => {
  let u
  try { u = new URL(req.url, 'http://x') } catch (_) { return ws.close() }
  if (TOKEN && u.searchParams.get('k') !== TOKEN) return ws.close(4001, 'token salah')
  if (u.searchParams.get('role') === 'page') onPage(ws, u.searchParams.get('tab') || '')
  else onApp(ws)
})

server.listen(PORT, '127.0.0.1', () => {
  log(`Node ${process.version} (${process.arch}) siap di port ${PORT}`)
  if (mfError) log('mineflayer GAGAL dimuat:', mfError)
  else log('mineflayer ' + mfVersion + ' dimuat')
  migrateFlat()
  seedDefaults()
  for (const n of listNames()) if (state.enabled[n]) startScript(n)
  publishScripts()
})
