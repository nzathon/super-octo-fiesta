// Setelan modul yang dikirim aplikasi: {"<modul>": {"enabled": true, "<kunci>": nilai}}.
// Nilai yang belum diisi memakai nilai awal dari definisi modul.
use serde_json::{json, Value};
use std::sync::Mutex;

static STORE: Mutex<Option<Value>> = Mutex::new(None);

pub fn init(v: Value) {
    *STORE.lock().unwrap() = Some(if v.is_object() { v } else { json!({}) });
}

pub fn set(module: &str, key: &str, val: Value) {
    let mut g = STORE.lock().unwrap();
    let root = g.get_or_insert_with(|| json!({}));
    if !root[module].is_object() {
        root[module] = json!({});
    }
    root[module][key] = val;
}

pub fn get(module: &str, key: &str) -> Value {
    {
        let g = STORE.lock().unwrap();
        if let Some(root) = g.as_ref() {
            let v = &root[module][key];
            if !v.is_null() {
                return v.clone();
            }
        }
    }
    crate::modules::default_of(module, key)
}

pub fn enabled(module: &str) -> bool {
    get(module, "enabled").as_bool().unwrap_or(false)
}

pub fn get_bool(module: &str, key: &str) -> bool {
    get(module, key).as_bool().unwrap_or(false)
}

pub fn get_str(module: &str, key: &str) -> String {
    match get(module, key) {
        Value::String(s) => s,
        Value::Null => String::new(),
        other => other.to_string(),
    }
}

pub fn get_f64(module: &str, key: &str) -> f64 {
    match get(module, key) {
        Value::Number(n) => n.as_f64().unwrap_or(0.0),
        Value::String(s) => s.trim().parse().unwrap_or(0.0),
        _ => 0.0,
    }
}

// ---- konteks koneksi (server dan akun yang sedang dipakai) ----
static CTX: std::sync::OnceLock<(String, u16, String)> = std::sync::OnceLock::new();

pub fn set_context(host: &str, port: u16, user: &str) {
    let _ = CTX.set((host.to_string(), port, user.to_string()));
}
pub fn host() -> String {
    CTX.get().map(|c| c.0.clone()).unwrap_or_default()
}
pub fn port() -> u16 {
    CTX.get().map(|c| c.1).unwrap_or(25565)
}
pub fn username() -> String {
    CTX.get().map(|c| c.2.clone()).unwrap_or_default()
}
