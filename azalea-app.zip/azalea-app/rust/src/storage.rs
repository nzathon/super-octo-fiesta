// Storage per modul: {"<modul>": {...bebas...}}. Disimpan oleh aplikasi (Kotlin) supaya tetap ada antar koneksi,
// dan bisa diedit pengguna di tab Storage. Perubahan dari sini dikirim ke aplikasi; perubahan dari aplikasi
// dikirim ke sini lewat stdin.
use serde_json::{json, Value};
use std::sync::Mutex;

static STORE: Mutex<Option<Value>> = Mutex::new(None);

pub fn init(v: Value) {
    *STORE.lock().unwrap() = Some(if v.is_object() { v } else { json!({}) });
}

pub fn get(module: &str) -> Value {
    let g = STORE.lock().unwrap();
    match g.as_ref().map(|r| r[module].clone()) {
        Some(v) if v.is_object() => v,
        _ => json!({}),
    }
}

fn put(module: &str, v: Value) {
    let mut g = STORE.lock().unwrap();
    let root = g.get_or_insert_with(|| json!({}));
    root[module] = v;
}

/// Simpan dari modul, lalu kabari aplikasi.
pub fn save(module: &str, v: Value) {
    put(module, v.clone());
    crate::out(json!({"t": "storage", "m": module, "v": v}));
}

/// Pengguna mengubah storage di aplikasi.
pub fn replace_from_app(module: &str, v: Value) {
    put(module, v);
}
