// Modul Relogin: sambung ulang otomatis + (opsional) login otomatis.
// Bagian login dijalankan di sini. Bagian sambung ulang dijalankan aplikasi (Core.kt), karena saat bot
// keluar prosesnya sudah tidak ada; setelannya (jeda) dideklarasikan di sini supaya satu kartu.
use std::time::Duration;

use azalea::prelude::*;
use serde_json::json;

use super::{Def, Setting};
use crate::settings;

pub fn def() -> Def {
    Def {
        id: "relogin",
        title: "Relogin",
        desc: "Menyambung ulang kalau bot keluar dari server, dan (opsional) mengirim login setelah masuk.",
        enabled: true,
        settings: vec![
            Setting { key: "min_delay", label: "Jeda sambung ulang awal (detik)", kind: "number", default: json!(5) },
            Setting { key: "max_delay", label: "Jeda sambung ulang maksimal (detik)", kind: "number", default: json!(60) },
            Setting { key: "login", label: "Login otomatis setelah masuk", kind: "boolean", default: json!(false) },
            Setting { key: "password", label: "Password", kind: "password", default: json!("") },
            Setting { key: "command", label: "Perintah login", kind: "text", default: json!("/login") },
            Setting { key: "delay", label: "Jeda sebelum login (detik)", kind: "number", default: json!(2) },
        ],
    }
}

pub async fn on_event(bot: &Client, event: &Event) {
    if let Event::Login = event {
        if !settings::get_bool("relogin", "login") {
            return;
        }
        let pw = settings::get_str("relogin", "password");
        if pw.is_empty() {
            crate::log("login otomatis aktif tapi password kosong");
            return;
        }
        let delay = settings::get_f64("relogin", "delay").clamp(0.0, 60.0);
        tokio::time::sleep(Duration::from_millis((delay * 1000.0) as u64)).await;
        let cmd = settings::get_str("relogin", "command");
        bot.chat(format!("{cmd} {pw}").as_str());
        crate::log("login otomatis: perintah dikirim");
    }
}
