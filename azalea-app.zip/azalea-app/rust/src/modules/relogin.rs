// Modul Relogin: login otomatis (password per server+akun di Storage), simpan password dari /login manual,
// register otomatis, dan setelan sambung ulang. Sambung ulang sendiri dijalankan aplikasi (Core.kt): saat bot
// keluar, prosesnya sudah tidak ada, jadi setelannya cuma dideklarasikan di sini supaya satu kartu.
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::Duration;

use azalea::prelude::*;
use serde_json::{json, Value};

use super::{Def, Setting};
use crate::{settings, storage};

const ID: &str = "relogin";

static LOGIN_SENT: AtomicBool = AtomicBool::new(false);
static REGISTER_SENT: AtomicBool = AtomicBool::new(false);
static LOGGED_IN: AtomicBool = AtomicBool::new(false);
static PENDING: Mutex<Option<String>> = Mutex::new(None); // password dari /login manual, menunggu balasan server

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Auto login & sambung ulang",
        desc: "Login otomatis memakai password yang tersimpan per server dan akun (tab Storage). Login manual sekali \
(/login passwordmu): password ditangkap dan disimpan setelah server membalas sukses. Juga mengatur sambung ulang otomatis.",
        enabled: true,
        settings: vec![
            Setting { key: "auto_login", label: "Login otomatis", kind: "boolean", default: json!(true) },
            Setting { key: "login_delay", label: "Jeda sebelum login (detik)", kind: "number", default: json!(2) },
            Setting { key: "login_command", label: "Perintah login ({password} {username})", kind: "text", default: json!("/login {password}") },
            Setting { key: "auto_save", label: "Simpan password dari /login manual", kind: "boolean", default: json!(true) },
            Setting { key: "auto_register", label: "Register otomatis kalau diminta", kind: "boolean", default: json!(false) },
            Setting { key: "register_command", label: "Perintah register", kind: "text", default: json!("/register {password} {password}") },
            Setting { key: "auto_reconnect", label: "Sambung ulang otomatis", kind: "boolean", default: json!(true) },
            Setting { key: "reconnect_delay", label: "Jeda sambung ulang (detik, naik tiap gagal, maks 60)", kind: "number", default: json!(5) },
            Setting { key: "max_reconnect", label: "Batas percobaan (0 = tanpa batas)", kind: "number", default: json!(0) },
        ],
    }
}

// ---------- storage: {"host:port": {"akun": [{"username","password"}]}} ----------

fn key() -> String {
    format!("{}:{}", settings::host(), settings::port())
}

fn same(a: &Value, user: &str) -> bool {
    a["username"].as_str().map(|u| u.eq_ignore_ascii_case(user)).unwrap_or(false)
}

/// Pastikan entri server dan akun ada di Storage (password kosong) supaya bisa diisi lebih awal.
fn ensure_entry() {
    let mut root = storage::get(ID);
    let (k, user) = (key(), settings::username());
    if !root[&k].is_object() {
        root[&k] = json!({"akun": []});
    }
    if !root[&k]["akun"].is_array() {
        root[&k]["akun"] = json!([]);
    }
    let has = root[&k]["akun"].as_array().map(|a| a.iter().any(|x| same(x, &user))).unwrap_or(false);
    if !has {
        root[&k]["akun"].as_array_mut().unwrap().push(json!({"username": user, "password": ""}));
        storage::save(ID, root);
        crate::log(format!("entri baru di Storage untuk {k}. Login manual sekali, password akan tersimpan otomatis."));
    }
}

fn password() -> Option<String> {
    let root = storage::get(ID);
    let user = settings::username();
    root[&key()]["akun"]
        .as_array()?
        .iter()
        .find(|a| same(a, &user))
        .and_then(|a| a["password"].as_str())
        .filter(|p| !p.is_empty())
        .map(|p| p.to_string())
}

fn save_password(pw: &str, why: &str) {
    ensure_entry();
    let mut root = storage::get(ID);
    let (k, user) = (key(), settings::username());
    if let Some(arr) = root[&k]["akun"].as_array_mut() {
        if let Some(a) = arr.iter_mut().find(|a| same(a, &user)) {
            if a["password"].as_str() == Some(pw) {
                return;
            }
            a["password"] = json!(pw);
        }
    }
    storage::save(ID, root);
    crate::log(format!("password untuk {user} disimpan di Storage ({why})"));
}

fn fill(tpl: &str, pw: &str) -> String {
    tpl.replace("{password}", pw).replace("{username}", &settings::username())
}

// ---------- pengenalan pesan server ----------

fn has_any(t: &str, words: &[&str]) -> bool {
    words.iter().any(|w| t.contains(w))
}
const OK: &[&str] = &[
    "logged in as", "welcome back", "berhasil login", "berhasil masuk", "successfully logged",
    "successfully authenticated", "login success", "login berhasil", "[ success ]",
];
const ALREADY: &[&str] = &["already logged", "session is already active", "sudah login"];
const LOGIN: &[&str] = &["/login", "please login", "please log in", "silakan login", "silakan masuk"];
const REGISTER: &[&str] = &["/register", "please register", "silakan daftar", "silakan register"];
const FAIL: &[&str] = &[
    "wrong", "incorrect", "invalid", "salah", "gagal", "failed", "not registered", "belum terdaftar", "tidak terdaftar",
];

// ---------- aksi ----------

fn send_login(bot: &Client, why: &str) {
    if LOGIN_SENT.load(Ordering::SeqCst) || !settings::get_bool(ID, "auto_login") {
        return;
    }
    match password() {
        None => crate::log("password belum diisi di Storage, login tidak dikirim"),
        Some(pw) => {
            LOGIN_SENT.store(true, Ordering::SeqCst);
            bot.chat(fill(&settings::get_str(ID, "login_command"), &pw).as_str());
            crate::log(format!("login dikirim ({why})"));
        }
    }
}

fn send_register(bot: &Client) {
    if REGISTER_SENT.load(Ordering::SeqCst) || !settings::get_bool(ID, "auto_register") {
        return;
    }
    if let Some(pw) = password() {
        REGISTER_SENT.store(true, Ordering::SeqCst);
        bot.chat(fill(&settings::get_str(ID, "register_command"), &pw).as_str());
        crate::log("register dikirim");
    }
}

fn settle(ok: bool, why: &str) {
    let pw = PENDING.lock().unwrap().take();
    if let Some(pw) = pw {
        if ok {
            save_password(&pw, why);
        } else {
            crate::log("server menolak login itu, password tidak disimpan");
        }
    }
}

/// Dipanggil saat pengguna mengirim chat/perintah dari aplikasi: tangkap /login dan /register manual.
pub fn on_outgoing(text: &str) {
    if !settings::get_bool(ID, "auto_save") {
        return;
    }
    let parts: Vec<&str> = text.trim().trim_start_matches('/').split_whitespace().collect();
    let cmd = parts.first().map(|c| c.to_lowercase()).unwrap_or_default();
    if !text.trim().starts_with('/') || !["login", "l", "log", "register", "reg"].contains(&cmd.as_str()) {
        return;
    }
    if let Some(pw) = parts.get(1) {
        *PENDING.lock().unwrap() = Some(pw.to_string());
        crate::log(format!("perintah /{cmd} terdeteksi; password disimpan setelah server membalas sukses"));
        tokio::spawn(async {
            tokio::time::sleep(Duration::from_secs(12)).await;
            settle(true, "tanpa balasan gagal"); // balasan sukses tidak dikenali: simpan kalau tidak ada penolakan
        });
    }
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login => {
            ensure_entry();
            if !settings::get_bool(ID, "auto_login") {
                return;
            }
            let delay = settings::get_f64(ID, "login_delay").clamp(0.0, 60.0);
            tokio::time::sleep(Duration::from_millis((delay * 1000.0) as u64)).await;
            if password().is_none() {
                crate::log("belum ada password tersimpan: login manual sekali (/login ...), nanti disimpan otomatis");
            } else {
                send_login(bot, "terjadwal");
            }
        }
        Event::Chat(m) => {
            let t = m.message().to_string().to_lowercase();
            if PENDING.lock().unwrap().is_some() {
                if has_any(&t, FAIL) {
                    settle(false, "gagal");
                } else if has_any(&t, OK) {
                    settle(true, "login berhasil");
                }
            }
            if LOGIN_SENT.load(Ordering::SeqCst) && !LOGGED_IN.load(Ordering::SeqCst) && has_any(&t, FAIL) {
                crate::log("server menolak login dari password tersimpan; periksa password di Storage atau login manual lagi");
            }
            if has_any(&t, ALREADY) || has_any(&t, OK) {
                LOGGED_IN.store(true, Ordering::SeqCst);
            } else if has_any(&t, LOGIN) {
                send_login(bot, "diminta server");
            } else if has_any(&t, REGISTER) {
                send_register(bot);
            }
        }
        _ => {}
    }
}
