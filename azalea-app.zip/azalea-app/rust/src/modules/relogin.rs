// Modul Relogin: login otomatis, pindah server lewat item menu, simpan password dari /login manual (password per server+akun di Storage),
// register otomatis, dan setelan sambung ulang. Sambung ulang sendiri dijalankan aplikasi (Core.kt): saat bot
// keluar, prosesnya sudah tidak ada, jadi setelannya cuma dideklarasikan di sini supaya satu kartu.
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use azalea::inventory::ItemStack;
use azalea::prelude::*;
use serde_json::{json, Value};

use super::{Def, Setting};
use crate::{settings, storage};

const ID: &str = "relogin";

static LOGIN_SENT: AtomicBool = AtomicBool::new(false);
static REGISTER_SENT: AtomicBool = AtomicBool::new(false);
static LOGGED_IN: AtomicBool = AtomicBool::new(false);
static TRANSFER_STARTED: AtomicBool = AtomicBool::new(false);
static PENDING: Mutex<Option<String>> = Mutex::new(None); // password dari /login manual, menunggu balasan server

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Auto login & sambung ulang",
        desc: "Login otomatis memakai password yang tersimpan per server dan akun (tab Storage). Login manual sekali \
(/login passwordmu): password ditangkap dan disimpan setelah server membalas sukses. Juga mengatur sambung ulang otomatis.",
        enabled: true,
        settings: vec![
            Setting { key: "auto_login", label: "Login otomatis", kind: "boolean", default: json!(true) },
            Setting { key: "login_delay", label: "Jeda sebelum login (detik)", kind: "number", default: json!(2) },
            Setting { key: "login_command", label: "Perintah login ({password} {username})", kind: "text", default: json!("/login {password}") },
            Setting { key: "auto_save", label: "Simpan password dari /login manual", kind: "boolean", default: json!(true) },
            Setting { key: "auto_register", label: "Register otomatis kalau diminta", kind: "boolean", default: json!(false) },
            Setting { key: "register_command", label: "Perintah register", kind: "text", default: json!("/register {password} {password}") },
            Setting { key: "auto_transfer", label: "Pindah server lewat item menu (diatur per server di Storage)", kind: "boolean", default: json!(true) },
            Setting { key: "transfer_delay", label: "Jeda sebelum pindah server (detik)", kind: "number", default: json!(3) },
            Setting { key: "auto_reconnect", label: "Sambung ulang otomatis", kind: "boolean", default: json!(true) },
            Setting { key: "reconnect_delay", label: "Jeda sambung ulang (detik, naik tiap gagal, maks 60)", kind: "number", default: json!(5) },
            Setting { key: "max_reconnect", label: "Batas percobaan (0 = tanpa batas)", kind: "number", default: json!(0) },
        ],
    }
}

// ---------- storage: {"host:port": {"akun": [{"username","password"}]}} ----------

fn key() -> String {
    format!("{}:{}", settings::host(), settings::port())
}

fn same(a: &Value, user: &str) -> bool {
    a["username"].as_str().map(|u| u.eq_ignore_ascii_case(user)).unwrap_or(false)
}

/// Pastikan entri server, akun, dan blok "pindah" ada di Storage (password kosong, pindah mati) supaya bisa diisi lebih awal.
fn ensure_entry() {
    let mut root = storage::get(ID);
    let (k, user) = (key(), settings::username());
    let mut changed = false;
    if !root[&k].is_object() {
        root[&k] = json!({"akun": []});
        changed = true;
    }
    if !root[&k]["akun"].is_array() {
        root[&k]["akun"] = json!([]);
        changed = true;
    }
    let has = root[&k]["akun"].as_array().map(|a| a.iter().any(|x| same(x, &user))).unwrap_or(false);
    if !has {
        root[&k]["akun"].as_array_mut().unwrap().push(json!({"username": user, "password": ""}));
        changed = true;
        crate::log(format!("entri baru di Storage untuk {k}. Login manual sekali, password akan tersimpan otomatis."));
    }
    if !root[&k]["pindah"].is_object() {
        root[&k]["pindah"] = json!({"aktif": false, "slotHotbar": 1, "slotMenu": 0});
        changed = true;
    }
    if changed {
        storage::save(ID, root);
    }
}

fn password() -> Option<String> {
    let root = storage::get(ID);
    let user = settings::username();
    root[&key()]["akun"]
        .as_array()?
        .iter()
        .find(|a| same(a, &user))
        .and_then(|a| a["password"].as_str())
        .filter(|p| !p.is_empty())
        .map(|p| p.to_string())
}

fn save_password(pw: &str, why: &str) {
    ensure_entry();
    let mut root = storage::get(ID);
    let (k, user) = (key(), settings::username());
    if let Some(arr) = root[&k]["akun"].as_array_mut() {
        if let Some(a) = arr.iter_mut().find(|a| same(a, &user)) {
            if a["password"].as_str() == Some(pw) {
                return;
            }
            a["password"] = json!(pw);
        }
    }
    storage::save(ID, root);
    crate::log(format!("password untuk {user} disimpan di Storage ({why})"));
}

fn fill(tpl: &str, pw: &str) -> String {
    tpl.replace("{password}", pw).replace("{username}", &settings::username())
}

// ---------- pindah server lewat item menu ----------
// Storage per server: "pindah": {"aktif": true, "slotHotbar": 1..9, "slotMenu": 0..}
// Setelah login: pegang item hotbar nomor slotHotbar, klik kanan (pakai item), tunggu menu terbuka,
// lalu klik kiri slot nomor slotMenu (mulai 0, kiri atas) di menu itu.

fn pindah() -> Option<(usize, usize)> {
    let root = storage::get(ID);
    let p = &root[&key()]["pindah"];
    if !p["aktif"].as_bool().unwrap_or(false) {
        return None;
    }
    let hb = p["slotHotbar"].as_u64().unwrap_or(1).clamp(1, 9) as usize - 1;
    let slot = p["slotMenu"].as_u64().unwrap_or(0) as usize;
    Some((hb, slot))
}

/// Jumlah slot menu yang sedang terbuka (46 = hanya inventory sendiri).
fn menu_slots(bot: &Client) -> Option<Vec<ItemStack>> {
    super::monitor::handle_of(bot)?.slots()
}

async fn transfer(bot: Client) {
    if !settings::get_bool(ID, "auto_transfer") {
        return;
    }
    let Some((hb, slot)) = pindah() else { return };
    if TRANSFER_STARTED.swap(true, Ordering::SeqCst) {
        return;
    }
    let delay = settings::get_f64(ID, "transfer_delay").clamp(0.0, 60.0);
    tokio::time::sleep(Duration::from_millis((delay * 1000.0) as u64)).await;
    for attempt in 1..=3 {
        let held = menu_slots(&bot).and_then(|s| s.get(36 + hb).cloned());
        if !held.map(|i| i.is_present()).unwrap_or(false) {
            crate::log(format!("slot hotbar {} masih kosong (percobaan {attempt}), menunggu...", hb + 1));
            tokio::time::sleep(Duration::from_secs(2)).await;
            continue;
        }
        let _ = bot.set_selected_hotbar_slot(hb as u8);
        tokio::time::sleep(Duration::from_millis(300)).await;
        bot.start_use_item();
        // tunggu menu terbuka (jumlah slot berubah dari 46)
        let t0 = Instant::now();
        let mut opened = false;
        while t0.elapsed() < Duration::from_secs(6) {
            tokio::time::sleep(Duration::from_millis(200)).await;
            if menu_slots(&bot).map(|s| s.len() != 46).unwrap_or(false) {
                opened = true;
                break;
            }
        }
        if !opened {
            crate::log(format!("menu tidak terbuka (percobaan {attempt})"));
            tokio::time::sleep(Duration::from_secs(2)).await;
            continue;
        }
        crate::log("menu terbuka, menunggu isi menu");
        // tunggu isi menu terkirim
        let t1 = Instant::now();
        let mut target: Option<ItemStack> = None;
        while t1.elapsed() < Duration::from_secs(5) {
            if let Some(it) = menu_slots(&bot).and_then(|s| s.get(slot).cloned()) {
                if it.is_present() {
                    target = Some(it);
                    break;
                }
            }
            tokio::time::sleep(Duration::from_millis(250)).await;
        }
        let Some(item) = target else {
            crate::log(format!("slot {slot} kosong di menu itu (percobaan {attempt})"));
            if let Some(h) = super::monitor::handle_of(&bot) {
                h.close();
            }
            tokio::time::sleep(Duration::from_millis(1500)).await;
            continue;
        };
        if let Some(h) = super::monitor::handle_of(&bot) {
            h.left_click(slot);
            crate::log(format!("klik slot {slot} ({})", super::monitor::item_name(&item)));
        }
        return;
    }
    crate::log("pindah server gagal setelah 3 percobaan (cek nomor slot di Storage)");
}

// ---------- pengenalan pesan server ----------

fn has_any(t: &str, words: &[&str]) -> bool {
    words.iter().any(|w| t.contains(w))
}
const OK: &[&str] = &[
    "logged in as", "welcome back", "berhasil login", "berhasil masuk", "successfully logged",
    "successfully authenticated", "login success", "login berhasil", "[ success ]",
];
const ALREADY: &[&str] = &["already logged", "session is already active", "sudah login"];
const LOGIN: &[&str] = &["/login", "please login", "please log in", "silakan login", "silakan masuk"];
const REGISTER: &[&str] = &["/register", "please register", "silakan daftar", "silakan register"];
const FAIL: &[&str] = &[
    "wrong", "incorrect", "invalid", "salah", "gagal", "failed", "not registered", "belum terdaftar", "tidak terdaftar",
];

// ---------- aksi ----------

fn send_login(bot: &Client, why: &str) {
    if LOGIN_SENT.load(Ordering::SeqCst) || !settings::get_bool(ID, "auto_login") {
        return;
    }
    match password() {
        None => crate::log("password belum diisi di Storage, login tidak dikirim"),
        Some(pw) => {
            LOGIN_SENT.store(true, Ordering::SeqCst);
            bot.chat(fill(&settings::get_str(ID, "login_command"), &pw).as_str());
            crate::log(format!("login dikirim ({why})"));
        }
    }
}

fn send_register(bot: &Client) {
    if REGISTER_SENT.load(Ordering::SeqCst) || !settings::get_bool(ID, "auto_register") {
        return;
    }
    if let Some(pw) = password() {
        REGISTER_SENT.store(true, Ordering::SeqCst);
        bot.chat(fill(&settings::get_str(ID, "register_command"), &pw).as_str());
        crate::log("register dikirim");
    }
}

fn settle(ok: bool, why: &str) {
    let pw = PENDING.lock().unwrap().take();
    if let Some(pw) = pw {
        if ok {
            save_password(&pw, why);
        } else {
            crate::log("server menolak login itu, password tidak disimpan");
        }
    }
}

/// Dipanggil saat pengguna mengirim chat/perintah dari aplikasi: tangkap /login dan /register manual.
pub fn on_outgoing(text: &str) {
    if !settings::get_bool(ID, "auto_save") {
        return;
    }
    let parts: Vec<&str> = text.trim().trim_start_matches('/').split_whitespace().collect();
    let cmd = parts.first().map(|c| c.to_lowercase()).unwrap_or_default();
    if !text.trim().starts_with('/') || !["login", "l", "log", "register", "reg"].contains(&cmd.as_str()) {
        return;
    }
    if let Some(pw) = parts.get(1) {
        *PENDING.lock().unwrap() = Some(pw.to_string());
        crate::log(format!("perintah /{cmd} terdeteksi; password disimpan setelah server membalas sukses"));
        tokio::spawn(async {
            tokio::time::sleep(Duration::from_secs(12)).await;
            settle(true, "tanpa balasan gagal"); // balasan sukses tidak dikenali: simpan kalau tidak ada penolakan
        });
    }
}

async fn after_login(bot: Client) {
    let delay = settings::get_f64(ID, "login_delay").clamp(0.0, 60.0);
    tokio::time::sleep(Duration::from_millis((delay * 1000.0) as u64)).await;
    if settings::get_bool(ID, "auto_login") {
        if password().is_none() {
            crate::log("belum ada password tersimpan: login manual sekali (/login ...), nanti disimpan otomatis");
            return;
        }
        send_login(&bot, "terjadwal");
        // tunggu hasil login (maks 8 detik), lanjut ke pindah server apa pun hasilnya
        let t0 = Instant::now();
        while !LOGGED_IN.load(Ordering::SeqCst) && t0.elapsed() < Duration::from_secs(8) {
            tokio::time::sleep(Duration::from_millis(250)).await;
        }
    }
    transfer(bot).await;
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login => {
            // Pekerjaan yang menunggu (jeda login, tunggu hasil, pindah server) dijalankan terpisah.
            // Kalau ditunggu di sini, event lain (paket, tick, chat) menumpuk di antrean azalea.
            ensure_entry();
            let b = bot.clone();
            tokio::spawn(after_login(b));
        }
        Event::Chat(m) => {
            let t = m.message().to_string().to_lowercase();
            if PENDING.lock().unwrap().is_some() {
                if has_any(&t, FAIL) {
                    settle(false, "gagal");
                } else if has_any(&t, OK) {
                    settle(true, "login berhasil");
                }
            }
            if LOGIN_SENT.load(Ordering::SeqCst) && !LOGGED_IN.load(Ordering::SeqCst) && has_any(&t, FAIL) {
                crate::log("server menolak login dari password tersimpan; periksa password di Storage atau login manual lagi");
            }
            if has_any(&t, ALREADY) || has_any(&t, OK) {
                LOGGED_IN.store(true, Ordering::SeqCst);
                let b = bot.clone();
                tokio::spawn(transfer(b));
            } else if has_any(&t, LOGIN) {
                send_login(bot, "diminta server");
            } else if has_any(&t, REGISTER) {
                send_register(bot);
            }
        }
        _ => {}
    }
}
