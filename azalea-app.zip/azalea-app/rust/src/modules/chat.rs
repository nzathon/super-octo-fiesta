// Modul Chat: meneruskan chat server (berwarna, kode ANSI) ke layar Chat aplikasi.
use azalea::prelude::*;
use serde_json::json;

use super::{Def, Setting};
use crate::settings;

pub fn def() -> Def {
    Def {
        id: "chat",
        title: "Chat",
        desc: "Menampilkan chat server berwarna (termasuk warna hex) di tab Chat. Kotak kirim ada di tab yang sama.",
        enabled: true,
        settings: vec![Setting {
            key: "filter_glyph",
            label: "Buang karakter glyph font kustom",
            kind: "boolean",
            default: json!(true),
        }],
    }
}

pub async fn on_event(_bot: &Client, event: &Event) {
    if let Event::Chat(m) = event {
        let raw = m.message().to_ansi();
        let t = if settings::get_bool("chat", "filter_glyph") { crate::clean(&raw) } else { raw };
        if !t.trim().is_empty() {
            crate::out(json!({"t": "chat", "v": t}));
        }
    }
}
