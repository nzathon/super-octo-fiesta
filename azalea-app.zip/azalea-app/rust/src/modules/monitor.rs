// Modul Monitor: isi inventory (atau menu server yang sedang terbuka) dikirim ke tab Inventory aplikasi,
// dan aksi dari tab itu (klik kiri/kanan/shift, pilih & pakai item hotbar, tutup menu) dijalankan di sini.
// Pipa: keluar {"t":"inv",...} dan {"t":"detail",...}; masuk {"t":"inv","a":aksi,"slot":n} (lihat main.rs).
//
// Catatan API (docs azalea.rs, 0.16.0+mc26.2):
// - Client::get_inventory() -> handle ke container yang sedang terbuka, atau inventory sendiri.
// - ContainerHandleRef: slots(), title(), left_click(), right_click(), shift_click(), close().
// - Client::set_selected_hotbar_slot(u8), Client::start_use_item().
// Versi rilis dan versi git berbeda soal pembungkus Result; trait `Soft` di bawah menampung dua-duanya.
use std::sync::Mutex;
use std::time::{Duration, Instant};

use azalea::container::ContainerHandleRef;
use azalea::entity::inventory::Inventory;
use azalea::inventory::ItemStack;
use azalea::prelude::*;
use serde_json::{json, Value};

use super::{Def, Setting};
use crate::settings;

const ID: &str = "monitor";
/// Menu inventory pemain selalu 46 slot; container lain lebih/kurang dari itu.
const PLAYER_MENU_LEN: usize = 46;

static LAST_JSON: Mutex<String> = Mutex::new(String::new());
static LAST_AT: Mutex<Option<Instant>> = Mutex::new(None);

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Monitor (Inventory)",
        desc: "Menampilkan inventory dan menu server di tab Inventory, bisa diklik (kiri, kanan, shift), \
pilih/pakai item hotbar, dan tutup menu.",
        enabled: true,
        settings: vec![Setting {
            key: "interval",
            label: "Jeda pembaruan (detik)",
            kind: "number",
            default: json!(0.5),
        }],
    }
}

// ---------- penampung supaya cocok dengan versi API yang mengembalikan Result maupun nilai langsung ----------

pub trait Soft<T> {
    fn soft(self) -> Option<T>;
}
impl<T, E> Soft<T> for Result<T, E> {
    fn soft(self) -> Option<T> {
        self.ok()
    }
}
impl Soft<ContainerHandleRef> for ContainerHandleRef {
    fn soft(self) -> Option<ContainerHandleRef> {
        Some(self)
    }
}
impl Soft<u8> for u8 {
    fn soft(self) -> Option<u8> {
        Some(self)
    }
}

pub fn handle_of(bot: &Client) -> Option<ContainerHandleRef> {
    bot.get_inventory().soft()
}

// ---------- pengubah data ----------

/// "DiamondPickaxe" -> "diamond_pickaxe"
fn snake(s: &str) -> String {
    let mut out = String::new();
    for (i, c) in s.chars().enumerate() {
        if c.is_ascii_uppercase() && i > 0 {
            out.push('_');
        }
        out.push(c.to_ascii_lowercase());
    }
    out
}

pub fn item_name(s: &ItemStack) -> String {
    snake(&format!("{:?}", s.kind()))
}

fn slot_json(s: &ItemStack) -> Value {
    match s.as_present() {
        Some(d) if s.is_present() => json!({"n": snake(&format!("{:?}", d.kind)), "c": d.count}),
        _ => Value::Null,
    }
}

fn snapshot(bot: &Client) -> Option<Value> {
    let h = handle_of(bot)?;
    let slots = h.slots()?;
    let len = slots.len();
    if len < 9 + 27 {
        return None;
    }
    let gui = len != PLAYER_MENU_LEN;
    let hot = if gui { len - 9 } else { 36 };
    let inv = hot - 27;
    let title = if gui {
        h.title().map(|t| crate::clean(&t.to_ansi())).unwrap_or_else(|| "Menu server".into())
    } else {
        String::new()
    };
    let held = bot.selected_hotbar_slot().soft().unwrap_or(0);
    let cursor = bot.component::<Inventory>().ok().map(|i| slot_json(&i.carried)).unwrap_or(Value::Null);
    Some(json!({
        "t": "inv", "gui": gui, "title": title, "inv": inv, "hot": hot, "held": held,
        "slots": slots.iter().map(slot_json).collect::<Vec<_>>(),
        "cursor": cursor,
    }))
}

fn push(bot: &Client, force: bool) {
    let Some(v) = snapshot(bot) else { return };
    let s = v.to_string();
    {
        let mut last = LAST_JSON.lock().unwrap();
        if !force && *last == s {
            return;
        }
        *last = s;
    }
    crate::out(v);
}

// ---------- event dan aksi ----------

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login | Event::Spawn => LAST_JSON.lock().unwrap().clear(),
        Event::Tick => {
            let every = Duration::from_millis((settings::get_f64(ID, "interval").max(0.2) * 1000.0) as u64);
            {
                let mut g = LAST_AT.lock().unwrap();
                if g.as_ref().map(|t| t.elapsed() < every).unwrap_or(false) {
                    return;
                }
                *g = Some(Instant::now());
            }
            push(bot, false);
        }
        _ => {}
    }
}

/// Aksi dari aplikasi: {"t":"inv","a":"left|right|shift|select|use|close|detail","slot":n}
pub fn on_action(bot: &Client, v: &Value) {
    let a = v["a"].as_str().unwrap_or("");
    let slot = v["slot"].as_u64().unwrap_or(0) as usize;
    match a {
        "left" | "right" | "shift" => {
            if let Some(h) = handle_of(bot) {
                match a {
                    "left" => h.left_click(slot),
                    "right" => h.right_click(slot),
                    _ => h.shift_click(slot),
                }
            }
        }
        "select" => {
            let _ = bot.set_selected_hotbar_slot(slot.min(8) as u8);
        }
        "use" => {
            let _ = bot.set_selected_hotbar_slot(slot.min(8) as u8);
            let b = bot.clone();
            tokio::spawn(async move {
                tokio::time::sleep(Duration::from_millis(300)).await;
                b.start_use_item();
            });
        }
        "close" => {
            if let Some(h) = handle_of(bot) {
                if h.slots().map(|s| s.len() != PLAYER_MENU_LEN).unwrap_or(false) {
                    h.close();
                }
            }
        }
        "detail" => {
            let raw = handle_of(bot)
                .and_then(|h| h.slots())
                .and_then(|s| s.get(slot).cloned())
                .map(|s| match s.as_present() {
                    Some(d) if s.is_present() => format!("{d:#?}"),
                    _ => "(kosong)".to_string(),
                })
                .unwrap_or_else(|| "(slot tidak ada)".to_string());
            crate::out(json!({"t": "detail", "slot": slot, "v": raw}));
            return;
        }
        _ => return,
    }
    // susulan supaya tampilan cepat menyusul hasil aksi
    let b = bot.clone();
    tokio::spawn(async move {
        tokio::time::sleep(Duration::from_millis(400)).await;
        push(&b, true);
    });
}
