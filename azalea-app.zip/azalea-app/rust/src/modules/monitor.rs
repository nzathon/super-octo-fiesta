use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use azalea::chat::style::Style as ChatStyle;
use azalea::container::ContainerHandleRef;
use azalea::core::game_type::GameMode;
use azalea::entity::ActiveEffects;
use azalea::entity::inventory::Inventory;
use azalea::inventory::components::{
    CustomName, Damage, EnchantmentGlintOverride, Enchantments, ItemName, Lore, MaxDamage,
    PartialOrFullProfile, PotionContents, Profile, StoredEnchantments,
};
use azalea::inventory::operations::{CloneClick, SwapClick, ThrowClick};
use azalea::inventory::{ItemStack, ItemStackData};
use azalea::prelude::*;
use azalea::protocol::packets::game::ClientboundGamePacket;
use azalea::protocol::packets::game::c_boss_event::{BossBarColor, Operation as BossOp};
use azalea::registry::DataRegistryKey;
use azalea::FormattedText;
use serde_json::{json, Value};

use super::{Def, Setting};
use crate::settings;

const ID: &str = "monitor";
/// Menu inventory pemain selalu 46 slot; container lain lebih/kurang dari itu.
const PLAYER_MENU_LEN: usize = 46;

static LAST_INV_JSON: Mutex<String> = Mutex::new(String::new());
static LAST_STATUS_JSON: Mutex<String> = Mutex::new(String::new());
static LAST_TICK_AT: Mutex<Option<Instant>> = Mutex::new(None);
static EFFECT_TRACK: Mutex<Option<HashMap<String, (i32, i32, Instant)>>> = Mutex::new(None);
static BOSS_BARS: Mutex<Vec<BossEntry>> = Mutex::new(Vec::new());
static FEED_STATE: Mutex<Option<FeedState>> = Mutex::new(None);

#[derive(Clone)]
struct BossEntry {
    id: u128,
    title: Vec<Value>,
    hp: f32,
    color: &'static str,
}

#[derive(Default, Clone)]
struct FeedChannel {
    cur: Option<Vec<Value>>,
    hist: Vec<FeedHistItem>,
    last_text: String,
    last_at: Option<Instant>,
}

#[derive(Clone)]
struct FeedHistItem {
    ts: u64,
    spans: Vec<Value>,
}

#[derive(Default, Clone)]
struct FeedState {
    bar: FeedChannel,
    title: FeedChannel,
    subtitle: FeedChannel,
}

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Monitor (Inventory & Status)",
        desc: "Menampilkan inventory, menu server, detail/lore item, HP/lapar/XP, efek, bossbar, dan action bar/title.",
        enabled: true,
        settings: vec![
            Setting { key: "interval", label: "Jeda pembaruan (detik)", kind: "number", default: json!(0.5) },
            Setting { key: "show_inv", label: "Tampilkan inventory", kind: "boolean", default: json!(true) },
            Setting { key: "show_status", label: "Tampilkan HP/lapar/XP", kind: "boolean", default: json!(true) },
            Setting { key: "show_effects", label: "Tampilkan efek", kind: "boolean", default: json!(true) },
            Setting { key: "show_boss", label: "Tampilkan bossbar", kind: "boolean", default: json!(true) },
            Setting { key: "show_bar", label: "Tampilkan action bar", kind: "boolean", default: json!(true) },
            Setting { key: "show_title", label: "Tampilkan title", kind: "boolean", default: json!(true) },
            Setting { key: "show_subtitle", label: "Tampilkan subtitle", kind: "boolean", default: json!(true) },
            Setting { key: "icons", label: "Ikon item (dari internet)", kind: "boolean", default: json!(true) },
            Setting { key: "skin", label: "Skin pemain", kind: "boolean", default: json!(true) },
            Setting {
                key: "icon_src",
                label: "Sumber ikon (pisah koma, {name} = id item)",
                kind: "text",
                default: json!("https://blocksitems.com/api/v2/items/minecraft:{name}/icon.png?size=64, https://blocksitems.com/api/v2/blocks/minecraft:{name}/render.png?angle=iso&size=64, https://assets.mcasset.cloud/26.2/assets/minecraft/textures/item/{name}.png, https://assets.mcasset.cloud/26.2/assets/minecraft/textures/block/{name}.png"),
            },
            Setting {
                key: "skin_src",
                label: "Sumber gambar pemain ({name} = username)",
                kind: "text",
                default: json!("https://mc-heads.net/body/{name}, https://minotar.net/armor/body/{name}/120.png"),
            },
            Setting { key: "history", label: "Riwayat teks (jumlah)", kind: "number", default: json!(15) },
            Setting { key: "double_tap", label: "Ketuk 2x slot = klik (left/right/middle/shift/off)", kind: "text", default: json!("left") },
        ],
    }
}

// ---------- penampung supaya cocok dengan versi API yang mengembalikan Result maupun nilai langsung ----------

pub trait Soft<T> {
    fn soft(self) -> Option<T>;
}
impl<T, E> Soft<T> for Result<T, E> {
    fn soft(self) -> Option<T> {
        self.ok()
    }
}
impl Soft<ContainerHandleRef> for ContainerHandleRef {
    fn soft(self) -> Option<ContainerHandleRef> {
        Some(self)
    }
}
impl Soft<u8> for u8 {
    fn soft(self) -> Option<u8> {
        Some(self)
    }
}

pub fn handle_of(bot: &Client) -> Option<ContainerHandleRef> {
    bot.get_inventory().soft()
}

// ---------- utilitas teks & warna ----------

fn snake(s: &str) -> String {
    let mut out = String::new();
    for (i, c) in s.chars().enumerate() {
        if c.is_ascii_uppercase() && i > 0 {
            out.push('_');
        }
        out.push(c.to_ascii_lowercase());
    }
    out
}

pub fn item_name(s: &ItemStack) -> String {
    let raw = s.kind().to_string();
    if let Some(stripped) = raw.strip_prefix("minecraft:") {
        stripped.to_string()
    } else if !raw.is_empty() {
        raw
    } else {
        snake(&format!("{:?}", s.kind()))
    }
}

fn title_case_words(s: &str) -> String {
    s.split('_')
        .filter(|w| !w.is_empty())
        .map(|w| {
            let mut ch = w.chars();
            match ch.next() {
                Some(first) => format!("{}{}", first.to_ascii_uppercase(), ch.as_str()),
                None => String::new(),
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

#[derive(Clone, Default, PartialEq)]
struct SpanStyle {
    c: Option<String>,
    b: bool,
    i: bool,
}

fn legacy_color_hex(code: char) -> Option<&'static str> {
    Some(match code {
        '0' => "#000000",
        '1' => "#0000aa",
        '2' => "#00aa00",
        '3' => "#00aaaa",
        '4' => "#aa0000",
        '5' => "#aa00aa",
        '6' => "#ffaa00",
        '7' => "#aaaaaa",
        '8' => "#555555",
        '9' => "#5555ff",
        'a' => "#55ff55",
        'b' => "#55ffff",
        'c' => "#ff5555",
        'd' => "#ff55ff",
        'e' => "#ffff55",
        'f' => "#ffffff",
        _ => return None,
    })
}

fn push_span_piece(out: &mut Vec<(String, SpanStyle)>, text: &str, style: &SpanStyle) {
    let cleaned = crate::clean(text);
    if cleaned.is_empty() {
        return;
    }
    if let Some((last_text, last_style)) = out.last_mut() {
        if last_style == style {
            last_text.push_str(&cleaned);
            return;
        }
    }
    out.push((cleaned, style.clone()));
}

fn push_legacy_text(out: &mut Vec<(String, SpanStyle)>, text: &str, base: &SpanStyle) {
    let mut cur = base.clone();
    let mut buf = String::new();
    let mut chars = text.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '§' {
            if let Some(&next) = chars.peek() {
                let code = next.to_ascii_lowercase();
                if let Some(hex) = legacy_color_hex(code) {
                    if !buf.is_empty() {
                        push_span_piece(out, &buf, &cur);
                        buf.clear();
                    }
                    cur = base.clone();
                    cur.c = Some(hex.to_string());
                    chars.next();
                    continue;
                } else if code == 'r' {
                    if !buf.is_empty() {
                        push_span_piece(out, &buf, &cur);
                        buf.clear();
                    }
                    cur = base.clone();
                    chars.next();
                    continue;
                } else if code == 'l' {
                    if !buf.is_empty() {
                        push_span_piece(out, &buf, &cur);
                        buf.clear();
                    }
                    cur.b = true;
                    chars.next();
                    continue;
                } else if code == 'o' {
                    if !buf.is_empty() {
                        push_span_piece(out, &buf, &cur);
                        buf.clear();
                    }
                    cur.i = true;
                    chars.next();
                    continue;
                } else if matches!(code, 'k' | 'm' | 'n') {
                    chars.next();
                    continue;
                }
            }
        }
        buf.push(ch);
    }
    if !buf.is_empty() {
        push_span_piece(out, &buf, &cur);
    }
}

fn merge_chat_style(parent: &ChatStyle, cur: &ChatStyle) -> ChatStyle {
    parent.merged_with(cur)
}

fn to_span_style(st: &ChatStyle) -> SpanStyle {
    SpanStyle {
        c: st.color.as_ref().map(|c| c.format_value().to_ascii_lowercase()),
        b: st.bold.unwrap_or(false),
        i: st.italic.unwrap_or(false),
    }
}

fn collect_spans(ft: &FormattedText, parent: &ChatStyle, out: &mut Vec<(String, SpanStyle)>) {
    let base = ft.get_base();
    let merged = merge_chat_style(parent, &base.style);
    let span_style = to_span_style(&merged);
    match ft {
        FormattedText::Text(c) => {
            if !c.text.is_empty() {
                push_legacy_text(out, &c.text, &span_style);
            }
        }
        FormattedText::Translatable(c) => match c.read() {
            Ok(resolved) => {
                let mut inner_parent = merged.clone();
                // resolved.base.style already reflects c.base.style; keep merged as parent
                let resolved_style = merge_chat_style(&inner_parent, &resolved.base.style);
                if !resolved.text.is_empty() {
                    push_legacy_text(out, &resolved.text, &to_span_style(&resolved_style));
                }
                inner_parent = resolved_style;
                for sib in &resolved.base.siblings {
                    collect_spans(sib, &inner_parent, out);
                }
            }
            Err(_) => {
                let fallback = c.fallback.as_deref().unwrap_or(&c.key);
                push_legacy_text(out, fallback, &span_style);
            }
        },
    }
    for sib in &base.siblings {
        collect_spans(sib, &merged, out);
    }
}

fn spans_of(ft: &FormattedText) -> Vec<Value> {
    let mut raw = Vec::new();
    collect_spans(ft, &ChatStyle::default(), &mut raw);
    raw.into_iter()
        .map(|(t, st)| {
            let mut m = serde_json::Map::new();
            m.insert("t".into(), Value::String(t));
            if let Some(c) = st.c {
                m.insert("c".into(), Value::String(c));
            }
            if st.b {
                m.insert("b".into(), Value::Bool(true));
            }
            if st.i {
                m.insert("i".into(), Value::Bool(true));
            }
            Value::Object(m)
        })
        .collect()
}

fn plain_of_spans(spans: &[Value]) -> String {
    let mut s = String::new();
    for sp in spans {
        if let Some(t) = sp["t"].as_str() {
            s.push_str(t);
        }
    }
    s
}

// ---------- base64 & skull texture hash ----------

fn decode_base64_utf8(input: &str) -> Option<String> {
    let mut bytes = Vec::with_capacity(input.len() * 3 / 4);
    let mut buf: u32 = 0;
    let mut bits: u8 = 0;
    for b in input.bytes() {
        if b.is_ascii_whitespace() {
            continue;
        }
        if b == b'=' {
            break;
        }
        let val = match b {
            b'A'..=b'Z' => b - b'A',
            b'a'..=b'z' => b - b'a' + 26,
            b'0'..=b'9' => b - b'0' + 52,
            b'+' => 62,
            b'/' => 63,
            _ => return None,
        };
        buf = (buf << 6) | (val as u32);
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            bytes.push(((buf >> bits) & 0xff) as u8);
        }
    }
    String::from_utf8(bytes).ok()
}

fn extract_texture_hash_from_str(s: &str) -> Option<String> {
    let needle = "textures.minecraft.net/texture/";
    let pos = s.find(needle)?;
    let rest = &s[pos + needle.len()..];
    let hash: String = rest.chars().take_while(|c| c.is_ascii_alphanumeric()).collect();
    if hash.len() >= 16 { Some(hash) } else { None }
}

fn skull_hash(d: &ItemStackData) -> Option<String> {
    let profile = d.get_component::<Profile>()?;
    let props = match profile.unpack.as_ref() {
        PartialOrFullProfile::Full(gp) => &gp.properties,
        PartialOrFullProfile::Partial(pp) => &pp.properties,
    };
    if let Some(tex) = props.map.get("textures") {
        if let Some(h) = extract_texture_hash_from_str(&tex.value) {
            return Some(h);
        }
        if let Some(decoded) = decode_base64_utf8(&tex.value) {
            if let Some(h) = extract_texture_hash_from_str(&decoded) {
                return Some(h);
            }
        }
    }
    None
}

// ---------- potion color & durability ----------

fn potion_hex(key: &str) -> u32 {
    match key {
        "water" | "awkward" | "mundane" | "thick" => 0x385dc6,
        "fire_resistance" | "long_fire_resistance" => 0xff9900,
        "harming" | "strong_harming" => 0xa9656a,
        "healing" | "strong_healing" => 0xf82423,
        "infested" => 0x8c9b8c,
        "invisibility" | "long_invisibility" => 0xf6f6f6,
        "leaping" | "long_leaping" | "strong_leaping" => 0xfdff84,
        "luck" => 0x59c106,
        "night_vision" | "long_night_vision" => 0xc2ff66,
        "oozing" => 0x99ffa3,
        "poison" | "long_poison" | "strong_poison" => 0x87a363,
        "regeneration" | "long_regeneration" | "strong_regeneration" => 0xcd5cab,
        "slow_falling" | "long_slow_falling" => 0xf3cfb9,
        "slowness" | "long_slowness" | "strong_slowness" => 0x8bafe0,
        "strength" | "long_strength" | "strong_strength" => 0xffc700,
        "swiftness" | "long_swiftness" | "strong_swiftness" => 0x33ebff,
        "turtle_master" | "long_turtle_master" | "strong_turtle_master" => 0x8b67b0,
        "water_breathing" | "long_water_breathing" => 0x98dac0,
        "weakness" | "long_weakness" => 0x484d48,
        "weaving" => 0x78695a,
        "wind_charged" => 0xbdc9ff,
        _ => 0x385dc6,
    }
}

fn potion_color(name: &str, d: &ItemStackData) -> Option<String> {
    if !matches!(name, "potion" | "splash_potion" | "lingering_potion" | "tipped_arrow") {
        return None;
    }
    let pc = d.get_component::<PotionContents>()?;
    if let Some(rgb) = pc.custom_color {
        return Some(format!("#{:06x}", (rgb as u32) & 0xFFFFFF));
    }
    if let Some(p) = pc.potion {
        let s = p.to_string();
        let key = s.strip_prefix("minecraft:").unwrap_or(&s);
        return Some(format!("#{:06x}", potion_hex(key)));
    }
    None
}

fn base_max(name: &str) -> Option<i64> {
    let (mat, part) = name.split_once('_')?;
    let tool = |m: &str| match m {
        "netherite" => Some(2031),
        "diamond" => Some(1561),
        "iron" => Some(250),
        "golden" => Some(32),
        "stone" => Some(131),
        "wooden" => Some(59),
        "copper" => Some(190),
        _ => None,
    };
    let armor = |m: &str, p: &str| {
        let (a, b, c, d) = match m {
            "netherite" => (407, 592, 555, 481),
            "diamond" => (363, 528, 495, 429),
            "iron" => (165, 240, 225, 195),
            "golden" => (77, 112, 105, 91),
            "chainmail" => (165, 240, 225, 195),
            "leather" => (55, 80, 75, 65),
            "copper" => (121, 176, 165, 143),
            _ => return None,
        };
        match p {
            "helmet" => Some(a),
            "chestplate" => Some(b),
            "leggings" => Some(c),
            "boots" => Some(d),
            _ => None,
        }
    };
    match part {
        "pickaxe" | "axe" | "shovel" | "hoe" | "sword" => tool(mat),
        "helmet" | "chestplate" | "leggings" | "boots" => armor(mat, part),
        _ => match name {
            "elytra" => Some(432),
            "shears" => Some(238),
            "fishing_rod" => Some(64),
            "bow" => Some(384),
            "crossbow" => Some(465),
            "trident" => Some(250),
            "shield" => Some(336),
            "flint_and_steel" => Some(64),
            "turtle_helmet" => Some(275),
            "mace" => Some(500),
            _ => None,
        },
    }
}

struct Extra {
    enchanted: bool,
    dur: Option<[i64; 2]>,
    title: Vec<Value>,
    label: String,
    lore: Vec<Vec<Value>>,
    ench: Vec<(String, i64)>,
    hash: Option<String>,
    pot: Option<String>,
}

fn extra_of(bot: Option<&Client>, name: &str, d: &ItemStackData) -> Extra {
    let mut enchanted = false;
    let mut ench = Vec::new();

    if let Some(e) = d.get_component::<Enchantments>() {
        if !e.levels.is_empty() {
            enchanted = true;
            for (k, &lvl) in &e.levels {
                let ename = bot
                    .and_then(|b| b.resolve_registry_key(k).ok().flatten())
                    .map(|rk| rk.into_ident().path().to_string())
                    .unwrap_or_else(|| format!("ench#{}", k.protocol_id()));
                ench.push((ename, lvl as i64));
            }
        }
    }
    if let Some(e) = d.get_component::<StoredEnchantments>() {
        if !e.enchantments.is_empty() {
            enchanted = true;
            for (k, &lvl) in &e.enchantments {
                let ename = bot
                    .and_then(|b| b.resolve_registry_key(k).ok().flatten())
                    .map(|rk| rk.into_ident().path().to_string())
                    .unwrap_or_else(|| format!("ench#{}", k.protocol_id()));
                ench.push((ename, lvl as i64));
            }
        }
    }
    if let Some(glint) = d.get_component::<EnchantmentGlintOverride>() {
        enchanted = glint.show_glint;
    }

    let dmg = d.get_component::<Damage>().map(|x| x.amount as i64);
    let max = d.get_component::<MaxDamage>().map(|x| x.amount as i64);
    let dur = match (dmg, max.or_else(|| base_max(name))) {
        (Some(dm), Some(mx)) if dm > 0 && mx > 0 => Some([dm, mx]),
        _ => None,
    };

    let title = d
        .get_component::<CustomName>()
        .map(|c| spans_of(&c.name))
        .or_else(|| d.get_component::<ItemName>().map(|c| spans_of(&c.name)))
        .unwrap_or_default();
    let label = plain_of_spans(&title);

    let lore = d
        .get_component::<Lore>()
        .map(|l| l.lines.iter().map(spans_of).collect())
        .unwrap_or_default();

    let hash = if name == "player_head" {
        skull_hash(d)
    } else {
        None
    };
    let pot = potion_color(name, d);

    Extra {
        enchanted,
        dur,
        title,
        label,
        lore,
        ench,
        hash,
        pot,
    }
}

fn slot_json(s: &ItemStack) -> Value {
    match s.as_present() {
        Some(d) if s.is_present() => {
            let name = item_name(s);
            let x = extra_of(None, &name, d);
            let mut v = json!({"n": name, "c": d.count, "e": x.enchanted});
            if let Some(du) = x.dur {
                v["d"] = json!(du);
            }
            if !x.label.is_empty() {
                v["t"] = json!(x.label);
            }
            if let Some(h) = x.hash {
                v["hash"] = json!(h);
            }
            if let Some(p) = x.pot {
                v["pot"] = json!(p);
            }
            v
        }
        _ => Value::Null,
    }
}

fn snapshot_inv(bot: &Client) -> Option<Value> {
    let h = handle_of(bot)?;
    let slots = h.slots()?;
    let len = slots.len();
    if len < 9 + 27 {
        return None;
    }
    let gui = len != PLAYER_MENU_LEN;
    let hot = if gui { len - 9 } else { 36 };
    let inv = hot - 27;
    let title = if gui {
        h.title().map(|t| crate::clean(&t.to_string())).unwrap_or_else(|| "Menu server".into())
    } else {
        String::new()
    };
    let held = bot.selected_hotbar_slot().soft().unwrap_or(0);
    let cursor = bot.component::<Inventory>().ok().map(|i| slot_json(&i.carried)).unwrap_or(Value::Null);
    Some(json!({
        "t": "inv", "type": "inv", "gui": gui, "title": title, "inv": inv, "hot": hot, "held": held,
        "slots": slots.iter().map(slot_json).collect::<Vec<_>>(),
        "cursor": cursor,
    }))
}

fn push_inv(bot: &Client, force: bool) {
    if !settings::get_bool(ID, "show_inv") {
        return;
    }
    let Some(v) = snapshot_inv(bot) else { return };
    let s = v.to_string();
    {
        let mut last = LAST_INV_JSON.lock().unwrap();
        if !force && *last == s {
            return;
        }
        *last = s;
    }
    crate::out(v);
}

// ---------- status, efek, bossbar ----------

fn roman_lvl(amp: i32) -> String {
    let lvl = amp + 1;
    match lvl {
        1 => "I".into(),
        2 => "II".into(),
        3 => "III".into(),
        4 => "IV".into(),
        5 => "V".into(),
        6 => "VI".into(),
        7 => "VII".into(),
        8 => "VIII".into(),
        9 => "IX".into(),
        10 => "X".into(),
        n => n.to_string(),
    }
}

fn effects_list(bot: &Client) -> Vec<Value> {
    let Ok(active) = bot.component::<ActiveEffects>() else {
        return Vec::new();
    };
    let mut track = EFFECT_TRACK.lock().unwrap();
    let map = track.get_or_insert_with(HashMap::new);
    let now = Instant::now();
    let mut active_keys = Vec::new();
    let mut out = Vec::new();

    for (eff, data) in &active.0 {
        let raw_id = eff.to_string();
        let short = raw_id.strip_prefix("minecraft:").unwrap_or(&raw_id);
        active_keys.push(short.to_string());
        let entry = map.entry(short.to_string()).or_insert((data.amplifier, data.duration, now));
        if entry.0 != data.amplifier || entry.1 != data.duration {
            *entry = (data.amplifier, data.duration, now);
        }
        let ms = if data.duration < 0 {
            Value::Null
        } else {
            let total_ms = (data.duration as i64) * 50;
            let elapsed = entry.2.elapsed().as_millis() as i64;
            json!((total_ms - elapsed).max(0))
        };
        let label = format!("{} {}", title_case_words(short), roman_lvl(data.amplifier));
        out.push(json!({ "name": label, "ms": ms }));
    }
    map.retain(|k, _| active_keys.contains(k));
    out
}

fn boss_color_hex(c: BossBarColor) -> &'static str {
    match c {
        BossBarColor::Pink => "#ff6fb5",
        BossBarColor::Blue => "#4c8bf5",
        BossBarColor::Red => "#e5493a",
        BossBarColor::Green => "#4cd964",
        BossBarColor::Yellow => "#ffd60a",
        BossBarColor::Purple => "#a45bd6",
        BossBarColor::White => "#ffffff",
    }
}

fn snapshot_status(bot: &Client) -> Value {
    let mut s = json!({ "t": "mon_status", "type": "status" });
    if settings::get_bool(ID, "show_status") {
        s["hp"] = bot.health().ok().map(|v| json!(v)).unwrap_or(Value::Null);
        if let Ok(h) = bot.hunger() {
            s["food"] = json!(h.food);
            s["sat"] = json!(h.saturation);
        } else {
            s["food"] = Value::Null;
            s["sat"] = Value::Null;
        }
        if let Ok(xp) = bot.experience() {
            s["xp"] = json!({ "level": xp.level, "progress": xp.progress, "points": xp.total });
        } else {
            s["xp"] = json!({ "level": 0, "progress": 0.0, "points": 0 });
        }

        let pos_part = bot
            .position()
            .ok()
            .map(|p| format!("x {:.1}  y {:.1}  z {:.1}", p.x, p.y, p.z))
            .unwrap_or_default();
        let dim_part = bot
            .world_name()
            .ok()
            .map(|w| {
                let s = w.to_string();
                s.strip_prefix("minecraft:").unwrap_or(&s).to_string()
            })
            .unwrap_or_else(|| "?".into());
        let mode_part = bot
            .component::<GameMode>()
            .ok()
            .map(|g| format!("{:?}", *g).to_lowercase())
            .unwrap_or_else(|| "?".into());
        let ping_part = bot
            .tab_list()
            .ok()
            .and_then(|t| t.get(&bot.uuid()).map(|p| format!("  |  ping {} ms", p.latency)))
            .unwrap_or_default();
        s["info"] = json!(if pos_part.is_empty() {
            String::new()
        } else {
            format!("{pos_part}  |  {dim_part}  |  {mode_part}{ping_part}")
        });
    }
    s["effects"] = if settings::get_bool(ID, "show_effects") {
        Value::Array(effects_list(bot))
    } else {
        json!([])
    };
    s["boss"] = if settings::get_bool(ID, "show_boss") {
        let bars = BOSS_BARS.lock().unwrap();
        Value::Array(
            bars.iter()
                .map(|b| json!({ "title": b.title, "hp": b.hp, "color": b.color }))
                .collect(),
        )
    } else {
        json!([])
    };
    s
}

fn push_status(bot: &Client, force: bool) {
    let v = snapshot_status(bot);
    let s = v.to_string();
    {
        let mut last = LAST_STATUS_JSON.lock().unwrap();
        if !force && *last == s {
            return;
        }
        *last = s;
    }
    crate::out(v);
}

// ---------- feed teks dari server (action bar, title, subtitle) ----------

fn now_epoch_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

fn feed_json(state: &FeedState) -> Value {
    let ser_ch = |ch: &FeedChannel| {
        json!({
            "cur": ch.cur.as_ref().map(|v| Value::Array(v.clone())).unwrap_or(Value::Null),
            "hist": ch.hist.iter().map(|h| json!({ "ts": h.ts, "spans": h.spans })).collect::<Vec<_>>()
        })
    };
    json!({
        "t": "mon_feed",
        "type": "feed",
        "feed": {
            "bar": ser_ch(&state.bar),
            "title": ser_ch(&state.title),
            "subtitle": ser_ch(&state.subtitle),
        }
    })
}

fn push_feed_entry(kind: &str, ft: &FormattedText) {
    let setting_key = match kind {
        "bar" => "show_bar",
        "title" => "show_title",
        "subtitle" => "show_subtitle",
        _ => return,
    };
    if !settings::get_bool(ID, setting_key) {
        return;
    }
    let spans = spans_of(ft);
    let text = plain_of_spans(&spans);
    let now = Instant::now();
    let max_hist = (settings::get_f64(ID, "history") as usize).clamp(1, 100);

    let out = {
        let mut guard = FEED_STATE.lock().unwrap();
        let state = guard.get_or_insert_with(FeedState::default);
        let ch = match kind {
            "bar" => &mut state.bar,
            "title" => &mut state.title,
            _ => &mut state.subtitle,
        };
        if ch.last_text == text
            && ch.last_at.map(|t| now.duration_since(t) < Duration::from_millis(400)).unwrap_or(false)
        {
            return;
        }
        ch.last_text = text.clone();
        ch.last_at = Some(now);
        ch.cur = Some(spans.clone());
        if !text.trim().is_empty() {
            ch.hist.push(FeedHistItem {
                ts: now_epoch_ms(),
                spans,
            });
            while ch.hist.len() > max_hist {
                ch.hist.remove(0);
            }
        }
        feed_json(state)
    };
    crate::out(out);
}

fn clear_feed() {
    let out = {
        let mut guard = FEED_STATE.lock().unwrap();
        let state = guard.get_or_insert_with(FeedState::default);
        state.bar = FeedChannel::default();
        state.title = FeedChannel::default();
        state.subtitle = FeedChannel::default();
        feed_json(state)
    };
    crate::out(out);
}

// ---------- paket, event, dan aksi ----------

pub fn on_packet(bot: &Client, packet: &ClientboundGamePacket) {
    match packet {
        ClientboundGamePacket::BossEvent(p) => {
            let id = p.id.as_u128();
            let mut changed = false;
            {
                let mut bars = BOSS_BARS.lock().unwrap();
                match &p.operation {
                    BossOp::Add(add) => {
                        let entry = BossEntry {
                            id,
                            title: spans_of(&add.name),
                            hp: add.progress,
                            color: boss_color_hex(add.style.color),
                        };
                        if let Some(pos) = bars.iter().position(|b| b.id == id) {
                            bars[pos] = entry;
                        } else {
                            bars.push(entry);
                        }
                        changed = true;
                    }
                    BossOp::Remove => {
                        let before = bars.len();
                        bars.retain(|b| b.id != id);
                        changed = bars.len() != before;
                    }
                    BossOp::UpdateProgress(progress) => {
                        if let Some(b) = bars.iter_mut().find(|b| b.id == id) {
                            b.hp = *progress;
                            changed = true;
                        }
                    }
                    BossOp::UpdateName(name) => {
                        if let Some(b) = bars.iter_mut().find(|b| b.id == id) {
                            b.title = spans_of(name);
                            changed = true;
                        }
                    }
                    BossOp::UpdateStyle(style) => {
                        if let Some(b) = bars.iter_mut().find(|b| b.id == id) {
                            b.color = boss_color_hex(style.color);
                            changed = true;
                        }
                    }
                    BossOp::UpdateProperties(_) => {}
                }
            }
            if changed {
                push_status(bot, false);
            }
        }
        ClientboundGamePacket::SetActionBarText(p) => {
            push_feed_entry("bar", &p.text);
        }
        ClientboundGamePacket::SetTitleText(p) => {
            push_feed_entry("title", &p.text);
        }
        ClientboundGamePacket::SetSubtitleText(p) => {
            push_feed_entry("subtitle", &p.text);
        }
        ClientboundGamePacket::ClearTitles(_) => {
            let out = {
                let mut guard = FEED_STATE.lock().unwrap();
                let state = guard.get_or_insert_with(FeedState::default);
                state.title.cur = None;
                state.subtitle.cur = None;
                feed_json(state)
            };
            crate::out(out);
        }
        ClientboundGamePacket::SystemChat(p) => {
            if p.overlay {
                push_feed_entry("bar", &p.content);
            }
        }
        _ => {}
    }
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login | Event::Spawn => {
            LAST_INV_JSON.lock().unwrap().clear();
            LAST_STATUS_JSON.lock().unwrap().clear();
            if matches!(event, Event::Login) {
                BOSS_BARS.lock().unwrap().clear();
                if let Some(m) = EFFECT_TRACK.lock().unwrap().as_mut() {
                    m.clear();
                }
            }
            push_inv(bot, true);
            push_status(bot, true);
            let out = {
                let mut guard = FEED_STATE.lock().unwrap();
                let state = guard.get_or_insert_with(FeedState::default);
                feed_json(state)
            };
            crate::out(out);
        }
        Event::Tick => {
            let every = Duration::from_millis((settings::get_f64(ID, "interval").max(0.2) * 1000.0) as u64);
            {
                let mut g = LAST_TICK_AT.lock().unwrap();
                if g.as_ref().map(|t| t.elapsed() < every).unwrap_or(false) {
                    return;
                }
                *g = Some(Instant::now());
            }
            push_inv(bot, false);
            push_status(bot, false);
        }
        _ => {}
    }
}

/// Aksi dari aplikasi: {"t":"inv","a":"left|right|shift|middle|drop1|dropall|offhand|select|use|close|detail|refresh|clear_feed","slot":n}
pub fn on_action(bot: &Client, v: &Value) {
    let a = v["a"].as_str().unwrap_or("");
    let slot = v["slot"].as_u64().unwrap_or(0) as usize;
    match a {
        "left" | "right" | "shift" | "middle" | "drop1" | "dropall" | "offhand" => {
            if let Some(h) = handle_of(bot) {
                match a {
                    "left" => h.left_click(slot),
                    "right" => h.right_click(slot),
                    "shift" => h.shift_click(slot),
                    "middle" => h.click(CloneClick { slot: slot as u16 }),
                    "drop1" => h.click(ThrowClick::Single { slot: slot as u16 }),
                    "dropall" => h.click(ThrowClick::All { slot: slot as u16 }),
                    "offhand" => h.click(SwapClick {
                        source_slot: slot as u16,
                        target_slot: 40,
                    }),
                    _ => {}
                }
            }
        }
        "select" => {
            let _ = bot.set_selected_hotbar_slot(slot.min(8) as u8);
        }
        "use" => {
            let _ = bot.set_selected_hotbar_slot(slot.min(8) as u8);
            let b = bot.clone();
            tokio::spawn(async move {
                tokio::time::sleep(Duration::from_millis(300)).await;
                b.start_use_item();
            });
        }
        "close" => {
            if let Some(h) = handle_of(bot) {
                if h.slots().map(|s| s.len() != PLAYER_MENU_LEN).unwrap_or(false) {
                    h.close();
                }
            }
        }
        "refresh" => {
            push_inv(bot, true);
            push_status(bot, true);
            let out = {
                let mut guard = FEED_STATE.lock().unwrap();
                let state = guard.get_or_insert_with(FeedState::default);
                feed_json(state)
            };
            crate::out(out);
            return;
        }
        "clear_feed" => {
            clear_feed();
            return;
        }
        "detail" => {
            let item = handle_of(bot).and_then(|h| h.slots()).and_then(|s| s.get(slot).cloned());
            let out = match item.as_ref().and_then(|s| s.as_present().filter(|_| s.is_present())) {
                Some(d) => {
                    let name = item_name(item.as_ref().unwrap());
                    let x = extra_of(Some(bot), &name, d);
                    let raw = serde_json::to_string_pretty(d).unwrap_or_else(|_| format!("{d:#?}"));
                    json!({
                        "type": "detail", "t": "detail", "slot": slot,
                        "item": {
                            "id": name,
                            "label": if x.label.is_empty() { title_case_words(&name) } else { x.label },
                            "count": d.count,
                            "e": x.enchanted,
                            "dur": x.dur,
                            "title": x.title,
                            "lore": x.lore,
                            "ench": x.ench.iter().map(|(n, l)| json!({"name": title_case_words(n), "lvl": l})).collect::<Vec<_>>(),
                            "hash": x.hash,
                            "pot": x.pot,
                            "raw": raw
                        }
                    })
                }
                None => json!({"type": "detail", "t": "detail", "slot": slot, "item": Value::Null}),
            };
            crate::out(out);
            return;
        }
        _ => return,
    }
    // susulan supaya tampilan cepat menyusul hasil aksi
    let b = bot.clone();
    tokio::spawn(async move {
        tokio::time::sleep(Duration::from_millis(400)).await;
        push_inv(&b, true);
        push_status(&b, false);
    });
}
