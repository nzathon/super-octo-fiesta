// Modul Monitor: isi inventory (atau menu server yang sedang terbuka) dikirim ke tab Inventory aplikasi,
// dan aksi dari tab itu (klik kiri/kanan/shift, pilih & pakai item hotbar, tutup menu) dijalankan di sini.
// Pipa: keluar {"t":"inv",...} dan {"t":"detail",...}; masuk {"t":"inv","a":aksi,"slot":n} (lihat main.rs).
//
// Catatan API (docs azalea.rs, 0.16.0+mc26.2):
// - Client::get_inventory() -> handle ke container yang sedang terbuka, atau inventory sendiri.
// - ContainerHandleRef: slots(), title(), left_click(), right_click(), shift_click(), close().
// - Client::set_selected_hotbar_slot(u8), Client::start_use_item().
// Versi rilis dan versi git berbeda soal pembungkus Result; trait `Soft` di bawah menampung dua-duanya.
use std::sync::Mutex;
use std::time::{Duration, Instant};

use azalea::container::ContainerHandleRef;
use azalea::entity::inventory::Inventory;
use azalea::inventory::ItemStack;
use azalea::prelude::*;
use serde_json::{json, Value};

use super::{Def, Setting};
use crate::settings;

const ID: &str = "monitor";
/// Menu inventory pemain selalu 46 slot; container lain lebih/kurang dari itu.
const PLAYER_MENU_LEN: usize = 46;

static LAST_JSON: Mutex<String> = Mutex::new(String::new());
static LAST_AT: Mutex<Option<Instant>> = Mutex::new(None);

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Monitor (Inventory)",
        desc: "Menampilkan inventory dan menu server di tab Inventory, bisa diklik (kiri, kanan, shift), \
pilih/pakai item hotbar, dan tutup menu.",
        enabled: true,
        settings: vec![
            Setting { key: "interval", label: "Jeda pembaruan (detik)", kind: "number", default: json!(0.5) },
            Setting { key: "icons", label: "Ikon item (dari internet)", kind: "boolean", default: json!(true) },
            Setting {
                key: "icon_src",
                label: "Sumber ikon (pisah koma, {name} = id item)",
                kind: "text",
                default: json!("https://blockrender.dev/render/item/{name}.png, https://blockrender.dev/render/block/{name}.png, https://raw.githubusercontent.com/PrismarineJS/minecraft-assets/master/data/1.21.8/assets/minecraft/textures/item/{name}.png, https://raw.githubusercontent.com/PrismarineJS/minecraft-assets/master/data/1.21.8/assets/minecraft/textures/block/{name}.png"),
            },
            Setting {
                key: "skin_src",
                label: "Sumber gambar pemain ({name} = username)",
                kind: "text",
                default: json!("https://mc-heads.net/body/{name}, https://minotar.net/armor/body/{name}/120.png"),
            },
            Setting { key: "double_tap", label: "Ketuk 2x slot = klik (left/right/shift/off)", kind: "text", default: json!("left") },
        ],
    }
}

// ---------- penampung supaya cocok dengan versi API yang mengembalikan Result maupun nilai langsung ----------

pub trait Soft<T> {
    fn soft(self) -> Option<T>;
}
impl<T, E> Soft<T> for Result<T, E> {
    fn soft(self) -> Option<T> {
        self.ok()
    }
}
impl Soft<ContainerHandleRef> for ContainerHandleRef {
    fn soft(self) -> Option<ContainerHandleRef> {
        Some(self)
    }
}
impl Soft<u8> for u8 {
    fn soft(self) -> Option<u8> {
        Some(self)
    }
}

pub fn handle_of(bot: &Client) -> Option<ContainerHandleRef> {
    bot.get_inventory().soft()
}

// ---------- pengubah data ----------

/// "DiamondPickaxe" -> "diamond_pickaxe"
fn snake(s: &str) -> String {
    let mut out = String::new();
    for (i, c) in s.chars().enumerate() {
        if c.is_ascii_uppercase() && i > 0 {
            out.push('_');
        }
        out.push(c.to_ascii_lowercase());
    }
    out
}

pub fn item_name(s: &ItemStack) -> String {
    snake(&format!("{:?}", s.kind()))
}

/// Bilangan bulat pertama di teks (untuk membaca isi komponen damage / max_damage dari Debug).
fn first_int(t: &str) -> Option<i64> {
    let b: Vec<char> = t.chars().collect();
    let mut i = 0;
    while i < b.len() {
        if b[i].is_ascii_digit() {
            let mut j = i;
            while j < b.len() && b[j].is_ascii_digit() {
                j += 1;
            }
            return b[i..j].iter().collect::<String>().parse().ok();
        }
        i += 1;
    }
    None
}

/// Pasangan "Nama: angka" dari teks Debug (dipakai untuk daftar enchant). Perkiraan; data asli ada di "raw".
fn name_levels(t: &str) -> Vec<(String, i64)> {
    let b: Vec<char> = t.chars().collect();
    let mut out = Vec::new();
    let mut i = 0;
    while i < b.len() {
        if b[i] == ':' && i + 1 < b.len() {
            let mut j = i + 1;
            while j < b.len() && b[j] == ' ' {
                j += 1;
            }
            let ds = j;
            while j < b.len() && b[j].is_ascii_digit() {
                j += 1;
            }
            if j > ds {
                let mut e = i;
                if e > 0 && b[e - 1] == '"' {
                    e -= 1;
                }
                let mut st = e;
                while st > 0 && (b[st - 1].is_alphanumeric() || b[st - 1] == '_' || b[st - 1] == ':') {
                    st -= 1;
                }
                let name: String = b[st..e].iter().collect();
                let name = name.rsplit(':').next().unwrap_or("").to_string();
                if !name.is_empty() && name != "levels" && name != "amount" && name != "damage" {
                    out.push((snake(&name), b[ds..j].iter().collect::<String>().parse().unwrap_or(0)));
                }
                i = j;
                continue;
            }
        }
        i += 1;
    }
    out
}

/// Teks polos dari Debug sebuah komponen teks: gabungan semua `text: "..."`.
fn texts_of(t: &str) -> String {
    let mut out = String::new();
    let mut rest = t;
    while let Some(p) = rest.find("text: \"") {
        let after = &rest[p + 7..];
        let mut piece = String::new();
        let mut esc = false;
        let mut used = 0;
        for (k, c) in after.char_indices() {
            used = k + c.len_utf8();
            if esc {
                piece.push(c);
                esc = false;
            } else if c == '\\' {
                esc = true;
            } else if c == '"' {
                break;
            } else {
                piece.push(c);
            }
        }
        out.push_str(&piece);
        rest = &after[used..];
    }
    out
}

/// Durability maksimum bawaan menurut nama item (komponen max_damage di item menimpa ini).
fn base_max(name: &str) -> Option<i64> {
    let (mat, part) = name.split_once('_')?;
    let tool = |m: &str| match m {
        "netherite" => Some(2031),
        "diamond" => Some(1561),
        "iron" => Some(250),
        "golden" => Some(32),
        "stone" => Some(131),
        "wooden" => Some(59),
        _ => None,
    };
    let armor = |m: &str, p: &str| {
        let (a, b, c, d) = match m {
            "netherite" => (407, 592, 555, 481),
            "diamond" => (363, 528, 495, 429),
            "iron" => (165, 240, 225, 195),
            "golden" => (77, 112, 105, 91),
            "chainmail" => (165, 240, 225, 195),
            "leather" => (55, 80, 75, 65),
            _ => return None,
        };
        match p {
            "helmet" => Some(a),
            "chestplate" => Some(b),
            "leggings" => Some(c),
            "boots" => Some(d),
            _ => None,
        }
    };
    match part {
        "pickaxe" | "axe" | "shovel" | "hoe" | "sword" => tool(mat),
        "helmet" | "chestplate" | "leggings" | "boots" => armor(mat, part),
        _ => match name {
            "elytra" => Some(432),
            "shears" => Some(238),
            "fishing_rod" => Some(64),
            "bow" => Some(384),
            "crossbow" => Some(465),
            "trident" => Some(250),
            "shield" => Some(336),
            "flint_and_steel" => Some(64),
            "turtle_helmet" => Some(275),
            "mace" => Some(500),
            _ => None,
        },
    }
}

struct Extra {
    enchanted: bool,
    dur: Option<[i64; 2]>,
    label: String,
    ench: Vec<(String, i64)>,
}

fn extra_of(name: &str, d: &azalea::inventory::ItemStackData) -> Extra {
    let mut x = Extra { enchanted: false, dur: None, label: String::new(), ench: Vec::new() };
    let (mut dmg, mut max): (Option<i64>, Option<i64>) = (None, None);
    for (kind, data) in d.component_patch.iter() {
        let k = kind.to_string();
        if k.contains("enchant") {
            x.enchanted = true;
        }
        let Some(data) = data else { continue };
        if k.ends_with("max_damage") {
            max = first_int(&format!("{data:?}"));
        } else if k.ends_with("damage") {
            dmg = first_int(&format!("{data:?}"));
        } else if k.ends_with("custom_name") {
            x.label = texts_of(&format!("{data:?}"));
        } else if k.ends_with("enchantments") || k.ends_with("stored_enchantments") {
            x.ench.extend(name_levels(&format!("{data:?}")));
        }
    }
    if let Some(dm) = dmg {
        if let Some(mx) = max.or_else(|| base_max(name)) {
            if dm > 0 && mx > 0 {
                x.dur = Some([dm, mx]);
            }
        }
    }
    x
}

fn slot_json(s: &ItemStack) -> Value {
    match s.as_present() {
        Some(d) if s.is_present() => {
            let name = snake(&format!("{:?}", d.kind));
            let x = extra_of(&name, d);
            let mut v = json!({"n": name, "c": d.count, "e": x.enchanted});
            if let Some(du) = x.dur {
                v["d"] = json!(du);
            }
            v
        }
        _ => Value::Null,
    }
}

fn snapshot(bot: &Client) -> Option<Value> {
    let h = handle_of(bot)?;
    let slots = h.slots()?;
    let len = slots.len();
    if len < 9 + 27 {
        return None;
    }
    let gui = len != PLAYER_MENU_LEN;
    let hot = if gui { len - 9 } else { 36 };
    let inv = hot - 27;
    let title = if gui {
        h.title().map(|t| crate::clean(&t.to_ansi())).unwrap_or_else(|| "Menu server".into())
    } else {
        String::new()
    };
    let held = bot.selected_hotbar_slot().soft().unwrap_or(0);
    let cursor = bot.component::<Inventory>().ok().map(|i| slot_json(&i.carried)).unwrap_or(Value::Null);
    Some(json!({
        "t": "inv", "type": "inv", "gui": gui, "title": title, "inv": inv, "hot": hot, "held": held,
        "slots": slots.iter().map(slot_json).collect::<Vec<_>>(),
        "cursor": cursor,
    }))
}

fn push(bot: &Client, force: bool) {
    let Some(v) = snapshot(bot) else { return };
    let s = v.to_string();
    {
        let mut last = LAST_JSON.lock().unwrap();
        if !force && *last == s {
            return;
        }
        *last = s;
    }
    crate::out(v);
}

// ---------- event dan aksi ----------

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login | Event::Spawn => LAST_JSON.lock().unwrap().clear(),
        Event::Tick => {
            let every = Duration::from_millis((settings::get_f64(ID, "interval").max(0.2) * 1000.0) as u64);
            {
                let mut g = LAST_AT.lock().unwrap();
                if g.as_ref().map(|t| t.elapsed() < every).unwrap_or(false) {
                    return;
                }
                *g = Some(Instant::now());
            }
            push(bot, false);
        }
        _ => {}
    }
}

/// Aksi dari aplikasi: {"t":"inv","a":"left|right|shift|select|use|close|detail","slot":n}
pub fn on_action(bot: &Client, v: &Value) {
    let a = v["a"].as_str().unwrap_or("");
    let slot = v["slot"].as_u64().unwrap_or(0) as usize;
    match a {
        "left" | "right" | "shift" => {
            if let Some(h) = handle_of(bot) {
                match a {
                    "left" => h.left_click(slot),
                    "right" => h.right_click(slot),
                    _ => h.shift_click(slot),
                }
            }
        }
        "select" => {
            let _ = bot.set_selected_hotbar_slot(slot.min(8) as u8);
        }
        "use" => {
            let _ = bot.set_selected_hotbar_slot(slot.min(8) as u8);
            let b = bot.clone();
            tokio::spawn(async move {
                tokio::time::sleep(Duration::from_millis(300)).await;
                b.start_use_item();
            });
        }
        "close" => {
            if let Some(h) = handle_of(bot) {
                if h.slots().map(|s| s.len() != PLAYER_MENU_LEN).unwrap_or(false) {
                    h.close();
                }
            }
        }
        "detail" => {
            let item = handle_of(bot).and_then(|h| h.slots()).and_then(|s| s.get(slot).cloned());
            let out = match item.as_ref().and_then(|s| s.as_present().filter(|_| s.is_present())) {
                Some(d) => {
                    let name = snake(&format!("{:?}", d.kind));
                    let x = extra_of(&name, d);
                    json!({
                        "type": "detail", "t": "detail", "slot": slot,
                        "item": {
                            "id": name, "count": d.count, "e": x.enchanted, "dur": x.dur,
                            "label": if x.label.is_empty() { Value::Null } else { json!(x.label) },
                            "ench": x.ench.iter().map(|(n, l)| json!({"name": n, "lvl": l})).collect::<Vec<_>>(),
                            "lore": [], "raw": format!("{d:#?}")
                        }
                    })
                }
                None => json!({"type": "detail", "t": "detail", "slot": slot, "item": Value::Null}),
            };
            crate::out(out);
            return;
        }
        _ => return,
    }
    // susulan supaya tampilan cepat menyusul hasil aksi
    let b = bot.clone();
    tokio::spawn(async move {
        tokio::time::sleep(Duration::from_millis(400)).await;
        push(&b, true);
    });
}
