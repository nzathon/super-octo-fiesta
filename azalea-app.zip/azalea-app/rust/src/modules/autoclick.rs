// Modul Auto klik: tahan klik kiri (hancurkan blok yang sedang dilihat) dan/atau klik kanan berulang (pakai item).
// API (source azalea 0.16.0+mc26.1, client_impl/mining.rs dan interact.rs):
// - Client::left_click_mine(enabled: bool): bot menggali blok yang dilihat selama masih terjangkau.
// - Client::start_use_item(): klik kanan sekali (item di tangan; kalau melihat blok/entitas, itu yang diklik).
// Modul dicek tiap tick supaya perubahan setelan langsung berlaku, dan klik kiri dilepas bila modul dimatikan.
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use azalea::prelude::*;
use serde_json::json;

use super::{Def, Setting};
use crate::settings;

const ID: &str = "autoclick";

static LEFT_ON: AtomicBool = AtomicBool::new(false);
static LAST_RIGHT: Mutex<Option<Instant>> = Mutex::new(None);

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Auto klik",
        desc: "Klik kiri: bot terus menghancurkan blok yang sedang dilihatnya. Klik kanan: bot memakai item di tangan \
berulang. Arahkan pandangan dan pegang item dulu. Klik terus-menerus bisa dianggap curang oleh anti-cheat server, \
pakai sesuai aturan server.",
        enabled: false,
        settings: vec![
            Setting { key: "left", label: "Klik kiri (hancurkan blok)", kind: "boolean", default: json!(false) },
            Setting { key: "right", label: "Klik kanan (pakai item)", kind: "boolean", default: json!(false) },
            Setting { key: "right_interval", label: "Jeda klik kanan (detik)", kind: "number", default: json!(0.25) },
        ],
    }
}

pub async fn on_event(bot: &Client, event: &Event) {
    if !matches!(event, Event::Tick) {
        return;
    }
    let on = settings::enabled(ID);

    let want_left = on && settings::get_bool(ID, "left");
    if LEFT_ON.swap(want_left, Ordering::SeqCst) != want_left {
        let _ = bot.left_click_mine(want_left);
        crate::log(if want_left { "klik kiri: aktif (menggali blok yang dilihat)" } else { "klik kiri: mati" });
    }

    if on && settings::get_bool(ID, "right") {
        let every = Duration::from_millis((settings::get_f64(ID, "right_interval").max(0.05) * 1000.0) as u64);
        let due = {
            let mut g = LAST_RIGHT.lock().unwrap();
            let due = g.as_ref().map(|t| t.elapsed() >= every).unwrap_or(true);
            if due {
                *g = Some(Instant::now());
            }
            due
        };
        if due {
            let _ = bot.start_use_item();
        }
    }
}
