// Daftar modul. Menambah modul baru = buat file modul (contoh: chat.rs), lalu tambahkan
// 1 baris `pub mod`, 1 baris di `all()`, dan 1 baris di `dispatch()`.
use azalea::prelude::*;
use serde_json::{json, Value};

use crate::settings;

pub mod autoclick;
pub mod chat;
pub mod monitor;
pub mod playerlist;
pub mod relogin;

pub struct Setting {
    pub key: &'static str,
    pub label: &'static str,
    /// boolean | text | number | password
    pub kind: &'static str,
    pub default: Value,
}

pub struct Def {
    pub id: &'static str,
    pub title: &'static str,
    pub desc: &'static str,
    pub enabled: bool,
    pub settings: Vec<Setting>,
}

pub fn all() -> Vec<Def> {
    vec![autoclick::def(), chat::def(), playerlist::def(), monitor::def(), relogin::def()]
}

/// Nilai awal setelan, dibuat sekali (dulu dibangun ulang tiap event sehingga tiap paket jadi mahal).
static DEFAULTS: std::sync::OnceLock<std::collections::HashMap<&'static str, std::collections::HashMap<&'static str, Value>>> =
    std::sync::OnceLock::new();

pub fn default_of(module: &str, key: &str) -> Value {
    let map = DEFAULTS.get_or_init(|| {
        let mut m: std::collections::HashMap<&'static str, std::collections::HashMap<&'static str, Value>> =
            std::collections::HashMap::new();
        for d in all() {
            let e = m.entry(d.id).or_default();
            e.insert("enabled", json!(d.enabled));
            for s in d.settings {
                e.insert(s.key, s.default);
            }
        }
        m
    });
    map.get(module).and_then(|e| e.get(key)).cloned().unwrap_or(Value::Null)
}

/// Skema yang dikirim ke aplikasi supaya layar Modul tergambar otomatis.
pub fn schema() -> Value {
    let list: Vec<Value> = all()
        .into_iter()
        .map(|d| {
            json!({
                "id": d.id, "title": d.title, "desc": d.desc, "enabled": d.enabled,
                "settings": d.settings.iter().map(|s| json!({
                    "key": s.key, "label": s.label, "type": s.kind, "default": s.default
                })).collect::<Vec<_>>()
            })
        })
        .collect();
    Value::Array(list)
}

/// Setiap event dari server diteruskan ke modul yang aktif.
pub async fn dispatch(bot: &Client, event: &Event) {
    // selalu dipanggil: perlu melepas klik kiri saat modul dimatikan
    autoclick::on_event(bot, event).await;
    if settings::enabled("chat") {
        chat::on_event(bot, event).await;
    }
    if settings::enabled("playerlist") {
        playerlist::on_event(bot, event).await;
    }
    if settings::enabled("monitor") {
        monitor::on_event(bot, event).await;
    }
    if settings::enabled("relogin") {
        relogin::on_event(bot, event).await;
    }
}
