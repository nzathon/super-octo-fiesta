// Daftar modul. Menambah modul baru = buat file modul (contoh: chat.rs), lalu tambahkan
// 1 baris `pub mod`, 1 baris di `all()`, dan 1 baris di `dispatch()`.
use azalea::prelude::*;
use serde_json::{json, Value};

use crate::settings;

pub mod chat;
pub mod relogin;

pub struct Setting {
    pub key: &'static str,
    pub label: &'static str,
    /// boolean | text | number | password
    pub kind: &'static str,
    pub default: Value,
}

pub struct Def {
    pub id: &'static str,
    pub title: &'static str,
    pub desc: &'static str,
    pub enabled: bool,
    pub settings: Vec<Setting>,
}

pub fn all() -> Vec<Def> {
    vec![chat::def(), relogin::def()]
}

pub fn default_of(module: &str, key: &str) -> Value {
    for d in all() {
        if d.id == module {
            if key == "enabled" {
                return json!(d.enabled);
            }
            for s in d.settings {
                if s.key == key {
                    return s.default;
                }
            }
        }
    }
    Value::Null
}

/// Skema yang dikirim ke aplikasi supaya layar Modul tergambar otomatis.
pub fn schema() -> Value {
    let list: Vec<Value> = all()
        .into_iter()
        .map(|d| {
            json!({
                "id": d.id, "title": d.title, "desc": d.desc, "enabled": d.enabled,
                "settings": d.settings.iter().map(|s| json!({
                    "key": s.key, "label": s.label, "type": s.kind, "default": s.default
                })).collect::<Vec<_>>()
            })
        })
        .collect();
    Value::Array(list)
}

/// Setiap event dari server diteruskan ke modul yang aktif.
pub async fn dispatch(bot: &Client, event: &Event) {
    if settings::enabled("chat") {
        chat::on_event(bot, event).await;
    }
    if settings::enabled("relogin") {
        relogin::on_event(bot, event).await;
    }
}
