// Modul Player List: daftar pemain online (nama tampilan berwarna + ping) ke tab Pemain aplikasi.
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use azalea::prelude::*;
use serde_json::{json, Value};

use super::{Def, Setting};
use crate::settings;

static PLAYERS: Mutex<Option<HashMap<String, Value>>> = Mutex::new(None);
static LAST: Mutex<Option<Instant>> = Mutex::new(None);
static PENDING: AtomicBool = AtomicBool::new(false);

pub fn def() -> Def {
    Def {
        id: "playerlist",
        title: "Player List",
        desc: "Menampilkan pemain online beserta ping di tab Pemain.",
        enabled: true,
        settings: vec![Setting {
            key: "interval",
            label: "Jeda pembaruan (detik)",
            kind: "number",
            default: json!(2),
        }],
    }
}

fn emit_now() {
    let me = settings::username();
    let mut list: Vec<Value> = {
        let g = PLAYERS.lock().unwrap();
        g.as_ref().map(|m| m.values().cloned().collect()).unwrap_or_default()
    };
    for p in list.iter_mut() {
        let is_me = p["name"].as_str() == Some(me.as_str());
        p["self"] = json!(is_me);
    }
    list.sort_by(|a, b| {
        let (sa, sb) = (a["self"].as_bool().unwrap_or(false), b["self"].as_bool().unwrap_or(false));
        sb.cmp(&sa).then_with(|| {
            a["name"].as_str().unwrap_or("").to_lowercase().cmp(&b["name"].as_str().unwrap_or("").to_lowercase())
        })
    });
    *LAST.lock().unwrap() = Some(Instant::now());
    crate::out(json!({"t": "players", "v": list}));
}

/// Dibatasi sesuai jeda; kalau tertahan, satu pembaruan susulan dijadwalkan supaya tidak ada yang basi.
fn push() {
    let every = Duration::from_millis((settings::get_f64("playerlist", "interval").max(0.5) * 1000.0) as u64);
    let wait = {
        let g = LAST.lock().unwrap();
        g.as_ref().map(|t| every.saturating_sub(t.elapsed())).unwrap_or(Duration::ZERO)
    };
    if wait.is_zero() {
        emit_now();
    } else if !PENDING.swap(true, Ordering::SeqCst) {
        tokio::spawn(async move {
            tokio::time::sleep(wait).await;
            PENDING.store(false, Ordering::SeqCst);
            emit_now();
        });
    }
}

pub async fn on_event(_bot: &Client, event: &Event) {
    match event {
        Event::AddPlayer(info) | Event::UpdatePlayer(info) => {
            let name = info.profile.name.clone();
            let v = json!({
                "name": name,
                "display": info.display_name.as_ref().map(|d| d.to_ansi()),
                "ping": info.latency
            });
            PLAYERS.lock().unwrap().get_or_insert_with(HashMap::new).insert(name, v);
            push();
        }
        Event::RemovePlayer(info) => {
            if let Some(m) = PLAYERS.lock().unwrap().as_mut() {
                m.remove(&info.profile.name);
            }
            push();
        }
        _ => {}
    }
}
