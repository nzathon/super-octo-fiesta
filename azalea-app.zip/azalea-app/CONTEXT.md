# Azalea — Konteks untuk AI

> Tempel file ini sebagai pesan pertama ke AI, lalu tambahkan masalah/fitur plus log.

## Aturan untuk AI
1. Pengguna bukan programmer, bekerja dari HP (Infinix X650C, Android 9, root). Bahasa Indonesia santai, ringkas.
2. Build lewat GitHub Actions dengan unggah ZIP. Pengguna tidak bisa unggah folder/file satuan, jadi kirim zip proyek utuh (`azalea-app.zip` & `azalea-core.zip`).
3. AI tidak bisa menjalankan/compile APK Kotlin atau binary Rust `aarch64-linux-android` di sini. Bedakan: terbukti (dari log), diuji simulasi, dugaan. Jangan sajikan dugaan sebagai fakta.
4. Satu masalah per putaran. Jangan simpan/minta password di log.
5. Server target punya anti-cheat; jangan buat perilaku tidak wajar. Server: proxy + `/login` wajib tiap koneksi (TIMEOUT ±5 menit), satu username tidak boleh login ganda, kadang SRV record, kadang pindah server lewat menu hotbar.

## Arsitektur
- Kotlin/Compose (`com.azalea.app`, dipecah per file `Theme.kt`, `Icons.kt`, `HomeScreen.kt`, `SettingsPage.kt`, `SessionScreen.kt`, `ChatTab.kt`, `PlayersTab.kt`, `LogBox.kt`, `ModulesUi.kt`, `Store.kt`, `TexCache.kt`, `BotService.kt`, `Core.kt`, `MainActivity.kt`, dll.): beranda Akun | Server | Modul | Setelan, daftar server ala Minecraft (ping, MOTD), layar sesi, dan akun dengan PlayerHead.
- `Core.kt`: menjalankan `libazalea.so` (atau `filesDir/core/azalea-core` hasil `CorePack`) lewat `ProcessBuilder`. Satu koneksi = satu proses. Pipa stdin/stdout berisi baris JSON. Sambung ulang diatur di Kotlin.
- `rust/src/main.rs`: azalea (git, nightly). stdin baris 1 = `{host,port,username,ip,rport,modules,storage}`; lalu `{"t":"chat"|"complete"|"inv"|"web"|"set"|"storage"|"quit",...}`. stdout: `{"t":"status|log|chat|players|notify|complete|web|storage",...}`.
- Versi Minecraft & protokol aktif (`mc_version`, `protocol`) dilaporkan langsung dari `azalea-core modules`.
- Build: `.github/workflows/build.yml` (APK + `azalea-core-pack`) dan `.github/workflows/build-core.yml` (`azalea-core-pack` saja). Kunci tanda tangan `blockchat.keystore` dipertahankan.

## Temuan terbukti
- Panic `ndk-context: android context was not initialized`: `azalea_protocol::resolve::RESOLVER` butuh konteks JNI Android yang tidak ada di proses terpisah. Solusi terbukti: DNS/SRV dikerjakan Kotlin, IP diberikan ke azalea lewat `JoinOpts::custom_socket_addr`.

## Status & Pembaruan
- **Teruji di HP (Android 9)**: Tema dark slate + emerald, ikon vektor, `MainActivity` modular, `PlayerHead` Akun & notifikasi PM, `autofish.rs`, `relogin.rs` multi-step, tab Monitor + Quick Hotbar 1–9, dan info versi MC inti.
- **Pembaruan Putaran 2 *(belum dicompile/uji di HP)***:
  - **Sub-tab Chat (`ChatTab.kt`)**: Tab kustom ala AdvancedChatCore (`Semua` + tab buatan pengguna per server di `ModStorage["chat"]`) lengkap dengan whitelist/blacklist (teks/regex/exact/prefix), toggle ikut blacklist global, dan badge belum terbaca.
  - **Tampilan Chat & Quick Command Live (`ChatTab.kt`, `Store.kt`, `Core.kt`)**: Timestamp (`HH:mm`/`HH:mm:ss`), PlayerHead inline di baris chat, serta Quick Command yang bisa diedit, ditambah, diurutkan, dan disembunyikan — semua langsung berlaku tanpa reconnect.
  - **Avatar Balasan Notif (`BotService.kt`)**: Saat membalas PM dari notifikasi Android, PlayerHead akun bot ikut tampil di gelembung balasan `MessagingStyle`.
  - **Tab Setelan (`HomeScreen.kt`, `SettingsPage.kt`, `ModulesUi.kt`, `TexCache.kt`)**: Menu `Setelan` baru di halaman awal menampung Import Core (`.zip`), Backup & Restore (`.json`), preferensi tampilan Chat & Quick Command, hapus cache avatar, pintasan Setelan Android, dan info versi.
  - **Monitor & Modul Baru (`monitor.rs`, `inventory.html`, `autoeat.rs`, `autorespawn.rs`, `Cargo.toml`)**: Hapus tombol Pilih Hotbar dari Detail Slot, tambah kontrol Look & Sneak di Monitor, modul `autoeat` & `autorespawn`, serta optimasi ukuran biner Rust (`opt-level = "s"`, `strip = true`, `lto = "thin"`).
