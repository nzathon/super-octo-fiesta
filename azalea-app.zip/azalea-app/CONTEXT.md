# Azalea — Konteks untuk AI

> Tempel file ini sebagai pesan pertama ke AI, lalu tambahkan masalah/fitur plus log.

## Aturan untuk AI
1. Pengguna bukan programmer, bekerja dari HP (Infinix X650C, Android 9, root). Bahasa Indonesia santai, ringkas.
2. Build lewat GitHub Actions dengan unggah ZIP. Pengguna tidak bisa unggah folder/file satuan, jadi kirim zip proyek utuh (`azalea-app.zip` & `azalea-core.zip`).
3. AI tidak bisa menjalankan/compile APK Kotlin atau binary Rust `aarch64-linux-android` di sini. Bedakan: terbukti (dari log), diuji simulasi, dugaan. Jangan sajikan dugaan sebagai fakta.
4. Satu masalah per putaran. Jangan simpan/minta password di log.
5. Server target punya anti-cheat; jangan buat perilaku tidak wajar. Server: proxy + `/login` wajib tiap koneksi (TIMEOUT ±5 menit), satu username tidak boleh login ganda, kadang SRV record, kadang pindah server lewat menu hotbar.

## Arsitektur
- Kotlin/Compose (`com.azalea.app`, dipecah per file `Theme.kt`, `Icons.kt`, `HomeScreen.kt`, `SessionScreen.kt`, `ChatTab.kt`, `PlayersTab.kt`, `LogBox.kt`, `MainActivity.kt`, dll.): beranda Akun | Server | Modul, daftar server ala Minecraft (ping, MOTD), layar sesi, dan akun dengan PlayerHead.
- `Core.kt`: menjalankan `libazalea.so` (atau `filesDir/core/azalea-core` hasil `CorePack`) lewat `ProcessBuilder`. Satu koneksi = satu proses. Pipa stdin/stdout berisi baris JSON. Sambung ulang diatur di Kotlin.
- `rust/src/main.rs`: azalea (git, nightly). stdin baris 1 = `{host,port,username,ip,rport,modules,storage}`; lalu `{"t":"chat"|"complete"|"inv"|"web"|"set"|"storage"|"quit",...}`. stdout: `{"t":"status|log|chat|players|notify|complete|web|storage",...}`.
- Versi Minecraft & protokol aktif (`mc_version`, `protocol`) dilaporkan langsung dari `azalea-core modules`.
- Build: `.github/workflows/build.yml` (APK + `azalea-core-pack`) dan `.github/workflows/build-core.yml` (`azalea-core-pack` saja). Kunci tanda tangan `blockchat.keystore` dipertahankan.

## Temuan terbukti
- Panic `ndk-context: android context was not initialized`: `azalea_protocol::resolve::RESOLVER` butuh konteks JNI Android yang tidak ada di proses terpisah. Solusi terbukti: DNS/SRV dikerjakan Kotlin, IP diberikan ke azalea lewat `JoinOpts::custom_socket_addr`.

## Status & Pembaruan Terbaru
- **UI & Tema (`azalea-app`)**: Tema dark slate + emerald (`Theme.kt`), ikon vektor (`Icons.kt`), pemecahan `MainActivity.kt`, banner Beranda dengan live uptime + tombol Putus langsung, `EditServerScreen` dengan info versi Core aktif & auto-parse `host:port`. *(Sudah ditulis, belum diuji compile/jalankan di HP)*
- **PlayerHead Akun & Notifikasi (`TexCache.kt`, `BotService.kt`, `HomeScreen.kt`)**: Avatar head di menu Akun memakai `TexCache` (sama seperti PlayerList, mendukung hash SkinsRestorer & fallback username) serta notifikasi PM (`MessagingStyle` + `setLargeIcon`) ikut menampilkan PlayerHead pengirim. *(Sudah ditulis, belum diuji compile/jalankan di HP)*
- **Tab Chat, Pemain & Log**: Toolbar mini di atas `ChatTab` (cari, bersihkan, filter blacklist tanpa menutupi pesan), command suggestion vertikal (atas-bawah), quick macro bar, highlight dark mode saat tap pesan/pemain, pencarian & sortir di `PlayersTab`, serta pencarian & bersihkan di `LogBox`. *(Sudah ditulis, belum diuji compile/jalankan di HP)*
- **Tab Monitor (`SessionScreen.kt` + `inventory.html`)**: Nama tab dikembalikan menjadi `Monitor`; tampilan dirapikan (panel Tampilan lipat, section Efek/Bossbar/Detail Slot otomatis sembunyi saat kosong, strip hotbar 1–9 cepat, riwayat feed ringkas). *(Sudah ditulis, belum diuji compile/jalankan di HP)*
- **Modul `autofish.rs`**: Deteksi suara `entity.fishing_bobber.splash`, jeda reaksi acak, `idle_timeout`, batas `min_durability`, dan `auto_swap_rod` di hotbar. *(Sudah ditulis, belum diuji compile/jalankan di HP)*
- **Modul `relogin.rs`**: Reset state login/transfer saat koneksi baru & saat terdeteksi balik ke lobby, dukungan multi-step `slotsMenu` + `jedaKlik`, serta custom patterns (`ok_words`, `login_words`, `fail_words`, `lobby_words`) di Storage. *(Sudah ditulis, belum diuji compile/jalankan di HP)*
