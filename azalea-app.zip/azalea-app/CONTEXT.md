# Azalea — konteks proyek untuk AI lain

> Tempel file ini sebagai pesan pertama ke AI, lalu tambahkan masalah/fitur plus log. Terakhir diperbarui: 22 Nov 2026.
> Proyek ini menggantikan versi lama berbasis mineflayer/Node (BlockChat MF, sudah dihapus dari proyek).

## Aturan untuk AI
1. Pengguna bukan programmer, bekerja dari HP (Infinix X650C, Android 9, root). Bahasa Indonesia santai, ringkas.
2. Build lewat GitHub Actions dengan unggah ZIP. Pengguna tidak bisa unggah folder/file satuan, jadi kirim zip proyek utuh.
3. AI hampir pasti tidak bisa menjalankan/compile apa pun (Kotlin, Rust, Azalea). Bedakan: terbukti (dari log), diuji simulasi, dugaan. Jangan sajikan dugaan sebagai fakta.
4. Satu masalah per putaran. Jangan simpan/minta password di log.
5. Server target punya anti-cheat; jangan buat perilaku tidak wajar. Server: proxy + `/login` wajib tiap koneksi (TIMEOUT ±5 menit), satu username tidak boleh login ganda, kadang SRV record, kadang pindah server lewat menu hotbar + resource pack.
6. Pengguna mining ancient debris otomatis (AFK) dengan beliung custom Efficiency 10.

## Arsitektur
- Kotlin/Compose (`com.azalea.app`): beranda Akun | Server, daftar server ala Minecraft (ping, MOTD), layar sesi (log + kirim chat), akun (username saja).
- `Core.kt`: menjalankan `libazalea.so` (program Rust, bukan JNI) lewat ProcessBuilder dari `nativeLibraryDir`. Satu koneksi = satu proses. Pipa stdin/stdout berisi baris JSON. Sambung ulang diatur di Kotlin.
- `rust/src/main.rs`: azalea (git, nightly). stdin baris 1 = `{host,port,username}`; lalu `{"t":"chat","v":..}` / `{"t":"quit"}`. stdout: `{"t":"status|log|chat","v":..}`; teks non-JSON diteruskan ke Log.
- Port 25565 dikirim tanpa port supaya azalea mencari SRV. Versi Minecraft ditentukan versi azalea (dropdown versi hanya tampilan).
- Build: `.github/workflows/build.yml` (rust nightly + cargo-ndk -> `libazalea.so` di `jniLibs/arm64-v8a`, lalu gradle). Kunci tanda tangan lama (`blockchat.keystore`) sengaja dipertahankan.

## Temuan terbukti (22 Nov 2026)
- Panic `ndk-context: android context was not initialized`: `azalea_protocol::resolve::RESOLVER` -> `hickory_resolver::builder_tokio` butuh konteks JNI Android, yang tidak ada di proses terpisah. Solusi yang dicoba: DNS/SRV dikerjakan Kotlin, IP diberikan ke azalea lewat `JoinOpts::custom_resolved_address` (TERBUKTI jalan: join server berhasil; nama method sekarang `custom_socket_addr`). Cadangan: Rust dijalankan sebagai library JNI di proses aplikasi.

## Status
- BELUM TERBUKTI: kompilasi Rust (API azalea ditulis dari ingatan), koneksi ke server, SRV di Android, DNS resolver azalea di Android.
- Sudah ditulis, BELUM terbukti dikompilasi/dijalankan: modul `monitor` (tab Inventory) dan pindah server lewat item menu (`relogin.rs`).
- Belum ada: auto mining, penanganan resource pack lobby, WifiLock, monitor HP/lapar/efek/bossbar/title.

## Rencana
1. Buktikan koneksi dasar. 2. (SELESAI, belum terbukti di HP) Kerangka modul Rust + layar Modul. 3. Auto mining, lalu auto fish. 4. Pisahkan inti dari APK (file `azalea-core` bisa diganti tanpa pasang APK; workflow dipecah inti/APK).
Keputusan: tidak ada mesin script (JS/Lua) — fitur dibuat sebagai modul Rust langsung agar semua fitur azalea terpakai; perubahan = compile ulang di GitHub.

## Tab Inventory (tampilan ala script Monitor lama)
`app/src/main/assets/inventory.html` = halaman Monitor lama yang dipangkas (panel inventory ala Minecraft, ikon dari internet, glint enchant, bar durability, detail + tombol aksi). Dimuat di WebView (`InventoryUi.kt`); jembatan JS `Android.send/copy`. Inti Rust (`monitor.rs`) mengirim `{"t":"inv",...}` dan `{"t":"detail",...}` yang diteruskan Kotlin apa adanya. Setelan modul Monitor: ikon, sumber ikon, sumber skin, ketuk 2x.
Belum: status/efek/bossbar/feed, skin 3D, tombol drop/offhand/middle.
