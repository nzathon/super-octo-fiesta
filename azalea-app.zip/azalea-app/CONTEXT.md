# Azalea — konteks proyek untuk AI lain

> Tempel file ini sebagai pesan pertama ke AI, lalu tambahkan masalah/fitur plus log. Terakhir diperbarui: 22 Nov 2026.
> Proyek ini menggantikan versi lama berbasis mineflayer/Node (BlockChat MF, sudah dihapus dari proyek).

## Aturan untuk AI
1. Pengguna bukan programmer, bekerja dari HP (Infinix X650C, Android 9, root). Bahasa Indonesia santai, ringkas.
2. Build lewat GitHub Actions dengan unggah ZIP. Pengguna tidak bisa unggah folder/file satuan, jadi kirim zip proyek utuh.
3. AI hampir pasti tidak bisa menjalankan/compile apa pun (Kotlin, Rust, Azalea). Bedakan: terbukti (dari log), diuji simulasi, dugaan. Jangan sajikan dugaan sebagai fakta.
4. Satu masalah per putaran. Jangan simpan/minta password di log.
5. Server target punya anti-cheat; jangan buat perilaku tidak wajar. Server: proxy + `/login` wajib tiap koneksi (TIMEOUT ±5 menit), satu username tidak boleh login ganda, kadang SRV record, kadang pindah server lewat menu hotbar + resource pack.
6. Pengguna mining ancient debris otomatis (AFK) dengan beliung custom Efficiency 10.

## Arsitektur
- Kotlin/Compose (`com.azalea.app`): beranda Akun | Server, daftar server ala Minecraft (ping, MOTD), layar sesi (log + kirim chat), akun (username saja).
- `Core.kt`: menjalankan `libazalea.so` (program Rust, bukan JNI) lewat ProcessBuilder dari `nativeLibraryDir`. Satu koneksi = satu proses. Pipa stdin/stdout berisi baris JSON. Sambung ulang diatur di Kotlin.
- `rust/src/main.rs`: azalea (git, nightly). stdin baris 1 = `{host,port,username}`; lalu `{"t":"chat","v":..}` / `{"t":"quit"}`. stdout: `{"t":"status|log|chat","v":..}`; teks non-JSON diteruskan ke Log.
- Port 25565 dikirim tanpa port supaya azalea mencari SRV. Versi Minecraft ditentukan versi azalea (dropdown versi hanya tampilan).
- Build: `.github/workflows/build.yml` (rust nightly + cargo-ndk -> `libazalea.so` di `jniLibs/arm64-v8a`, lalu gradle). Kunci tanda tangan lama (`blockchat.keystore`) sengaja dipertahankan.

## Temuan terbukti (22 Nov 2026)
- Panic `ndk-context: android context was not initialized`: `azalea_protocol::resolve::RESOLVER` -> `hickory_resolver::builder_tokio` butuh konteks JNI Android, yang tidak ada di proses terpisah. Solusi yang dicoba: DNS/SRV dikerjakan Kotlin, IP diberikan ke azalea lewat `JoinOpts::custom_resolved_address` (TERBUKTI jalan: join server berhasil; nama method sekarang `custom_socket_addr`). Cadangan: Rust dijalankan sebagai library JNI di proses aplikasi.

## Status
- BELUM TERBUKTI: kompilasi Rust (API azalea ditulis dari ingatan), koneksi ke server, SRV di Android, DNS resolver azalea di Android.
- Sudah ditulis, BELUM terbukti dikompilasi/dijalankan: modul `monitor` (tab Inventory) dan pindah server lewat item menu (`relogin.rs`).
- Sudah ditulis (BELUM terbukti dikompilasi/dijalankan di HP): modul `monitor` lengkap (inventory + menu server, detail/lore item berwarna, 3D player_head gaya EMI tanpa API head pihak ketiga, pewarnaan potion, status HP/lapar/XP/koordinat/ping, efek aktif, bossbar, action bar/title/subtitle, tombol klik tengah/drop/offhand) dan pindah server lewat item menu (`relogin.rs`).
- Belum ada: auto mining, penanganan resource pack lobby, WifiLock.

## Rencana
1. Buktikan koneksi dasar. 2. (SELESAI, belum terbukti di HP) Kerangka modul Rust + layar Modul. 3. Auto mining, lalu auto fish. 4. (SELESAI, belum diuji di HP) Pisahkan inti dari APK (`CorePack` + `azalea-core-pack.zip` + tab web dinamis + workflow `build-core.yml`).
Keputusan: tidak ada mesin script (JS/Lua) — fitur dibuat sebagai modul Rust langsung agar semua fitur azalea terpakai; perubahan = compile ulang di GitHub.

## Tab Inventory (tampilan ala script Monitor lama)
`app/src/main/assets/inventory.html` = halaman Monitor lengkap (chips toggle, status HP/lapar/XP/koordinat/ping, efek potion + countdown, bossbar, panel inventory ala Minecraft, ikon gaya EMI via `blocksitems.com` + `assets.mcasset.cloud`, 3D `player_head` dari `textures.minecraft.net` + proxy cache CORS di `InventoryUi.kt`, glint enchant, pewarnaan potion, bar durability, detail + lore berwarna + semua tombol aksi termasuk middle/drop1/dropall/offhand, serta feed action bar/title/subtitle). Inti Rust (`monitor.rs` + `main.rs`) mengirim `inv`, `detail`, `mon_status`, `mon_feed`.

## Modul Auto klik (autoclick.rs)
Klik kiri (tahan, gali blok yang dilihat) = `Client::left_click_mine(bool)`; klik kanan berulang = `Client::start_use_item()` tiap N detik. Keduanya toggle di setelan modul, dicek tiap tick. Mati secara default.

## Pembaruan Terbaru
- `WebTabHost.kt` (`WebTabBus` + `GlobalWebTab`): host WebView global sadar lifecycle (`ON_PAUSE`/`ON_RESUME`) dengan conflated snapshot per channel agar tidak terjadi replay antrean pesan saat kembali dari AFK, serta cache CORS PNG bersama lewat `TexCache.kt`.
- `TexCache.kt`: cache disk + decoder head skin Mojang (`8x8` + topi `40,8,8,8` + deteksi topi hitam legacy 64x32) untuk `PlayersTab` (native Compose, tanpa API pihak ketiga & tanpa WebView) dan `GlobalWebTab`.
- `chat.rs`: format `FormattedText` rekursif + placeholder sentinel untuk `TranslatableComponent` + `with_registry_holder` agar warna chat player (JSON/hex/`§`) tetap utuh.
- `playerlist.rs`: key pemain memakai UUID (`info.uuid`) dan mengirim `hash` tekstur Mojang.
- `relogin.rs`: `/login` & `/register` manual langsung disimpan ke Storage; `after_login` menunggu konfirmasi `LOGGED_IN` lewat `tokio::spawn` + `Notify` tanpa memblokir antrean paket Azalea.
- `autoclick.rs`: mereset `LEFT_ON` saat `Login`/`Spawn` agar `left_click_mine` aktif lagi setelah respawn/pindah dunia.
- `MainActivity.kt`: `ChatTab` (`rememberSaveable`) & `LogBox` (`LazyColumn`) memakai tombol `↓` ke bawah saat pengguna scroll ke atas, dan auto-scroll tetap aktif melewati batas 300/400 baris.
- `CorePack.kt` + `targetSdk = 28`: inti Rust (`azalea-core`) dan aset web (`web/`) bisa diimpor dari `azalea-core-pack.zip` (atau binary ELF) di layar Modul tanpa build/reinstall APK, dengan uji coba `<bin> modules` sebelum aktivasi serta tombol Reset ke inti bawaan APK.
- Tab WebView dinamis (`modules/mod.rs` `web_tabs()` + `dispatch_web()`, `main.rs` `web_emit()`, `WebTabHost.kt` `WEB_ORIGIN`, `InventoryUi.kt` `DynamicWebTab`): modul Rust baru beserta file HTML-nya di `app/src/main/assets/` (atau `web/`) otomatis muncul sebagai tab di layar Sesi dan bisa saling berkirim JSON (`{"t":"web",...}`) tanpa mengubah kode Kotlin APK.
- Workflow GitHub Actions dipecah: `.github/workflows/build-core.yml` hanya membangun `azalea-core-pack` (tanpa Gradle) saat `rust/**` atau aset web berubah, sedangkan `.github/workflows/build.yml` membangun APK + `azalea-core-pack` saat kode Kotlin/Gradle berubah.
- `SessionScreen` kini memakai sidebar garis tiga (`ModalNavigationDrawer`) untuk **Modul & Core** dan **Log** sehingga bar tab hanya berisi tab fitur aktif (`Chat`, `Inventory`, `Pemain`, + tab dinamis). Tab modul (`monitor`, `playerlist`, serta `WebTab.module`) otomatis sembunyi saat modulnya dimatikan, dan WebView tetap disimpan hangat di memori (`View.VISIBLE`/`INVISIBLE` + `WebTabBus` pause/resume) agar tidak blank saat ganti tab.
- `rust/CORE_CONTEXT.md` ikut dikemas di `azalea-core-pack.zip` sebagai panduan khusus AI saat hanya bekerja di bundel Core & WebView tanpa APK.

- `chat.rs`, `Core.kt` & `MainActivity.kt`: `blacklist` di Storage modul `chat` memakai array objek bernama dengan tipe per-pattern (`{"name": "broadcast", "patterns": [["regex", "..."], ["match", "..."]], "enable": true, "case_sensitive": false}`), bekerja secara **live** di `ChatTab` (`chat.rs` tetap meneruskan event `chat` dengan flag `"blocked": true` agar `Core.chat` menyimpan riwayat penuh dan pesan langsung tersembunyi/muncul ulang saat aturan atau toggle Blacklist diubah), ditambah ikon gear (`ChatBlacklistDialog`) dan deteksi `ClickEvent` + `/command` untuk quick action.
- `BotService.kt`, `AndroidManifest.xml`, `Core.kt` & `chat.rs`: Notifikasi PM memakai `MessagingStyle` + `RemoteInput` (`NotificationReplyReceiver`) agar bisa dibalas langsung dari panel notifikasi seperti WhatsApp, dengan template `global.reply_command` bawaan `"/msg {nama} {pesan}"` (dan override opsional `servers["<host>:<port>"].reply_command`, mis. `"/r {pesan}"`).
