# Pertahankan jembatan JavaScript WebView (@JavascriptInterface) di InventoryUi.kt
-keepattributes JavascriptInterface, *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.azalea.app.InvBridge { *; }
-keep class com.azalea.app.DynamicWebBridge { *; }

# Komponen AndroidManifest
-keep public class com.azalea.app.MainActivity
-keep public class com.azalea.app.BotService
-keep public class com.azalea.app.NotificationReplyReceiver

# Abaikan referensi kelas opsional JVM/TLS dari OkHttp/Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**
-dontwarn java.lang.invoke.**
