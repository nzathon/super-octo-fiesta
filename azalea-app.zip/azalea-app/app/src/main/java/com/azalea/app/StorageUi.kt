package com.azalea.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private fun nodeText(v: Any?): String = when (v) {
    null -> ""
    is Double -> if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
    else -> v.toString()
}

private fun pathKey(path: List<Any>): String = path.joinToString("/")

/** Isi tab Storage: data script sebagai pohon (kunci -> nilai -> nilai ...) atau JSON mentah, plus Export/Import 1 modul. */
@Composable
fun ModuleStorageContent(name: String) {
    val ctx = LocalContext.current
    val all by ModStorage.data.collectAsState()
    val data = all[name] ?: JSONObject()
    var jsonMode by remember { mutableStateOf(false) }
    var notice by remember(name) { mutableStateOf<String?>(null) }
    var isError by remember(name) { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val payload = JSONObject()
                .put("type", "azalea_module_storage")
                .put("module", name)
                .put("data", data)
                .toString(2)
            writeUriText(ctx, uri, payload)
            notice = "Storage modul '$name' berhasil diexport."
            isError = false
        } catch (e: Throwable) {
            notice = "Gagal export storage: ${e.message ?: e.javaClass.simpleName}"
            isError = true
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val root = JSONObject(readUriText(ctx, uri))
            val kind = root.optString("type", "")
            if (kind == "azalea_backup") {
                notice = "Ini file Backup penuh. Gunakan tombol Restore di halaman Modul & Core."
                isError = true
                return@rememberLauncherForActivityResult
            }
            if (kind == "azalea_module_settings") {
                notice = "Ini file Setelan modul. Import lewat tab Setelan."
                isError = true
                return@rememberLauncherForActivityResult
            }
            val importedObj = if (kind == "azalea_module_storage") {
                val fileMod = root.optString("module", "").trim()
                if (fileMod.isNotEmpty() && fileMod != name) {
                    notice = "File ini storage untuk modul '$fileMod', bukan '$name'."
                    isError = true
                    return@rememberLauncherForActivityResult
                }
                root.optJSONObject("data")
                    ?: run {
                        notice = "Objek 'data' tidak ditemukan di file JSON."
                        isError = true
                        return@rememberLauncherForActivityResult
                    }
            } else {
                root
            }
            ModStorage.replace(name, JSONObject(importedObj.toString()), fromUser = true)
            notice = "Storage modul '$name' berhasil diimport."
            isError = false
        } catch (e: Throwable) {
            notice = "JSON storage tidak valid: ${e.message ?: e.javaClass.simpleName}"
            isError = true
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { exportLauncher.launch("azalea-storage-$name.json") },
                modifier = Modifier.weight(1f),
            ) {
                Text("Export Storage")
            }
            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("application/json", "text/*", "*/*")) },
                modifier = Modifier.weight(1f),
            ) {
                Text("Import Storage")
            }
        }
        notice?.let { msg ->
            Spacer(Modifier.height(4.dp))
            Text(
                msg,
                style = MaterialTheme.typography.bodySmall,
                color = if (isError) Color(0xFFE26B6B) else Color(0xFF7FD67F),
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mode JSON", Modifier.weight(1f))
            Switch(jsonMode, { jsonMode = it })
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (jsonMode) {
                JsonEditor(name, data)
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    if (data.length() == 0) {
                        Text(
                            "Storage kosong. Tambah kunci dengan tombol di bawah, atau biarkan modul mengisinya sendiri.",
                            Modifier.padding(vertical = 12.dp)
                        )
                    }
                    ObjectNode(name, data, emptyList(), 0)
                }
            }
        }
    }
}

@Composable
private fun JsonEditor(script: String, data: JSONObject) {
    var text by remember(data.toString()) { mutableStateOf(data.toString(2)) }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            text, { text = it }, modifier = Modifier.weight(1f).fillMaxWidth(),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        )
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            try {
                ModStorage.replace(script, JSONObject(text))
                msg = "Tersimpan."
            } catch (e: Throwable) {
                msg = "JSON tidak valid: ${e.message}"
            }
        }) { Text("Simpan JSON") }
    }
}

@Composable
private fun ObjectNode(script: String, obj: JSONObject, path: List<Any>, depth: Int) {
    val keys = obj.keys().asSequence().toList()
    Column {
        for (k in keys) NodeRow(script, k, obj.opt(k), path + k, depth)
        AddChildButton(script, path, isArray = false, nextIndex = 0, depth = depth)
    }
}

@Composable
private fun ArrayNode(script: String, arr: JSONArray, path: List<Any>, depth: Int) {
    Column {
        for (i in 0 until arr.length()) NodeRow(script, "[$i]", arr.opt(i), path + i, depth)
        AddChildButton(script, path, isArray = true, nextIndex = arr.length(), depth = depth)
    }
}

@Composable
private fun NodeRow(script: String, label: String, value: Any?, path: List<Any>, depth: Int) {
    Column(Modifier.fillMaxWidth().padding(start = (depth * 12).dp, top = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.titleSmall)
                val kind = when (value) {
                    is JSONObject -> "objek, ${value.length()} isi"
                    is JSONArray -> "daftar, ${value.length()} item"
                    is Boolean -> "on/off"
                    is Number -> "angka"
                    is String -> "teks"
                    else -> "kosong"
                }
                Text(kind, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (value is Boolean) {
                Switch(checked = value, onCheckedChange = { ModStorage.set(script, path, it) })
            }
            TextButton(onClick = { ModStorage.delete(script, path) }) { Text("Hapus") }
        }
        when (value) {
            is JSONObject -> ObjectNode(script, value, path, depth + 1)
            is JSONArray -> ArrayNode(script, value, path, depth + 1)
            is Number -> ValueField(script, path, value, number = true)
            is String -> ValueField(script, path, value, number = false)
            else -> { }
        }
        HorizontalDivider()
    }
}

/** Kolom edit nilai teks/angka. Ketikan pengguna tidak ditimpa balasan dari Node. */
@Composable
private fun ValueField(script: String, path: List<Any>, value: Any, number: Boolean) {
    // Teks: dibuat ulang kalau isi dari luar berubah. Angka: hanya per lokasi (supaya "5." tidak langsung jadi "5").
    var text by remember(pathKey(path), if (number) "" else value.toString()) { mutableStateOf(nodeText(value)) }
    OutlinedTextField(
        value = text,
        onValueChange = { v ->
            val nv = if (number) v.filter { it.isDigit() || it == '.' || it == '-' } else v
            text = nv
            if (!number) ModStorage.set(script, path, nv)
            else nv.toDoubleOrNull()?.let { ModStorage.set(script, path, it) }
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun AddChildButton(script: String, path: List<Any>, isArray: Boolean, nextIndex: Int, depth: Int) {
    var adding by remember { mutableStateOf(false) }
    Box(Modifier.padding(start = (depth * 12).dp)) {
        TextButton(onClick = { adding = true }) { Text(if (isArray) "+ item" else "+ kunci") }
    }
    if (adding) {
        AddNodeDialog(
            isArray = isArray,
            onDismiss = { adding = false },
            onAdd = { key, value ->
                val target: List<Any> = if (isArray) path + nextIndex else path + (key ?: "")
                ModStorage.set(script, target, value)
                adding = false
            }
        )
    }
}

@Composable
private fun AddNodeDialog(isArray: Boolean, onDismiss: () -> Unit, onAdd: (String?, Any) -> Unit) {
    var key by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("text") }
    var text by remember { mutableStateOf("") }
    var flag by remember { mutableStateOf(false) }
    val types = listOf("text" to "Teks", "number" to "Angka", "boolean" to "On/Off", "object" to "Objek (berisi kunci)", "array" to "Daftar (berisi item)")
    val keyOk = isArray || (key.isNotBlank() && key != "__proto__" && key != "constructor" && key != "prototype")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isArray) "Tambah item" else "Tambah kunci") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!isArray) {
                    OutlinedTextField(key, { key = it }, label = { Text("Nama kunci") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Text("Tipe", style = MaterialTheme.typography.bodySmall)
                for ((t, label) in types) {
                    Row(Modifier.fillMaxWidth().clickable { type = t }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = type == t, onClick = { type = t })
                        Text(label)
                    }
                }
                when (type) {
                    "boolean" -> Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Nilai awal (on)", Modifier.weight(1f))
                        Switch(flag, { flag = it })
                    }
                    "text", "number" -> OutlinedTextField(
                        text, { text = it }, label = { Text("Nilai awal") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    else -> { }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = keyOk, onClick = {
                val value: Any = when (type) {
                    "number" -> text.toDoubleOrNull() ?: 0.0
                    "boolean" -> flag
                    "object" -> JSONObject()
                    "array" -> JSONArray()
                    else -> text
                }
                onAdd(if (isArray) null else key.trim(), value)
            }) { Text("Tambah") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
