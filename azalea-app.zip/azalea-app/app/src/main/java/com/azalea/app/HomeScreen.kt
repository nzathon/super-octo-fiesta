package com.azalea.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun HomeScreen(
    tab: Int,
    onTab: (Int) -> Unit,
    servers: List<Server>,
    accounts: List<Account>,
    selectedId: String,
    onSelectAccount: (String) -> Unit,
    onSaveAccount: (Account) -> Unit,
    onDeleteAccount: (String) -> Unit,
    onConnect: (Server, Account) -> Unit,
    onEditServer: (Server?) -> Unit,
    onOpenSession: () -> Unit,
    onModuleSettings: (String) -> Unit,
) {
    val info by Core.info.collectAsState()
    val bad by Core.infoBad.collectAsState()
    val status by Core.status.collectAsState()
    val onlineSince by Core.onlineSinceMs.collectAsState()
    val mcVer by Modules.mcVersion.collectAsState()
    val mcProto by Modules.mcProtocol.collectAsState()
    var showLog by remember { mutableStateOf(false) }
    var needAccount by remember { mutableStateOf(false) }
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(status, onlineSince) {
        if (status == "online" && onlineSince != null) {
            while (true) {
                nowMs = System.currentTimeMillis()
                delay(1000L)
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Azalea", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                val protoInfo = if (mcVer.isNotBlank()) " · MC $mcVer" + (if (mcProto > 0) " (#$mcProto)" else "") else ""
                Text(
                    info + protoInfo,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (bad) AzaleaPalette.Danger else AzaleaPalette.TextMuted,
                )
            }
            TextButton(onClick = { showLog = true }) { Text("Log") }
        }
        if (status != "offline") {
            val activeConn = Core.current()
            val uptime = if (status == "online" && onlineSince != null) " · ${formatDuration(nowMs - onlineSince!!)}" else ""
            Surface(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = AzaleaPalette.CardAlt,
                border = BorderStroke(1.dp, if (status == "online") AzaleaPalette.Emerald else AzaleaPalette.Border),
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            activeConn?.first?.name ?: "Sedang terhubung",
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            statusLabel(status) +
                                (activeConn?.second?.username?.let { " · $it" } ?: "") +
                                uptime,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (status == "online") AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = { Core.disconnect() },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        border = BorderStroke(1.dp, AzaleaPalette.Border),
                    ) {
                        Text("Putus", color = AzaleaPalette.Danger, fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(6.dp))
                    Button(
                        onClick = onOpenSession,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                    ) { Text("Buka", fontSize = 12.sp) }
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> AccountsPage(accounts, selectedId, onSelectAccount, onSaveAccount, onDeleteAccount)
                1 -> ServersPage(
                    servers = servers,
                    onConnect = { sv ->
                        val acc = accounts.firstOrNull { it.id == selectedId }
                        if (acc == null) needAccount = true else onConnect(sv, acc)
                    },
                    onEdit = onEditServer,
                )
                2 -> ModulesPage(onModuleSettings)
                else -> SettingsPage()
            }
        }
        NavigationBar(containerColor = AzaleaPalette.Surface) {
            NavigationBarItem(
                selected = tab == 0,
                onClick = { onTab(0) },
                icon = { Icon(AzaleaIcons.Account, contentDescription = "Akun", modifier = Modifier.size(22.dp)) },
                label = { Text("Akun") },
            )
            NavigationBarItem(
                selected = tab == 1,
                onClick = { onTab(1) },
                icon = { Icon(AzaleaIcons.Server, contentDescription = "Server", modifier = Modifier.size(22.dp)) },
                label = { Text("Server") },
            )
            NavigationBarItem(
                selected = tab == 2,
                onClick = { onTab(2) },
                icon = { Icon(AzaleaIcons.Modules, contentDescription = "Modul", modifier = Modifier.size(22.dp)) },
                label = { Text("Modul") },
            )
            NavigationBarItem(
                selected = tab == 3,
                onClick = { onTab(3) },
                icon = { Icon(AzaleaIcons.Settings, contentDescription = "Setelan", modifier = Modifier.size(22.dp)) },
                label = { Text("Setelan") },
            )
        }
    }
    if (showLog) {
        AlertDialog(
            onDismissRequest = { showLog = false },
            title = { Text("Log") },
            text = { LogBox(Modifier.fillMaxWidth().height(360.dp)) },
            confirmButton = { TextButton(onClick = { showLog = false }) { Text("Tutup") } },
        )
    }
    if (needAccount) {
        AlertDialog(
            onDismissRequest = { needAccount = false },
            title = { Text("Pilih akun dulu") },
            text = { Text("Belum ada akun yang dipilih. Tambah atau pilih username di tab Akun.") },
            confirmButton = { TextButton(onClick = { needAccount = false; onTab(0) }) { Text("Ke tab Akun") } },
            dismissButton = { TextButton(onClick = { needAccount = false }) { Text("Batal") } },
        )
    }
}

@Composable
private fun AccountsPage(
    accounts: List<Account>,
    selectedId: String,
    onSelect: (String) -> Unit,
    onSave: (Account) -> Unit,
    onDelete: (String) -> Unit,
) {
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }
    val hashVer by TexCache.hashVersion.collectAsState()
    val players by Core.players.collectAsState()

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Text(
                    "Akun: pilih username yang dipakai untuk join",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AzaleaPalette.TextMuted,
                )
            }
            if (accounts.isEmpty()) item {
                Text("Belum ada akun. Tekan + untuk menambah username.", Modifier.padding(vertical = 16.dp))
            }
            items(accounts, key = { it.id }) { a ->
                val liveHash = remember(a.username, hashVer, players) {
                    players.firstOrNull { it.name.equals(a.username, ignoreCase = true) }?.hash
                        ?: TexCache.knownHashFor(a.username)
                }
                val isSelected = a.id == selectedId
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(a.id) },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) AzaleaPalette.CardSelected else AzaleaPalette.Card,
                    ),
                    border = BorderStroke(1.dp, if (isSelected) AzaleaPalette.BorderSelected else AzaleaPalette.Border),
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        PlayerHead(name = a.username, hash = liveHash, size = 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.username, style = MaterialTheme.typography.titleMedium)
                            if (isSelected) {
                                Text("Dipakai", style = MaterialTheme.typography.bodySmall, color = AzaleaPalette.Emerald)
                            }
                        }
                        TextButton(onClick = { editing = a }) { Text("Ubah") }
                        RadioButton(selected = isSelected, onClick = { onSelect(a.id) })
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { adding = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = AzaleaPalette.Emerald,
            contentColor = Color(0xFF052E1E),
        ) {
            Icon(AzaleaIcons.Add, contentDescription = "Tambah Akun", modifier = Modifier.size(24.dp))
        }
    }
    if (adding) {
        AccountDialog(
            account = null,
            onSave = { onSave(it); adding = false },
            onDelete = { },
            onDismiss = { adding = false },
        )
    }
    editing?.let { acc ->
        AccountDialog(
            account = acc,
            onSave = { onSave(it); editing = null },
            onDelete = { onDelete(it); editing = null },
            onDismiss = { editing = null },
        )
    }
}

@Composable
private fun AccountDialog(
    account: Account?,
    onSave: (Account) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(account?.username ?: "") }
    val valid = Regex("^[A-Za-z0-9_]{3,16}$").matches(name)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (account == null) "Akun baru" else "Ubah akun") },
        text = {
            OutlinedTextField(
                name, { name = it.trim() }, label = { Text("Username") }, singleLine = true,
                isError = name.isNotEmpty() && !valid,
                supportingText = { Text("3-16 karakter: huruf, angka, garis bawah") },
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onSave(Account(account?.id ?: UUID.randomUUID().toString(), name)) }) {
                Text("Simpan")
            }
        },
        dismissButton = {
            Row {
                if (account != null) TextButton(onClick = { onDelete(account.id) }) { Text("Hapus", color = AzaleaPalette.Danger) }
                TextButton(onClick = onDismiss) { Text("Batal") }
            }
        },
    )
}

@Composable
private fun ServersPage(servers: List<Server>, onConnect: (Server) -> Unit, onEdit: (Server?) -> Unit) {
    val status = remember { mutableStateMapOf<String, ServerStatus>() }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(servers, tick) {
        while (true) {
            coroutineScope {
                for (sv in servers) launch { status[sv.id] = ServerPing.ping(sv.host, sv.port) }
            }
            delay(30_000)
        }
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Ketuk server untuk join", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = AzaleaPalette.TextMuted)
                    TextButton(onClick = { status.clear(); tick++ }) { Text("Segarkan") }
                }
            }
            if (servers.isEmpty()) item { Text("Belum ada server. Tekan + untuk menambah.", Modifier.padding(vertical = 16.dp)) }
            items(servers, key = { it.id }) { sv ->
                ServerRow(sv, status[sv.id], onClick = { onConnect(sv) }, onEdit = { onEdit(sv) })
            }
        }
        FloatingActionButton(
            onClick = { onEdit(null) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = AzaleaPalette.Emerald,
            contentColor = Color(0xFF052E1E),
        ) {
            Icon(AzaleaIcons.Add, contentDescription = "Tambah Server", modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun ServerRow(sv: Server, st: ServerStatus?, onClick: () -> Unit, onEdit: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(AzaleaPalette.Card).border(1.dp, AzaleaPalette.Border, shape)
            .clickable { onClick() }.padding(10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(6.dp)).background(AzaleaPalette.CardAlt),
            contentAlignment = Alignment.Center,
        ) {
            if (st?.favicon != null) Image(st.favicon, null, Modifier.size(56.dp), filterQuality = FilterQuality.None)
            else Text(if (st == null) "…" else if (st.online) "MC" else "×", color = AzaleaPalette.TextMuted, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sv.name, Modifier.weight(1f), color = AzaleaPalette.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (st != null && st.online) {
                    Text("${st.players}/${st.maxPlayers}", color = AzaleaPalette.TextMuted, fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    PingBars(st.latencyMs)
                }
            }
            when {
                st == null -> Text("Memeriksa server…", color = AzaleaPalette.TextMuted, fontSize = 12.sp)
                st.online -> Text(
                    if (st.motd.text.isBlank()) AnnotatedString("(tanpa MOTD)") else st.motd,
                    color = AzaleaPalette.TextMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp,
                )
                else -> Text("Tidak bisa terhubung (${st.error})", color = AzaleaPalette.Danger, fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                val ver = if (st != null && st.online && st.versionName.isNotBlank()) st.versionName else "Azalea Core"
                Text(
                    "${sv.host}:${sv.port} · $ver" + if (st != null && st.online && st.latencyMs >= 0) " · ${st.latencyMs} ms" else "",
                    Modifier.weight(1f), color = AzaleaPalette.TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                TextButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text("Ubah", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun PingBars(ms: Int) {
    val level = when { ms < 0 -> 1; ms < 150 -> 5; ms < 300 -> 4; ms < 600 -> 3; ms < 1000 -> 2; else -> 1 }
    val on = if (level >= 4) AzaleaPalette.Emerald else if (level == 3) AzaleaPalette.Warning else AzaleaPalette.Danger
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(1.5.dp)) {
        for (i in 1..5) Box(Modifier.width(3.dp).height((3 + i * 2).dp).background(if (i <= level) on else AzaleaPalette.Border))
    }
}

@Composable
fun EditServerScreen(server: Server?, onSave: (Server) -> Unit, onDelete: (String) -> Unit, onCancel: () -> Unit) {
    var name by remember { mutableStateOf(server?.name ?: "") }
    var host by remember { mutableStateOf(server?.host ?: "") }
    var port by remember { mutableStateOf((server?.port ?: 25565).toString()) }
    val mcVer by Modules.mcVersion.collectAsState()
    val mcProto by Modules.mcProtocol.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (server == null) "Server baru" else "Ubah server", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, label = { Text("Nama server") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = host,
            onValueChange = { raw ->
                val trimmed = raw.trim()
                val idx = trimmed.lastIndexOf(':')
                if (idx > 0 && idx < trimmed.length - 1) {
                    val maybePort = trimmed.substring(idx + 1)
                    if (maybePort.all { it.isDigit() }) {
                        host = trimmed.substring(0, idx)
                        port = maybePort
                        return@OutlinedTextField
                    }
                }
                host = trimmed
            },
            label = { Text("Alamat (IP / domain, bisa tempel host:port)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            color = AzaleaPalette.Card,
            border = BorderStroke(1.dp, AzaleaPalette.Border),
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Versi Klien (Core Aktif)", style = MaterialTheme.typography.labelMedium, color = AzaleaPalette.Emerald)
                val protoDesc = if (mcVer.isNotBlank()) {
                    "Minecraft $mcVer" + if (mcProto > 0) " (Protokol $mcProto)" else ""
                } else {
                    "Ditentukan oleh Azalea Core yang terpasang"
                }
                Text(protoDesc, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Versi protokol dikunci pada binary azalea-core. Server proxy modern (ViaVersion) tetap bisa dimasuki otomatis.",
                    style = MaterialTheme.typography.bodySmall,
                    color = AzaleaPalette.TextMuted,
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onSave(
                        Server(
                            id = server?.id ?: UUID.randomUUID().toString(),
                            name = name.trim().ifBlank { host },
                            host = host,
                            port = port.toIntOrNull() ?: 25565,
                            version = mcVer.ifBlank { server?.version ?: "auto" },
                        )
                    )
                },
                enabled = host.isNotBlank(),
            ) { Text("Simpan") }
            OutlinedButton(onClick = onCancel) { Text("Batal") }
            if (server != null) TextButton(onClick = { onDelete(server.id) }) { Text("Hapus", color = AzaleaPalette.Danger) }
        }
    }
}
