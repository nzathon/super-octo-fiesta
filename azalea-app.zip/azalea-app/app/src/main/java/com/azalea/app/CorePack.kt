package com.azalea.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

data class CorePackInfo(
    val isExternal: Boolean = false,
    val hasWebOverride: Boolean = false,
    val version: String = "",
    val detail: String = "Inti bawaan APK",
    val busy: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
)

/**
 * Mengelola bundel inti eksternal (`filesDir/core/`) agar inti Azalea dan aset web modul
 * bisa diperbarui dari file ZIP tanpa build ulang atau pasang ulang APK.
 */
object CorePack {
    val state = MutableStateFlow(CorePackInfo())
    private val lock = Any()

    @Volatile
    private var externalFailureReason: String? = null

    private fun coreDir(ctx: Context): File = File(ctx.filesDir, "core")
    private fun extBin(ctx: Context): File = File(coreDir(ctx), "azalea-core")
    private fun extWebDir(ctx: Context): File = File(coreDir(ctx), "web")
    private fun manifestFile(ctx: Context): File = File(coreDir(ctx), "manifest.json")
    private fun bundledBin(ctx: Context): File = File(ctx.applicationInfo.nativeLibraryDir, "libazalea.so")

    fun isUsingExternal(ctx: Context): Boolean =
        externalFailureReason == null && extBin(ctx).let { it.isFile && it.length() > 0L }

    fun hasExternalBinaryFile(ctx: Context): Boolean =
        extBin(ctx).let { it.isFile && it.length() > 0L }

    fun isExternalBinary(ctx: Context, bin: File): Boolean =
        bin.absolutePath == extBin(ctx).absolutePath

    fun bundledBinary(ctx: Context): File? =
        bundledBin(ctx).takeIf { it.isFile && it.length() > 0L }

    fun hasWebOverride(ctx: Context): Boolean =
        extWebDir(ctx).let { it.isDirectory && hasAnyFile(it) }

    fun resolveBinary(ctx: Context): File? {
        val ext = extBin(ctx)
        val bundled = bundledBin(ctx)
        if (ext.isFile && ext.length() > 0L && (externalFailureReason == null || !bundled.isFile)) {
            coreDir(ctx).setExecutable(true, false)
            if (!ext.canExecute()) ext.setExecutable(true, false)
            return ext
        }
        return if (bundled.isFile && bundled.length() > 0L) {
            if (!bundled.canExecute()) bundled.setExecutable(true, false)
            bundled
        } else null
    }

    fun markExternalFailure(ctx: Context, reason: String) {
        externalFailureReason = reason
        refreshInfo(ctx, error = reason)
    }

    fun clearExternalFailure() {
        externalFailureReason = null
    }

    fun configureProcessEnv(ctx: Context, bin: File, pb: ProcessBuilder) {
        val env = pb.environment()
        env["HOME"] = ctx.filesDir.absolutePath
        env["TMPDIR"] = ctx.cacheDir.absolutePath
        val libDirs = listOfNotNull(
            bin.parentFile?.absolutePath,
            ctx.applicationInfo.nativeLibraryDir,
            "/system/lib64",
        ).distinct()
        val prevLd = env["LD_LIBRARY_PATH"]?.takeIf { it.isNotBlank() }
        env["LD_LIBRARY_PATH"] = if (prevLd != null) {
            (libDirs + prevLd).joinToString(":")
        } else {
            libDirs.joinToString(":")
        }
    }

    fun openWebAsset(ctx: Context, relPath: String): InputStream? {
        val clean = relPath.trimStart('/')
        if (clean.isEmpty()) return null
        val parts = clean.split('/')
        if (parts.any { it.isEmpty() || it == "." || it == ".." }) return null

        val webDir = extWebDir(ctx)
        if (webDir.isDirectory) {
            try {
                val baseCanon = webDir.canonicalPath
                val target = File(webDir, clean)
                val targetCanon = target.canonicalPath
                if (targetCanon.startsWith(baseCanon + File.separator) && target.isFile) {
                    return FileInputStream(target)
                }
            } catch (_: Throwable) { }
        }
        return try {
            ctx.assets.open(clean)
        } catch (_: Throwable) {
            null
        }
    }

    fun refreshInfo(
        ctx: Context,
        versionOverride: String? = null,
        error: String? = null,
        notice: String? = null,
    ) {
        val app = ctx.applicationContext
        val ext = isUsingExternal(app)
        val hasExtFile = hasExternalBinaryFile(app)
        val hasWeb = hasWebOverride(app)
        val bin = resolveBinary(app)

        var manifestVer = ""
        var manifestRun = ""
        var manifestSha = ""
        val mf = manifestFile(app)
        if (mf.isFile) {
            try {
                val o = JSONObject(mf.readText())
                manifestVer = o.optString("core_version", o.optString("version", ""))
                manifestRun = o.optString("run_number", "")
                manifestSha = o.optString("sha", "")
            } catch (_: Throwable) { }
        }

        val ver = versionOverride?.takeIf { it.isNotBlank() }
            ?: manifestVer.takeIf { it.isNotBlank() }
            ?: Modules.coreVersion.value
        val metaParts = buildList {
            if (ver.isNotBlank()) add("v$ver")
            if (ext && manifestRun.isNotBlank()) add("#$manifestRun")
            if (ext && manifestSha.isNotBlank()) add(manifestSha.take(7))
        }
        val sizeMb = bin?.let { String.format("%.1f MB", it.length() / (1024.0 * 1024.0)) }
        val detail = when {
            bin == null -> "Inti Azalea tidak ditemukan"
            ext -> buildString {
                append("Inti eksternal")
                if (metaParts.isNotEmpty()) append(" (${metaParts.joinToString(" · ")})")
                if (sizeMb != null) append(" · $sizeMb")
                if (hasWeb) append(" · web override")
            }
            else -> buildString {
                append("Inti bawaan APK")
                if (ver.isNotBlank()) append(" (v$ver)")
                if (sizeMb != null) append(" · $sizeMb")
                if (hasWeb) append(" · web override")
                if (hasExtFile && externalFailureReason != null) append(" · fallback")
            }
        }

        val effectiveError = error ?: externalFailureReason
        state.value = CorePackInfo(
            isExternal = ext,
            hasWebOverride = hasWeb,
            version = ver,
            detail = detail,
            busy = false,
            error = effectiveError,
            notice = notice,
        )
        Core.infoBad.value = bin == null || effectiveError != null
        Core.info.value = when {
            bin == null -> "Inti Azalea tidak ditemukan"
            effectiveError != null -> "Inti bermasalah: ${effectiveError.take(48)}"
            ext -> "Inti: Eksternal" + if (ver.isNotBlank()) " v$ver" else ""
            else -> "Inti: Bawaan APK" + if (ver.isNotBlank()) " v$ver" else ""
        }
    }

    fun reload(ctx: Context, onDone: (Boolean) -> Unit = {}) {
        val app = ctx.applicationContext
        if (state.value.busy) return
        state.value = state.value.copy(busy = true, error = null, notice = null)
        Thread({
            val ok = synchronized(lock) {
                externalFailureReason = null
                Modules.loadSync(app, refreshCorePack = false)
            }
            if (ok) {
                refreshInfo(app, notice = "Inti & daftar modul berhasil dimuat ulang")
            } else {
                val err = Modules.lastError.value ?: "Gagal memuat inti Azalea"
                refreshInfo(app, error = err)
            }
            onDone(ok)
        }, "reload-core").start()
    }

    fun importFromUri(ctx: Context, uri: Uri, onDone: (Boolean, String) -> Unit = { _, _ -> }) {
        val app = ctx.applicationContext
        if (state.value.busy) {
            onDone(false, "Sedang memproses import lain")
            return
        }
        state.value = state.value.copy(busy = true, error = null, notice = null)
        Thread({
            synchronized(lock) {
                val tmp = File(app.cacheDir, "core-import.tmp")
                val tmpNested = File(app.cacheDir, "core-import-nested.tmp")
                val staging = File(app.filesDir, "core_staging")
                try {
                    deleteRecursively(staging)
                    staging.mkdirs()
                    staging.setExecutable(true, false)

                    val input = app.contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("Gagal membuka file yang dipilih")
                    input.use { ins ->
                        FileOutputStream(tmp).use { out ->
                            val buf = ByteArray(16 * 1024)
                            var total = 0L
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                if (n == 0) continue
                                total += n
                                if (total > 200L * 1024L * 1024L) {
                                    throw IllegalStateException("Ukuran file terlalu besar (>200 MB)")
                                }
                                out.write(buf, 0, n)
                            }
                        }
                    }

                    val header = ByteArray(4)
                    val readLen = FileInputStream(tmp).use { it.read(header) }
                    if (readLen < 4) throw IllegalStateException("File kosong atau rusak")

                    val isElf = header[0] == 0x7F.toByte() && header[1] == 'E'.code.toByte() &&
                        header[2] == 'L'.code.toByte() && header[3] == 'F'.code.toByte()
                    val isZip = header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()

                    when {
                        isElf -> {
                            tmp.copyTo(File(staging, "azalea-core"), overwrite = true)
                        }
                        isZip -> {
                            val nestedZip = extractBundleZip(tmp, staging, tmpNested)
                            val hasContent = File(staging, "azalea-core").isFile ||
                                hasAnyFile(File(staging, "web"))
                            if (!hasContent && nestedZip != null && nestedZip.isFile) {
                                deleteRecursively(staging)
                                staging.mkdirs()
                                staging.setExecutable(true, false)
                                extractBundleZip(nestedZip, staging, null)
                            }
                        }
                        else -> throw IllegalStateException("Format file tidak didukung (pilih .zip core-pack atau binary azalea-core)")
                    }

                    val stagedBin = File(staging, "azalea-core")
                    val stagedWeb = File(staging, "web")
                    val stagedManifest = File(staging, "manifest.json")
                    val hasBin = stagedBin.isFile && stagedBin.length() > 0L
                    val hasWeb = stagedWeb.isDirectory && hasAnyFile(stagedWeb)

                    if (!hasBin && !hasWeb) {
                        throw IllegalStateException("Arsip tidak berisi azalea-core atau folder web/")
                    }

                    var testedVersion = ""
                    if (hasBin) {
                        val bHead = ByteArray(4)
                        val bRead = FileInputStream(stagedBin).use { it.read(bHead) }
                        val validElf = bRead == 4 && bHead[0] == 0x7F.toByte() &&
                            bHead[1] == 'E'.code.toByte() && bHead[2] == 'L'.code.toByte() &&
                            bHead[3] == 'F'.code.toByte()
                        if (!validElf) {
                            throw IllegalStateException("File azalea-core di dalam arsip bukan binary ELF Android")
                        }
                        stagedBin.setExecutable(true, false)
                        testedVersion = probeBinary(app, stagedBin)
                    }

                    if (Core.current() != null || Core.status.value != "offline") {
                        Core.stopAndAwait(1500L)
                    }

                    val destDir = coreDir(app)
                    destDir.mkdirs()
                    destDir.setExecutable(true, false)

                    if (hasBin) {
                        val destBin = extBin(app)
                        val tmpSwap = File(destDir, "azalea-core.new")
                        stagedBin.copyTo(tmpSwap, overwrite = true)
                        tmpSwap.setExecutable(true, false)
                        if (destBin.exists()) destBin.delete()
                        if (!tmpSwap.renameTo(destBin)) {
                            tmpSwap.copyTo(destBin, overwrite = true)
                            tmpSwap.delete()
                        }
                        destBin.setExecutable(true, false)
                    }

                    if (hasWeb) {
                        val destWeb = extWebDir(app)
                        deleteRecursively(destWeb)
                        copyDirectory(stagedWeb, destWeb)
                    } else if (hasBin && !isElf) {
                        // Zip baru tidak membawa web/: hapus web override lama agar sinkron dengan aset APK/core baru
                        deleteRecursively(extWebDir(app))
                    }

                    if (stagedManifest.isFile) {
                        stagedManifest.copyTo(manifestFile(app), overwrite = true)
                    } else if (hasBin) {
                        manifestFile(app).delete()
                    }

                    externalFailureReason = null

                    val okMsg = when {
                        hasBin && hasWeb -> "Core & aset web berhasil dipasang"
                        hasBin -> "Binary core berhasil dipasang"
                        else -> "Aset web berhasil diperbarui"
                    }
                    Core.appLog("CorePack: $okMsg")
                    val loaded = Modules.loadSync(app, refreshCorePack = false)
                    if (loaded) {
                        refreshInfo(app, versionOverride = testedVersion.ifBlank { null }, notice = okMsg)
                        onDone(true, okMsg)
                    } else {
                        val loadErr = Modules.lastError.value ?: "Core terpasang, tetapi gagal memuat daftar modul"
                        refreshInfo(app, versionOverride = testedVersion.ifBlank { null }, error = loadErr)
                        onDone(false, loadErr)
                    }
                } catch (e: Throwable) {
                    val msg = e.message?.ifBlank { e.javaClass.simpleName } ?: e.javaClass.simpleName
                    Core.appLog("Import core gagal: $msg")
                    refreshInfo(app, error = msg)
                    onDone(false, msg)
                } finally {
                    tmp.delete()
                    tmpNested.delete()
                    deleteRecursively(staging)
                }
            }
        }, "import-core").start()
    }

    fun resetToBundled(ctx: Context, onDone: (String) -> Unit = {}) {
        val app = ctx.applicationContext
        if (state.value.busy) return
        state.value = state.value.copy(busy = true, error = null, notice = null)
        Thread({
            synchronized(lock) {
                try {
                    if (Core.current() != null || Core.status.value != "offline") {
                        Core.stopAndAwait(1500L)
                    }
                    deleteRecursively(coreDir(app))
                    externalFailureReason = null
                    val msg = "Kembali ke inti bawaan APK"
                    Core.appLog("CorePack: $msg")
                    val loaded = Modules.loadSync(app, refreshCorePack = false)
                    if (loaded) {
                        refreshInfo(app, notice = msg)
                    } else {
                        val err = Modules.lastError.value ?: "Gagal memuat inti bawaan APK"
                        refreshInfo(app, error = err)
                    }
                    onDone(msg)
                } catch (e: Throwable) {
                    val msg = e.message ?: e.javaClass.simpleName
                    refreshInfo(app, error = msg)
                    onDone(msg)
                }
            }
        }, "reset-core").start()
    }

    private fun probeBinary(ctx: Context, bin: File): String {
        bin.parentFile?.setExecutable(true, false)
        bin.setExecutable(true, false)
        val p = try {
            val pb = ProcessBuilder(bin.absolutePath, "modules").redirectErrorStream(true)
            configureProcessEnv(ctx, bin, pb)
            pb.start()
        } catch (e: Throwable) {
            throw IllegalStateException("Binary tidak bisa dijalankan: ${e.message}")
        }
        val outLines = ArrayList<String>()
        val readerThread = Thread({
            try {
                p.inputStream.bufferedReader().forEachLine { outLines.add(it) }
            } catch (_: Throwable) { }
        }, "probe-core")
        readerThread.start()
        val finished = p.waitFor(6, TimeUnit.SECONDS)
        if (!finished) {
            p.destroyForcibly()
            throw IllegalStateException("Uji coba core timeout (>6 detik)")
        }
        readerThread.join(1000)
        val code = p.exitValue()
        val root = parseModulesJson(outLines)
        if (code != 0 || root == null) {
            val hint = outLines.firstOrNull { it.isNotBlank() }?.trim()?.take(140) ?: "keluar kode $code"
            throw IllegalStateException("Uji coba core gagal (kode $code: $hint)")
        }
        return root.optString("core_version", "")
    }

    fun parseModulesJson(lines: List<String>): JSONObject? {
        for (raw in lines) {
            val s = raw.trim()
            if (!s.startsWith("{")) continue
            try {
                val o = JSONObject(s)
                if (o.optString("t") == "modules") return o
            } catch (_: Throwable) { }
        }
        return null
    }

    private fun extractBundleZip(zipFile: File, stagingDir: File, nestedOut: File?): File? {
        val validEntries = ArrayList<Pair<ZipEntry, String>>()
        ZipFile(zipFile).use { zf ->
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val entry = en.nextElement()
                if (entry.isDirectory) continue
                val rawName = entry.name.replace('\\', '/').trimStart('/')
                val parts = rawName.split('/')
                if (parts.any { it == ".." || it == "." || it.isEmpty() || it == "__MACOSX" || it == ".DS_Store" }) continue
                validEntries.add(entry to rawName)
            }

            if (validEntries.isEmpty()) return null

            // Deteksi wrapper folder tunggal (mis. core-pack/, azalea-core-pack-123/, dll.)
            val firstSegments = validEntries.mapNotNull { (_, p) ->
                val idx = p.indexOf('/')
                if (idx > 0) p.substring(0, idx) else null
            }.toSet()
            val allHaveSlash = validEntries.all { (_, p) -> p.contains('/') }
            val commonWrapper = if (allHaveSlash && firstSegments.size == 1) {
                val only = firstSegments.first()
                if (only != "web" && only != "assets" && only != "lib") "$only/" else null
            } else null

            val normalized = validEntries.map { (entry, raw) ->
                val stripped = if (commonWrapper != null && raw.startsWith(commonWrapper)) {
                    raw.removePrefix(commonWrapper)
                } else {
                    normalizeEntryPath(raw)
                }
                entry to stripped
            }

            var bestBinEntry: ZipEntry? = null
            var bestBinScore = -1
            var manifestEntry: ZipEntry? = null
            var manifestExact = false
            val webEntries = ArrayList<Pair<ZipEntry, String>>()
            val assetEntries = ArrayList<Pair<ZipEntry, String>>()
            val zipCandidates = ArrayList<Pair<ZipEntry, String>>()

            for ((entry, norm) in normalized) {
                val lower = norm.lowercase()
                val binScore = when {
                    norm == "azalea-core" || norm == "libazalea.so" -> 4
                    norm == "arm64-v8a/libazalea.so" || lower.endsWith("/arm64-v8a/libazalea.so") -> 3
                    (norm.endsWith("/azalea-core") || norm.endsWith("/libazalea.so")) &&
                        !lower.contains("armeabi") && !lower.contains("x86") -> 2
                    norm.endsWith("/azalea-core") || norm.endsWith("/libazalea.so") -> 1
                    else -> -1
                }
                if (binScore > bestBinScore) {
                    bestBinScore = binScore
                    bestBinEntry = entry
                }

                when {
                    norm == "manifest.json" -> {
                        manifestEntry = entry
                        manifestExact = true
                    }
                    !manifestExact && norm.endsWith("/manifest.json") -> {
                        manifestEntry = entry
                    }
                }

                when {
                    norm.startsWith("web/") -> {
                        val rel = norm.removePrefix("web/").trimStart('/')
                        if (rel.isNotEmpty()) webEntries.add(entry to rel)
                    }
                    norm.contains("/web/") -> {
                        val rel = norm.substringAfter("/web/").trimStart('/')
                        if (rel.isNotEmpty()) webEntries.add(entry to rel)
                    }
                    norm.startsWith("assets/") -> {
                        val rel = norm.removePrefix("assets/").trimStart('/')
                        if (rel.isNotEmpty()) assetEntries.add(entry to rel)
                    }
                    lower.endsWith(".zip") -> {
                        zipCandidates.add(entry to norm)
                    }
                }
            }

            if (bestBinEntry == null && webEntries.isEmpty() && assetEntries.isEmpty()) {
                val looksLikeSource = normalized.any { (_, p) ->
                    p == "rust/Cargo.toml" || p.endsWith("/rust/Cargo.toml") ||
                        p == "app/build.gradle.kts" || p.endsWith("/app/build.gradle.kts")
                }
                if (looksLikeSource && zipCandidates.isEmpty()) {
                    throw IllegalStateException("Ini ZIP source proyek, bukan azalea-core-pack.zip hasil build GitHub Actions")
                }
                if (nestedOut != null && zipCandidates.isNotEmpty()) {
                    val chosen = zipCandidates.firstOrNull { it.second.lowercase().contains("core") }
                        ?: if (zipCandidates.size == 1) zipCandidates.first() else null
                    if (chosen != null) {
                        val buf = ByteArray(16 * 1024)
                        zf.getInputStream(chosen.first).use { ins -> writeStream(ins, nestedOut, buf) }
                        return nestedOut
                    }
                }
                return null
            }

            val buf = ByteArray(16 * 1024)
            bestBinEntry?.let { entry ->
                zf.getInputStream(entry).use { ins ->
                    writeStream(ins, File(stagingDir, "azalea-core"), buf)
                }
            }
            manifestEntry?.let { entry ->
                zf.getInputStream(entry).use { ins ->
                    writeStream(ins, File(stagingDir, "manifest.json"), buf)
                }
            }
            val chosenWeb = if (webEntries.isNotEmpty()) webEntries else assetEntries
            for ((entry, rel) in chosenWeb) {
                zf.getInputStream(entry).use { ins ->
                    writeStream(ins, File(File(stagingDir, "web"), rel), buf)
                }
            }
        }
        return null
    }

    private fun normalizeEntryPath(path: String): String {
        val prefixes = listOf("core-pack/", "azalea-core-pack/")
        for (p in prefixes) {
            if (path.startsWith(p)) return path.removePrefix(p)
        }
        return path
    }

    private fun writeStream(ins: InputStream, dest: File, buf: ByteArray) {
        dest.parentFile?.mkdirs()
        FileOutputStream(dest).use { out ->
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                if (n == 0) continue
                out.write(buf, 0, n)
            }
        }
    }

    private fun hasAnyFile(dir: File): Boolean {
        if (!dir.isDirectory) return false
        val children = dir.listFiles() ?: return false
        for (c in children) {
            if (c.isFile || (c.isDirectory && hasAnyFile(c))) return true
        }
        return false
    }

    private fun copyDirectory(src: File, dst: File) {
        dst.mkdirs()
        val children = src.listFiles() ?: return
        for (c in children) {
            val target = File(dst, c.name)
            if (c.isDirectory) copyDirectory(c, target)
            else c.copyTo(target, overwrite = true)
        }
    }

    private fun deleteRecursively(f: File) {
        if (!f.exists()) return
        if (f.isDirectory) {
            f.listFiles()?.forEach { deleteRecursively(it) }
        }
        f.delete()
    }
}
