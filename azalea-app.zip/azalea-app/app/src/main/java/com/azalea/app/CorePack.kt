package com.azalea.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

data class CorePackInfo(
    val isExternal: Boolean = false,
    val hasWebOverride: Boolean = false,
    val version: String = "",
    val detail: String = "Inti bawaan APK",
    val busy: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
)

/**
 * Mengelola bundel inti eksternal (`filesDir/core/`) agar inti Azalea dan aset web modul
 * bisa diperbarui dari file ZIP tanpa build ulang atau pasang ulang APK.
 */
object CorePack {
    val state = MutableStateFlow(CorePackInfo())
    private val lock = Any()

    private fun coreDir(ctx: Context): File = File(ctx.filesDir, "core")
    private fun extBin(ctx: Context): File = File(coreDir(ctx), "azalea-core")
    private fun extWebDir(ctx: Context): File = File(coreDir(ctx), "web")
    private fun manifestFile(ctx: Context): File = File(coreDir(ctx), "manifest.json")
    private fun bundledBin(ctx: Context): File = File(ctx.applicationInfo.nativeLibraryDir, "libazalea.so")

    fun isUsingExternal(ctx: Context): Boolean =
        extBin(ctx).let { it.isFile && it.length() > 0L }

    fun hasWebOverride(ctx: Context): Boolean =
        extWebDir(ctx).let { it.isDirectory && hasAnyFile(it) }

    fun resolveBinary(ctx: Context): File? {
        val ext = extBin(ctx)
        if (ext.isFile && ext.length() > 0L) {
            if (!ext.canExecute()) ext.setExecutable(true, false)
            return ext
        }
        val bundled = bundledBin(ctx)
        return if (bundled.isFile) bundled else null
    }

    fun openWebAsset(ctx: Context, relPath: String): InputStream? {
        val clean = relPath.trimStart('/')
        if (clean.isEmpty()) return null
        val parts = clean.split('/')
        if (parts.any { it.isEmpty() || it == "." || it == ".." }) return null

        val webDir = extWebDir(ctx)
        if (webDir.isDirectory) {
            try {
                val baseCanon = webDir.canonicalPath
                val target = File(webDir, clean)
                val targetCanon = target.canonicalPath
                if (targetCanon.startsWith(baseCanon + File.separator) && target.isFile) {
                    return FileInputStream(target)
                }
            } catch (_: Throwable) { }
        }
        return try {
            ctx.assets.open(clean)
        } catch (_: Throwable) {
            null
        }
    }

    fun refreshInfo(
        ctx: Context,
        versionOverride: String? = null,
        error: String? = null,
        notice: String? = null,
    ) {
        val app = ctx.applicationContext
        val ext = isUsingExternal(app)
        val hasWeb = hasWebOverride(app)
        val bin = resolveBinary(app)

        var manifestVer = ""
        var manifestRun = ""
        var manifestSha = ""
        val mf = manifestFile(app)
        if (mf.isFile) {
            try {
                val o = JSONObject(mf.readText())
                manifestVer = o.optString("core_version", o.optString("version", ""))
                manifestRun = o.optString("run_number", "")
                manifestSha = o.optString("sha", "")
            } catch (_: Throwable) { }
        }

        val ver = versionOverride?.takeIf { it.isNotBlank() }
            ?: manifestVer.takeIf { it.isNotBlank() }
            ?: Modules.coreVersion.value
        val metaParts = buildList {
            if (ver.isNotBlank()) add("v$ver")
            if (ext && manifestRun.isNotBlank()) add("#$manifestRun")
            if (ext && manifestSha.isNotBlank()) add(manifestSha.take(7))
        }
        val sizeMb = bin?.let { String.format("%.1f MB", it.length() / (1024.0 * 1024.0)) }
        val detail = when {
            bin == null -> "Inti Azalea tidak ditemukan"
            ext -> buildString {
                append("Inti eksternal")
                if (metaParts.isNotEmpty()) append(" (${metaParts.joinToString(" · ")})")
                if (sizeMb != null) append(" · $sizeMb")
                if (hasWeb) append(" · web override")
            }
            else -> buildString {
                append("Inti bawaan APK")
                if (ver.isNotBlank()) append(" (v$ver)")
                if (sizeMb != null) append(" · $sizeMb")
                if (hasWeb) append(" · web override")
            }
        }

        state.value = CorePackInfo(
            isExternal = ext,
            hasWebOverride = hasWeb,
            version = ver,
            detail = detail,
            busy = false,
            error = error,
            notice = notice,
        )
        Core.infoBad.value = bin == null
        Core.info.value = if (bin == null) "Inti Azalea tidak ditemukan"
        else if (ext) "Inti: Eksternal" + if (ver.isNotBlank()) " v$ver" else ""
        else "Inti: Bawaan APK" + if (ver.isNotBlank()) " v$ver" else ""
    }

    fun importFromUri(ctx: Context, uri: Uri, onDone: (Boolean, String) -> Unit = { _, _ -> }) {
        val app = ctx.applicationContext
        if (state.value.busy) {
            onDone(false, "Sedang memproses import lain")
            return
        }
        state.value = state.value.copy(busy = true, error = null, notice = null)
        Thread({
            synchronized(lock) {
                val tmp = File(app.cacheDir, "core-import.tmp")
                val tmpNested = File(app.cacheDir, "core-import-nested.tmp")
                val staging = File(app.filesDir, "core_staging")
                try {
                    deleteRecursively(staging)
                    staging.mkdirs()

                    val input = app.contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("Gagal membuka file yang dipilih")
                    input.use { ins ->
                        FileOutputStream(tmp).use { out ->
                            val buf = ByteArray(16 * 1024)
                            var total = 0L
                            while (true) {
                                val n = ins.read(buf)
                                if (n <= 0) break
                                total += n
                                if (total > 150L * 1024L * 1024L) {
                                    throw IllegalStateException("Ukuran file terlalu besar (>150 MB)")
                                }
                                out.write(buf, 0, n)
                            }
                        }
                    }

                    val header = ByteArray(4)
                    val readLen = FileInputStream(tmp).use { it.read(header) }
                    if (readLen < 4) throw IllegalStateException("File kosong atau rusak")

                    val isElf = header[0] == 0x7F.toByte() && header[1] == 'E'.code.toByte() &&
                        header[2] == 'L'.code.toByte() && header[3] == 'F'.code.toByte()
                    val isZip = header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()

                    when {
                        isElf -> {
                            tmp.copyTo(File(staging, "azalea-core"), overwrite = true)
                        }
                        isZip -> {
                            val nestedZip = extractBundleZip(tmp, staging, tmpNested)
                            val hasContent = File(staging, "azalea-core").isFile ||
                                hasAnyFile(File(staging, "web"))
                            if (!hasContent && nestedZip != null && nestedZip.isFile) {
                                deleteRecursively(staging)
                                staging.mkdirs()
                                extractBundleZip(nestedZip, staging, null)
                            }
                        }
                        else -> throw IllegalStateException("Format file tidak didukung (pilih .zip core-pack atau binary azalea-core)")
                    }

                    val stagedBin = File(staging, "azalea-core")
                    val stagedWeb = File(staging, "web")
                    val stagedManifest = File(staging, "manifest.json")
                    val hasBin = stagedBin.isFile && stagedBin.length() > 0L
                    val hasWeb = stagedWeb.isDirectory && hasAnyFile(stagedWeb)

                    if (!hasBin && !hasWeb) {
                        throw IllegalStateException("Arsip tidak berisi azalea-core atau folder web/")
                    }

                    var testedVersion = ""
                    if (hasBin) {
                        val bHead = ByteArray(4)
                        val bRead = FileInputStream(stagedBin).use { it.read(bHead) }
                        val validElf = bRead == 4 && bHead[0] == 0x7F.toByte() &&
                            bHead[1] == 'E'.code.toByte() && bHead[2] == 'L'.code.toByte() &&
                            bHead[3] == 'F'.code.toByte()
                        if (!validElf) {
                            throw IllegalStateException("File azalea-core di dalam arsip bukan binary ELF Android")
                        }
                        stagedBin.setExecutable(true, false)
                        testedVersion = probeBinary(stagedBin)
                    }

                    if (Core.current() != null) {
                        Core.disconnect()
                        Thread.sleep(150)
                    }

                    val destDir = coreDir(app)
                    destDir.mkdirs()

                    if (hasBin) {
                        val destBin = extBin(app)
                        val tmpSwap = File(destDir, "azalea-core.new")
                        stagedBin.copyTo(tmpSwap, overwrite = true)
                        tmpSwap.setExecutable(true, false)
                        if (destBin.exists()) destBin.delete()
                        if (!tmpSwap.renameTo(destBin)) {
                            tmpSwap.copyTo(destBin, overwrite = true)
                            tmpSwap.delete()
                        }
                        destBin.setExecutable(true, false)
                    }

                    if (hasWeb) {
                        val destWeb = extWebDir(app)
                        deleteRecursively(destWeb)
                        copyDirectory(stagedWeb, destWeb)
                    } else if (hasBin && !isElf) {
                        // Zip baru tidak membawa web/: hapus web override lama agar sinkron dengan aset APK/core baru
                        deleteRecursively(extWebDir(app))
                    }

                    if (stagedManifest.isFile) {
                        stagedManifest.copyTo(manifestFile(app), overwrite = true)
                    } else if (hasBin) {
                        manifestFile(app).delete()
                    }

                    val okMsg = when {
                        hasBin && hasWeb -> "Core & aset web berhasil dipasang"
                        hasBin -> "Binary core berhasil dipasang"
                        else -> "Aset web berhasil diperbarui"
                    }
                    Core.appLog("CorePack: $okMsg")
                    Modules.load(app) { _ ->
                        refreshInfo(app, versionOverride = testedVersion.ifBlank { null }, notice = okMsg)
                    }
                    onDone(true, okMsg)
                } catch (e: Throwable) {
                    val msg = e.message?.ifBlank { e.javaClass.simpleName } ?: e.javaClass.simpleName
                    Core.appLog("Import core gagal: $msg")
                    refreshInfo(app, error = msg)
                    onDone(false, msg)
                } finally {
                    tmp.delete()
                    tmpNested.delete()
                    deleteRecursively(staging)
                }
            }
        }, "import-core").start()
    }

    fun resetToBundled(ctx: Context, onDone: (String) -> Unit = {}) {
        val app = ctx.applicationContext
        if (state.value.busy) return
        state.value = state.value.copy(busy = true, error = null, notice = null)
        Thread({
            synchronized(lock) {
                try {
                    if (Core.current() != null) {
                        Core.disconnect()
                        Thread.sleep(150)
                    }
                    deleteRecursively(coreDir(app))
                    val msg = "Kembali ke inti bawaan APK"
                    Core.appLog("CorePack: $msg")
                    Modules.load(app) { _ ->
                        refreshInfo(app, notice = msg)
                    }
                    onDone(msg)
                } catch (e: Throwable) {
                    val msg = e.message ?: e.javaClass.simpleName
                    refreshInfo(app, error = msg)
                    onDone(msg)
                }
            }
        }, "reset-core").start()
    }

    private fun probeBinary(bin: File): String {
        val p = try {
            ProcessBuilder(bin.absolutePath, "modules").redirectErrorStream(true).start()
        } catch (e: Throwable) {
            throw IllegalStateException("Binary tidak bisa dijalankan: ${e.message}")
        }
        val outLines = ArrayList<String>()
        val readerThread = Thread({
            try {
                p.inputStream.bufferedReader().forEachLine { outLines.add(it) }
            } catch (_: Throwable) { }
        }, "probe-core")
        readerThread.start()
        val finished = p.waitFor(6, TimeUnit.SECONDS)
        if (!finished) {
            p.destroyForcibly()
            throw IllegalStateException("Uji coba core timeout (>6 detik)")
        }
        readerThread.join(1000)
        val code = p.exitValue()
        val jsonLine = outLines.firstOrNull { it.startsWith("{\"t\":\"modules\"") }
        if (code != 0 || jsonLine == null) {
            val hint = outLines.firstOrNull { it.isNotBlank() }?.take(140) ?: "keluar kode $code"
            throw IllegalStateException("Uji coba core gagal ($hint)")
        }
        return try {
            JSONObject(jsonLine).optString("core_version", "")
        } catch (_: Throwable) {
            ""
        }
    }

    private fun extractBundleZip(zipFile: File, stagingDir: File, nestedOut: File?): File? {
        var foundNested: File? = null
        var nestedCount = 0
        ZipInputStream(FileInputStream(zipFile).buffered()).use { zis ->
            val buf = ByteArray(16 * 1024)
            while (true) {
                val entry = zis.nextEntry ?: break
                if (entry.isDirectory) {
                    zis.closeEntry()
                    continue
                }
                val rawName = entry.name.replace('\\', '/').trimStart('/')
                if (rawName.split('/').any { it == ".." || it.isEmpty() }) {
                    zis.closeEntry()
                    continue
                }
                val norm = normalizeEntryPath(rawName)
                when {
                    norm == "azalea-core" || norm == "libazalea.so" ||
                        norm.endsWith("/azalea-core") || norm.endsWith("/libazalea.so") -> {
                        writeEntry(zis, File(stagingDir, "azalea-core"), buf)
                    }
                    norm == "manifest.json" -> {
                        writeEntry(zis, File(stagingDir, "manifest.json"), buf)
                    }
                    norm.startsWith("web/") -> {
                        val rel = norm.removePrefix("web/").trimStart('/')
                        if (rel.isNotEmpty()) {
                            writeEntry(zis, File(File(stagingDir, "web"), rel), buf)
                        }
                    }
                    norm.startsWith("assets/") -> {
                        val rel = norm.removePrefix("assets/").trimStart('/')
                        if (rel.isNotEmpty()) {
                            writeEntry(zis, File(File(stagingDir, "web"), rel), buf)
                        }
                    }
                    nestedOut != null && norm.endsWith(".zip", ignoreCase = true) && !norm.contains('/') -> {
                        nestedCount++
                        if (nestedCount == 1) {
                            writeEntry(zis, nestedOut, buf)
                            foundNested = nestedOut
                        }
                    }
                }
                zis.closeEntry()
            }
        }
        return if (nestedCount == 1) foundNested else null
    }

    private fun normalizeEntryPath(path: String): String {
        val prefixes = listOf("core-pack/", "azalea-core-pack/")
        for (p in prefixes) {
            if (path.startsWith(p)) return path.removePrefix(p)
        }
        return path
    }

    private fun writeEntry(ins: InputStream, dest: File, buf: ByteArray) {
        dest.parentFile?.mkdirs()
        FileOutputStream(dest).use { out ->
            while (true) {
                val n = ins.read(buf)
                if (n <= 0) break
                out.write(buf, 0, n)
            }
        }
    }

    private fun hasAnyFile(dir: File): Boolean {
        if (!dir.isDirectory) return false
        val children = dir.listFiles() ?: return false
        for (c in children) {
            if (c.isFile || (c.isDirectory && hasAnyFile(c))) return true
        }
        return false
    }

    private fun copyDirectory(src: File, dst: File) {
        dst.mkdirs()
        val children = src.listFiles() ?: return
        for (c in children) {
            val target = File(dst, c.name)
            if (c.isDirectory) copyDirectory(c, target)
            else c.copyTo(target, overwrite = true)
        }
    }

    private fun deleteRecursively(f: File) {
        if (!f.exists()) return
        if (f.isDirectory) {
            f.listFiles()?.forEach { deleteRecursively(it) }
        }
        f.delete()
    }
}
