package com.azalea.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File

data class ModSetting(val key: String, val label: String, val type: String, val def: Any?)

/** inApp = true: dijalankan oleh aplikasi (Kotlin), false: dijalankan di dalam inti Azalea (Rust). */
data class ModDef(
    val id: String,
    val title: String,
    val desc: String,
    val enabled: Boolean,
    val settings: List<ModSetting>,
    val inApp: Boolean
)

/**
 * Daftar modul + nilai setelannya. Skema modul dibaca dari `libazalea.so modules`,
 * jadi modul baru di Rust muncul sendiri di layar Modul tanpa mengubah Kotlin.
 */
object Modules {
    val list = MutableStateFlow<List<ModDef>>(emptyList())

    /** Dipanggil saat aplikasi mulai. Cepat, tidak butuh koneksi. */
    fun load(ctx: Context) {
        Thread({
            try {
                val bin = File(ctx.applicationInfo.nativeLibraryDir, "libazalea.so")
                if (!bin.exists()) { Core.appLog("daftar modul: libazalea.so tidak ada"); return@Thread }
                val p = ProcessBuilder(bin.absolutePath, "modules").redirectErrorStream(true).start()
                val line = p.inputStream.bufferedReader().readLines().firstOrNull { it.startsWith("{\"t\":\"modules\"") }
                p.waitFor()
                if (line == null) { Core.appLog("daftar modul: keluaran tidak dikenali"); return@Thread }
                val arr = JSONObject(line).getJSONArray("v")
                val rust = (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    val ss = o.optJSONArray("settings")
                    ModDef(
                        o.getString("id"), o.optString("title"), o.optString("desc"), o.optBoolean("enabled", false),
                        (0 until (ss?.length() ?: 0)).map { j ->
                            val s = ss!!.getJSONObject(j)
                            ModSetting(s.getString("key"), s.optString("label"), s.optString("type", "text"), s.opt("default"))
                        },
                        inApp = false
                    )
                }
                list.value = rust
            } catch (e: Throwable) {
                Core.appLog("daftar modul gagal: ${e.javaClass.simpleName}: ${e.message}")
            }
        }, "load-modules").start()
    }

    private fun default(id: String, key: String): Any? {
        val m = list.value.firstOrNull { it.id == id } ?: return null
        if (key == "enabled") return m.enabled
        return m.settings.firstOrNull { it.key == key }?.def
    }

    fun get(id: String, key: String): Any? = Store.moduleGet(id, key) ?: default(id, key)

    /** fallback dipakai kalau daftar modul belum berhasil dimuat. */
    fun bool(id: String, key: String, fallback: Boolean = false): Boolean = when (val v = get(id, key)) {
        null -> fallback
        is Boolean -> v
        is String -> v.equals("true", true)
        else -> fallback
    }

    fun num(id: String, key: String, fallback: Double = 0.0): Double =
        (get(id, key) as? Number)?.toDouble()
            ?: get(id, key)?.toString()?.trim()?.toDoubleOrNull()
            ?: (default(id, key) as? Number)?.toDouble()
            ?: fallback

    fun str(id: String, key: String): String = when (val v = get(id, key)) {
        null -> ""
        is Double -> if (v == Math.floor(v)) v.toLong().toString() else v.toString()
        else -> v.toString()
    }

    fun set(id: String, key: String, value: Any) {
        Store.moduleSet(id, key, value)
        Core.sendSetting(id, key, value)
    }
}
