package com.azalea.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

data class ModSetting(val key: String, val label: String, val type: String, val def: Any?)

/** inApp = true: dijalankan oleh aplikasi (Kotlin), false: dijalankan di dalam inti Azalea (Rust). */
data class ModDef(
    val id: String,
    val title: String,
    val desc: String,
    val enabled: Boolean,
    val settings: List<ModSetting>,
    val inApp: Boolean,
)

/** Tab WebView dinamis yang dideklarasikan oleh inti Rust (tidak perlu ubah APK untuk menambah tab baru). */
data class WebTabDef(
    val id: String,
    val title: String,
    val html: String,
    val channel: String,
    val module: String = "",
)

/**
 * Daftar modul + nilai setelannya. Skema modul & tab web dibaca dari `<inti> modules`,
 * jadi modul baru di Rust muncul sendiri di layar Modul & tab Sesi tanpa mengubah Kotlin.
 */
object Modules {
    val list = MutableStateFlow<List<ModDef>>(emptyList())
    val tabs = MutableStateFlow<List<WebTabDef>>(emptyList())
    val coreVersion = MutableStateFlow("")
    val version = MutableStateFlow(0)

    /** Dipanggil saat aplikasi mulai atau setelah CorePack diperbarui. */
    fun load(ctx: Context, onComplete: ((Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        Thread({
            var ok = false
            try {
                val bin = CorePack.resolveBinary(app)
                if (bin == null) {
                    Core.appLog("daftar modul: inti Azalea tidak ditemukan")
                    list.value = emptyList()
                    tabs.value = emptyList()
                    coreVersion.value = ""
                    CorePack.refreshInfo(app)
                    onComplete?.invoke(false)
                    return@Thread
                }
                val p = ProcessBuilder(bin.absolutePath, "modules").redirectErrorStream(true).start()
                val line = p.inputStream.bufferedReader().readLines().firstOrNull { it.startsWith("{\"t\":\"modules\"") }
                p.waitFor()
                if (line == null) {
                    Core.appLog("daftar modul: keluaran tidak dikenali")
                    CorePack.refreshInfo(app)
                    onComplete?.invoke(false)
                    return@Thread
                }
                val root = JSONObject(line)
                val ver = root.optString("core_version", "")
                val arr = root.getJSONArray("v")
                val rust = (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    val ss = o.optJSONArray("settings")
                    ModDef(
                        o.getString("id"),
                        o.optString("title"),
                        o.optString("desc"),
                        o.optBoolean("enabled", false),
                        (0 until (ss?.length() ?: 0)).map { j ->
                            val s = ss!!.getJSONObject(j)
                            ModSetting(s.getString("key"), s.optString("label"), s.optString("type", "text"), s.opt("default"))
                        },
                        inApp = false,
                    )
                }
                val tabArr = root.optJSONArray("tabs")
                val dynTabs = (0 until (tabArr?.length() ?: 0)).mapNotNull { i ->
                    val t = tabArr!!.optJSONObject(i) ?: return@mapNotNull null
                    val id = t.optString("id").trim()
                    val html = t.optString("html").trim()
                    if (id.isEmpty() || html.isEmpty()) return@mapNotNull null
                    WebTabDef(
                        id = id,
                        title = t.optString("title", id).ifBlank { id },
                        html = html,
                        channel = t.optString("channel", id).ifBlank { id },
                        module = t.optString("module", "").trim(),
                    )
                }
                coreVersion.value = ver
                list.value = rust
                tabs.value = dynTabs
                ok = true
                CorePack.refreshInfo(app, versionOverride = ver.ifBlank { null })
            } catch (e: Throwable) {
                Core.appLog("daftar modul gagal: ${e.javaClass.simpleName}: ${e.message}")
                CorePack.refreshInfo(app)
            }
            onComplete?.invoke(ok)
        }, "load-modules").start()
    }

    private fun default(id: String, key: String): Any? {
        val m = list.value.firstOrNull { it.id == id } ?: return null
        if (key == "enabled") return m.enabled
        return m.settings.firstOrNull { it.key == key }?.def
    }

    fun get(id: String, key: String): Any? = Store.moduleGet(id, key) ?: default(id, key)

    /** fallback dipakai kalau daftar modul belum berhasil dimuat. */
    fun bool(id: String, key: String, fallback: Boolean = false): Boolean = when (val v = get(id, key)) {
        null -> fallback
        is Boolean -> v
        is String -> v.equals("true", true)
        else -> fallback
    }

    fun num(id: String, key: String, fallback: Double = 0.0): Double =
        (get(id, key) as? Number)?.toDouble()
            ?: get(id, key)?.toString()?.trim()?.toDoubleOrNull()
            ?: (default(id, key) as? Number)?.toDouble()
            ?: fallback

    fun str(id: String, key: String): String = when (val v = get(id, key)) {
        null -> ""
        is Double -> if (v == Math.floor(v)) v.toLong().toString() else v.toString()
        else -> v.toString()
    }

    fun set(id: String, key: String, value: Any) {
        Store.moduleSet(id, key, value)
        Core.sendSetting(id, key, value)
        version.value++
    }
}
