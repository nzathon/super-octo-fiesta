package com.azalea.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class ModSetting(val key: String, val label: String, val type: String, val def: Any?)

/** inApp = true: dijalankan oleh aplikasi (Kotlin), false: dijalankan di dalam inti Azalea (Rust). */
data class ModDef(
    val id: String,
    val title: String,
    val desc: String,
    val enabled: Boolean,
    val settings: List<ModSetting>,
    val inApp: Boolean,
)

/** Tab WebView dinamis yang dideklarasikan oleh inti Rust (tidak perlu ubah APK untuk menambah tab baru). */
data class WebTabDef(
    val id: String,
    val title: String,
    val html: String,
    val channel: String,
    val module: String = "",
)

/**
 * Daftar modul + nilai setelannya. Skema modul & tab web dibaca dari `<inti> modules`,
 * jadi modul baru di Rust muncul sendiri di layar Modul & tab Sesi tanpa mengubah Kotlin.
 */
object Modules {
    val list = MutableStateFlow<List<ModDef>>(emptyList())
    val tabs = MutableStateFlow<List<WebTabDef>>(emptyList())
    val coreName = MutableStateFlow("")
    val coreVersion = MutableStateFlow("")
    val mcVersion = MutableStateFlow("")
    val mcProtocol = MutableStateFlow(0)
    val version = MutableStateFlow(0)
    val importEpoch = MutableStateFlow(0)
    val lastError = MutableStateFlow<String?>(null)
    private val loadLock = Any()

    /** Dipanggil saat aplikasi mulai atau setelah CorePack diperbarui. */
    fun load(ctx: Context, onComplete: ((Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        Thread({
            val ok = loadSync(app, refreshCorePack = true)
            onComplete?.invoke(ok)
        }, "load-modules").start()
    }

    fun loadSync(ctx: Context, refreshCorePack: Boolean = true): Boolean = synchronized(loadLock) {
        val app = ctx.applicationContext
        val bin = CorePack.resolveBinary(app)
        if (bin == null) {
            val msg = "Inti Azalea tidak ditemukan (coba Import Core .zip)"
            Core.appLog("daftar modul: $msg")
            list.value = emptyList()
            tabs.value = emptyList()
            coreName.value = ""
            coreVersion.value = ""
            mcVersion.value = ""
            mcProtocol.value = 0
            lastError.value = msg
            if (refreshCorePack) CorePack.refreshInfo(app, error = msg)
            return false
        }
        val firstTry = runModulesBinary(app, bin)
        val result = if (firstTry.isSuccess) {
            firstTry
        } else if (CorePack.isExternalBinary(app, bin)) {
            val extErr = firstTry.exceptionOrNull()?.message ?: "Binary eksternal gagal dijalankan"
            Core.appLog("daftar modul core eksternal gagal: $extErr")
            val bundled = CorePack.bundledBinary(app)
            if (bundled != null) {
                Core.appLog("mencoba fallback ke inti bawaan APK...")
                CorePack.markExternalFailure(app, "Core eksternal gagal ($extErr), memakai bawaan APK")
                runModulesBinary(app, bundled)
            } else {
                CorePack.markExternalFailure(app, extErr)
                firstTry
            }
        } else {
            firstTry
        }
        result.fold(
            onSuccess = { parsed ->
                coreName.value = parsed.coreName
                coreVersion.value = parsed.coreVersion
                mcVersion.value = parsed.mcVersion
                mcProtocol.value = parsed.mcProtocol
                list.value = parsed.modules
                tabs.value = parsed.tabs
                lastError.value = null
                if (refreshCorePack) {
                    CorePack.refreshInfo(
                        app,
                        nameOverride = parsed.coreName.ifBlank { null },
                        versionOverride = parsed.coreVersion.ifBlank { null },
                    )
                }
                true
            },
            onFailure = { e ->
                val msg = e.message?.ifBlank { e.javaClass.simpleName } ?: e.javaClass.simpleName
                Core.appLog("daftar modul gagal: $msg")
                lastError.value = msg
                if (refreshCorePack) CorePack.refreshInfo(app, error = msg)
                false
            },
        )
    }

    private data class ParsedSchema(
        val coreName: String,
        val coreVersion: String,
        val mcVersion: String,
        val mcProtocol: Int,
        val modules: List<ModDef>,
        val tabs: List<WebTabDef>,
    )

    private fun runModulesBinary(app: Context, bin: File): Result<ParsedSchema> {
        return try {
            bin.parentFile?.setExecutable(true, false)
            if (!bin.canExecute()) bin.setExecutable(true, false)
            val pb = ProcessBuilder(bin.absolutePath, "modules").redirectErrorStream(true)
            CorePack.configureProcessEnv(app, bin, pb)
            val p = pb.start()
            val outLines = ArrayList<String>()
            val readerThread = Thread({
                try {
                    p.inputStream.bufferedReader().forEachLine { outLines.add(it) }
                } catch (_: Throwable) { }
            }, "read-modules")
            readerThread.start()
            val finished = p.waitFor(6, TimeUnit.SECONDS)
            if (!finished) {
                p.destroyForcibly()
                return Result.failure(IllegalStateException("Timeout menjalankan ${bin.name} modules (>6 detik)"))
            }
            readerThread.join(1000)
            val code = p.exitValue()
            val root = CorePack.parseModulesJson(outLines)
            if (code != 0 || root == null) {
                val hint = outLines.firstOrNull { it.isNotBlank() }?.trim()?.take(160) ?: "keluar kode $code"
                return Result.failure(IllegalStateException("Keluar kode $code: $hint"))
            }
            val cname = root.optString("core_name", "").trim()
            val ver = root.optString("core_version", "").trim()
            val mcVer = root.optString("mc_version", "").trim()
            val mcProto = root.optInt("protocol", 0)
            val arr = root.getJSONArray("v")
            val rust = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ss = o.optJSONArray("settings")
                ModDef(
                    o.getString("id"),
                    o.optString("title"),
                    o.optString("desc"),
                    o.optBoolean("enabled", false),
                    (0 until (ss?.length() ?: 0)).map { j ->
                        val s = ss!!.getJSONObject(j)
                        ModSetting(s.getString("key"), s.optString("label"), s.optString("type", "text"), s.opt("default"))
                    },
                    inApp = false,
                )
            }
            val tabArr = root.optJSONArray("tabs")
            val dynTabs = (0 until (tabArr?.length() ?: 0)).mapNotNull { i ->
                val t = tabArr!!.optJSONObject(i) ?: return@mapNotNull null
                val id = t.optString("id").trim()
                val html = t.optString("html").trim()
                if (id.isEmpty() || html.isEmpty()) return@mapNotNull null
                WebTabDef(
                    id = id,
                    title = t.optString("title", id).ifBlank { id },
                    html = html,
                    channel = t.optString("channel", id).ifBlank { id },
                    module = t.optString("module", "").trim(),
                )
            }
            Result.success(ParsedSchema(cname, ver, mcVer, mcProto, rust, dynTabs))
        } catch (e: Throwable) {
            Result.failure(IllegalStateException("${e.javaClass.simpleName}: ${e.message ?: "gagal dijalankan"}"))
        }
    }

    private fun default(id: String, key: String): Any? {
        val m = list.value.firstOrNull { it.id == id } ?: return null
        if (key == "enabled") return m.enabled
        return m.settings.firstOrNull { it.key == key }?.def
    }

    fun get(id: String, key: String): Any? = Store.moduleGet(id, key) ?: default(id, key)

    /** fallback dipakai kalau daftar modul belum berhasil dimuat. */
    fun bool(id: String, key: String, fallback: Boolean = false): Boolean = when (val v = get(id, key)) {
        null -> fallback
        is Boolean -> v
        is String -> v.equals("true", true)
        else -> fallback
    }

    fun num(id: String, key: String, fallback: Double = 0.0): Double =
        (get(id, key) as? Number)?.toDouble()
            ?: get(id, key)?.toString()?.trim()?.toDoubleOrNull()
            ?: (default(id, key) as? Number)?.toDouble()
            ?: fallback

    fun str(id: String, key: String): String = when (val v = get(id, key)) {
        null -> ""
        is Double -> if (v == Math.floor(v)) v.toLong().toString() else v.toString()
        else -> v.toString()
    }

    fun set(id: String, key: String, value: Any) {
        Store.moduleSet(id, key, value)
        Core.sendSetting(id, key, value)
        version.value++
    }

    fun notifyExternalReload() {
        version.value++
        importEpoch.value++
    }

    /** Export setelan 1 modul (gabungan default modul + nilai tersimpan). */
    fun exportModuleSettingsJson(id: String): String {
        val settingsObj = JSONObject()
        val m = list.value.firstOrNull { it.id == id }
        if (m != null) {
            settingsObj.put("enabled", bool(id, "enabled", m.enabled))
            for (s in m.settings) {
                val cur = get(id, s.key)
                if (cur != null && cur != JSONObject.NULL) {
                    settingsObj.put(s.key, cur)
                }
            }
        }
        val saved = Store.modulesJson().optJSONObject(id)
        if (saved != null) {
            for (k in saved.keys()) {
                val v = saved.opt(k)
                if (v != null && v != JSONObject.NULL) settingsObj.put(k, v)
            }
        }
        return JSONObject()
            .put("type", "azalea_module_settings")
            .put("module", id)
            .put("settings", settingsObj)
            .toString(2)
    }

    /** Import setelan 1 modul. Mendukung file bertype `azalea_module_settings` maupun JSON objek mentah. */
    fun importModuleSettingsJson(expectedId: String, raw: String): Result<String> {
        return try {
            val root = JSONObject(raw)
            val kind = root.optString("type", "")
            if (kind == "azalea_backup") {
                return Result.failure(IllegalArgumentException("Ini file Backup penuh. Gunakan tombol Restore di halaman Modul & Core."))
            }
            if (kind == "azalea_module_storage") {
                return Result.failure(IllegalArgumentException("Ini file Storage modul. Import lewat tab Storage."))
            }
            val settingsObj = if (kind == "azalea_module_settings") {
                val fileMod = root.optString("module", "").trim()
                if (fileMod.isNotEmpty() && fileMod != expectedId) {
                    return Result.failure(IllegalArgumentException("File ini setelan untuk modul '$fileMod', bukan '$expectedId'."))
                }
                root.optJSONObject("settings")
                    ?: return Result.failure(IllegalArgumentException("Objek 'settings' tidak ditemukan di file JSON."))
            } else {
                root
            }
            val clean = JSONObject()
            for (k in settingsObj.keys()) {
                val v = settingsObj.opt(k)
                if (v != null && v != JSONObject.NULL) clean.put(k, v)
            }
            Store.moduleReplace(expectedId, clean)
            for (k in clean.keys()) {
                val v = clean.opt(k)
                if (v != null && v != JSONObject.NULL) {
                    Core.sendSetting(expectedId, k, v)
                }
            }
            notifyExternalReload()
            Result.success("Setelan modul '$expectedId' berhasil diimport (${clean.length()} kunci)")
        } catch (e: Throwable) {
            Result.failure(IllegalArgumentException("JSON setelan tidak valid: ${e.message ?: e.javaClass.simpleName}"))
        }
    }
}
