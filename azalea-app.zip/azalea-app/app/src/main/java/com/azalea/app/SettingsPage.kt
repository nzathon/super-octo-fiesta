package com.azalea.app

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsPage() {
    var showQuickEditor by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 8.dp),
    ) {
        item(key = "_core_pack_") {
            CoreManagerCard()
        }
        item(key = "_backup_restore_") {
            BackupRestoreCard()
        }
        item(key = "_chat_prefs_") {
            ChatAppearanceSettingsCard(onOpenQuickEditor = { showQuickEditor = true })
        }
        item(key = "_maint_info_") {
            MaintenanceAndInfoCard()
        }
    }

    if (showQuickEditor) {
        QuickCmdEditorDialog(onDismiss = { showQuickEditor = false })
    }
}

@Composable
internal fun CoreManagerCard() {
    val ctx = LocalContext.current
    val pack by CorePack.state.collectAsState()
    val mods by Modules.list.collectAsState()
    val dynTabs by Modules.tabs.collectAsState()
    val mcVer by Modules.mcVersion.collectAsState()
    val mcProto by Modules.mcProtocol.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) CorePack.importFromUri(ctx, uri)
    }
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        color = AzaleaPalette.Card,
        border = BorderStroke(1.dp, if (pack.isExternal) AzaleaPalette.BorderSelected else AzaleaPalette.Border),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Inti Azalea",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    if (pack.isExternal) "Eksternal" else "Bawaan APK",
                    fontSize = 12.sp,
                    color = if (pack.isExternal) AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                )
            }
            if (pack.name.isNotBlank() || pack.version.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    buildString {
                        if (pack.name.isNotBlank()) append(pack.name)
                        if (pack.version.isNotBlank()) {
                            if (isNotEmpty()) append(" ")
                            append("v${pack.version}")
                        }
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = AzaleaPalette.TextPrimary,
                    fontWeight = FontWeight.Medium,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                pack.detail,
                style = MaterialTheme.typography.bodySmall,
                color = AzaleaPalette.TextMuted,
            )
            val mcText = if (mcVer.isNotBlank()) " · MC $mcVer" + (if (mcProto > 0) " (#$mcProto)" else "") else ""
            Text(
                "${mods.size} modul" + (if (dynTabs.isNotEmpty()) " · ${dynTabs.size} tab web" else "") + mcText,
                style = MaterialTheme.typography.bodySmall,
                color = AzaleaPalette.TextMuted,
            )
            pack.error?.let { err ->
                Spacer(Modifier.height(6.dp))
                Text(err, style = MaterialTheme.typography.bodySmall, color = AzaleaPalette.Danger)
            }
            pack.notice?.let { note ->
                Spacer(Modifier.height(6.dp))
                Text(note, style = MaterialTheme.typography.bodySmall, color = AzaleaPalette.Emerald)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    enabled = !pack.busy,
                    onClick = { picker.launch(arrayOf("*/*")) },
                ) {
                    Text(if (pack.busy) "Memasang..." else "Import Core (.zip)")
                }
                OutlinedButton(
                    enabled = !pack.busy,
                    onClick = { CorePack.reload(ctx) },
                ) {
                    Text("Muat Ulang")
                }
            }
            if (pack.isExternal || pack.hasWebOverride) {
                Spacer(Modifier.height(6.dp))
                OutlinedButton(
                    enabled = !pack.busy,
                    onClick = { CorePack.resetToBundled(ctx) },
                ) {
                    Text("Reset Bawaan APK")
                }
            }
        }
    }
}

@Composable
internal fun BackupRestoreCard() {
    val ctx = LocalContext.current
    var notice by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            writeUriText(ctx, uri, Store.exportBackupJson())
            notice = "Backup semua data berhasil disimpan."
            isError = false
        } catch (e: Throwable) {
            notice = "Gagal menyimpan backup: ${e.message ?: e.javaClass.simpleName}"
            isError = true
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val raw = readUriText(ctx, uri)
            val res = Store.restoreBackupJson(raw)
            res.fold(
                onSuccess = { msg -> notice = msg; isError = false },
                onFailure = { e -> notice = e.message ?: "Restore gagal"; isError = true },
            )
        } catch (e: Throwable) {
            notice = "Gagal membaca file: ${e.message ?: e.javaClass.simpleName}"
            isError = true
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        color = AzaleaPalette.Card,
        border = BorderStroke(1.dp, AzaleaPalette.Border),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(
                "Backup & Restore",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Simpan atau pulihkan semua server, akun, setelan modul, storage, dan preferensi chat sekaligus.",
                style = MaterialTheme.typography.bodySmall,
                color = AzaleaPalette.TextMuted,
            )
            notice?.let { msg ->
                Spacer(Modifier.height(6.dp))
                Text(
                    msg,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isError) AzaleaPalette.Danger else AzaleaPalette.Emerald,
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { backupLauncher.launch("azalea-backup.json") },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Backup (.json)")
                }
                OutlinedButton(
                    onClick = { restoreLauncher.launch(arrayOf("application/json", "text/*", "*/*")) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Restore (.json)")
                }
            }
        }
    }
}

@Composable
private fun ChatAppearanceSettingsCard(onOpenQuickEditor: () -> Unit) {
    val ap by Store.appPrefs.collectAsState()
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        color = AzaleaPalette.Card,
        border = BorderStroke(1.dp, AzaleaPalette.Border),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(
                "Tampilan Chat & Quick Command",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Berlaku langsung pada semua pesan di tab Chat tanpa perlu sambung ulang.",
                style = MaterialTheme.typography.bodySmall,
                color = AzaleaPalette.TextMuted,
            )
            Spacer(Modifier.height(8.dp))
            SettingSwitchRow(
                title = "Tampilkan waktu di chat",
                subtitle = "Menampilkan jam pesan masuk di awal baris",
                checked = ap.chatShowTime,
                onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowTime = v) } },
            )
            if (ap.chatShowTime) {
                SettingSwitchRow(
                    title = "Tampilkan detik (HH:mm:ss)",
                    subtitle = "Jika mati memakai format ringkas HH:mm",
                    checked = ap.chatShowSeconds,
                    onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowSeconds = v) } },
                )
            }
            SettingSwitchRow(
                title = "Tampilkan PlayerHead di chat",
                subtitle = "Menampilkan kepala skin pengirim pesan jika dikenali",
                checked = ap.chatShowHead,
                onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowHead = v) } },
            )
            SettingSwitchRow(
                title = "Tampilkan bilah Quick Command",
                subtitle = "Bar pintasan perintah cepat di atas kolom ketik",
                checked = ap.chatShowQuickCmd,
                onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowQuickCmd = v) } },
            )
            Spacer(Modifier.height(6.dp))
            OutlinedButton(
                onClick = onOpenQuickEditor,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Edit Isi Quick Command (${ap.chatQuickCmds.size})")
            }
        }
    }
}

@Composable
private fun MaintenanceAndInfoCard() {
    val ctx = LocalContext.current
    val mcVer by Modules.mcVersion.collectAsState()
    val mcProto by Modules.mcProtocol.collectAsState()
    var cacheNote by remember { mutableStateOf<String?>(null) }
    val appVer = remember {
        try {
            @Suppress("DEPRECATION")
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            pi.versionName ?: "-"
        } catch (_: Throwable) {
            "-"
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        color = AzaleaPalette.Card,
        border = BorderStroke(1.dp, AzaleaPalette.Border),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(
                "Pemeliharaan & Info Aplikasi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                buildString {
                    append("Azalea v$appVer")
                    if (mcVer.isNotBlank()) {
                        append(" · Inti MC $mcVer")
                        if (mcProto > 0) append(" (#$mcProto)")
                    }
                },
                style = MaterialTheme.typography.bodySmall,
                color = AzaleaPalette.TextMuted,
            )
            cacheNote?.let { msg ->
                Spacer(Modifier.height(6.dp))
                Text(msg, style = MaterialTheme.typography.bodySmall, color = AzaleaPalette.Emerald)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val n = TexCache.clearCache(ctx)
                        cacheNote = if (n > 0) "$n berkas cache avatar dibersihkan." else "Cache avatar sudah bersih."
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Bersihkan Cache Skin", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", ctx.packageName, null)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            ctx.startActivity(intent)
                        } catch (_: Throwable) {
                            cacheNote = "Tidak bisa membuka Info Aplikasi sistem."
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Setelan Android", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
internal fun SettingSwitchRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = AzaleaPalette.TextPrimary)
            if (!subtitle.isNullOrBlank()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = AzaleaPalette.TextMuted)
            }
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
internal fun QuickCmdEditorDialog(onDismiss: () -> Unit) {
    val ap by Store.appPrefs.collectAsState()
    var editIndex by remember { mutableStateOf<Int?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Isi Quick Command") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SettingSwitchRow(
                    title = "Tampilkan bilah Quick Command",
                    checked = ap.chatShowQuickCmd,
                    onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowQuickCmd = v) } },
                )
                HorizontalDivider(color = AzaleaPalette.Border)
                if (ap.chatQuickCmds.isEmpty()) {
                    Text(
                        "Belum ada quick command. Tekan \"Tambah\" untuk membuat baru.",
                        style = MaterialTheme.typography.bodySmall,
                        color = AzaleaPalette.TextMuted,
                    )
                } else {
                    ap.chatQuickCmds.forEachIndexed { idx, item ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = AzaleaPalette.CardAlt,
                            border = BorderStroke(1.dp, AzaleaPalette.Border),
                        ) {
                            Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            item.label,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        Text(
                                            item.cmd + if (item.send) " · langsung kirim" else " · isi ke input",
                                            fontSize = 11.sp,
                                            color = AzaleaPalette.TextMuted,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                    TextButton(
                                        onClick = { editIndex = idx },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                    ) { Text("Ubah", fontSize = 12.sp) }
                                    TextButton(
                                        onClick = {
                                            Store.updateAppPrefs { cur ->
                                                val list = cur.chatQuickCmds.toMutableList()
                                                if (idx in list.indices) list.removeAt(idx)
                                                cur.copy(chatQuickCmds = list)
                                            }
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                    ) { Text("Hapus", fontSize = 12.sp, color = AzaleaPalette.Danger) }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (idx > 0) {
                                        OutlinedButton(
                                            onClick = {
                                                Store.updateAppPrefs { cur ->
                                                    val list = cur.chatQuickCmds.toMutableList()
                                                    val moved = list.removeAt(idx)
                                                    list.add(idx - 1, moved)
                                                    cur.copy(chatQuickCmds = list)
                                                }
                                            },
                                            modifier = Modifier.height(28.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                        ) { Text("Naik", fontSize = 11.sp) }
                                    }
                                    if (idx + 1 < ap.chatQuickCmds.size) {
                                        OutlinedButton(
                                            onClick = {
                                                Store.updateAppPrefs { cur ->
                                                    val list = cur.chatQuickCmds.toMutableList()
                                                    val moved = list.removeAt(idx)
                                                    list.add(idx + 1, moved)
                                                    cur.copy(chatQuickCmds = list)
                                                }
                                            },
                                            modifier = Modifier.height(28.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                        ) { Text("Turun", fontSize = 11.sp) }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { showAdd = true },
                        modifier = Modifier.weight(1f),
                    ) { Text("Tambah Command") }
                    OutlinedButton(
                        onClick = { Store.updateAppPrefs { it.copy(chatQuickCmds = DEFAULT_QUICK_CMDS) } },
                    ) { Text("Reset") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        },
    )

    if (showAdd || editIndex != null) {
        val editing = editIndex?.let { ap.chatQuickCmds.getOrNull(it) }
        var label by remember(editIndex, showAdd) { mutableStateOf(editing?.label ?: "") }
        var cmd by remember(editIndex, showAdd) { mutableStateOf(editing?.cmd ?: "/") }
        var sendDirectly by remember(editIndex, showAdd) { mutableStateOf(editing?.send ?: false) }
        AlertDialog(
            onDismissRequest = { showAdd = false; editIndex = null },
            title = { Text(if (editing == null) "Tambah Quick Command" else "Ubah Quick Command") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it },
                        singleLine = true,
                        label = { Text("Label tombol (mis. Home)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = cmd,
                        onValueChange = { cmd = it },
                        singleLine = true,
                        label = { Text("Isi perintah / teks (mis. /home)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    SettingSwitchRow(
                        title = "Langsung kirim saat diketuk",
                        subtitle = "Jika mati, hanya mengisi ke kolom ketik",
                        checked = sendDirectly,
                        onCheckedChange = { sendDirectly = it },
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = cmd.isNotBlank(),
                    onClick = {
                        val finalItem = QuickCmdItem(
                            label = label.trim().ifBlank { cmd.trim() },
                            cmd = cmd,
                            send = sendDirectly,
                        )
                        Store.updateAppPrefs { cur ->
                            val list = cur.chatQuickCmds.toMutableList()
                            val idx = editIndex
                            if (idx != null && idx in list.indices) list[idx] = finalItem else list.add(finalItem)
                            cur.copy(chatQuickCmds = list)
                        }
                        showAdd = false
                        editIndex = null
                    },
                ) { Text("Simpan") }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false; editIndex = null }) { Text("Batal") }
            },
        )
    }
}
