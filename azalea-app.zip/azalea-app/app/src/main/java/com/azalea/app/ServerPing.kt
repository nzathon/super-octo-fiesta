package com.azalea.app

import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Hasil cek server (Server List Ping, seperti daftar Multiplayer di Minecraft). */
data class ServerStatus(
    val online: Boolean,
    val latencyMs: Int = -1,
    val motd: AnnotatedString = AnnotatedString(""),
    val players: Int = 0,
    val maxPlayers: Int = 0,
    val versionName: String = "",
    val favicon: ImageBitmap? = null,
    val error: String = ""
)

object ServerPing {
    private val NAMED = mapOf(
        "black" to 0x000000, "dark_blue" to 0x0000AA, "dark_green" to 0x00AA00, "dark_aqua" to 0x00AAAA,
        "dark_red" to 0xAA0000, "dark_purple" to 0xAA00AA, "gold" to 0xFFAA00, "gray" to 0xAAAAAA,
        "dark_gray" to 0x555555, "blue" to 0x5555FF, "green" to 0x55FF55, "aqua" to 0x55FFFF,
        "red" to 0xFF5555, "light_purple" to 0xFF55FF, "yellow" to 0xFFFF55, "white" to 0xFFFFFF
    )
    private const val CODES = "0123456789abcdef"
    private val BY_CODE = listOf(
        0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA,
        0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF
    )

    suspend fun ping(host: String, port: Int): ServerStatus = withContext(Dispatchers.IO) {
        try {
            // ikuti SRV record (_minecraft._tcp) seperti klien Minecraft asli, hanya untuk port bawaan
            val target = if (port == 25565) srv(host) else null
            val connHost = target?.first ?: host
            val connPort = target?.second ?: port
            Socket().use { s ->
                s.connect(InetSocketAddress(connHost, connPort), 4000)
                s.soTimeout = 5000
                val out = DataOutputStream(s.getOutputStream())
                val inp = DataInputStream(s.getInputStream())

                val hs = ByteArrayOutputStream()
                val h = DataOutputStream(hs)
                writeVar(h, 0); writeVar(h, 774); writeStr(h, host); h.writeShort(connPort); writeVar(h, 1)
                packet(out, hs.toByteArray())
                packet(out, byteArrayOf(0))

                val body = readPacket(inp)
                val bi = DataInputStream(ByteArrayInputStream(body))
                readVar(bi)                                   // id paket (0)
                val jsonLen = readVar(bi)
                val jb = ByteArray(jsonLen); bi.readFully(jb)
                val root = JSONObject(String(jb, Charsets.UTF_8))

                // pong -> latensi
                var lat = -1
                try {
                    val pb = ByteArrayOutputStream()
                    val p = DataOutputStream(pb)
                    writeVar(p, 1); p.writeLong(System.currentTimeMillis())
                    val t0 = System.nanoTime()
                    packet(out, pb.toByteArray())
                    readPacket(inp)
                    lat = ((System.nanoTime() - t0) / 1_000_000).toInt()
                } catch (_: Throwable) { }

                val pl = root.optJSONObject("players")
                val ver = root.optJSONObject("version")
                var icon: ImageBitmap? = null
                val fav = root.optString("favicon", "")
                if (fav.startsWith("data:image")) {
                    try {
                        val raw = android.util.Base64.decode(fav.substringAfter("base64,"), android.util.Base64.DEFAULT)
                        icon = BitmapFactory.decodeByteArray(raw, 0, raw.size)?.asImageBitmap()
                    } catch (_: Throwable) { }
                }
                ServerStatus(
                    online = true, latencyMs = lat, motd = motd(root.opt("description")),
                    players = pl?.optInt("online", 0) ?: 0, maxPlayers = pl?.optInt("max", 0) ?: 0,
                    versionName = (ver?.optString("name", "") ?: "").replace(Regex("§."), "").trim(), favicon = icon
                )
            }
        } catch (e: Throwable) {
            ServerStatus(online = false, error = e.javaClass.simpleName + (e.message?.let { ": " + it.take(60) } ?: ""))
        }
    }

    /** Cari SRV lewat DNS-over-HTTPS (Android tidak punya API SRV bawaan). Null kalau tidak ada. */
    fun srv(host: String): Pair<String, Int>? {
        if (Regex("^[0-9.]+$").matches(host) || host.contains(":")) return null
        val urls = listOf(
            "https://dns.google/resolve?name=_minecraft._tcp.$host&type=SRV",
            "https://cloudflare-dns.com/dns-query?name=_minecraft._tcp.$host&type=SRV"
        )
        for (u in urls) {
            try {
                val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 2500; c.readTimeout = 2500
                c.setRequestProperty("Accept", "application/dns-json")
                val ans = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optJSONArray("Answer") ?: continue
                var best: Triple<Int, String, Int>? = null
                for (i in 0 until ans.length()) {
                    val o = ans.getJSONObject(i)
                    if (o.optInt("type") != 33) continue
                    val p = o.getString("data").trim().split(" ")
                    if (p.size < 4) continue
                    val cand = Triple(p[0].toInt(), p[3].trimEnd('.'), p[2].toInt())
                    if (best == null || cand.first < best.first) best = cand
                }
                if (best != null) return best.second to best.third
                return null          // DNS menjawab tapi tidak ada SRV: pakai alamat langsung
            } catch (_: Throwable) { }
        }
        return null
    }

    // ----- protokol -----
    private fun writeVar(o: DataOutputStream, v: Int) {
        var x = v
        while (true) {
            if ((x and 0x7F.inv()) == 0) { o.writeByte(x); return }
            o.writeByte((x and 0x7F) or 0x80)
            x = x ushr 7
        }
    }
    private fun writeStr(o: DataOutputStream, s: String) {
        val b = s.toByteArray(Charsets.UTF_8); writeVar(o, b.size); o.write(b)
    }
    private fun packet(out: DataOutputStream, data: ByteArray) {
        writeVar(out, data.size); out.write(data); out.flush()
    }
    private fun readVar(i: DataInputStream): Int {
        var n = 0; var shift = 0
        while (true) {
            val b = i.readUnsignedByte()
            n = n or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) return n
            shift += 7
            if (shift > 35) throw java.io.IOException("VarInt terlalu panjang")
        }
    }
    private fun readPacket(i: DataInputStream): ByteArray {
        val len = readVar(i)
        if (len < 0 || len > 4_000_000) throw java.io.IOException("paket tidak wajar")
        val b = ByteArray(len); i.readFully(b); return b
    }

    // ----- MOTD -> teks berwarna -----
    private fun motd(el: Any?): AnnotatedString = buildAnnotatedString { walk(el, null, false) }

    private fun parseColor(s: String): Color? {
        if (s.isEmpty()) return null
        if (s.startsWith("#") && s.length == 7) return try { Color(0xFF000000.toInt() or s.substring(1).toInt(16)) } catch (_: Throwable) { null }
        return NAMED[s]?.let { Color(0xFF000000.toInt() or it) }
    }

    private fun AnnotatedString.Builder.walk(el: Any?, color: Color?, bold: Boolean) {
        when (el) {
            is String -> legacy(el, color, bold)
            is JSONArray -> for (i in 0 until el.length()) walk(el.get(i), color, bold)
            is JSONObject -> {
                val c = parseColor(el.optString("color", "")) ?: color
                val b = if (el.has("bold")) el.optBoolean("bold") else bold
                legacy(el.optString("text", ""), c, b)
                val extra = el.optJSONArray("extra")
                if (extra != null) for (i in 0 until extra.length()) walk(extra.get(i), c, b)
            }
        }
    }

    private fun AnnotatedString.Builder.legacy(text: String, color0: Color?, bold0: Boolean) {
        var color = color0; var bold = bold0
        val sb = StringBuilder()
        fun flush() {
            if (sb.isEmpty()) return
            pushStyle(SpanStyle(color = color ?: Color.Unspecified, fontWeight = if (bold) FontWeight.Bold else null))
            append(sb.toString()); pop(); sb.setLength(0)
        }
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch == '§' && i + 1 < text.length) {
                flush()
                val code = text[i + 1].lowercaseChar()
                val ci = CODES.indexOf(code)
                when {
                    ci >= 0 -> color = Color(0xFF000000.toInt() or BY_CODE[ci])
                    code == 'l' -> bold = true
                    code == 'r' -> { color = color0; bold = bold0 }
                }
                i += 2
            } else { sb.append(ch); i++ }
        }
        flush()
    }
}
