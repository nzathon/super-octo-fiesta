package com.azalea.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.ContextWrapper
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import java.io.ByteArrayInputStream

/**
 * Saluran data global untuk tab WebView.
 * Menyimpan HANYA snapshot terbaru per (channel, key) dan menggabungkan kiriman cepat (coalesce),
 * serta berhenti mengirim saat layar tidak aktif agar tidak terjadi replay beruntun setelah AFK.
 */
object WebTabBus {
    private class Host(
        var paused: Boolean,
        val pushRaw: (String) -> Unit,
    ) {
        val pending = LinkedHashMap<String, String>()
        var flushScheduled = false
    }

    private val lock = Any()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val snapshots = LinkedHashMap<String, LinkedHashMap<String, String>>()
    private val hosts = HashMap<String, Host>()

    fun publish(channel: String, key: String, json: String) {
        val shouldPost: Boolean
        synchronized(lock) {
            val map = snapshots.getOrPut(channel) { LinkedHashMap() }
            map[key] = json
            val host = hosts[channel]
            if (host != null && !host.paused) {
                host.pending[key] = json
                shouldPost = !host.flushScheduled
                if (shouldPost) host.flushScheduled = true
            } else {
                shouldPost = false
            }
        }
        if (shouldPost) {
            mainHandler.post { flush(channel) }
        }
    }

    fun emitLive(channel: String, key: String, json: String) {
        val shouldPost: Boolean
        synchronized(lock) {
            val host = hosts[channel]
            if (host != null && !host.paused) {
                host.pending[key] = json
                shouldPost = !host.flushScheduled
                if (shouldPost) host.flushScheduled = true
            } else {
                shouldPost = false
            }
        }
        if (shouldPost) {
            mainHandler.post { flush(channel) }
        }
    }

    private fun flush(channel: String) {
        val batch: List<String>
        val push: ((String) -> Unit)?
        synchronized(lock) {
            val host = hosts[channel] ?: return
            host.flushScheduled = false
            if (host.paused || host.pending.isEmpty()) {
                host.pending.clear()
                return
            }
            batch = host.pending.values.toList()
            host.pending.clear()
            push = host.pushRaw
        }
        for (msg in batch) {
            push.invoke(msg)
        }
    }

    fun attach(channel: String, paused: Boolean, pushRaw: (String) -> Unit): List<String> {
        synchronized(lock) {
            hosts[channel] = Host(paused, pushRaw)
            return snapshots[channel]?.values?.toList() ?: emptyList()
        }
    }

    fun setPaused(channel: String, paused: Boolean): List<String> {
        synchronized(lock) {
            val host = hosts[channel]
            if (host != null) {
                host.paused = paused
                if (paused) {
                    host.pending.clear()
                    host.flushScheduled = false
                    return emptyList()
                }
            }
            return snapshots[channel]?.values?.toList() ?: emptyList()
        }
    }

    fun detach(channel: String) {
        synchronized(lock) {
            hosts.remove(channel)
        }
    }

    fun clear(channel: String? = null) {
        synchronized(lock) {
            if (channel == null) {
                snapshots.clear()
                for (h in hosts.values) {
                    h.pending.clear()
                    h.flushScheduled = false
                }
            } else {
                snapshots.remove(channel)
                hosts[channel]?.let {
                    it.pending.clear()
                    it.flushScheduled = false
                }
            }
        }
    }
}

private tailrec fun Context.findLifecycleOwner(): LifecycleOwner? = when (this) {
    is LifecycleOwner -> this
    is ContextWrapper -> baseContext.findLifecycleOwner()
    else -> null
}

/**
 * Host WebView global yang sadar lifecycle Android (ON_PAUSE / ON_RESUME).
 * Modul WebView apa pun cukup memakai komponen ini agar bebas antrean replay saat AFK
 * dan otomatis mendapat proxy cache CORS untuk tekstur Mojang / mcasset.cloud.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GlobalWebTab(
    channel: String,
    url: String,
    bridgeName: String,
    modifier: Modifier = Modifier,
    bridgeFactory: (push: (String) -> Unit) -> Any,
    onSync: (push: (String) -> Unit) -> Unit = {},
    onResumeRefresh: () -> Unit = {},
) {
    val ctx = LocalContext.current
    val lifecycleOwner = ctx.findLifecycleOwner()
    val latestOnSync by rememberUpdatedState(onSync)
    val latestOnRefresh by rememberUpdatedState(onResumeRefresh)

    val webRef = androidx.compose.runtime.remember { arrayOfNulls<WebView>(1) }
    val pageReadyRef = androidx.compose.runtime.remember { booleanArrayOf(false) }
    val destroyedRef = androidx.compose.runtime.remember { booleanArrayOf(false) }

    DisposableEffect(lifecycleOwner, channel) {
        val lifecycle = lifecycleOwner?.lifecycle
        val obs = LifecycleEventObserver { _, event ->
            val w = webRef[0] ?: return@LifecycleEventObserver
            val push: (String) -> Unit = { json -> if (!destroyedRef[0]) w.evaluateJavascript("window.__tabMsg($json)", null) }
            when (event) {
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
                    WebTabBus.setPaused(channel, true)
                    w.onPause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    w.onResume()
                    val latest = WebTabBus.setPaused(channel, false)
                    if (pageReadyRef[0]) {
                        latestOnSync(push)
                        for (msg in latest) push(msg)
                        latestOnRefresh()
                    }
                }
                else -> {}
            }
        }
        lifecycle?.addObserver(obs)
        onDispose {
            lifecycle?.removeObserver(obs)
            WebTabBus.detach(channel)
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { c ->
            val looper = Handler(Looper.getMainLooper())
            WebView(c).apply {
                webRef[0] = this
                setBackgroundColor(0xFF15171C.toInt())
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                val web = this
                val pushNow: (String) -> Unit = { json ->
                    if (Looper.myLooper() == Looper.getMainLooper()) {
                        if (!destroyedRef[0]) web.evaluateJavascript("window.__tabMsg($json)", null)
                    } else {
                        looper.post { if (!destroyedRef[0]) web.evaluateJavascript("window.__tabMsg($json)", null) }
                    }
                }
                addJavascriptInterface(bridgeFactory(pushNow), bridgeName)
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?,
                    ): WebResourceResponse? {
                        val reqUrl = request?.url?.toString() ?: return null
                        if (request.method.equals("GET", ignoreCase = true) && (
                                reqUrl.startsWith("https://textures.minecraft.net/texture/") ||
                                reqUrl.startsWith("https://assets.mcasset.cloud/")
                            )
                        ) {
                            val bytes = TexCache.fetchPngBytes(c, reqUrl) ?: return null
                            return WebResourceResponse(
                                "image/png",
                                null,
                                200,
                                "OK",
                                mapOf(
                                    "Access-Control-Allow-Origin" to "*",
                                    "Cache-Control" to "public, max-age=604800",
                                ),
                                ByteArrayInputStream(bytes),
                            )
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                        pageReadyRef[0] = true
                        val isResumed = lifecycleOwner?.lifecycle?.currentState
                            ?.isAtLeast(Lifecycle.State.RESUMED) ?: true
                        val latest = WebTabBus.attach(channel, paused = !isResumed, pushRaw = pushNow)
                        if (isResumed) {
                            latestOnSync(pushNow)
                            for (msg in latest) pushNow(msg)
                            latestOnRefresh()
                        }
                    }
                }
                loadUrl(url)
            }
        },
        onRelease = { w ->
            destroyedRef[0] = true
            pageReadyRef[0] = false
            if (webRef[0] === w) webRef[0] = null
            WebTabBus.detach(channel)
            w.removeJavascriptInterface(bridgeName)
            w.destroy()
        },
    )
}
