package com.azalea.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

internal fun formatDuration(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSec / 3600L
    val m = (totalSec % 3600L) / 60L
    val s = totalSec % 60L
    return if (h > 0L) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

@Composable
fun SessionScreen(
    title: String,
    subtitle: String,
    serverKey: String = "",
    canReconnect: Boolean,
    onReconnect: () -> Unit,
    onBack: () -> Unit,
) {
    val status by Core.status.collectAsState()
    val onlineSince by Core.onlineSinceMs.collectAsState()
    val dynTabs by Modules.tabs.collectAsState()
    val modVer by Modules.version.collectAsState()
    val mods by Modules.list.collectAsState()
    val pack by CorePack.state.collectAsState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var sessionView by rememberSaveable { mutableStateOf("tabs") } // tabs | modul | log
    var tabKey by rememberSaveable { mutableStateOf("chat") }
    var chatText by rememberSaveable { mutableStateOf("") }
    var moduleDetail by remember { mutableStateOf<String?>(null) }
    val visitedWebKeys = remember { mutableStateMapOf<String, Boolean>() }

    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(status, onlineSince) {
        if (status == "online" && onlineSince != null) {
            while (true) {
                nowMs = System.currentTimeMillis()
                delay(1000L)
            }
        }
    }

    val showMonitor = remember(modVer, mods) { Modules.bool("monitor", "enabled", true) }
    val showPlayers = remember(modVer, mods) { Modules.bool("playerlist", "enabled", false) }
    val visibleDynTabs = remember(dynTabs, modVer, mods) {
        dynTabs.filter { it.module.isBlank() || Modules.bool(it.module, "enabled", false) }
    }
    val tabKeys = remember(showMonitor, showPlayers, visibleDynTabs) {
        buildList {
            add("chat" to "Chat")
            if (showMonitor) add("inv" to "Monitor")
            if (showPlayers) add("players" to "Pemain")
            for (t in visibleDynTabs) add("web:${t.id}" to t.title)
        }
    }
    val selectedIdx = tabKeys.indexOfFirst { it.first == tabKey }.let { if (it >= 0) it else 0 }
    val activeKey = tabKeys[selectedIdx].first

    LaunchedEffect(status) {
        if (status != "online") visitedWebKeys.clear()
    }
    LaunchedEffect(sessionView, activeKey, status) {
        if (status == "online" && sessionView == "tabs" && (activeKey == "inv" || activeKey.startsWith("web:"))) {
            visitedWebKeys[activeKey] = true
        }
    }

    BackHandler(enabled = drawerState.isOpen || sessionView != "tabs") {
        when {
            drawerState.isOpen -> scope.launch { drawerState.close() }
            sessionView == "modul" && moduleDetail != null -> moduleDetail = null
            else -> sessionView = "tabs"
        }
    }

    val uptimeStr = if (status == "online" && onlineSince != null) {
        " · ${formatDuration(nowMs - onlineSince!!)}"
    } else ""

    val onWebTab = status == "online" && sessionView == "tabs" &&
        (activeKey == "inv" || activeKey.startsWith("web:"))

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen || drawerState.isAnimationRunning || !onWebTab,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = AzaleaPalette.Surface) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        statusLabel(status) + (if (subtitle.isNotBlank()) " · $subtitle" else "") + uptimeStr,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (status == "online") AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        pack.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = AzaleaPalette.TextMuted,
                    )
                }
                HorizontalDivider(color = AzaleaPalette.Border)
                Spacer(Modifier.height(8.dp))
                NavigationDrawerItem(
                    label = { Text("Tab Sesi") },
                    selected = sessionView == "tabs",
                    onClick = {
                        sessionView = "tabs"
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                NavigationDrawerItem(
                    label = { Text("Modul & Core") },
                    selected = sessionView == "modul",
                    onClick = {
                        sessionView = "modul"
                        moduleDetail = null
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                NavigationDrawerItem(
                    label = { Text("Log") },
                    selected = sessionView == "log",
                    onClick = {
                        sessionView = "log"
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = AzaleaPalette.Border)
                Spacer(Modifier.height(8.dp))
                NavigationDrawerItem(
                    label = { Text("Beranda (Akun / Server)") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        onBack()
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                if (status != "offline") {
                    NavigationDrawerItem(
                        label = { Text("Putus Koneksi", color = AzaleaPalette.Danger) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            Core.disconnect()
                            onBack()
                        },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    )
                }
            }
        },
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 6.dp, end = 12.dp, top = 8.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                    Icon(AzaleaIcons.Menu, contentDescription = "Menu", modifier = Modifier.size(22.dp))
                }
                Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                    Text(
                        when (sessionView) {
                            "modul" -> "Modul & Core"
                            "log" -> "Log"
                            else -> title
                        },
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        statusLabel(status) + (if (subtitle.isNotBlank()) " · $subtitle" else "") + uptimeStr,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (status == "online") AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (status != "offline") {
                    OutlinedButton(onClick = { Core.disconnect(); onBack() }) { Text("Putus") }
                } else {
                    OutlinedButton(onClick = onReconnect, enabled = canReconnect) { Text("Konek") }
                }
            }
            if (sessionView == "tabs") {
                ScrollableTabRow(
                    selectedTabIndex = selectedIdx,
                    edgePadding = 8.dp,
                    containerColor = AzaleaPalette.Surface,
                ) {
                    tabKeys.forEach { (key, label) ->
                        Tab(selected = activeKey == key, onClick = { tabKey = key }, text = { Text(label) })
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (sessionView) {
                    "modul" -> {
                        val d = moduleDetail
                        if (d != null) ModuleDetailScreen(d, onClose = { moduleDetail = null })
                        else ModulesPage(onSettings = { moduleDetail = it })
                    }
                    "log" -> LogBox(Modifier.fillMaxSize().padding(8.dp))
                    else -> {
                        when {
                            activeKey == "chat" -> ChatTab(
                                online = status == "online",
                                serverKey = serverKey,
                                text = chatText,
                                onTextChange = { chatText = it },
                            )
                            activeKey == "players" -> PlayersTab(
                                serverKey = serverKey,
                                onChatAction = { prefill ->
                                    chatText = prefill
                                    tabKey = "chat"
                                },
                            )
                            status != "online" -> Text(
                                "Konek ke server dulu.",
                                Modifier.padding(16.dp),
                                color = AzaleaPalette.TextMuted,
                            )
                        }
                    }
                }
                if (status == "online" && showMonitor && visitedWebKeys["inv"] == true) {
                    InventoryTab(
                        online = true,
                        visible = (sessionView == "tabs" && activeKey == "inv"),
                    )
                }
                if (status == "online") {
                    for (wt in visibleDynTabs) {
                        val wk = "web:${wt.id}"
                        if (visitedWebKeys[wk] == true) {
                            key(wt.id) {
                                DynamicWebTab(
                                    tab = wt,
                                    online = true,
                                    visible = (sessionView == "tabs" && activeKey == wk),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
