package com.azalea.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
internal fun ScrollToBottomButton(
    visible: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    SmallFloatingActionButton(
        onClick = onClick,
        modifier = modifier.padding(12.dp),
        shape = CircleShape,
        containerColor = AzaleaPalette.CardAlt,
        contentColor = AzaleaPalette.Emerald,
    ) {
        Icon(AzaleaIcons.ArrowDown, contentDescription = "Ke bawah", modifier = Modifier.size(18.dp))
    }
}

@Composable
fun LogBox(modifier: Modifier = Modifier) {
    val logs by Core.logs.collectAsState()
    val ctx = LocalContext.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var stickToBottom by remember { mutableStateOf(true) }
    val isAtBottom by remember { derivedStateOf { !listState.canScrollForward } }
    var copied by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val filtered = remember(logs, query) {
        val q = query.trim()
        if (q.isEmpty()) logs else logs.filter { Ansi.strip(it).contains(q, ignoreCase = true) }
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
            .collect { (scrolling, canFwd) ->
                if (scrolling || !canFwd) stickToBottom = !canFwd
            }
    }
    LaunchedEffect(filtered.size, filtered.lastOrNull()) {
        if (filtered.isNotEmpty() && stickToBottom) listState.scrollToItem(filtered.size - 1)
    }

    // Teks log tidak dibungkus SelectionContainer agar tidak crash saat log terus bertambah.
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = AzaleaPalette.Card),
        border = BorderStroke(1.dp, AzaleaPalette.Border),
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (copied) "Log disalin" else if (query.isNotBlank()) "${filtered.size} / ${logs.size} baris" else "${logs.size} baris",
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall,
                    color = AzaleaPalette.TextMuted,
                )
                IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) query = "" }, modifier = Modifier.size(34.dp)) {
                    Icon(AzaleaIcons.Search, contentDescription = "Cari log", modifier = Modifier.size(17.dp), tint = if (searchOpen) AzaleaPalette.Emerald else AzaleaPalette.TextMuted)
                }
                TextButton(
                    onClick = { Core.clearLogs(); copied = false },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                ) { Text("Bersihkan", fontSize = 12.sp) }
                TextButton(
                    onClick = {
                        copyText(ctx, "log", Ansi.strip(filtered.joinToString("\n")))
                        copied = true
                    },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                ) { Text("Salin", fontSize = 12.sp) }
            }
            if (searchOpen) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Filter log...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 4.dp), state = listState) {
                    if (filtered.isEmpty()) item {
                        Text(
                            if (logs.isEmpty()) "(log kosong)" else "(tidak ada log yang cocok)",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = AzaleaPalette.TextMuted,
                        )
                    }
                    items(filtered.size) { i ->
                        Text(Ansi.annotated(filtered[i]), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
                ScrollToBottomButton(
                    visible = filtered.isNotEmpty() && !isAtBottom,
                    onClick = {
                        stickToBottom = true
                        scope.launch { listState.animateScrollToItem(filtered.size - 1) }
                    },
                    modifier = Modifier.align(Alignment.BottomEnd),
                )
            }
        }
    }
}
