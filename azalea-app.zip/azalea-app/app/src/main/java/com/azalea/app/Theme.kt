package com.azalea.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object AzaleaPalette {
    val Bg = Color(0xFF0F141A)
    val Surface = Color(0xFF151C24)
    val Card = Color(0xFF171E27)
    val CardAlt = Color(0xFF1C2530)
    val CardSelected = Color(0xFF202D3B)
    val Border = Color(0xFF263242)
    val BorderSelected = Color(0xFF34D399)
    val Emerald = Color(0xFF34D399)
    val EmeraldDark = Color(0xFF13382C)
    val Sky = Color(0xFF60A5FA)
    val TextPrimary = Color(0xFFE6EDF5)
    val TextMuted = Color(0xFF94A3B8)
    val Danger = Color(0xFFF87171)
    val Warning = Color(0xFFFBBF24)
}

private val AzaleaColorScheme = darkColorScheme(
    primary = AzaleaPalette.Emerald,
    onPrimary = Color(0xFF052E1E),
    primaryContainer = AzaleaPalette.EmeraldDark,
    onPrimaryContainer = Color(0xFFA7F3D0),
    secondary = AzaleaPalette.Sky,
    onSecondary = Color(0xFF0B2545),
    secondaryContainer = Color(0xFF1E324B),
    onSecondaryContainer = Color(0xFFBFDBFE),
    background = AzaleaPalette.Bg,
    onBackground = AzaleaPalette.TextPrimary,
    surface = AzaleaPalette.Surface,
    onSurface = AzaleaPalette.TextPrimary,
    surfaceVariant = AzaleaPalette.CardAlt,
    onSurfaceVariant = AzaleaPalette.TextMuted,
    outline = AzaleaPalette.Border,
    error = AzaleaPalette.Danger,
    onError = Color(0xFF3B0D0D),
)

@Composable
fun AzaleaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AzaleaColorScheme,
        content = content,
    )
}
