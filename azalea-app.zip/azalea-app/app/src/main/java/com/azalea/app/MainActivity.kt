package com.azalea.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Catat crash ke berkas (filesDir/crash.txt) lalu tampilkan di layar Log pada pembukaan berikutnya.
        val crashFile = java.io.File(filesDir, "crash.txt")
        if (!crashHooked) {   // satu kali per proses, supaya tidak menumpuk saat Activity dibuat ulang
            crashHooked = true
            val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                try { crashFile.writeText("${java.util.Date()} thread=${t.name}\n" + android.util.Log.getStackTraceString(e)) } catch (_: Throwable) { }
                prevHandler?.uncaughtException(t, e)
            }
        }
        if (crashFile.exists()) {
            try { Core.appLog("CRASH TERAKHIR:\n" + crashFile.readText().take(3000)) } catch (_: Throwable) { }
            crashFile.delete()
        }
        Store.init(applicationContext)
        Core.init(applicationContext)
        setContent {
            AzaleaTheme {
                Surface(Modifier.fillMaxSize(), color = AzaleaPalette.Bg) { App() }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_SESSION, false)) openSessionTick.intValue++
    }

    companion object {
        const val EXTRA_OPEN_SESSION = "open_session"
        /** Naik tiap notifikasi diketuk saat aplikasi sudah terbuka; App() membuka layar sesi. */
        val openSessionTick = mutableIntStateOf(0)
        private var crashHooked = false
    }
}

sealed interface Screen {
    data object Home : Screen
    data class EditServer(val server: Server?) : Screen
    data object Session : Screen
    data class ModuleDetail(val id: String) : Screen
}

@Composable
fun App() {
    val active = remember { Core.current() }
    var screen by remember { mutableStateOf<Screen>(if (active != null) Screen.Session else Screen.Home) }
    var homeTab by rememberSaveable { mutableIntStateOf(1) }   // 0 Akun, 1 Server, 2 Modul
    var servers by remember { mutableStateOf(Store.servers()) }
    var accounts by remember { mutableStateOf(Store.accounts()) }
    var selectedId by remember { mutableStateOf(Store.selectedAccountId()) }
    var sessionTitle by remember { mutableStateOf(active?.first?.name ?: "") }
    var sessionUser by remember { mutableStateOf(active?.second?.username ?: "") }
    var lastConn by remember { mutableStateOf<Pair<Server, Account>?>(active) }
    val storeRev by Store.revision.collectAsState()
    LaunchedEffect(storeRev) {
        if (storeRev > 0) {
            servers = Store.servers()
            accounts = Store.accounts()
            selectedId = Store.selectedAccountId()
        }
    }
    val openTick by MainActivity.openSessionTick
    LaunchedEffect(openTick) {
        if (openTick > 0) Core.current()?.let { (sv, acc) ->
            sessionTitle = sv.name; sessionUser = acc.username; lastConn = sv to acc
            screen = Screen.Session
        }
    }
    BackHandler(enabled = screen !is Screen.Home) { screen = Screen.Home }
    when (val s = screen) {
        is Screen.Home -> HomeScreen(
            tab = homeTab,
            onTab = { homeTab = it },
            servers = servers,
            accounts = accounts,
            selectedId = selectedId,
            onSelectAccount = { Store.setSelectedAccount(it); selectedId = it },
            onSaveAccount = {
                accounts = Store.upsertAccount(it)
                if (selectedId.isBlank()) { selectedId = it.id; Store.setSelectedAccount(it.id) }
            },
            onDeleteAccount = { accounts = Store.deleteAccount(it); selectedId = Store.selectedAccountId() },
            onConnect = { sv, acc ->
                sessionTitle = sv.name
                sessionUser = acc.username
                lastConn = sv to acc
                Core.connect(sv, acc)
                screen = Screen.Session
            },
            onEditServer = { screen = Screen.EditServer(it) },
            onOpenSession = { screen = Screen.Session },
            onModuleSettings = { screen = Screen.ModuleDetail(it) },
        )
        is Screen.EditServer -> EditServerScreen(
            server = s.server,
            onSave = { servers = Store.upsertServer(it); screen = Screen.Home },
            onDelete = { servers = Store.deleteServer(it); screen = Screen.Home },
            onCancel = { screen = Screen.Home },
        )
        is Screen.ModuleDetail -> ModuleDetailScreen(s.id, onClose = { screen = Screen.Home })
        is Screen.Session -> SessionScreen(
            title = sessionTitle.ifBlank { "Sesi" },
            subtitle = sessionUser,
            serverKey = lastConn?.first?.let { "${it.host}:${it.port}" } ?: "",
            canReconnect = lastConn != null,
            onReconnect = { lastConn?.let { (sv, acc) -> Core.connect(sv, acc) } },
            onBack = { screen = Screen.Home },
        )
    }
}

fun statusLabel(s: String): String = when (s) {
    "online" -> "Online"
    "connecting" -> "Menghubungkan..."
    "reconnecting" -> "Menyambung ulang..."
    else -> "Offline"
}
