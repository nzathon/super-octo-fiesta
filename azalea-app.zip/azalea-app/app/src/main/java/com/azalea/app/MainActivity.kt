package com.azalea.app

import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.ButtonDefaults
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TabRow
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.key
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Catat crash ke berkas (filesDir/crash.txt) lalu tampilkan di layar Log pada pembukaan berikutnya.
        val crashFile = java.io.File(filesDir, "crash.txt")
        if (!crashHooked) {   // satu kali per proses, supaya tidak menumpuk saat Activity dibuat ulang
            crashHooked = true
            val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                try { crashFile.writeText("${java.util.Date()} thread=${t.name}\n" + android.util.Log.getStackTraceString(e)) } catch (_: Throwable) { }
                prevHandler?.uncaughtException(t, e)
            }
        }
        if (crashFile.exists()) {
            try { Core.appLog("CRASH TERAKHIR:\n" + crashFile.readText().take(3000)) } catch (_: Throwable) { }
            crashFile.delete()
        }
        Store.init(applicationContext)
        Core.init(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_SESSION, false)) openSessionTick.intValue++
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    companion object {
        const val EXTRA_OPEN_SESSION = "open_session"

        /** Naik tiap notifikasi diketuk saat aplikasi sudah terbuka; App() membuka layar sesi. */
        val openSessionTick = androidx.compose.runtime.mutableIntStateOf(0)

        private var crashHooked = false
    }
}

sealed interface Screen {
    data object Home : Screen
    data class EditServer(val server: Server?) : Screen
    data object Session : Screen
    data class ModuleDetail(val id: String) : Screen
}

@Composable
fun App() {
    // Kalau masih ada koneksi aktif (mis. aplikasi dibuka dari notifikasi), langsung ke layar sesi.
    val active = remember { Core.current() }
    var screen by remember { mutableStateOf<Screen>(if (active != null) Screen.Session else Screen.Home) }
    var homeTab by rememberSaveable { mutableIntStateOf(1) }   // 0 Akun, 1 Server
    var servers by remember { mutableStateOf(Store.servers()) }
    var accounts by remember { mutableStateOf(Store.accounts()) }
    var selectedId by remember { mutableStateOf(Store.selectedAccountId()) }
    var sessionTitle by remember { mutableStateOf(active?.first?.name ?: "") }
    var sessionUser by remember { mutableStateOf(active?.second?.username ?: "") }
    var lastConn by remember { mutableStateOf<Pair<Server, Account>?>(active) }
    val storeRev by Store.revision.collectAsState()
    LaunchedEffect(storeRev) {
        if (storeRev > 0) {
            servers = Store.servers()
            accounts = Store.accounts()
            selectedId = Store.selectedAccountId()
        }
    }

    val openTick by MainActivity.openSessionTick
    androidx.compose.runtime.LaunchedEffect(openTick) {
        if (openTick > 0) Core.current()?.let { (sv, acc) ->
            sessionTitle = sv.name; sessionUser = acc.username; lastConn = sv to acc
            screen = Screen.Session
        }
    }

    BackHandler(enabled = screen !is Screen.Home) { screen = Screen.Home }

    when (val s = screen) {
        is Screen.Home -> HomeScreen(
            tab = homeTab,
            onTab = { homeTab = it },
            servers = servers,
            accounts = accounts,
            selectedId = selectedId,
            onSelectAccount = { Store.setSelectedAccount(it); selectedId = it },
            onSaveAccount = {
                accounts = Store.upsertAccount(it)
                if (selectedId.isBlank()) { selectedId = it.id; Store.setSelectedAccount(it.id) }
            },
            onDeleteAccount = { accounts = Store.deleteAccount(it); selectedId = Store.selectedAccountId() },
            onConnect = { sv, acc ->
                sessionTitle = sv.name
                sessionUser = acc.username
                lastConn = sv to acc
                Core.connect(sv, acc)
                screen = Screen.Session
            },
            onEditServer = { screen = Screen.EditServer(it) },
            onOpenSession = { screen = Screen.Session },
            onModuleSettings = { screen = Screen.ModuleDetail(it) }
        )
        is Screen.EditServer -> EditServerScreen(
            server = s.server,
            onSave = { servers = Store.upsertServer(it); screen = Screen.Home },
            onDelete = { servers = Store.deleteServer(it); screen = Screen.Home },
            onCancel = { screen = Screen.Home }
        )
        is Screen.ModuleDetail -> ModuleDetailScreen(s.id, onClose = { screen = Screen.Home })
        is Screen.Session -> SessionScreen(
            title = sessionTitle.ifBlank { "Sesi" },
            subtitle = sessionUser,
            serverKey = lastConn?.first?.let { "${it.host}:${it.port}" } ?: "",
            canReconnect = lastConn != null,
            onReconnect = { lastConn?.let { (sv, acc) -> Core.connect(sv, acc) } },
            onBack = { screen = Screen.Home }
        )
    }
}

fun statusLabel(s: String): String = when (s) {
    "online" -> "Online"
    "connecting" -> "Menghubungkan..."
    "reconnecting" -> "Menyambung ulang..."
    else -> "Offline"
}

// ===================== Beranda: Akun | Server =====================

@Composable
fun HomeScreen(
    tab: Int,
    onTab: (Int) -> Unit,
    servers: List<Server>,
    accounts: List<Account>,
    selectedId: String,
    onSelectAccount: (String) -> Unit,
    onSaveAccount: (Account) -> Unit,
    onDeleteAccount: (String) -> Unit,
    onConnect: (Server, Account) -> Unit,
    onEditServer: (Server?) -> Unit,
    onOpenSession: () -> Unit,
    onModuleSettings: (String) -> Unit
) {
    val info by Core.info.collectAsState()
    val bad by Core.infoBad.collectAsState()
    val status by Core.status.collectAsState()
    var showLog by remember { mutableStateOf(false) }
    var needAccount by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Azalea", style = MaterialTheme.typography.headlineSmall)
                Text(
                    info, style = MaterialTheme.typography.bodySmall,
                    color = if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = { showLog = true }) { Text("Log") }
        }
        if (status != "offline") {
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Sedang terhubung", style = MaterialTheme.typography.titleMedium)
                        Text(statusLabel(status), style = MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick = onOpenSession) { Text("Buka") }
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> AccountsPage(accounts, selectedId, onSelectAccount, onSaveAccount, onDeleteAccount)
                1 -> ServersPage(
                    servers = servers,
                    onConnect = { sv ->
                        val acc = accounts.firstOrNull { it.id == selectedId }
                        if (acc == null) needAccount = true else onConnect(sv, acc)
                    },
                    onEdit = onEditServer
                )
                else -> ModulesPage(onModuleSettings)
            }
        }
        NavigationBar {
            NavigationBarItem(selected = tab == 0, onClick = { onTab(0) }, icon = { Text("@") }, label = { Text("Akun") })
            NavigationBarItem(selected = tab == 1, onClick = { onTab(1) }, icon = { Text("≡") }, label = { Text("Server") })
            NavigationBarItem(selected = tab == 2, onClick = { onTab(2) }, icon = { Text("◆") }, label = { Text("Modul") })
        }
    }

    if (showLog) {
        AlertDialog(
            onDismissRequest = { showLog = false },
            title = { Text("Log") },
            text = { LogBox(Modifier.fillMaxWidth().height(340.dp)) },
            confirmButton = { TextButton(onClick = { showLog = false }) { Text("Tutup") } }
        )
    }
    if (needAccount) {
        AlertDialog(
            onDismissRequest = { needAccount = false },
            title = { Text("Pilih akun dulu") },
            text = { Text("Belum ada akun yang dipilih. Tambah atau pilih username di tab Akun.") },
            confirmButton = { TextButton(onClick = { needAccount = false; onTab(0) }) { Text("Ke tab Akun") } },
            dismissButton = { TextButton(onClick = { needAccount = false }) { Text("Batal") } }
        )
    }
}

// ----- Akun -----

@Composable
private fun AccountsPage(
    accounts: List<Account>,
    selectedId: String,
    onSelect: (String) -> Unit,
    onSave: (Account) -> Unit,
    onDelete: (String) -> Unit
) {
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("Akun: pilih username yang dipakai untuk join", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (accounts.isEmpty()) item { Text("Belum ada akun. Tekan + untuk menambah username.", Modifier.padding(vertical = 16.dp)) }
            items(accounts, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(a.id) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) { Text(a.username.take(1).uppercase(), style = MaterialTheme.typography.titleMedium) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.username, style = MaterialTheme.typography.titleMedium)
                            if (a.id == selectedId) Text("Dipakai", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                        TextButton(onClick = { editing = a }) { Text("Ubah") }
                        RadioButton(selected = a.id == selectedId, onClick = { onSelect(a.id) })
                    }
                }
            }
        }
        FloatingActionButton(onClick = { adding = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Text("+", fontSize = 24.sp)
        }
    }

    if (adding) {
        AccountDialog(
            account = null,
            onSave = { onSave(it); adding = false },
            onDelete = { },
            onDismiss = { adding = false }
        )
    }
    editing?.let { acc ->
        AccountDialog(
            account = acc,
            onSave = { onSave(it); editing = null },
            onDelete = { onDelete(it); editing = null },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun AccountDialog(account: Account?, onSave: (Account) -> Unit, onDelete: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(account?.username ?: "") }
    val valid = Regex("^[A-Za-z0-9_]{3,16}$").matches(name)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (account == null) "Akun baru" else "Ubah akun") },
        text = {
            OutlinedTextField(
                name, { name = it.trim() }, label = { Text("Username") }, singleLine = true,
                isError = name.isNotEmpty() && !valid,
                supportingText = { Text("3-16 karakter: huruf, angka, garis bawah") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onSave(Account(account?.id ?: UUID.randomUUID().toString(), name)) }) { Text("Simpan") }
        },
        dismissButton = {
            Row {
                if (account != null) TextButton(onClick = { onDelete(account.id) }) { Text("Hapus") }
                TextButton(onClick = onDismiss) { Text("Batal") }
            }
        }
    )
}

// ----- Server -----

@Composable
private fun ServersPage(servers: List<Server>, onConnect: (Server) -> Unit, onEdit: (Server?) -> Unit) {
    val status = remember { mutableStateMapOf<String, ServerStatus>() }
    var tick by remember { mutableIntStateOf(0) }
    // cek semua server saat halaman tampil, lalu ulangi tiap 30 detik (berhenti otomatis saat halaman ditutup)
    LaunchedEffect(servers, tick) {
        while (true) {
            kotlinx.coroutines.coroutineScope {
                for (sv in servers) launch { status[sv.id] = ServerPing.ping(sv.host, sv.port) }
            }
            kotlinx.coroutines.delay(30_000)
        }
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Ketuk server untuk join", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { status.clear(); tick++ }) { Text("Segarkan") }
                }
            }
            if (servers.isEmpty()) item { Text("Belum ada server. Tekan + untuk menambah.", Modifier.padding(vertical = 16.dp)) }
            items(servers, key = { it.id }) { sv ->
                ServerRow(sv, status[sv.id], onClick = { onConnect(sv) }, onEdit = { onEdit(sv) })
            }
        }
        FloatingActionButton(onClick = { onEdit(null) }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Text("+", fontSize = 24.sp)
        }
    }
}

/** Satu baris server ala daftar Multiplayer Minecraft: ikon, nama, MOTD, pemain, ping. */
@Composable
private fun ServerRow(sv: Server, st: ServerStatus?, onClick: () -> Unit, onEdit: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF1B1B1B)).border(2.dp, Color(0xFF3A3A3A), shape)
            .clickable { onClick() }.padding(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2E2E2E)), contentAlignment = Alignment.Center) {
            if (st?.favicon != null) Image(st.favicon, null, Modifier.size(56.dp), filterQuality = FilterQuality.None)
            else Text(if (st == null) "…" else if (st.online) "▣" else "✕", color = Color(0xFF777777), fontSize = 22.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sv.name, Modifier.weight(1f), color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (st != null && st.online) {
                    Text("${st.players}/${st.maxPlayers}", color = Color(0xFFAAAAAA), fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    PingBars(st.latencyMs)
                }
            }
            when {
                st == null -> Text("Memeriksa server…", color = Color(0xFF999999), fontSize = 12.sp)
                st.online -> Text(
                    if (st.motd.text.isBlank()) AnnotatedString("(tanpa MOTD)") else st.motd,
                    color = Color(0xFFAAAAAA), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp
                )
                else -> Text("Tidak bisa terhubung (${st.error})", color = Color(0xFFFF5555), fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                val ver = if (st != null && st.online && st.versionName.isNotBlank()) st.versionName
                else if (sv.version.equals("auto", true)) "Auto" else sv.version
                Text(
                    "${sv.host}:${sv.port} · $ver" + if (st != null && st.online && st.latencyMs >= 0) " · ${st.latencyMs} ms" else "",
                    Modifier.weight(1f), color = Color(0xFF777777), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                TextButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Text("Ubah", fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun PingBars(ms: Int) {
    val level = when { ms < 0 -> 1; ms < 150 -> 5; ms < 300 -> 4; ms < 600 -> 3; ms < 1000 -> 2; else -> 1 }
    val on = if (level >= 4) Color(0xFF55FF55) else if (level == 3) Color(0xFFFFFF55) else Color(0xFFFF5555)
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        for (i in 1..5) Box(Modifier.width(3.dp).height((3 + i * 2).dp).background(if (i <= level) on else Color(0xFF444444)))
    }
}

@Composable
fun EditServerScreen(server: Server?, onSave: (Server) -> Unit, onDelete: (String) -> Unit, onCancel: () -> Unit) {
    var name by remember { mutableStateOf(server?.name ?: "") }
    var host by remember { mutableStateOf(server?.host ?: "") }
    var port by remember { mutableStateOf((server?.port ?: 25565).toString()) }
    var version by remember { mutableStateOf(server?.version ?: "auto") }
    var versionMenu by remember { mutableStateOf(false) }
    val versionList by Core.versions.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (server == null) "Server baru" else "Ubah server", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, label = { Text("Nama server") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(host, { host = it.trim() }, label = { Text("Alamat (IP / domain)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        // Dropdown versi (seperti ChatCraft): Auto + semua versi yang didukung mineflayer
        Box(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = if (version.equals("auto", true)) "Auto (deteksi otomatis)" else version,
                onValueChange = {}, readOnly = true, singleLine = true,
                label = { Text("Versi Minecraft") },
                trailingIcon = { Text("\u25BE", fontSize = 18.sp) },
                modifier = Modifier.fillMaxWidth()
            )
            Box(Modifier.matchParentSize().clickable { versionMenu = true })
            DropdownMenu(expanded = versionMenu, onDismissRequest = { versionMenu = false }) {
                DropdownMenuItem(text = { Text("Auto (deteksi otomatis)") }, onClick = { version = "auto"; versionMenu = false })
                val shown = if (version.equals("auto", true) || version in versionList) versionList else listOf(version) + versionList
                for (v in shown) {
                    DropdownMenuItem(text = { Text(v) }, onClick = { version = v; versionMenu = false })
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                onSave(
                    Server(
                        id = server?.id ?: UUID.randomUUID().toString(),
                        name = name.trim().ifBlank { host },
                        host = host,
                        port = port.toIntOrNull() ?: 25565,
                        version = version.ifBlank { "auto" }
                    )
                )
            }, enabled = host.isNotBlank()) { Text("Simpan") }
            OutlinedButton(onClick = onCancel) { Text("Batal") }
            if (server != null) TextButton(onClick = { onDelete(server.id) }) { Text("Hapus") }
        }
    }
}

// ===================== Sesi =====================

@Composable
fun SessionScreen(
    title: String,
    subtitle: String,
    serverKey: String = "",
    canReconnect: Boolean,
    onReconnect: () -> Unit,
    onBack: () -> Unit
) {
    val status by Core.status.collectAsState()
    val dynTabs by Modules.tabs.collectAsState()
    val modVer by Modules.version.collectAsState()
    val mods by Modules.list.collectAsState()
    val pack by CorePack.state.collectAsState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var sessionView by rememberSaveable { mutableStateOf("tabs") } // tabs | modul | log
    var tabKey by rememberSaveable { mutableStateOf("chat") }
    var chatText by rememberSaveable { mutableStateOf("") }
    var moduleDetail by remember { mutableStateOf<String?>(null) }
    val visitedWebKeys = remember { mutableStateMapOf<String, Boolean>() }

    val showInv = remember(modVer, mods) { Modules.bool("monitor", "enabled", true) }
    val showPlayers = remember(modVer, mods) { Modules.bool("playerlist", "enabled", false) }
    val visibleDynTabs = remember(dynTabs, modVer, mods) {
        dynTabs.filter { it.module.isBlank() || Modules.bool(it.module, "enabled", false) }
    }

    val tabKeys = remember(showInv, showPlayers, visibleDynTabs) {
        buildList {
            add("chat" to "Chat")
            if (showInv) add("inv" to "Inventory")
            if (showPlayers) add("players" to "Pemain")
            for (t in visibleDynTabs) add("web:${t.id}" to t.title)
        }
    }
    val selectedIdx = tabKeys.indexOfFirst { it.first == tabKey }.let { if (it >= 0) it else 0 }
    val activeKey = tabKeys[selectedIdx].first

    LaunchedEffect(status) {
        if (status != "online") visitedWebKeys.clear()
    }
    LaunchedEffect(sessionView, activeKey, status) {
        if (status == "online" && sessionView == "tabs" && (activeKey == "inv" || activeKey.startsWith("web:"))) {
            visitedWebKeys[activeKey] = true
        }
    }

    BackHandler(enabled = drawerState.isOpen || sessionView != "tabs") {
        when {
            drawerState.isOpen -> scope.launch { drawerState.close() }
            sessionView == "modul" && moduleDetail != null -> moduleDetail = null
            else -> sessionView = "tabs"
        }
    }

    val onWebTab = status == "online" && sessionView == "tabs" &&
        (activeKey == "inv" || activeKey.startsWith("web:"))

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen || drawerState.isAnimationRunning || !onWebTab,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        statusLabel(status) + if (subtitle.isNotBlank()) " · $subtitle" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        pack.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                NavigationDrawerItem(
                    label = { Text("Tab Sesi") },
                    selected = sessionView == "tabs",
                    onClick = {
                        sessionView = "tabs"
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                NavigationDrawerItem(
                    label = { Text("Modul & Core") },
                    selected = sessionView == "modul",
                    onClick = {
                        sessionView = "modul"
                        moduleDetail = null
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                NavigationDrawerItem(
                    label = { Text("Log") },
                    selected = sessionView == "log",
                    onClick = {
                        sessionView = "log"
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                Spacer(Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                NavigationDrawerItem(
                    label = { Text("Beranda (Akun / Server)") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        onBack()
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                if (status != "offline") {
                    NavigationDrawerItem(
                        label = { Text("Putus Koneksi", color = Color(0xFFE26B6B)) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            Core.disconnect()
                            onBack()
                        },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    )
                }
            }
        },
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 6.dp, end = 16.dp, top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = { scope.launch { drawerState.open() } }) {
                    Text("☰", fontSize = 22.sp)
                }
                Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                    Text(
                        when (sessionView) {
                            "modul" -> "Modul & Core"
                            "log" -> "Log"
                            else -> title
                        },
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        statusLabel(status) + if (subtitle.isNotBlank()) " · $subtitle" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (status != "offline") {
                    // Putus = hentikan koneksi (termasuk sambung ulang) lalu kembali ke beranda
                    OutlinedButton(onClick = { Core.disconnect(); onBack() }) { Text("Putus") }
                } else {
                    OutlinedButton(onClick = onReconnect, enabled = canReconnect) { Text("Konek") }
                }
            }
            if (sessionView == "tabs") {
                ScrollableTabRow(selectedTabIndex = selectedIdx, edgePadding = 8.dp) {
                    tabKeys.forEach { (key, label) ->
                        Tab(selected = activeKey == key, onClick = { tabKey = key }, text = { Text(label) })
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (sessionView) {
                    "modul" -> {
                        val d = moduleDetail
                        if (d != null) ModuleDetailScreen(d, onClose = { moduleDetail = null })
                        else ModulesPage(onSettings = { moduleDetail = it })
                    }
                    "log" -> LogBox(Modifier.fillMaxSize().padding(8.dp))
                    else -> {
                        when {
                            activeKey == "chat" -> ChatTab(
                                online = status == "online",
                                serverKey = serverKey,
                                text = chatText,
                                onTextChange = { chatText = it },
                            )
                            activeKey == "players" -> PlayersTab(
                                serverKey = serverKey,
                                onChatAction = { prefill ->
                                    chatText = prefill
                                    tabKey = "chat"
                                }
                            )
                            status != "online" -> Text("Konek ke server dulu.", Modifier.padding(16.dp))
                        }
                    }
                }
                if (status == "online" && showInv && visitedWebKeys["inv"] == true) {
                    InventoryTab(
                        online = true,
                        visible = (sessionView == "tabs" && activeKey == "inv"),
                    )
                }
                if (status == "online") {
                    for (wt in visibleDynTabs) {
                        val wk = "web:${wt.id}"
                        if (visitedWebKeys[wk] == true) {
                            key(wt.id) {
                                DynamicWebTab(
                                    tab = wt,
                                    online = true,
                                    visible = (sessionView == "tabs" && activeKey == wk),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScrollToBottomButton(
    visible: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    SmallFloatingActionButton(
        onClick = onClick,
        modifier = modifier.padding(12.dp),
        shape = CircleShape,
    ) {
        Text("↓", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun ChatTab(online: Boolean, serverKey: String, text: String, onTextChange: (String) -> Unit) {
    val lines by Core.chat.collectAsState()
    val comp by Core.completions.collectAsState()
    val allStorage by ModStorage.data.collectAsState()
    val modVer by Modules.version.collectAsState()
    val mods by Modules.list.collectAsState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var stickToBottom by remember { mutableStateOf(true) }
    val isAtBottom by remember { derivedStateOf { !listState.canScrollForward } }
    var tfv by remember { mutableStateOf(TextFieldValue(text, TextRange(text.length))) }
    var showFilterDialog by remember { mutableStateOf(false) }

    val activeServerKey = Core.current()?.first?.let { "${it.host}:${it.port}" } ?: serverKey
    val blacklistMasterOn = remember(modVer, mods) { Modules.bool("chat", "blacklist", true) }
    val chatStorage = allStorage["chat"]
    val quickSendAll = remember(chatStorage) { chatStorage?.optBoolean("quick_send", false) == true }
    val blacklistRules = remember(chatStorage, activeServerKey) {
        parseChatBlacklistUiRules(chatStorage, activeServerKey)
    }
    val activeRuleCount = remember(blacklistRules) { blacklistRules.count { it.enabled } }

    LaunchedEffect(text) {
        if (text != tfv.text) {
            tfv = TextFieldValue(text, TextRange(text.length))
        }
    }
    LaunchedEffect(online, text) {
        if (!online || !text.startsWith("/")) {
            Core.clearCompletions()
        } else {
            kotlinx.coroutines.delay(90)
            Core.requestComplete(text)
        }
    }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
            .collect { (scrolling, canFwd) ->
                if (scrolling || !canFwd) stickToBottom = !canFwd
            }
    }
    LaunchedEffect(lines.size, lines.lastOrNull()) {
        if (lines.isNotEmpty() && stickToBottom) listState.scrollToItem(lines.size - 1)
    }

    fun applySuggestion(s: TabSuggestion) {
        val st = comp.start.coerceIn(0, text.length)
        val en = comp.end.coerceIn(st, text.length)
        val next = text.substring(0, st) + s.text + text.substring(en)
        onTextChange(next)
    }

    Column(Modifier.fillMaxSize()) {
        var selectedChatIdx by remember { mutableStateOf<Int?>(null) }
        var copiedChatIdx by remember { mutableStateOf<Int?>(null) }
        val ctx = androidx.compose.ui.platform.LocalContext.current

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 8.dp),
                contentPadding = PaddingValues(vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                state = listState,
            ) {
                if (lines.isEmpty()) item {
                    Text("Belum ada chat. Pastikan modul Chat aktif.", Modifier.padding(vertical = 12.dp))
                }
                items(lines.size, key = { it }) { i ->
                    val chatLine = lines[i]
                    val interactionSource = remember { MutableInteractionSource() }
                    val isPressed by interactionSource.collectIsPressedAsState()
                    val toggled = selectedChatIdx == i
                    val inverted = isPressed || toggled
                    val shape = RoundedCornerShape(8.dp)
                    val cardBg = if (inverted) Color(0xFFE6EAF2) else Color.Transparent
                    val borderCol = if (inverted) Color(0xFF9AA4B5) else Color.Transparent
                    val quickCmds = remember(chatLine, toggled) {
                        if (toggled) extractChatCommands(chatLine) else emptyList()
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .combinedClickable(
                                interactionSource = interactionSource,
                                indication = null,
                                onClick = {
                                    selectedChatIdx = if (toggled) null else i
                                    copiedChatIdx = null
                                },
                                onLongClick = {},
                            ),
                        shape = shape,
                        color = cardBg,
                        border = BorderStroke(1.dp, borderCol),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                            Text(
                                Ansi.annotated(chatLine.text, invert = inverted),
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                            )
                            if (toggled) {
                                Spacer(Modifier.height(6.dp))
                                FlowRow(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    for (q in quickCmds) {
                                        val autoSend = q.run || quickSendAll
                                        val chipShape = RoundedCornerShape(16.dp)
                                        val chipBg = if (autoSend) Color(0xFF28354D) else Color(0xFFD6DEEC)
                                        val chipFg = if (autoSend) Color.White else Color(0xFF151820)
                                        val chipBorder = if (autoSend) Color(0xFF28354D) else Color(0xFF7D8799)
                                        Surface(
                                            modifier = Modifier
                                                .height(28.dp)
                                                .clip(chipShape)
                                                .combinedClickable(
                                                    onClick = {
                                                        selectedChatIdx = null
                                                        if (autoSend && online) Core.send(q.cmd)
                                                        else onTextChange(q.cmd)
                                                    },
                                                    onLongClick = {
                                                        selectedChatIdx = null
                                                        if (autoSend) onTextChange(q.cmd)
                                                        else if (online) Core.send(q.cmd)
                                                        else onTextChange(q.cmd)
                                                    },
                                                ),
                                            shape = chipShape,
                                            color = chipBg,
                                            border = BorderStroke(1.dp, chipBorder),
                                        ) {
                                            Box(
                                                Modifier.padding(horizontal = 10.dp),
                                                contentAlignment = Alignment.Center,
                                            ) {
                                                Text(
                                                    text = if (autoSend) "▶ ${q.cmd}" else q.cmd,
                                                    fontSize = 11.sp,
                                                    color = chipFg,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            copyText(ctx, "chat", Ansi.strip(chatLine.text))
                                            copiedChatIdx = i
                                        },
                                        modifier = Modifier.height(28.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                        border = BorderStroke(1.dp, Color(0xFF7D8799)),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF151820)),
                                    ) {
                                        Text(if (copiedChatIdx == i) "Tersalin" else "Salin", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable { showFilterDialog = true },
                shape = CircleShape,
                color = Color(0xD91B202A),
                border = BorderStroke(
                    1.dp,
                    if (blacklistMasterOn && activeRuleCount > 0) Color(0xFF4F78B8) else Color(0xFF394357),
                ),
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    SettingsGearIcon(
                        tint = if (blacklistMasterOn && activeRuleCount > 0) Color(0xFF9AC2FF) else Color(0xFFCBD2DF),
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
            ScrollToBottomButton(
                visible = lines.isNotEmpty() && !isAtBottom,
                onClick = {
                    stickToBottom = true
                    scope.launch { listState.animateScrollToItem(lines.size - 1) }
                },
                modifier = Modifier.align(Alignment.BottomEnd),
            )
        }
        if (showFilterDialog) {
            ChatBlacklistDialog(
                serverKey = activeServerKey,
                masterEnabled = blacklistMasterOn,
                quickSendAll = quickSendAll,
                rules = blacklistRules,
                storageObj = chatStorage,
                onToggleMaster = { Modules.set("chat", "blacklist", it) },
                onToggleQuickSend = { setChatQuickSend(chatStorage, activeServerKey, it) },
                onDismiss = { showFilterDialog = false },
            )
        }
        if (online && comp.items.isNotEmpty() && text.isNotEmpty()) {
            LazyRow(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(comp.items.size) { idx ->
                    val item = comp.items[idx]
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { applySuggestion(item) },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF232936),
                        border = BorderStroke(1.dp, Color(0xFF394357)),
                    ) {
                        Row(
                            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(item.text, fontSize = 12.sp, color = Color(0xFFEAECEF))
                            if (!item.tip.isNullOrBlank()) {
                                Spacer(Modifier.width(4.dp))
                                Text(item.tip, fontSize = 11.sp, color = Color(0xFF8FA0BD))
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = tfv,
                onValueChange = {
                    tfv = it
                    if (it.text != text) onTextChange(it.text)
                },
                singleLine = true,
                placeholder = { Text("Chat atau /perintah") },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(6.dp))
            OutlinedButton(
                enabled = online && text.isNotEmpty(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                onClick = {
                    if (comp.items.isNotEmpty()) applySuggestion(comp.items.first())
                    else Core.requestComplete(text, force = true)
                },
            ) {
                Text("⇥", fontSize = 16.sp)
            }
            Spacer(Modifier.width(6.dp))
            Button(
                enabled = online && text.isNotBlank(),
                onClick = { Core.send(text); onTextChange("") },
            ) {
                Text("Kirim")
            }
        }
    }
}

private val CHAT_URL_REGEX = Regex("https?://\\S+", RegexOption.IGNORE_CASE)
private val CHAT_QUOTED_CMD_REGEX = Regex("""[`"'\[\(]\s*(/[A-Za-z][A-Za-z0-9_:-]{0,31}(?:\s+[^\s`"'\)\]]{1,24}){0,2})\s*[`"'\)\]]""")
private val CHAT_INLINE_CMD_REGEX = Regex("""(?:^|[\s\[(<"'«:,|>\-])(/[A-Za-z][A-Za-z0-9_:-]{0,31})""")
private val CHAT_PROSE_STOPWORDS = setOf(
    "untuk", "atau", "dan", "agar", "biar", "karena", "lalu", "kemudian", "jika", "kalau",
    "saat", "ke", "di", "dari", "yang", "sekarang", "klik", "ketik", "tekan", "gunakan",
    "for", "to", "and", "or", "the", "if", "when", "then", "please", "click", "type", "use",
)

private fun trimQuotedCommandProse(rawCmd: String): String {
    val parts = rawCmd.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (parts.isEmpty()) return ""
    val out = ArrayList<String>(parts.size)
    out.add(parts[0])
    for (i in 1 until parts.size) {
        val tok = parts[i].trimEnd('.', ',', '!', '?', ';', ':')
        if (tok.isEmpty() || tok.lowercase() in CHAT_PROSE_STOPWORDS) break
        out.add(tok)
    }
    return out.joinToString(" ")
}

private fun extractChatCommands(line: ChatLine): List<ChatQuickCmd> {
    val out = ArrayList<ChatQuickCmd>()
    fun addCmd(raw: String, run: Boolean) {
        val cleaned = raw.trim().trimEnd('.', ',', '!', '?', ';')
        if (cleaned.isEmpty()) return
        val existingIdx = out.indexOfFirst { it.cmd.equals(cleaned, ignoreCase = true) }
        if (existingIdx >= 0) {
            if (run && !out[existingIdx].run) {
                out[existingIdx] = out[existingIdx].copy(run = true)
            }
            return
        }
        out.add(ChatQuickCmd(cleaned, run))
    }

    for (c in line.cmds) {
        addCmd(c.cmd, c.run)
    }
    val plain = Ansi.strip(line.text)
    val noUrls = plain.replace(CHAT_URL_REGEX, " ")
    for (m in CHAT_QUOTED_CMD_REGEX.findAll(noUrls)) {
        val phrase = trimQuotedCommandProse(m.groupValues[1])
        if (phrase.startsWith("/") && phrase.length > 1) {
            addCmd(phrase, false)
        }
    }
    for (m in CHAT_INLINE_CMD_REGEX.findAll(noUrls)) {
        val single = m.groupValues[1].trimEnd('.', ',', '!', '?', ';', ':')
        val alreadyCoveredByMulti = out.any {
            it.cmd.startsWith("$single ", ignoreCase = true) || it.cmd.equals(single, ignoreCase = true)
        }
        if (single.length > 1 && !alreadyCoveredByMulti) {
            addCmd(single, false)
        }
    }
    return out.take(6)
}

private data class ChatPatternEntry(
    val kind: String,
    val pattern: String,
    val caseSensitive: Boolean = false,
)

private data class ChatBlacklistRuleUi(
    val scope: String,
    val index: Int,
    val name: String,
    val entries: List<ChatPatternEntry>,
    val enabled: Boolean,
    val caseSensitive: Boolean,
)

private val RULE_KIND_MODES = listOf("regex", "match", "exact", "starts")
private val RULE_KIND_KEYWORDS = setOf("regex", "match", "contains", "exact", "starts", "prefix")

private fun normalizeRuleKind(raw: String): String = when (val k = raw.trim().lowercase()) {
    "regex", "match", "exact", "starts" -> k
    "prefix" -> "starts"
    "contains", "" -> "match"
    else -> k
}

private fun collectPatternEntries(
    raw: Any?,
    fallbackKind: String,
    defaultCs: Boolean,
    out: MutableList<ChatPatternEntry>,
) {
    when (raw) {
        is String -> if (raw.isNotEmpty()) out.add(ChatPatternEntry(fallbackKind, raw, defaultCs))
        is JSONArray -> {
            if (raw.length() >= 2 && raw.opt(0) is String && (raw.opt(1) is String || raw.opt(1) is JSONArray)) {
                val k = normalizeRuleKind(raw.optString(0, fallbackKind))
                val cs = raw.optBoolean(2, defaultCs)
                val second = raw.opt(1)
                if (second is String && second.isNotEmpty()) {
                    out.add(ChatPatternEntry(k, second, cs))
                } else if (second is JSONArray) {
                    for (j in 0 until second.length()) {
                        val s = second.optString(j)
                        if (s.isNotEmpty()) out.add(ChatPatternEntry(k, s, cs))
                    }
                }
            } else {
                for (i in 0 until raw.length()) {
                    val item = raw.opt(i)
                    if (item is String && item.isNotEmpty()) {
                        out.add(ChatPatternEntry(fallbackKind, item, defaultCs))
                    }
                }
            }
        }
        is JSONObject -> {
            val k = normalizeRuleKind(
                raw.optString("type").ifBlank { raw.optString("mode").ifBlank { raw.optString("kind") } }
                    .ifBlank { fallbackKind },
            )
            val cs = raw.optBoolean("case_sensitive", defaultCs)
            val pVal = raw.opt("pattern")
                ?: raw.opt("patterns")
                ?: raw.opt("text")
                ?: raw.opt("isi")
                ?: raw.opt("value")
            if (pVal is String && pVal.isNotEmpty()) {
                out.add(ChatPatternEntry(k, pVal, cs))
            } else if (pVal is JSONArray) {
                for (i in 0 until pVal.length()) {
                    val s = pVal.optString(i)
                    if (s.isNotEmpty()) out.add(ChatPatternEntry(k, s, cs))
                }
            }
        }
    }
}

private fun parseChatBlacklistRuleItem(scope: String, index: Int, raw: Any?): ChatBlacklistRuleUi? = when (raw) {
    is JSONObject -> {
        val enabled = if (raw.has("enable")) raw.optBoolean("enable", true) else raw.optBoolean("enabled", true)
        val explicitKind = raw.optString("type").ifBlank { raw.optString("mode").ifBlank { raw.optString("kind") } }
            .trim().lowercase()
        val fallbackKind = normalizeRuleKind(explicitKind)
        val defaultCs = raw.optBoolean("case_sensitive", false)
        val entries = ArrayList<ChatPatternEntry>()
        val patArr = raw.optJSONArray("patterns") ?: raw.optJSONArray("pattern")
        if (patArr != null) {
            var allStrings = true
            for (i in 0 until patArr.length()) {
                if (patArr.opt(i) !is String) {
                    allStrings = false
                    break
                }
            }
            val flatShorthand = explicitKind.isBlank() &&
                patArr.length() >= 2 &&
                allStrings &&
                patArr.optString(0).trim().lowercase() in RULE_KIND_KEYWORDS
            if (flatShorthand) {
                val k = normalizeRuleKind(patArr.optString(0))
                for (i in 1 until patArr.length()) {
                    val s = patArr.optString(i)
                    if (s.isNotEmpty()) entries.add(ChatPatternEntry(k, s, defaultCs))
                }
            } else {
                for (i in 0 until patArr.length()) {
                    collectPatternEntries(patArr.opt(i), fallbackKind, defaultCs, entries)
                }
            }
        } else {
            val single = raw.optString("pattern")
                .ifBlank { raw.optString("text") }
                .ifBlank { raw.optString("isi") }
                .ifBlank { raw.optString("value") }
            if (single.isNotEmpty()) entries.add(ChatPatternEntry(fallbackKind, single, defaultCs))
        }
        val label = raw.optString("name").ifBlank { raw.optString("nama") }.trim()
            .ifBlank { entries.firstOrNull()?.pattern?.take(24) ?: "Aturan #${index + 1}" }
        ChatBlacklistRuleUi(scope, index, label, entries, enabled, defaultCs)
    }
    is JSONArray -> {
        val entries = ArrayList<ChatPatternEntry>()
        collectPatternEntries(raw, "match", false, entries)
        if (entries.isEmpty()) null
        else {
            val label = entries.firstOrNull()?.pattern?.take(24) ?: "Aturan #${index + 1}"
            ChatBlacklistRuleUi(scope, index, label, entries, true, entries.first().caseSensitive)
        }
    }
    is String -> if (raw.isNotEmpty()) {
        ChatBlacklistRuleUi(scope, index, raw.take(24), listOf(ChatPatternEntry("match", raw, false)), true, false)
    } else null
    else -> null
}

private fun parseChatBlacklistSection(section: JSONObject?, scope: String): List<ChatBlacklistRuleUi> {
    if (section == null) return emptyList()
    val arr = section.optJSONArray("blacklist")
        ?: section.optJSONArray("filter")
        ?: section.optJSONArray("rules")
        ?: return emptyList()
    val out = ArrayList<ChatBlacklistRuleUi>()
    for (i in 0 until arr.length()) {
        parseChatBlacklistRuleItem(scope, i, arr.opt(i))?.let { out.add(it) }
    }
    return out
}

private fun parseChatBlacklistUiRules(storageObj: JSONObject?, serverKey: String): List<ChatBlacklistRuleUi> {
    val out = ArrayList<ChatBlacklistRuleUi>()
    val globalObj = storageObj?.optJSONObject("global")
    out.addAll(parseChatBlacklistSection(globalObj, "global"))
    if (serverKey.isNotBlank()) {
        val srvObj = storageObj?.optJSONObject("servers")?.optJSONObject(serverKey)
        out.addAll(parseChatBlacklistSection(srvObj, "server"))
    }
    return out
}

private fun ensureChatStorageRoot(existing: JSONObject?, serverKey: String): JSONObject {
    val root = try {
        JSONObject(existing?.toString() ?: "{}")
    } catch (_: Throwable) {
        JSONObject()
    }
    val global = root.optJSONObject("global") ?: JSONObject().also { root.put("global", it) }
    if (global.optJSONArray("blacklist") == null) {
        global.put(
            "blacklist",
            JSONArray().put(
                JSONObject()
                    .put("name", "broadcast")
                    .put(
                        "patterns",
                        JSONArray().put(JSONArray().put("regex").put("contoh regex broadcast")),
                    )
                    .put("enable", false)
                    .put("case_sensitive", false),
            ),
        )
    }
    if (global.optJSONArray("private_chat") == null) {
        global.put(
            "private_chat",
            JSONArray().put(
                JSONArray()
                    .put("regex")
                    .put("(?i)(?:^|\\s*)([a-zA-Z0-9_]{3,16})\\s*->\\s*me\\s*[:\\s]\\s*(.*)"),
            ),
        )
    }
    val servers = root.optJSONObject("servers") ?: JSONObject().also { root.put("servers", it) }
    if (serverKey.isNotBlank()) {
        val srv = servers.optJSONObject(serverKey) ?: JSONObject().also { servers.put(serverKey, it) }
        if (srv.optJSONArray("blacklist") == null) srv.put("blacklist", JSONArray())
        if (srv.optJSONArray("private_chat") == null) srv.put("private_chat", JSONArray())
    }
    return root
}

private fun blacklistArrayForScope(root: JSONObject, serverKey: String, scope: String): JSONArray {
    val section = if (scope == "server" && serverKey.isNotBlank()) {
        val servers = root.optJSONObject("servers") ?: JSONObject().also { root.put("servers", it) }
        servers.optJSONObject(serverKey) ?: JSONObject().also { servers.put(serverKey, it) }
    } else {
        root.optJSONObject("global") ?: JSONObject().also { root.put("global", it) }
    }
    val existingArr = section.optJSONArray("blacklist")
        ?: section.optJSONArray("filter")
        ?: section.optJSONArray("rules")
    if (existingArr != null) {
        if (!section.has("blacklist")) section.put("blacklist", existingArr)
        return existingArr
    }
    return JSONArray().also { section.put("blacklist", it) }
}

private fun buildRuleJsonObject(
    name: String,
    entries: List<ChatPatternEntry>,
    enable: Boolean,
    caseSensitive: Boolean,
): JSONObject {
    val pats = JSONArray()
    for (e in entries) {
        val item = JSONArray().put(normalizeRuleKind(e.kind)).put(e.pattern)
        if (e.caseSensitive && e.caseSensitive != caseSensitive) {
            item.put(true)
        }
        pats.put(item)
    }
    return JSONObject()
        .put("name", name.trim())
        .put("patterns", pats)
        .put("enable", enable)
        .put("case_sensitive", caseSensitive)
}

private fun setChatQuickSend(existing: JSONObject?, serverKey: String, quickSend: Boolean) {
    val root = ensureChatStorageRoot(existing, serverKey)
    root.put("quick_send", quickSend)
    ModStorage.replace("chat", root, fromUser = true)
}

private fun setChatBlacklistRuleEnabled(
    existing: JSONObject?,
    serverKey: String,
    rule: ChatBlacklistRuleUi,
    enable: Boolean,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val arr = blacklistArrayForScope(root, serverKey, rule.scope)
    if (rule.index !in 0 until arr.length()) return
    val raw = arr.opt(rule.index)
    if (raw is JSONObject) {
        raw.put("enable", enable)
        raw.remove("enabled")
    } else {
        arr.put(rule.index, buildRuleJsonObject(rule.name, rule.entries, enable, rule.caseSensitive))
    }
    ModStorage.replace("chat", root, fromUser = true)
}

private fun saveChatBlacklistRule(
    existing: JSONObject?,
    serverKey: String,
    editing: ChatBlacklistRuleUi?,
    scope: String,
    name: String,
    entries: List<ChatPatternEntry>,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val targetScope = editing?.scope ?: scope
    val arr = blacklistArrayForScope(root, serverKey, targetScope)
    val obj = buildRuleJsonObject(
        name = name,
        entries = entries,
        enable = editing?.enabled ?: true,
        caseSensitive = editing?.caseSensitive ?: false,
    )
    if (editing != null && editing.index in 0 until arr.length()) {
        arr.put(editing.index, obj)
    } else {
        arr.put(obj)
    }
    ModStorage.replace("chat", root, fromUser = true)
}

private fun deleteChatBlacklistRule(
    existing: JSONObject?,
    serverKey: String,
    rule: ChatBlacklistRuleUi,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val arr = blacklistArrayForScope(root, serverKey, rule.scope)
    if (rule.index !in 0 until arr.length()) return
    val next = JSONArray()
    for (i in 0 until arr.length()) {
        if (i != rule.index) next.put(arr.opt(i))
    }
    val section = if (rule.scope == "server" && serverKey.isNotBlank()) {
        root.getJSONObject("servers").getJSONObject(serverKey)
    } else {
        root.getJSONObject("global")
    }
    section.put("blacklist", next)
    ModStorage.replace("chat", root, fromUser = true)
}

@Composable
private fun SettingsGearIcon(tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val rOuter = size.minDimension * 0.34f
        val rInner = size.minDimension * 0.14f
        val toothStart = size.minDimension * 0.33f
        val toothEnd = size.minDimension * 0.46f
        val strokeW = size.minDimension * 0.11f
        drawCircle(color = tint, radius = rOuter, center = Offset(cx, cy), style = Stroke(width = strokeW))
        drawCircle(color = tint, radius = rInner, center = Offset(cx, cy), style = Stroke(width = strokeW * 0.9f))
        for (i in 0 until 8) {
            val angle = i * (PI / 4.0)
            val dx = cos(angle).toFloat()
            val dy = sin(angle).toFloat()
            drawLine(
                color = tint,
                start = Offset(cx + dx * toothStart, cy + dy * toothStart),
                end = Offset(cx + dx * toothEnd, cy + dy * toothEnd),
                strokeWidth = strokeW * 1.15f,
                cap = StrokeCap.Round,
            )
        }
    }
}

@Composable
private fun ChatBlacklistDialog(
    serverKey: String,
    masterEnabled: Boolean,
    quickSendAll: Boolean,
    rules: List<ChatBlacklistRuleUi>,
    storageObj: JSONObject?,
    onToggleMaster: (Boolean) -> Unit,
    onToggleQuickSend: (Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    var editingRule by remember { mutableStateOf<ChatBlacklistRuleUi?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var formName by remember { mutableStateOf("") }
    var formScope by remember { mutableStateOf("global") }
    var formPatterns by remember { mutableStateOf(listOf("regex" to "")) }

    val globalRules = remember(rules) { rules.filter { it.scope == "global" } }
    val serverRules = remember(rules) { rules.filter { it.scope == "server" } }

    fun openAddForm() {
        editingRule = null
        formName = ""
        formScope = "global"
        formPatterns = listOf("regex" to "")
        showForm = true
    }

    fun openEditForm(rule: ChatBlacklistRuleUi) {
        editingRule = rule
        formName = rule.name
        formScope = rule.scope
        formPatterns = rule.entries.map { it.kind to it.pattern }.ifEmpty { listOf("regex" to "") }
        showForm = true
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pengaturan & Filter Chat") },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Aktifkan Blacklist", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Sembunyikan pesan yang cocok dengan aturan",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = masterEnabled, onCheckedChange = onToggleMaster)
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Kirim langsung quick command", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Ketuk command di chat langsung kirim (tahan = isi kolom)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = quickSendAll, onCheckedChange = onToggleQuickSend)
                }
                HorizontalDivider()
                if (rules.isEmpty()) {
                    Text(
                        "Belum ada aturan blacklist. Tekan + Tambah Aturan atau atur di Modul -> Chat -> Storage.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    if (globalRules.isNotEmpty()) {
                        Text(
                            "Blacklist Global",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF9AC2FF),
                        )
                        for (r in globalRules) {
                            ChatBlacklistRuleRow(
                                rule = r,
                                onEdit = { openEditForm(r) },
                                onToggle = { en -> setChatBlacklistRuleEnabled(storageObj, serverKey, r, en) },
                                onDelete = {
                                    if (editingRule == r) showForm = false
                                    deleteChatBlacklistRule(storageObj, serverKey, r)
                                },
                            )
                        }
                    }
                    if (serverRules.isNotEmpty()) {
                        Text(
                            "Blacklist Server ($serverKey)",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF7FD67F),
                        )
                        for (r in serverRules) {
                            ChatBlacklistRuleRow(
                                rule = r,
                                onEdit = { openEditForm(r) },
                                onToggle = { en -> setChatBlacklistRuleEnabled(storageObj, serverKey, r, en) },
                                onDelete = {
                                    if (editingRule == r) showForm = false
                                    deleteChatBlacklistRule(storageObj, serverKey, r)
                                },
                            )
                        }
                    }
                }
                if (showForm) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF222733),
                        border = BorderStroke(1.dp, Color(0xFF394357)),
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                if (editingRule == null) "Aturan Baru" else "Ubah Aturan",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color(0xFF9AC2FF),
                            )
                            OutlinedTextField(
                                value = formName,
                                onValueChange = { formName = it },
                                label = { Text("Nama aturan (mis. broadcast)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            if (editingRule == null && serverKey.isNotBlank()) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    for ((sc, lbl) in listOf("global" to "Global", "server" to "Server ini")) {
                                        val selected = formScope == sc
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(6.dp))
                                                .clickable { formScope = sc },
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (selected) Color(0xFF31496E) else Color(0xFF1A1E27),
                                            border = BorderStroke(1.dp, if (selected) Color(0xFF6B9AE0) else Color(0xFF394357)),
                                        ) {
                                            Box(Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                                Text(lbl, fontSize = 11.sp, color = Color(0xFFEAECEF))
                                            }
                                        }
                                    }
                                }
                            }
                            Text(
                                "Pattern (tiap pattern bisa beda tipe):",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            formPatterns.forEachIndexed { idx, (rowKind, rowPat) ->
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF191D26),
                                    border = BorderStroke(1.dp, Color(0xFF2F3748)),
                                ) {
                                    Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        ) {
                                            for (k in RULE_KIND_MODES) {
                                                val selected = rowKind == k
                                                Surface(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clip(RoundedCornerShape(5.dp))
                                                        .clickable {
                                                            formPatterns = formPatterns.toMutableList().also {
                                                                it[idx] = k to rowPat
                                                            }
                                                        },
                                                    shape = RoundedCornerShape(5.dp),
                                                    color = if (selected) Color(0xFF31496E) else Color(0xFF232936),
                                                    border = BorderStroke(1.dp, if (selected) Color(0xFF6B9AE0) else Color(0xFF394357)),
                                                ) {
                                                    Box(Modifier.padding(vertical = 5.dp), contentAlignment = Alignment.Center) {
                                                        Text(k, fontSize = 11.sp, color = Color(0xFFEAECEF))
                                                    }
                                                }
                                            }
                                            if (formPatterns.size > 1) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(26.dp)
                                                        .clip(CircleShape)
                                                        .clickable {
                                                            formPatterns = formPatterns.toMutableList().also {
                                                                it.removeAt(idx)
                                                            }
                                                        },
                                                    contentAlignment = Alignment.Center,
                                                ) {
                                                    Text("×", fontSize = 16.sp, color = Color(0xFFE26B6B))
                                                }
                                            }
                                        }
                                        OutlinedTextField(
                                            value = rowPat,
                                            onValueChange = { v ->
                                                formPatterns = formPatterns.toMutableList().also {
                                                    it[idx] = rowKind to v
                                                }
                                            },
                                            label = { Text("Pattern #${idx + 1}") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth(),
                                        )
                                    }
                                }
                            }
                            TextButton(
                                onClick = { formPatterns = formPatterns + ("match" to "") },
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text("+ Tambah Pattern Lain")
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { showForm = false; editingRule = null }) { Text("Batal") }
                                val cleanEntries = formPatterns
                                    .mapNotNull { (k, p) ->
                                        val trimmed = p.trim()
                                        if (trimmed.isEmpty()) null else ChatPatternEntry(k, trimmed, false)
                                    }
                                Button(
                                    enabled = formName.isNotBlank() && cleanEntries.isNotEmpty(),
                                    onClick = {
                                        saveChatBlacklistRule(
                                            existing = storageObj,
                                            serverKey = serverKey,
                                            editing = editingRule,
                                            scope = formScope,
                                            name = formName,
                                            entries = cleanEntries,
                                        )
                                        showForm = false
                                        editingRule = null
                                    },
                                ) {
                                    Text("Simpan")
                                }
                            }
                        }
                    }
                } else {
                    OutlinedButton(
                        onClick = { openAddForm() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("+ Tambah Aturan Blacklist")
                    }
                }
                Text(
                    "Ketuk aturan untuk edit pattern/tipe. Edit JSON lengkap tersedia di Modul -> Chat -> Storage.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
    )
}

@Composable
private fun ChatBlacklistRuleRow(
    rule: ChatBlacklistRuleUi,
    onEdit: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onEdit),
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF1B2029),
        border = BorderStroke(1.dp, Color(0xFF2D3444)),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    rule.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val kinds = rule.entries.map { it.kind }.distinct().joinToString(", ").ifBlank { "match" }
                val preview = rule.entries.firstOrNull()?.pattern ?: "(kosong)"
                val countInfo = if (rule.entries.size > 1) " (${rule.entries.size} pola)" else ""
                Text(
                    "$kinds$countInfo · $preview",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Box(
                modifier = Modifier
                    .padding(end = 6.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onDelete),
                contentAlignment = Alignment.Center,
            ) {
                Text("×", fontSize = 18.sp, color = Color(0xFFE26B6B))
            }
            Switch(checked = rule.enabled, onCheckedChange = onToggle)
        }
    }
}

@Composable
private fun PlayerHead(name: String, hash: String?) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, key1 = name, key2 = hash) {
        value = TexCache.loadPlayerHead(ctx, name, hash)
    }
    val shape = RoundedCornerShape(6.dp)
    if (bmp != null) {
        Image(
            bitmap = bmp!!,
            contentDescription = name,
            modifier = Modifier.size(40.dp).clip(shape),
            filterQuality = FilterQuality.None,
        )
    } else {
        val hue = (name.lowercase().hashCode() and 0x7FFFFFFF)
        val palette = listOf(Color(0xFF3E6B89), Color(0xFF4F7A48), Color(0xFF8A5A3B), Color(0xFF6B4C8A), Color(0xFF8A3B5E), Color(0xFF3B7A73))
        val bg = palette[hue % palette.size]
        Box(
            Modifier.size(40.dp).clip(shape).background(bg).border(1.dp, Color(0x28FFFFFF), shape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.take(1).uppercase().ifEmpty { "?" },
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private data class PlayerQuickAction(val label: String, val cmd: String, val send: Boolean = false)

private fun parseQuickActionEntry(raw: Any?): PlayerQuickAction? = when (raw) {
    is org.json.JSONObject -> {
        val cmd = raw.optString("cmd").ifBlank { raw.optString("command").ifBlank { raw.optString("perintah") } }
        val label = raw.optString("label").ifBlank { raw.optString("name").ifBlank { raw.optString("nama") } }
            .ifBlank { cmd.trim().removePrefix("/").substringBefore(' ').replaceFirstChar { it.uppercase() } }
        val send = raw.optBoolean("send", raw.optBoolean("kirim", false))
        if (cmd.isBlank() && label.isBlank()) null else PlayerQuickAction(label, cmd, send)
    }
    is String -> {
        val cmd = raw
        val label = cmd.trim().removePrefix("/").substringBefore(' ').replaceFirstChar { it.uppercase() }
        if (cmd.isBlank()) null else PlayerQuickAction(label.ifBlank { "Aksi" }, cmd, false)
    }
    else -> null
}

private fun parseQuickActionArray(arr: org.json.JSONArray?): List<PlayerQuickAction> {
    if (arr == null) return emptyList()
    val out = ArrayList<PlayerQuickAction>()
    for (i in 0 until arr.length()) {
        parseQuickActionEntry(arr.opt(i))?.let { out.add(it) }
    }
    return out
}

private fun resolvePlayerQuickActions(storageObj: org.json.JSONObject?, serverKey: String): List<PlayerQuickAction> {
    val defaults = listOf(
        PlayerQuickAction("Message", "/msg <name> ", false),
        PlayerQuickAction("TPA", "/tpa <name>", true),
    )
    val base = if (storageObj != null && storageObj.has("global")) {
        parseQuickActionArray(storageObj.optJSONArray("global"))
    } else {
        defaults
    }
    val merged = base.toMutableList()
    val serversObj = storageObj?.optJSONObject("servers")
    if (serversObj != null && serverKey.isNotBlank()) {
        val hostOnly = serverKey.substringBefore(':')
        val srvArr = serversObj.optJSONArray(serverKey)
            ?: if (hostOnly.isNotBlank()) serversObj.optJSONArray(hostOnly) else null
        for (item in parseQuickActionArray(srvArr)) {
            val idx = merged.indexOfFirst { it.label.equals(item.label, ignoreCase = true) }
            if (idx >= 0) merged[idx] = item else merged.add(item)
        }
    }
    return merged
}

private fun formatPlayerCommand(template: String, playerName: String): String =
    template
        .replace("<name>", playerName, ignoreCase = true)
        .replace("<player>", playerName, ignoreCase = true)
        .replace("{name}", playerName, ignoreCase = true)

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun PlayersTab(serverKey: String, onChatAction: (String) -> Unit) {
    val players by Core.players.collectAsState()
    val allStorage by ModStorage.data.collectAsState()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var selectedPlayerId by remember { mutableStateOf<String?>(null) }
    var copiedPlayerId by remember { mutableStateOf<String?>(null) }
    val activeKey = Core.current()?.first?.let { "${it.host}:${it.port}" } ?: serverKey
    val quickActions = remember(allStorage, activeKey) {
        resolvePlayerQuickActions(allStorage["playerlist"], activeKey)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Pemain online (${players.size})",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleSmall,
            )
            Text(
                "Ketuk: aksi · Tahan: invert",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (players.isEmpty()) item {
                Text("Belum ada data. Aktifkan modul Player List lalu konek.", Modifier.padding(16.dp))
            }
            items(players, key = { it.id }) { p ->
                val interactionSource = remember { MutableInteractionSource() }
                val isPressed by interactionSource.collectIsPressedAsState()
                val toggled = selectedPlayerId == p.id
                val inverted = isPressed || toggled
                val shape = RoundedCornerShape(10.dp)
                val cardBg = if (inverted) Color(0xFFE6EAF2) else Color(0xFF1C2029)
                val borderCol = when {
                    inverted -> Color(0xFF9AA4B5)
                    p.self -> Color(0xFF3D5C80)
                    else -> Color(0xFF2B313F)
                }
                val defaultDisplayCol = if (inverted) Color(0xFF151820) else Color(0xFFEAECEF)
                val subCol = if (inverted) Color(0xFF475063) else Color(0xFF9AA3B2)
                val ping = p.ping
                val pingCol = when {
                    ping == null -> subCol
                    inverted && ping < 100 -> Color(0xFF1B7F37)
                    inverted && ping < 200 -> Color(0xFF9A6700)
                    inverted -> Color(0xFFC92A2A)
                    ping < 100 -> Color(0xFF7FD67F)
                    ping < 200 -> Color(0xFFF5C542)
                    else -> Color(0xFFE26B6B)
                }
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .combinedClickable(
                            interactionSource = interactionSource,
                            indication = null,
                            onClick = {
                                selectedPlayerId = if (toggled) null else p.id
                                copiedPlayerId = null
                            },
                            onLongClick = {},
                        ),
                    shape = shape,
                    color = cardBg,
                    border = BorderStroke(1.dp, borderCol),
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            PlayerHead(p.name, p.hash)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    Ansi.annotated(p.display),
                                    fontSize = 17.sp,
                                    color = defaultDisplayCol,
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    p.name + if (p.self) " (kamu)" else "",
                                    fontSize = 13.sp,
                                    color = subCol,
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (ping == null) "-" else "$ping ms",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = pingCol,
                            )
                        }
                        if (toggled) {
                            HorizontalDivider(color = Color(0xFFC2CAD8))
                            FlowRow(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                quickActions.forEachIndexed { idx, act ->
                                    val cmd = formatPlayerCommand(act.cmd, p.name)
                                    val onActClick = {
                                        selectedPlayerId = null
                                        if (act.send) Core.send(cmd) else onChatAction(cmd)
                                    }
                                    if (idx == 0) {
                                        Button(
                                            onClick = onActClick,
                                            modifier = Modifier.height(34.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color(0xFF28354D),
                                                contentColor = Color.White,
                                            ),
                                        ) {
                                            Text(act.label, fontSize = 12.sp)
                                        }
                                    } else {
                                        OutlinedButton(
                                            onClick = onActClick,
                                            modifier = Modifier.height(34.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                            border = BorderStroke(1.dp, Color(0xFF7D8799)),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF151820)),
                                        ) {
                                            Text(act.label, fontSize = 12.sp)
                                        }
                                    }
                                }
                                OutlinedButton(
                                    onClick = {
                                        copyText(ctx, "username", p.name)
                                        copiedPlayerId = p.id
                                    },
                                    modifier = Modifier.height(34.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                    border = BorderStroke(1.dp, Color(0xFF7D8799)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF151820)),
                                ) {
                                    Text(if (copiedPlayerId == p.id) "Tersalin" else "Salin", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogBox(modifier: Modifier = Modifier) {
    val logs by Core.logs.collectAsState()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var stickToBottom by remember { mutableStateOf(true) }
    val isAtBottom by remember { derivedStateOf { !listState.canScrollForward } }
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
            .collect { (scrolling, canFwd) ->
                if (scrolling || !canFwd) stickToBottom = !canFwd
            }
    }
    LaunchedEffect(logs.size, logs.lastOrNull()) {
        if (logs.isNotEmpty() && stickToBottom) listState.scrollToItem(logs.size - 1)
    }
    // Teks log sengaja TIDAK dibungkus SelectionContainer: log terus bertambah dan itu membuat Compose crash
    // (NullPointerException di SelectionManager). Sebagai gantinya ada tombol "Salin semua".
    Card(modifier) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (copied) "Log disalin" else "${logs.size} baris", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = {
                    copyText(ctx, "log", Ansi.strip(logs.joinToString("\n")))
                    copied = true
                }) { Text("Salin semua") }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 4.dp), state = listState) {
                    if (logs.isEmpty()) item {
                        Text("(log kosong)", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                    items(logs.size) { i ->
                        Text(Ansi.annotated(logs[i]), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
                ScrollToBottomButton(
                    visible = logs.isNotEmpty() && !isAtBottom,
                    onClick = {
                        stickToBottom = true
                        scope.launch { listState.animateScrollToItem(logs.size - 1) }
                    },
                    modifier = Modifier.align(Alignment.BottomEnd),
                )
            }
        }
    }
}
