package com.azalea.app

import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TabRow
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Catat crash ke berkas (filesDir/crash.txt) lalu tampilkan di layar Log pada pembukaan berikutnya.
        val crashFile = java.io.File(filesDir, "crash.txt")
        if (!crashHooked) {   // satu kali per proses, supaya tidak menumpuk saat Activity dibuat ulang
            crashHooked = true
            val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                try { crashFile.writeText("${java.util.Date()} thread=${t.name}\n" + android.util.Log.getStackTraceString(e)) } catch (_: Throwable) { }
                prevHandler?.uncaughtException(t, e)
            }
        }
        if (crashFile.exists()) {
            try { Core.appLog("CRASH TERAKHIR:\n" + crashFile.readText().take(3000)) } catch (_: Throwable) { }
            crashFile.delete()
        }
        Store.init(applicationContext)
        Core.init(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_SESSION, false)) openSessionTick.intValue++
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    companion object {
        const val EXTRA_OPEN_SESSION = "open_session"

        /** Naik tiap notifikasi diketuk saat aplikasi sudah terbuka; App() membuka layar sesi. */
        val openSessionTick = androidx.compose.runtime.mutableIntStateOf(0)

        private var crashHooked = false
    }
}

sealed interface Screen {
    data object Home : Screen
    data class EditServer(val server: Server?) : Screen
    data object Session : Screen
    data class ModuleDetail(val id: String) : Screen
}

@Composable
fun App() {
    // Kalau masih ada koneksi aktif (mis. aplikasi dibuka dari notifikasi), langsung ke layar sesi.
    val active = remember { Core.current() }
    var screen by remember { mutableStateOf<Screen>(if (active != null) Screen.Session else Screen.Home) }
    var homeTab by rememberSaveable { mutableIntStateOf(1) }   // 0 Akun, 1 Server
    var servers by remember { mutableStateOf(Store.servers()) }
    var accounts by remember { mutableStateOf(Store.accounts()) }
    var selectedId by remember { mutableStateOf(Store.selectedAccountId()) }
    var sessionTitle by remember { mutableStateOf(active?.first?.name ?: "") }
    var sessionUser by remember { mutableStateOf(active?.second?.username ?: "") }
    var lastConn by remember { mutableStateOf<Pair<Server, Account>?>(active) }

    val openTick by MainActivity.openSessionTick
    androidx.compose.runtime.LaunchedEffect(openTick) {
        if (openTick > 0) Core.current()?.let { (sv, acc) ->
            sessionTitle = sv.name; sessionUser = acc.username; lastConn = sv to acc
            screen = Screen.Session
        }
    }

    BackHandler(enabled = screen !is Screen.Home) { screen = Screen.Home }

    when (val s = screen) {
        is Screen.Home -> HomeScreen(
            tab = homeTab,
            onTab = { homeTab = it },
            servers = servers,
            accounts = accounts,
            selectedId = selectedId,
            onSelectAccount = { Store.setSelectedAccount(it); selectedId = it },
            onSaveAccount = {
                accounts = Store.upsertAccount(it)
                if (selectedId.isBlank()) { selectedId = it.id; Store.setSelectedAccount(it.id) }
            },
            onDeleteAccount = { accounts = Store.deleteAccount(it); selectedId = Store.selectedAccountId() },
            onConnect = { sv, acc ->
                sessionTitle = sv.name
                sessionUser = acc.username
                lastConn = sv to acc
                Core.connect(sv, acc)
                screen = Screen.Session
            },
            onEditServer = { screen = Screen.EditServer(it) },
            onOpenSession = { screen = Screen.Session },
            onModuleSettings = { screen = Screen.ModuleDetail(it) }
        )
        is Screen.EditServer -> EditServerScreen(
            server = s.server,
            onSave = { servers = Store.upsertServer(it); screen = Screen.Home },
            onDelete = { servers = Store.deleteServer(it); screen = Screen.Home },
            onCancel = { screen = Screen.Home }
        )
        is Screen.ModuleDetail -> ModuleDetailScreen(s.id, onClose = { screen = Screen.Home })
        is Screen.Session -> SessionScreen(
            title = sessionTitle.ifBlank { "Sesi" },
            subtitle = sessionUser,
            canReconnect = lastConn != null,
            onReconnect = { lastConn?.let { (sv, acc) -> Core.connect(sv, acc) } },
            onBack = { screen = Screen.Home }
        )
    }
}

fun statusLabel(s: String): String = when (s) {
    "online" -> "Online"
    "connecting" -> "Menghubungkan..."
    "reconnecting" -> "Menyambung ulang..."
    else -> "Offline"
}

// ===================== Beranda: Akun | Server =====================

@Composable
fun HomeScreen(
    tab: Int,
    onTab: (Int) -> Unit,
    servers: List<Server>,
    accounts: List<Account>,
    selectedId: String,
    onSelectAccount: (String) -> Unit,
    onSaveAccount: (Account) -> Unit,
    onDeleteAccount: (String) -> Unit,
    onConnect: (Server, Account) -> Unit,
    onEditServer: (Server?) -> Unit,
    onOpenSession: () -> Unit,
    onModuleSettings: (String) -> Unit
) {
    val info by Core.info.collectAsState()
    val bad by Core.infoBad.collectAsState()
    val status by Core.status.collectAsState()
    var showLog by remember { mutableStateOf(false) }
    var needAccount by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Azalea", style = MaterialTheme.typography.headlineSmall)
                Text(
                    info, style = MaterialTheme.typography.bodySmall,
                    color = if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = { showLog = true }) { Text("Log") }
        }
        if (status != "offline") {
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Sedang terhubung", style = MaterialTheme.typography.titleMedium)
                        Text(statusLabel(status), style = MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick = onOpenSession) { Text("Buka") }
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> AccountsPage(accounts, selectedId, onSelectAccount, onSaveAccount, onDeleteAccount)
                1 -> ServersPage(
                    servers = servers,
                    onConnect = { sv ->
                        val acc = accounts.firstOrNull { it.id == selectedId }
                        if (acc == null) needAccount = true else onConnect(sv, acc)
                    },
                    onEdit = onEditServer
                )
                else -> ModulesPage(onModuleSettings)
            }
        }
        NavigationBar {
            NavigationBarItem(selected = tab == 0, onClick = { onTab(0) }, icon = { Text("@") }, label = { Text("Akun") })
            NavigationBarItem(selected = tab == 1, onClick = { onTab(1) }, icon = { Text("≡") }, label = { Text("Server") })
            NavigationBarItem(selected = tab == 2, onClick = { onTab(2) }, icon = { Text("◆") }, label = { Text("Modul") })
        }
    }

    if (showLog) {
        AlertDialog(
            onDismissRequest = { showLog = false },
            title = { Text("Log") },
            text = { LogBox(Modifier.fillMaxWidth().height(340.dp)) },
            confirmButton = { TextButton(onClick = { showLog = false }) { Text("Tutup") } }
        )
    }
    if (needAccount) {
        AlertDialog(
            onDismissRequest = { needAccount = false },
            title = { Text("Pilih akun dulu") },
            text = { Text("Belum ada akun yang dipilih. Tambah atau pilih username di tab Akun.") },
            confirmButton = { TextButton(onClick = { needAccount = false; onTab(0) }) { Text("Ke tab Akun") } },
            dismissButton = { TextButton(onClick = { needAccount = false }) { Text("Batal") } }
        )
    }
}

// ----- Akun -----

@Composable
private fun AccountsPage(
    accounts: List<Account>,
    selectedId: String,
    onSelect: (String) -> Unit,
    onSave: (Account) -> Unit,
    onDelete: (String) -> Unit
) {
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("Akun: pilih username yang dipakai untuk join", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (accounts.isEmpty()) item { Text("Belum ada akun. Tekan + untuk menambah username.", Modifier.padding(vertical = 16.dp)) }
            items(accounts, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(a.id) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) { Text(a.username.take(1).uppercase(), style = MaterialTheme.typography.titleMedium) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.username, style = MaterialTheme.typography.titleMedium)
                            if (a.id == selectedId) Text("Dipakai", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                        TextButton(onClick = { editing = a }) { Text("Ubah") }
                        RadioButton(selected = a.id == selectedId, onClick = { onSelect(a.id) })
                    }
                }
            }
        }
        FloatingActionButton(onClick = { adding = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Text("+", fontSize = 24.sp)
        }
    }

    if (adding) {
        AccountDialog(
            account = null,
            onSave = { onSave(it); adding = false },
            onDelete = { },
            onDismiss = { adding = false }
        )
    }
    editing?.let { acc ->
        AccountDialog(
            account = acc,
            onSave = { onSave(it); editing = null },
            onDelete = { onDelete(it); editing = null },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun AccountDialog(account: Account?, onSave: (Account) -> Unit, onDelete: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(account?.username ?: "") }
    val valid = Regex("^[A-Za-z0-9_]{3,16}$").matches(name)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (account == null) "Akun baru" else "Ubah akun") },
        text = {
            OutlinedTextField(
                name, { name = it.trim() }, label = { Text("Username") }, singleLine = true,
                isError = name.isNotEmpty() && !valid,
                supportingText = { Text("3-16 karakter: huruf, angka, garis bawah") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onSave(Account(account?.id ?: UUID.randomUUID().toString(), name)) }) { Text("Simpan") }
        },
        dismissButton = {
            Row {
                if (account != null) TextButton(onClick = { onDelete(account.id) }) { Text("Hapus") }
                TextButton(onClick = onDismiss) { Text("Batal") }
            }
        }
    )
}

// ----- Server -----

@Composable
private fun ServersPage(servers: List<Server>, onConnect: (Server) -> Unit, onEdit: (Server?) -> Unit) {
    val status = remember { mutableStateMapOf<String, ServerStatus>() }
    var tick by remember { mutableIntStateOf(0) }
    // cek semua server saat halaman tampil, lalu ulangi tiap 30 detik (berhenti otomatis saat halaman ditutup)
    LaunchedEffect(servers, tick) {
        while (true) {
            kotlinx.coroutines.coroutineScope {
                for (sv in servers) launch { status[sv.id] = ServerPing.ping(sv.host, sv.port) }
            }
            kotlinx.coroutines.delay(30_000)
        }
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Ketuk server untuk join", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { status.clear(); tick++ }) { Text("Segarkan") }
                }
            }
            if (servers.isEmpty()) item { Text("Belum ada server. Tekan + untuk menambah.", Modifier.padding(vertical = 16.dp)) }
            items(servers, key = { it.id }) { sv ->
                ServerRow(sv, status[sv.id], onClick = { onConnect(sv) }, onEdit = { onEdit(sv) })
            }
        }
        FloatingActionButton(onClick = { onEdit(null) }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Text("+", fontSize = 24.sp)
        }
    }
}

/** Satu baris server ala daftar Multiplayer Minecraft: ikon, nama, MOTD, pemain, ping. */
@Composable
private fun ServerRow(sv: Server, st: ServerStatus?, onClick: () -> Unit, onEdit: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF1B1B1B)).border(2.dp, Color(0xFF3A3A3A), shape)
            .clickable { onClick() }.padding(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2E2E2E)), contentAlignment = Alignment.Center) {
            if (st?.favicon != null) Image(st.favicon, null, Modifier.size(56.dp), filterQuality = FilterQuality.None)
            else Text(if (st == null) "…" else if (st.online) "▣" else "✕", color = Color(0xFF777777), fontSize = 22.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sv.name, Modifier.weight(1f), color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (st != null && st.online) {
                    Text("${st.players}/${st.maxPlayers}", color = Color(0xFFAAAAAA), fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    PingBars(st.latencyMs)
                }
            }
            when {
                st == null -> Text("Memeriksa server…", color = Color(0xFF999999), fontSize = 12.sp)
                st.online -> Text(
                    if (st.motd.text.isBlank()) AnnotatedString("(tanpa MOTD)") else st.motd,
                    color = Color(0xFFAAAAAA), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp
                )
                else -> Text("Tidak bisa terhubung (${st.error})", color = Color(0xFFFF5555), fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                val ver = if (st != null && st.online && st.versionName.isNotBlank()) st.versionName
                else if (sv.version.equals("auto", true)) "Auto" else sv.version
                Text(
                    "${sv.host}:${sv.port} · $ver" + if (st != null && st.online && st.latencyMs >= 0) " · ${st.latencyMs} ms" else "",
                    Modifier.weight(1f), color = Color(0xFF777777), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                TextButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Text("Ubah", fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun PingBars(ms: Int) {
    val level = when { ms < 0 -> 1; ms < 150 -> 5; ms < 300 -> 4; ms < 600 -> 3; ms < 1000 -> 2; else -> 1 }
    val on = if (level >= 4) Color(0xFF55FF55) else if (level == 3) Color(0xFFFFFF55) else Color(0xFFFF5555)
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        for (i in 1..5) Box(Modifier.width(3.dp).height((3 + i * 2).dp).background(if (i <= level) on else Color(0xFF444444)))
    }
}

@Composable
fun EditServerScreen(server: Server?, onSave: (Server) -> Unit, onDelete: (String) -> Unit, onCancel: () -> Unit) {
    var name by remember { mutableStateOf(server?.name ?: "") }
    var host by remember { mutableStateOf(server?.host ?: "") }
    var port by remember { mutableStateOf((server?.port ?: 25565).toString()) }
    var version by remember { mutableStateOf(server?.version ?: "auto") }
    var versionMenu by remember { mutableStateOf(false) }
    val versionList by Core.versions.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (server == null) "Server baru" else "Ubah server", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, label = { Text("Nama server") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(host, { host = it.trim() }, label = { Text("Alamat (IP / domain)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        // Dropdown versi (seperti ChatCraft): Auto + semua versi yang didukung mineflayer
        Box(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = if (version.equals("auto", true)) "Auto (deteksi otomatis)" else version,
                onValueChange = {}, readOnly = true, singleLine = true,
                label = { Text("Versi Minecraft") },
                trailingIcon = { Text("\u25BE", fontSize = 18.sp) },
                modifier = Modifier.fillMaxWidth()
            )
            Box(Modifier.matchParentSize().clickable { versionMenu = true })
            DropdownMenu(expanded = versionMenu, onDismissRequest = { versionMenu = false }) {
                DropdownMenuItem(text = { Text("Auto (deteksi otomatis)") }, onClick = { version = "auto"; versionMenu = false })
                val shown = if (version.equals("auto", true) || version in versionList) versionList else listOf(version) + versionList
                for (v in shown) {
                    DropdownMenuItem(text = { Text(v) }, onClick = { version = v; versionMenu = false })
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                onSave(
                    Server(
                        id = server?.id ?: UUID.randomUUID().toString(),
                        name = name.trim().ifBlank { host },
                        host = host,
                        port = port.toIntOrNull() ?: 25565,
                        version = version.ifBlank { "auto" }
                    )
                )
            }, enabled = host.isNotBlank()) { Text("Simpan") }
            OutlinedButton(onClick = onCancel) { Text("Batal") }
            if (server != null) TextButton(onClick = { onDelete(server.id) }) { Text("Hapus") }
        }
    }
}

// ===================== Sesi =====================

@Composable
fun SessionScreen(
    title: String,
    subtitle: String,
    canReconnect: Boolean,
    onReconnect: () -> Unit,
    onBack: () -> Unit
) {
    val status by Core.status.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var moduleDetail by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(
                    statusLabel(status) + if (subtitle.isNotBlank()) " · $subtitle" else "",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (status != "offline") {
                // Putus = hentikan koneksi (termasuk sambung ulang) lalu kembali ke beranda
                OutlinedButton(onClick = { Core.disconnect(); onBack() }) { Text("Putus") }
            } else {
                OutlinedButton(onClick = onReconnect, enabled = canReconnect) { Text("Konek") }
            }
        }
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Chat") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Inventory") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Pemain") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Modul") })
            Tab(selected = tab == 4, onClick = { tab = 4 }, text = { Text("Log") })
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> ChatTab(status == "online")
                1 -> InventoryTab(status == "online")
                2 -> PlayersTab()
                3 -> {
                    val d = moduleDetail
                    if (d != null) ModuleDetailScreen(d, onClose = { moduleDetail = null })
                    else ModulesPage(onSettings = { moduleDetail = it })
                }
                else -> LogBox(Modifier.fillMaxSize().padding(8.dp))
            }
        }
    }
}

@Composable
private fun ScrollToBottomButton(
    visible: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    SmallFloatingActionButton(
        onClick = onClick,
        modifier = modifier.padding(12.dp),
        shape = CircleShape,
    ) {
        Text("↓", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ChatTab(online: Boolean) {
    val lines by Core.chat.collectAsState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var stickToBottom by remember { mutableStateOf(true) }
    val isAtBottom by remember { derivedStateOf { !listState.canScrollForward } }
    var text by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
            .collect { (scrolling, canFwd) ->
                if (scrolling || !canFwd) stickToBottom = !canFwd
            }
    }
    LaunchedEffect(lines.size, lines.lastOrNull()) {
        if (lines.isNotEmpty() && stickToBottom) listState.scrollToItem(lines.size - 1)
    }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), state = listState) {
                if (lines.isEmpty()) item { Text("Belum ada chat. Pastikan modul Chat aktif.", Modifier.padding(vertical = 12.dp)) }
                items(lines.size) { i -> Text(Ansi.annotated(lines[i]), fontSize = 13.sp, modifier = Modifier.padding(vertical = 2.dp)) }
            }
            ScrollToBottomButton(
                visible = lines.isNotEmpty() && !isAtBottom,
                onClick = {
                    stickToBottom = true
                    scope.launch { listState.animateScrollToItem(lines.size - 1) }
                },
                modifier = Modifier.align(Alignment.BottomEnd),
            )
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                text, { text = it }, singleLine = true, placeholder = { Text("Chat atau /perintah") },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(enabled = online && text.isNotBlank(), onClick = { Core.send(text); text = "" }) { Text("Kirim") }
        }
    }
}

@Composable
private fun PlayerHead(name: String, hash: String?) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, key1 = name, key2 = hash) {
        value = TexCache.loadPlayerHead(ctx, name, hash)
    }
    val shape = RoundedCornerShape(6.dp)
    if (bmp != null) {
        Image(
            bitmap = bmp!!,
            contentDescription = name,
            modifier = Modifier.size(40.dp).clip(shape),
            filterQuality = FilterQuality.None,
        )
    } else {
        val hue = (name.lowercase().hashCode() and 0x7FFFFFFF)
        val palette = listOf(Color(0xFF3E6B89), Color(0xFF4F7A48), Color(0xFF8A5A3B), Color(0xFF6B4C8A), Color(0xFF8A3B5E), Color(0xFF3B7A73))
        val bg = palette[hue % palette.size]
        Box(
            Modifier.size(40.dp).clip(shape).background(bg).border(1.dp, Color(0x28FFFFFF), shape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.take(1).uppercase().ifEmpty { "?" },
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun PlayersTab() {
    val players by Core.players.collectAsState()
    val invertedIds = remember { mutableStateMapOf<String, Boolean>() }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Pemain online (${players.size})",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleSmall,
            )
            Text(
                "Ketuk kartu untuk invert warna",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (players.isEmpty()) item {
                Text("Belum ada data. Aktifkan modul Player List lalu konek.", Modifier.padding(16.dp))
            }
            items(players, key = { it.id }) { p ->
                val inverted = invertedIds[p.id] == true
                val shape = RoundedCornerShape(10.dp)
                val cardBg = if (inverted) Color(0xFFE6EAF2) else Color(0xFF1C2029)
                val borderCol = when {
                    inverted -> Color(0xFF9AA4B5)
                    p.self -> Color(0xFF3D5C80)
                    else -> Color(0xFF2B313F)
                }
                val defaultDisplayCol = if (inverted) Color(0xFF151820) else Color(0xFFEAECEF)
                val subCol = if (inverted) Color(0xFF475063) else Color(0xFF9AA3B2)
                val ping = p.ping
                val pingCol = when {
                    ping == null -> subCol
                    inverted && ping < 100 -> Color(0xFF1B7F37)
                    inverted && ping < 200 -> Color(0xFF9A6700)
                    inverted -> Color(0xFFC92A2A)
                    ping < 100 -> Color(0xFF7FD67F)
                    ping < 200 -> Color(0xFFF5C542)
                    else -> Color(0xFFE26B6B)
                }
                Surface(
                    modifier = Modifier.fillMaxWidth().clip(shape).clickable { invertedIds[p.id] = !inverted },
                    shape = shape,
                    color = cardBg,
                    border = BorderStroke(1.dp, borderCol),
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PlayerHead(p.name, p.hash)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                Ansi.annotated(p.display),
                                fontSize = 17.sp,
                                color = defaultDisplayCol,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                p.name + if (p.self) " (kamu)" else "",
                                fontSize = 13.sp,
                                color = subCol,
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (ping == null) "-" else "$ping ms",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = pingCol,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LogBox(modifier: Modifier = Modifier) {
    val logs by Core.logs.collectAsState()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var stickToBottom by remember { mutableStateOf(true) }
    val isAtBottom by remember { derivedStateOf { !listState.canScrollForward } }
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
            .collect { (scrolling, canFwd) ->
                if (scrolling || !canFwd) stickToBottom = !canFwd
            }
    }
    LaunchedEffect(logs.size, logs.lastOrNull()) {
        if (logs.isNotEmpty() && stickToBottom) listState.scrollToItem(logs.size - 1)
    }
    // Teks log sengaja TIDAK dibungkus SelectionContainer: log terus bertambah dan itu membuat Compose crash
    // (NullPointerException di SelectionManager). Sebagai gantinya ada tombol "Salin semua".
    Card(modifier) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (copied) "Log disalin" else "${logs.size} baris", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = {
                    copyText(ctx, "log", Ansi.strip(logs.joinToString("\n")))
                    copied = true
                }) { Text("Salin semua") }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 4.dp), state = listState) {
                    if (logs.isEmpty()) item {
                        Text("(log kosong)", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                    items(logs.size) { i ->
                        Text(Ansi.annotated(logs[i]), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
                ScrollToBottomButton(
                    visible = logs.isNotEmpty() && !isAtBottom,
                    onClick = {
                        stickToBottom = true
                        scope.launch { listState.animateScrollToItem(logs.size - 1) }
                    },
                    modifier = Modifier.align(Alignment.BottomEnd),
                )
            }
        }
    }
}
