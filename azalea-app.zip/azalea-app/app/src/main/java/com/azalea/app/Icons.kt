package com.azalea.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object AzaleaIcons {
    private fun vec(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply(block).build()

    val Account: ImageVector by lazy {
        vec("Account") {
            path(fill = SolidColor(Color.White)) {
                // Head circle + shoulders
                moveTo(12f, 12f)
                curveTo(14.21f, 12f, 16f, 10.21f, 16f, 8f)
                curveTo(16f, 5.79f, 14.21f, 4f, 12f, 4f)
                curveTo(9.79f, 4f, 8f, 5.79f, 8f, 8f)
                curveTo(8f, 10.21f, 9.79f, 12f, 12f, 12f)
                close()
                moveTo(12f, 14f)
                curveTo(9.33f, 14f, 4f, 15.34f, 4f, 18f)
                verticalLineTo(20f)
                horizontalLineTo(20f)
                verticalLineTo(18f)
                curveTo(20f, 15.34f, 14.67f, 14f, 12f, 14f)
                close()
            }
        }
    }

    val Server: ImageVector by lazy {
        vec("Server") {
            path(fill = SolidColor(Color.White), pathFillType = PathFillType.EvenOdd) {
                moveTo(4f, 4f)
                horizontalLineTo(20f)
                verticalLineTo(10f)
                horizontalLineTo(4f)
                close()
                moveTo(6f, 6f)
                horizontalLineTo(8f)
                verticalLineTo(8f)
                horizontalLineTo(6f)
                close()
                moveTo(4f, 14f)
                horizontalLineTo(20f)
                verticalLineTo(20f)
                horizontalLineTo(4f)
                close()
                moveTo(6f, 16f)
                horizontalLineTo(8f)
                verticalLineTo(18f)
                horizontalLineTo(6f)
                close()
            }
        }
    }

    val Modules: ImageVector by lazy {
        vec("Modules") {
            path(fill = SolidColor(Color.White)) {
                moveTo(4f, 4f); horizontalLineTo(11f); verticalLineTo(11f); horizontalLineTo(4f); close()
                moveTo(13f, 4f); horizontalLineTo(20f); verticalLineTo(11f); horizontalLineTo(13f); close()
                moveTo(4f, 13f); horizontalLineTo(11f); verticalLineTo(20f); horizontalLineTo(4f); close()
                moveTo(13f, 13f); horizontalLineTo(20f); verticalLineTo(20f); horizontalLineTo(13f); close()
            }
        }
    }

    val Menu: ImageVector by lazy {
        vec("Menu") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(4f, 6f); lineTo(20f, 6f)
                moveTo(4f, 12f); lineTo(20f, 12f)
                moveTo(4f, 18f); lineTo(20f, 18f)
            }
        }
    }

    val Settings: ImageVector by lazy {
        vec("Settings") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(12f, 15f)
                curveTo(13.66f, 15f, 15f, 13.66f, 15f, 12f)
                curveTo(15f, 10.34f, 13.66f, 9f, 12f, 9f)
                curveTo(10.34f, 9f, 9f, 10.34f, 9f, 12f)
                curveTo(9f, 13.66f, 10.34f, 15f, 12f, 15f)
                close()
                moveTo(12f, 3f); lineTo(12f, 5.5f)
                moveTo(12f, 18.5f); lineTo(12f, 21f)
                moveTo(3f, 12f); lineTo(5.5f, 12f)
                moveTo(18.5f, 12f); lineTo(21f, 12f)
                moveTo(5.6f, 5.6f); lineTo(7.4f, 7.4f)
                moveTo(16.6f, 16.6f); lineTo(18.4f, 18.4f)
                moveTo(18.4f, 5.6f); lineTo(16.6f, 7.4f)
                moveTo(7.4f, 16.6f); lineTo(5.6f, 18.4f)
            }
        }
    }

    val Add: ImageVector by lazy {
        vec("Add") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.4f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(12f, 5f); lineTo(12f, 19f)
                moveTo(5f, 12f); lineTo(19f, 12f)
            }
        }
    }

    val Send: ImageVector by lazy {
        vec("Send") {
            path(fill = SolidColor(Color.White)) {
                moveTo(3f, 20f)
                lineTo(21f, 12f)
                lineTo(3f, 4f)
                lineTo(3f, 10.2f)
                lineTo(15f, 12f)
                lineTo(3f, 13.8f)
                close()
            }
        }
    }

    val TabComplete: ImageVector by lazy {
        vec("TabComplete") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.1f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(4f, 12f); lineTo(15f, 12f)
                moveTo(11f, 7f); lineTo(16f, 12f); lineTo(11f, 17f)
                moveTo(19f, 6f); lineTo(19f, 18f)
            }
        }
    }

    val ArrowDown: ImageVector by lazy {
        vec("ArrowDown") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.3f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(12f, 5f); lineTo(12f, 18f)
                moveTo(6f, 13f); lineTo(12f, 19f); lineTo(18f, 13f)
            }
        }
    }

    val Search: ImageVector by lazy {
        vec("Search") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.1f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(15.5f, 15.5f); lineTo(20f, 20f)
                moveTo(10.5f, 4f)
                curveTo(14.09f, 4f, 17f, 6.91f, 17f, 10.5f)
                curveTo(17f, 14.09f, 14.09f, 17f, 10.5f, 17f)
                curveTo(6.91f, 17f, 4f, 14.09f, 4f, 10.5f)
                curveTo(4f, 6.91f, 6.91f, 4f, 10.5f, 4f)
                close()
            }
        }
    }

    val Close: ImageVector by lazy {
        vec("Close") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(6f, 6f); lineTo(18f, 18f)
                moveTo(18f, 6f); lineTo(6f, 18f)
            }
        }
    }

    val Clear: ImageVector by lazy {
        vec("Clear") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(5f, 7f); lineTo(19f, 7f)
                moveTo(9f, 7f); lineTo(9.5f, 4.5f); lineTo(14.5f, 4.5f); lineTo(15f, 7f)
                moveTo(7f, 7f); lineTo(8f, 19.5f); lineTo(16f, 19.5f); lineTo(17f, 7f)
            }
        }
    }

    val Filter: ImageVector by lazy {
        vec("Filter") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(4f, 5f); lineTo(20f, 5f); lineTo(14f, 12.5f); lineTo(14f, 18.5f); lineTo(10f, 20f); lineTo(10f, 12.5f); close()
            }
        }
    }
}
