package com.azalea.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import kotlinx.coroutines.runBlocking
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

internal data class NotifyMsgEntry(val isSelf: Boolean, val text: String, val timeMs: Long)

internal data class NotifyThreadState(
    val title: String,
    val sender: String,
    val selfName: String = "",
    val messages: MutableList<NotifyMsgEntry> = mutableListOf(),
    val avatar: Bitmap? = null,
    val selfAvatar: Bitmap? = null,
)

/** Menjaga proses aplikasi (dan inti Azalea) tetap hidup walau layar mati. Hanya aktif selama ada koneksi yang diinginkan. */
class BotService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "Koneksi", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_OPEN_SESSION, true)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Azalea")
            .setContentText("Bot berjalan di latar belakang")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "azalea:bot").apply { acquire() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        private const val CH = "service"
        private const val CH_ALERT = "alerts"
        const val DEFAULT_REPLY_COMMAND = "/msg {nama} {pesan}"
        const val KEY_REPLY = "azalea_notif_reply"
        const val ACTION_REPLY = "com.azalea.app.ACTION_NOTIF_REPLY"
        const val ACTION_DISMISS = "com.azalea.app.ACTION_NOTIF_DISMISS"
        const val EXTRA_NOTIFY_ID = "notify_id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SENDER = "sender"
        const val EXTRA_REPLY_CMD = "reply_cmd"

        private val threads = ConcurrentHashMap<Int, NotifyThreadState>()
        private val notifExec = Executors.newSingleThreadExecutor { r ->
            Thread(r, "notif-head").apply { isDaemon = true }
        }

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BotService::class.java))
        }

        fun stop(ctx: Context) {
            threads.clear()
            ctx.stopService(Intent(ctx, BotService::class.java))
        }

        fun dismissThread(notifyId: Int) {
            threads.remove(notifyId)
        }

        fun resolveReplyTemplate(fallback: String = ""): String {
            val chatStorage = ModStorage.data.value["chat"]
            val serverKey = Core.current()?.first?.let { "${it.host}:${it.port}" }.orEmpty()
            val srvCmd = if (serverKey.isNotEmpty()) {
                chatStorage?.optJSONObject("servers")
                    ?.optJSONObject(serverKey)
                    ?.optString("reply_command", "")
                    ?.trim()
                    .orEmpty()
            } else {
                ""
            }
            if (srvCmd.isNotEmpty()) return srvCmd
            val globalCmd = chatStorage?.optJSONObject("global")
                ?.optString("reply_command", "")
                ?.trim()
                .orEmpty()
            if (globalCmd.isNotEmpty()) return globalCmd
            return fallback.trim().ifEmpty { DEFAULT_REPLY_COMMAND }
        }

        fun formatReplyCommand(template: String, sender: String, message: String): String {
            val cleanMsg = message.replace('\n', ' ').replace('\r', ' ').trim()
            if (cleanMsg.isEmpty()) return ""
            val cleanSender = sender.trim()
            val tpl = template.trim().ifEmpty { DEFAULT_REPLY_COMMAND }
            val needsSender = Regex("\\{(?:nama|name|sender|player)\\}", RegexOption.IGNORE_CASE).containsMatchIn(tpl)
            if (needsSender && cleanSender.isEmpty()) {
                return "/r $cleanMsg"
            }
            val hasMsgPlaceholder = Regex("\\{(?:pesan|message|msg|text)\\}", RegexOption.IGNORE_CASE).containsMatchIn(tpl)
            var out = tpl
            out = Regex("\\{(?:nama|name|sender|player)\\}", RegexOption.IGNORE_CASE).replace(out) { cleanSender }
            out = Regex("\\{(?:pesan|message|msg|text)\\}", RegexOption.IGNORE_CASE).replace(out) { cleanMsg }
            if (!hasMsgPlaceholder) {
                out = "${out.trimEnd()} $cleanMsg"
            }
            return out.trim()
        }

        private fun resolveHeadSync(appCtx: Context, username: String): Bitmap? {
            if (username.isBlank()) return null
            val hash = Core.players.value
                .firstOrNull { it.name.equals(username, ignoreCase = true) }
                ?.hash
                ?: TexCache.knownHashFor(username)
            return try {
                runBlocking { TexCache.loadPlayerHeadBitmap(appCtx, username, hash, 96) }
            } catch (_: Throwable) {
                null
            }
        }

        private fun fetchMissingAvatars(
            appCtx: Context,
            notifyId: Int,
            senderName: String,
            selfUser: String,
            needSender: Boolean,
            needSelf: Boolean,
            replyCmd: String,
        ) {
            if (!needSender && !needSelf) return
            notifExec.execute {
                val peerBmp = if (needSender && senderName.isNotBlank()) resolveHeadSync(appCtx, senderName) else null
                val selfBmp = if (needSelf && selfUser.isNotBlank()) resolveHeadSync(appCtx, selfUser) else null
                if (peerBmp != null || selfBmp != null) {
                    val updated = synchronized(threads) {
                        val cur = threads[notifyId] ?: return@synchronized null
                        val next = cur.copy(
                            avatar = cur.avatar ?: peerBmp,
                            selfAvatar = cur.selfAvatar ?: selfBmp,
                        )
                        threads[notifyId] = next
                        next.copy(messages = next.messages.toMutableList())
                    }
                    if (updated != null) {
                        postConversationNotification(appCtx, notifyId, updated, replyCmd, silent = true)
                    }
                }
            }
        }

        fun notifyAlert(
            ctx: Context,
            title: String,
            body: String,
            sender: String = "",
            replyCmd: String = "",
        ) {
            val appCtx = ctx.applicationContext
            val cleanSender = sender.trim()
            val selfUser = Core.current()?.second?.username?.trim().orEmpty()
            val notifyId = if (cleanSender.isNotEmpty()) {
                1000 + (cleanSender.lowercase().hashCode() and 0x7FFFFFFF) % 50000
            } else {
                (System.currentTimeMillis() % 100000).toInt() + 60000
            }
            val now = System.currentTimeMillis()
            val state = synchronized(threads) {
                val cur = threads[notifyId]
                val next = if (cur != null && cur.sender.equals(cleanSender, ignoreCase = true)) {
                    if (selfUser.isNotEmpty() && cur.selfName != selfUser) cur.copy(selfName = selfUser, selfAvatar = null) else cur
                } else {
                    NotifyThreadState(title, cleanSender, selfName = selfUser)
                }
                next.messages.add(NotifyMsgEntry(isSelf = false, text = body, timeMs = now))
                while (next.messages.size > 6) next.messages.removeAt(0)
                threads[notifyId] = next
                next.copy(messages = next.messages.toMutableList())
            }
            postConversationNotification(appCtx, notifyId, state, replyCmd, silent = false)
            fetchMissingAvatars(
                appCtx = appCtx,
                notifyId = notifyId,
                senderName = cleanSender,
                selfUser = selfUser,
                needSender = cleanSender.isNotEmpty() && state.avatar == null,
                needSelf = selfUser.isNotEmpty() && state.selfAvatar == null,
                replyCmd = replyCmd,
            )
        }

        fun appendSelfReply(
            ctx: Context,
            notifyId: Int,
            title: String,
            sender: String,
            replyCmd: String,
            replyText: String,
        ) {
            val appCtx = ctx.applicationContext
            val selfUser = Core.current()?.second?.username?.trim().orEmpty()
            val now = System.currentTimeMillis()
            val state = synchronized(threads) {
                val cur = threads[notifyId] ?: NotifyThreadState(title, sender, selfName = selfUser)
                val next = if (selfUser.isNotEmpty() && cur.selfName.isBlank()) cur.copy(selfName = selfUser) else cur
                next.messages.add(NotifyMsgEntry(isSelf = true, text = replyText, timeMs = now))
                while (next.messages.size > 6) next.messages.removeAt(0)
                threads[notifyId] = next
                next.copy(messages = next.messages.toMutableList())
            }
            postConversationNotification(appCtx, notifyId, state, replyCmd, silent = true)
            fetchMissingAvatars(
                appCtx = appCtx,
                notifyId = notifyId,
                senderName = sender.trim(),
                selfUser = state.selfName.ifBlank { selfUser },
                needSender = sender.isNotBlank() && state.avatar == null,
                needSelf = (state.selfName.isNotBlank() || selfUser.isNotBlank()) && state.selfAvatar == null,
                replyCmd = replyCmd,
            )
        }

        private fun postConversationNotification(
            ctx: Context,
            notifyId: Int,
            state: NotifyThreadState,
            replyCmd: String,
            silent: Boolean,
        ) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                val ch = NotificationChannel(CH_ALERT, "Pesan & Alert", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Notifikasi pesan pribadi / chat penting"
                    enableVibration(true)
                }
                nm.createNotificationChannel(ch)
            }
            val open = PendingIntent.getActivity(
                ctx,
                notifyId + 200000,
                Intent(ctx, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_OPEN_SESSION, true)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val dismissIntent = Intent(ctx, NotificationReplyReceiver::class.java)
                .setAction(ACTION_DISMISS)
                .putExtra(EXTRA_NOTIFY_ID, notifyId)
            val dismissPending = PendingIntent.getBroadcast(
                ctx,
                notifyId + 100000,
                dismissIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val peerName = state.sender.ifBlank { state.title.ifBlank { "Pesan Pribadi" } }
            val meBuilder = Person.Builder().setName(state.selfName.ifBlank { "Kamu" })
            state.selfAvatar?.let { bmp ->
                meBuilder.setIcon(IconCompat.createWithBitmap(bmp))
            }
            val me = meBuilder.build()
            val peerBuilder = Person.Builder().setName(peerName)
            state.avatar?.let { bmp ->
                peerBuilder.setIcon(IconCompat.createWithBitmap(bmp))
            }
            val peer = peerBuilder.build()
            val style = NotificationCompat.MessagingStyle(me)
            for (m in state.messages) {
                style.addMessage(m.text, m.timeMs, if (m.isSelf) me else peer)
            }
            val remoteInput = RemoteInput.Builder(KEY_REPLY)
                .setLabel(if (state.sender.isNotBlank()) "Balas ${state.sender}..." else "Balas pesan...")
                .build()
            val replyIntent = Intent(ctx, NotificationReplyReceiver::class.java)
                .setAction(ACTION_REPLY)
                .putExtra(EXTRA_NOTIFY_ID, notifyId)
                .putExtra(EXTRA_TITLE, state.title)
                .putExtra(EXTRA_SENDER, state.sender)
                .putExtra(EXTRA_REPLY_CMD, replyCmd)
            val replyFlags = if (Build.VERSION.SDK_INT >= 31) {
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val replyPending = PendingIntent.getBroadcast(ctx, notifyId, replyIntent, replyFlags)
            val replyAction = NotificationCompat.Action.Builder(
                android.R.drawable.ic_menu_send,
                "Balas",
                replyPending,
            )
                .addRemoteInput(remoteInput)
                .setAllowGeneratedReplies(false)
                .build()
            val lastText = state.messages.lastOrNull()?.text ?: ""
            val builder = NotificationCompat.Builder(ctx, CH_ALERT)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(state.title.ifBlank { peerName })
                .setContentText(lastText)
                .setStyle(style)
                .setContentIntent(open)
                .setDeleteIntent(dismissPending)
                .setAutoCancel(true)
                .setOnlyAlertOnce(silent)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .addAction(replyAction)
            state.avatar?.let { bmp ->
                builder.setLargeIcon(bmp)
            }
            if (!silent) {
                builder.setDefaults(NotificationCompat.DEFAULT_ALL)
            }
            nm.notify(notifyId, builder.build())
        }
    }
}

class NotificationReplyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return
        val notifyId = intent.getIntExtra(BotService.EXTRA_NOTIFY_ID, -1)
        when (intent.action) {
            BotService.ACTION_DISMISS -> {
                if (notifyId >= 0) BotService.dismissThread(notifyId)
            }
            BotService.ACTION_REPLY -> {
                val replyText = RemoteInput.getResultsFromIntent(intent)
                    ?.getCharSequence(BotService.KEY_REPLY)
                    ?.toString()
                    ?.trim()
                    .orEmpty()
                val title = intent.getStringExtra(BotService.EXTRA_TITLE).orEmpty()
                val sender = intent.getStringExtra(BotService.EXTRA_SENDER).orEmpty()
                val fallbackCmd = intent.getStringExtra(BotService.EXTRA_REPLY_CMD).orEmpty()
                if (replyText.isNotEmpty()) {
                    val tpl = BotService.resolveReplyTemplate(fallbackCmd)
                    val outCmd = BotService.formatReplyCommand(tpl, sender, replyText)
                    if (outCmd.isNotEmpty()) {
                        Thread({ Core.send(outCmd) }, "notif-reply").start()
                    }
                    if (notifyId >= 0) {
                        BotService.appendSelfReply(context, notifyId, title, sender, tpl, replyText)
                    }
                } else if (notifyId >= 0) {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.cancel(notifyId)
                    BotService.dismissThread(notifyId)
                }
            }
        }
    }
}
