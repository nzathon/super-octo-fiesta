package com.azalea.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun CoreManagerCard() {
    val ctx = LocalContext.current
    val pack by CorePack.state.collectAsState()
    val mods by Modules.list.collectAsState()
    val dynTabs by Modules.tabs.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) CorePack.importFromUri(ctx, uri)
    }
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF1C2029),
        border = BorderStroke(1.dp, if (pack.isExternal) Color(0xFF3D5C80) else Color(0xFF2B313F)),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Inti Azalea",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    if (pack.isExternal) "Eksternal" else "Bawaan APK",
                    fontSize = 12.sp,
                    color = if (pack.isExternal) Color(0xFF7FD67F) else Color(0xFF9AA3B2),
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                pack.detail,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF9AA3B2),
            )
            Text(
                "${mods.size} modul" + if (dynTabs.isNotEmpty()) " · ${dynTabs.size} tab web tambahan" else "",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF9AA3B2),
            )
            pack.error?.let { err ->
                Spacer(Modifier.height(6.dp))
                Text(err, style = MaterialTheme.typography.bodySmall, color = Color(0xFFE26B6B))
            }
            pack.notice?.let { note ->
                Spacer(Modifier.height(6.dp))
                Text(note, style = MaterialTheme.typography.bodySmall, color = Color(0xFF7FD67F))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    enabled = !pack.busy,
                    onClick = { picker.launch(arrayOf("*/*")) },
                ) {
                    Text(if (pack.busy) "Memasang..." else "Import Core (.zip)")
                }
                OutlinedButton(
                    enabled = !pack.busy,
                    onClick = { CorePack.reload(ctx) },
                ) {
                    Text("Muat Ulang")
                }
            }
            if (pack.isExternal || pack.hasWebOverride) {
                Spacer(Modifier.height(6.dp))
                OutlinedButton(
                    enabled = !pack.busy,
                    onClick = { CorePack.resetToBundled(ctx) },
                ) {
                    Text("Reset Bawaan APK")
                }
            }
        }
    }
}

/** Daftar modul: panel CorePack + daftar modul, ikon setelan, switch. Ketuk nama untuk deskripsi. */
@Composable
fun ModulesPage(onSettings: (String) -> Unit) {
    val mods by Modules.list.collectAsState()
    LazyColumn(Modifier.fillMaxSize()) {
        item(key = "_core_pack_") {
            CoreManagerCard()
        }
        if (mods.isEmpty()) {
            item(key = "_empty_mods_") {
                Box(Modifier.fillMaxWidth().padding(24.dp)) {
                    Text("Daftar modul belum termuat. Ketuk \"Muat Ulang\", import ulang core-pack, atau cek tab Log.")
                }
            }
        } else {
            items(mods, key = { it.id }) { m ->
                ModuleRow(m, onSettings)
                HorizontalDivider(color = Color(0xFF2B313F))
            }
        }
    }
}

@Composable
private fun ModuleRow(m: ModDef, onSettings: (String) -> Unit) {
    val ver by Modules.version.collectAsState()
    var enabled by remember(m.id, ver) { mutableStateOf(Modules.bool(m.id, "enabled", true)) }
    var open by remember(m.id) { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable { open = !open }) {
                Text(m.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (enabled) "Berjalan" else "Mati",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            OutlinedButton(onClick = { onSettings(m.id) }) { Text("⚙", fontSize = 18.sp) }
            Spacer(Modifier.padding(start = 8.dp))
            Switch(checked = enabled, onCheckedChange = { enabled = it; Modules.set(m.id, "enabled", it) })
        }
        if (open) {
            Text(m.desc, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

/** Halaman satu modul: tab Setelan dan Storage. */
@Composable
fun ModuleDetailScreen(id: String, onClose: () -> Unit) {
    val mods by Modules.list.collectAsState()
    val m = mods.firstOrNull { it.id == id }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(m?.title ?: id, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Kembali") }
        }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Setelan") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Storage") })
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab == 0) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (m == null || m.settings.isEmpty()) Text("Modul ini tidak punya setelan.")
                    else for (s in m.settings) SettingField(m, s)
                    Spacer(Modifier.height(24.dp))
                }
            } else {
                ModuleStorageContent(id)
            }
        }
    }
}

@Composable
private fun SettingField(m: ModDef, s: ModSetting) {
    if (s.type == "boolean") {
        val ver by Modules.version.collectAsState()
        var v by remember(m.id, s.key, ver) { mutableStateOf(Modules.bool(m.id, s.key)) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(s.label, Modifier.weight(1f))
            Switch(checked = v, onCheckedChange = { v = it; Modules.set(m.id, s.key, it) })
        }
    } else {
        var v by remember(m.id, s.key) { mutableStateOf(Modules.str(m.id, s.key)) }
        OutlinedTextField(
            value = v,
            onValueChange = {
                v = it
                val out: Any = if (s.type == "number") (it.trim().toDoubleOrNull() ?: it) else it
                Modules.set(m.id, s.key, out)
            },
            label = { Text(s.label) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (s.type == "password") PasswordVisualTransformation() else VisualTransformation.None,
        )
    }
}
