package com.azalea.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Daftar modul: ikon setelan, switch. Ketuk nama untuk deskripsi. */
@Composable
fun ModulesPage(onSettings: (String) -> Unit) {
    val mods by Modules.list.collectAsState()
    LazyColumn(Modifier.fillMaxSize()) {
        if (mods.isEmpty()) {
            item(key = "_empty_mods_") {
                Box(Modifier.fillMaxWidth().padding(24.dp)) {
                    Text("Daftar modul belum termuat. Import ulang core-pack di tab Setelan atau cek tab Log.")
                }
            }
        } else {
            items(mods, key = { it.id }) { m ->
                ModuleRow(m, onSettings)
                HorizontalDivider(color = Color(0xFF2B313F))
            }
        }
    }
}

@Composable
private fun ModuleRow(m: ModDef, onSettings: (String) -> Unit) {
    val ver by Modules.version.collectAsState()
    var enabled by remember(m.id, ver) { mutableStateOf(Modules.bool(m.id, "enabled", true)) }
    var open by remember(m.id) { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable { open = !open }) {
                Text(m.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (enabled) "Berjalan" else "Mati",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            OutlinedButton(onClick = { onSettings(m.id) }) { Icon(AzaleaIcons.Settings, contentDescription = "Setelan", modifier = Modifier.size(18.dp)) }
            Spacer(Modifier.padding(start = 8.dp))
            Switch(checked = enabled, onCheckedChange = { enabled = it; Modules.set(m.id, "enabled", it) })
        }
        if (open) {
            Text(m.desc, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

/** Halaman satu modul: tab Setelan dan Storage. */
@Composable
fun ModuleDetailScreen(id: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val mods by Modules.list.collectAsState()
    val m = mods.firstOrNull { it.id == id }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var notice by remember(id) { mutableStateOf<String?>(null) }
    var isError by remember(id) { mutableStateOf(false) }

    val exportSettingsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            writeUriText(ctx, uri, Modules.exportModuleSettingsJson(id))
            notice = "Setelan modul '$id' berhasil diexport."
            isError = false
        } catch (e: Throwable) {
            notice = "Gagal export setelan: ${e.message ?: e.javaClass.simpleName}"
            isError = true
        }
    }

    val importSettingsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val raw = readUriText(ctx, uri)
            val res = Modules.importModuleSettingsJson(id, raw)
            res.fold(
                onSuccess = { msg -> notice = msg; isError = false },
                onFailure = { e -> notice = e.message ?: "Import setelan gagal"; isError = true },
            )
        } catch (e: Throwable) {
            notice = "Gagal membaca file: ${e.message ?: e.javaClass.simpleName}"
            isError = true
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(m?.title ?: id, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Kembali") }
        }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Setelan") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Storage") })
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab == 0) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { exportSettingsLauncher.launch("azalea-setelan-$id.json") },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("Export Setelan")
                        }
                        OutlinedButton(
                            onClick = { importSettingsLauncher.launch(arrayOf("application/json", "text/*", "*/*")) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("Import Setelan")
                        }
                    }
                    notice?.let { msg ->
                        Text(
                            msg,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isError) Color(0xFFE26B6B) else Color(0xFF7FD67F),
                        )
                    }
                    HorizontalDivider(color = Color(0xFF2B313F))
                    if (m == null || m.settings.isEmpty()) Text("Modul ini tidak punya setelan.")
                    else for (s in m.settings) SettingField(m, s)
                    if (id == "chat") {
                        HorizontalDivider(color = Color(0xFF2B313F))
                        ChatModuleAppearanceSection()
                    }
                    Spacer(Modifier.height(24.dp))
                }
            } else {
                ModuleStorageContent(id)
            }
        }
    }
}

@Composable
private fun SettingField(m: ModDef, s: ModSetting) {
    if (s.type == "boolean") {
        val ver by Modules.version.collectAsState()
        var v by remember(m.id, s.key, ver) { mutableStateOf(Modules.bool(m.id, s.key)) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(s.label, Modifier.weight(1f))
            Switch(checked = v, onCheckedChange = { v = it; Modules.set(m.id, s.key, it) })
        }
    } else {
        val epoch by Modules.importEpoch.collectAsState()
        var v by remember(m.id, s.key, epoch) { mutableStateOf(Modules.str(m.id, s.key)) }
        OutlinedTextField(
            value = v,
            onValueChange = {
                v = it
                val out: Any = if (s.type == "number") (it.trim().toDoubleOrNull() ?: it) else it
                Modules.set(m.id, s.key, out)
            },
            label = { Text(s.label) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (s.type == "password") PasswordVisualTransformation() else VisualTransformation.None,
        )
    }
}

@Composable
private fun ChatModuleAppearanceSection() {
    val ap by Store.appPrefs.collectAsState()
    var showQuickEditor by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            "Tampilan Chat & Quick Command",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            "Berlaku langsung pada semua pesan di tab Chat tanpa perlu sambung ulang.",
            style = MaterialTheme.typography.bodySmall,
            color = AzaleaPalette.TextMuted,
        )
        Spacer(Modifier.height(4.dp))
        SettingSwitchRow(
            title = "Tampilkan waktu di chat",
            subtitle = "Menampilkan jam pesan masuk di awal baris",
            checked = ap.chatShowTime,
            onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowTime = v) } },
        )
        if (ap.chatShowTime) {
            SettingSwitchRow(
                title = "Tampilkan detik (HH:mm:ss)",
                subtitle = "Jika mati memakai format ringkas HH:mm",
                checked = ap.chatShowSeconds,
                onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowSeconds = v) } },
            )
        }
        SettingSwitchRow(
            title = "Tampilkan PlayerHead di chat",
            subtitle = "Menampilkan kepala skin pengirim pesan jika dikenali",
            checked = ap.chatShowHead,
            onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowHead = v) } },
        )
        SettingSwitchRow(
            title = "Tampilkan bilah Quick Command",
            subtitle = "Bar pintasan perintah cepat di atas kolom ketik",
            checked = ap.chatShowQuickCmd,
            onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowQuickCmd = v) } },
        )
        SettingSwitchRow(
            title = "Tampilkan jumlah pesan belum terbaca",
            subtitle = "Menampilkan angka pesan baru pada sub-tab Chat lain",
            checked = ap.chatShowUnread,
            onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowUnread = v) } },
        )
        Spacer(Modifier.height(4.dp))
        OutlinedButton(
            onClick = { showQuickEditor = true },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Edit Isi Quick Command (${ap.chatQuickCmds.size})")
        }
    }

    if (showQuickEditor) {
        QuickCmdEditorDialog(onDismiss = { showQuickEditor = false })
    }
}
