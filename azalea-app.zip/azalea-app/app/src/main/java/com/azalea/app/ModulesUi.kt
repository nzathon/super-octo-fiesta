package com.azalea.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun ModulesPage() {
    val mods by Modules.list.collectAsState()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(mods, key = { it.id }) { ModuleCard(it) }
    }
}

@Composable
private fun ModuleCard(m: ModDef) {
    var enabled by remember(m.id) { mutableStateOf(Modules.bool(m.id, "enabled", true)) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { enabled = it; Modules.set(m.id, "enabled", it) })
            }
            Text(m.desc, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            if (enabled) {
                for (s in m.settings) {
                    Spacer(Modifier.height(8.dp))
                    SettingField(m, s)
                }
            }
        }
    }
}

@Composable
private fun SettingField(m: ModDef, s: ModSetting) {
    if (s.type == "boolean") {
        var v by remember(m.id, s.key) { mutableStateOf(Modules.bool(m.id, s.key)) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(s.label, Modifier.weight(1f))
            Switch(checked = v, onCheckedChange = { v = it; Modules.set(m.id, s.key, it) })
        }
    } else {
        var v by remember(m.id, s.key) { mutableStateOf(Modules.str(m.id, s.key)) }
        OutlinedTextField(
            value = v,
            onValueChange = {
                v = it
                val out: Any = if (s.type == "number") (it.trim().toDoubleOrNull() ?: it) else it
                Modules.set(m.id, s.key, out)
            },
            label = { Text(s.label) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (s.type == "password") PasswordVisualTransformation() else VisualTransformation.None
        )
    }
}
