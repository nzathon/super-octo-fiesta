package com.azalea.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Daftar modul: nama + status, ikon setelan, switch. Ketuk nama untuk membuka/menutup deskripsi. */
@Composable
fun ModulesPage(onSettings: (String) -> Unit) {
    val mods by Modules.list.collectAsState()
    if (mods.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Daftar modul belum termuat. Cek tab Log (baris \"daftar modul\").")
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(mods, key = { it.id }) { m ->
            ModuleRow(m, onSettings)
            HorizontalDivider()
        }
    }
}

@Composable
private fun ModuleRow(m: ModDef, onSettings: (String) -> Unit) {
    val ver by Modules.version.collectAsState()
    var enabled by remember(m.id, ver) { mutableStateOf(Modules.bool(m.id, "enabled", true)) }
    var open by remember(m.id) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable { open = !open }) {
                Text(m.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (enabled) "Berjalan" else "Mati",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(onClick = { onSettings(m.id) }) { Text("⚙", fontSize = 18.sp) }
            Spacer(Modifier.padding(start = 8.dp))
            Switch(checked = enabled, onCheckedChange = { enabled = it; Modules.set(m.id, "enabled", it) })
        }
        if (open) {
            Text(m.desc, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

/** Halaman satu modul: tab Setelan dan Storage. */
@Composable
fun ModuleDetailScreen(id: String, onClose: () -> Unit) {
    val mods by Modules.list.collectAsState()
    val m = mods.firstOrNull { it.id == id }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(m?.title ?: id, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Kembali") }
        }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Setelan") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Storage") })
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab == 0) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (m == null || m.settings.isEmpty()) Text("Modul ini tidak punya setelan.")
                    else for (s in m.settings) SettingField(m, s)
                    Spacer(Modifier.height(24.dp))
                }
            } else {
                ModuleStorageContent(id)
            }
        }
    }
}

@Composable
private fun SettingField(m: ModDef, s: ModSetting) {
    if (s.type == "boolean") {
        val ver by Modules.version.collectAsState()
        var v by remember(m.id, s.key, ver) { mutableStateOf(Modules.bool(m.id, s.key)) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(s.label, Modifier.weight(1f))
            Switch(checked = v, onCheckedChange = { v = it; Modules.set(m.id, s.key, it) })
        }
    } else {
        var v by remember(m.id, s.key) { mutableStateOf(Modules.str(m.id, s.key)) }
        OutlinedTextField(
            value = v,
            onValueChange = {
                v = it
                val out: Any = if (s.type == "number") (it.trim().toDoubleOrNull() ?: it) else it
                Modules.set(m.id, s.key, out)
            },
            label = { Text(s.label) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (s.type == "password") PasswordVisualTransformation() else VisualTransformation.None
        )
    }
}
