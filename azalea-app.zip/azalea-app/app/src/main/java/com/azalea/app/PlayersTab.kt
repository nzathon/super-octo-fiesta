package com.azalea.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
internal fun PlayerHead(name: String, hash: String?, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, key1 = name, key2 = hash) {
        value = TexCache.loadPlayerHead(ctx, name, hash)
    }
    val shape = RoundedCornerShape(6.dp)
    if (bmp != null) {
        Image(
            bitmap = bmp!!,
            contentDescription = name,
            modifier = Modifier.size(size).clip(shape),
            filterQuality = FilterQuality.None,
        )
    } else {
        val hue = (name.lowercase().hashCode() and 0x7FFFFFFF)
        val palette = listOf(
            Color(0xFF3E6B89), Color(0xFF4F7A48), Color(0xFF8A5A3B),
            Color(0xFF6B4C8A), Color(0xFF8A3B5E), Color(0xFF3B7A73),
        )
        val bg = palette[hue % palette.size]
        Box(
            Modifier.size(size).clip(shape).background(bg).border(1.dp, Color(0x28FFFFFF), shape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.take(1).uppercase().ifEmpty { "?" },
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private data class PlayerQuickAction(val label: String, val cmd: String, val send: Boolean = false)

private fun parseQuickActionEntry(raw: Any?): PlayerQuickAction? = when (raw) {
    is org.json.JSONObject -> {
        val cmd = raw.optString("cmd").ifBlank { raw.optString("command").ifBlank { raw.optString("perintah") } }
        val label = raw.optString("label").ifBlank { raw.optString("name").ifBlank { raw.optString("nama") } }
            .ifBlank { cmd.trim().removePrefix("/").substringBefore(' ').replaceFirstChar { it.uppercase() } }
        val send = raw.optBoolean("send", raw.optBoolean("kirim", false))
        if (cmd.isBlank() && label.isBlank()) null else PlayerQuickAction(label, cmd, send)
    }
    is String -> {
        val cmd = raw
        val label = cmd.trim().removePrefix("/").substringBefore(' ').replaceFirstChar { it.uppercase() }
        if (cmd.isBlank()) null else PlayerQuickAction(label.ifBlank { "Aksi" }, cmd, false)
    }
    else -> null
}

private fun parseQuickActionArray(arr: org.json.JSONArray?): List<PlayerQuickAction> {
    if (arr == null) return emptyList()
    val out = ArrayList<PlayerQuickAction>()
    for (i in 0 until arr.length()) {
        parseQuickActionEntry(arr.opt(i))?.let { out.add(it) }
    }
    return out
}

private fun resolvePlayerQuickActions(storageObj: org.json.JSONObject?, serverKey: String): List<PlayerQuickAction> {
    val defaults = listOf(
        PlayerQuickAction("Message", "/msg <name> ", false),
        PlayerQuickAction("TPA", "/tpa <name>", true),
    )
    val base = if (storageObj != null && storageObj.has("global")) {
        parseQuickActionArray(storageObj.optJSONArray("global"))
    } else {
        defaults
    }
    val merged = base.toMutableList()
    val serversObj = storageObj?.optJSONObject("servers")
    if (serversObj != null && serverKey.isNotBlank()) {
        val hostOnly = serverKey.substringBefore(':')
        val srvArr = serversObj.optJSONArray(serverKey)
            ?: if (hostOnly.isNotBlank()) serversObj.optJSONArray(hostOnly) else null
        for (item in parseQuickActionArray(srvArr)) {
            val idx = merged.indexOfFirst { it.label.equals(item.label, ignoreCase = true) }
            if (idx >= 0) merged[idx] = item else merged.add(item)
        }
    }
    return merged
}

private fun formatPlayerCommand(template: String, playerName: String): String =
    template
        .replace("<name>", playerName, ignoreCase = true)
        .replace("<player>", playerName, ignoreCase = true)
        .replace("{name}", playerName, ignoreCase = true)

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
internal fun PlayersTab(serverKey: String, onChatAction: (String) -> Unit) {
    val players by Core.players.collectAsState()
    val allStorage by ModStorage.data.collectAsState()
    val ctx = LocalContext.current
    var selectedPlayerId by remember { mutableStateOf<String?>(null) }
    var copiedPlayerId by remember { mutableStateOf<String?>(null) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var sortByPing by remember { mutableStateOf(false) }

    val activeKey = Core.current()?.first?.let { "${it.host}:${it.port}" } ?: serverKey
    val quickActions = remember(allStorage, activeKey) {
        resolvePlayerQuickActions(allStorage["playerlist"], activeKey)
    }

    val shownPlayers = remember(players, searchQuery, sortByPing) {
        val q = searchQuery.trim()
        val filtered = if (q.isEmpty()) players else players.filter {
            it.name.contains(q, ignoreCase = true) || Ansi.strip(it.display).contains(q, ignoreCase = true)
        }
        if (sortByPing) {
            filtered.sortedWith(compareBy<PlayerRow> { !it.self }.thenBy { it.ping ?: Int.MAX_VALUE }.thenBy { it.name.lowercase() })
        } else {
            filtered
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 8.dp, top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Online: ${players.size}",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleSmall,
                color = AzaleaPalette.TextPrimary,
            )
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { sortByPing = !sortByPing },
                shape = RoundedCornerShape(8.dp),
                color = if (sortByPing) AzaleaPalette.EmeraldDark else AzaleaPalette.CardAlt,
                border = BorderStroke(1.dp, if (sortByPing) AzaleaPalette.Emerald else AzaleaPalette.Border),
            ) {
                Text(
                    if (sortByPing) "Urut: Ping" else "Urut: A-Z",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    fontSize = 11.sp,
                    color = if (sortByPing) AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                )
            }
            Spacer(Modifier.width(4.dp))
            IconButton(
                onClick = { searchOpen = !searchOpen; if (!searchOpen) searchQuery = "" },
                modifier = Modifier.size(34.dp),
            ) {
                Icon(
                    AzaleaIcons.Search,
                    contentDescription = "Cari pemain",
                    modifier = Modifier.size(18.dp),
                    tint = if (searchOpen) AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                )
            }
        }
        if (searchOpen) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Cari nama pemain...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (shownPlayers.isEmpty()) item {
                Text(
                    if (players.isEmpty()) "Belum ada data. Aktifkan modul Player List lalu konek."
                    else "Tidak ada pemain yang cocok dengan \"$searchQuery\".",
                    Modifier.padding(16.dp),
                    color = AzaleaPalette.TextMuted,
                )
            }
            items(shownPlayers, key = { it.id }) { p ->
                val interactionSource = remember { MutableInteractionSource() }
                val isPressed by interactionSource.collectIsPressedAsState()
                val toggled = selectedPlayerId == p.id
                val highlighted = isPressed || toggled
                val shape = RoundedCornerShape(10.dp)
                val cardBg = if (highlighted) AzaleaPalette.CardSelected else AzaleaPalette.Card
                val borderCol = if (highlighted) AzaleaPalette.BorderSelected else if (p.self) Color(0xFF335C4C) else AzaleaPalette.Border
                val ping = p.ping
                val pingCol = when {
                    ping == null -> AzaleaPalette.TextMuted
                    ping < 100 -> AzaleaPalette.Emerald
                    ping < 200 -> AzaleaPalette.Warning
                    else -> AzaleaPalette.Danger
                }
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .combinedClickable(
                            interactionSource = interactionSource,
                            indication = null,
                            onClick = {
                                selectedPlayerId = if (toggled) null else p.id
                                copiedPlayerId = null
                            },
                            onLongClick = {},
                        ),
                    shape = shape,
                    color = cardBg,
                    border = BorderStroke(1.dp, borderCol),
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            PlayerHead(p.name, p.hash)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    Ansi.annotated(p.display, invert = false),
                                    fontSize = 16.sp,
                                    color = AzaleaPalette.TextPrimary,
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    p.name + if (p.self) " (kamu)" else "",
                                    fontSize = 12.sp,
                                    color = if (p.self) AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (ping == null) "-" else "$ping ms",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = pingCol,
                            )
                        }
                        if (toggled) {
                            HorizontalDivider(color = AzaleaPalette.Border)
                            FlowRow(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                quickActions.forEachIndexed { idx, act ->
                                    val cmd = formatPlayerCommand(act.cmd, p.name)
                                    val onActClick = {
                                        selectedPlayerId = null
                                        if (act.send) Core.send(cmd) else onChatAction(cmd)
                                    }
                                    if (idx == 0) {
                                        Button(
                                            onClick = onActClick,
                                            modifier = Modifier.height(34.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = AzaleaPalette.Emerald,
                                                contentColor = Color(0xFF052E1E),
                                            ),
                                        ) {
                                            Text(act.label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    } else {
                                        OutlinedButton(
                                            onClick = onActClick,
                                            modifier = Modifier.height(34.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                            border = BorderStroke(1.dp, AzaleaPalette.Border),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AzaleaPalette.TextPrimary),
                                        ) {
                                            Text(act.label, fontSize = 12.sp)
                                        }
                                    }
                                }
                                OutlinedButton(
                                    onClick = {
                                        copyText(ctx, "username", p.name)
                                        copiedPlayerId = p.id
                                    },
                                    modifier = Modifier.height(34.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                    border = BorderStroke(1.dp, AzaleaPalette.Border),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AzaleaPalette.TextPrimary),
                                ) {
                                    Text(if (copiedPlayerId == p.id) "Tersalin" else "Salin", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
