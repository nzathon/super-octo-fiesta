package com.azalea.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
}

/**
 * Pengendali inti Azalea. Menjalankan libazalea.so sebagai proses anak (satu koneksi = satu proses)
 * dan berbicara lewat pipa stdin/stdout. Sambung ulang otomatis diatur di sini.
 */
object Core {
    val info = MutableStateFlow("Inti: Azalea (Rust)")
    val infoBad = MutableStateFlow(false)
    val status = MutableStateFlow("offline")        // offline | connecting | online | reconnecting
    val logs = MutableStateFlow<List<String>>(emptyList())

    /** Azalea hanya mengerti satu versi Minecraft (yang ada di dalamnya); dropdown ini cuma tampilan. */
    val versions = MutableStateFlow(listOf("1.21.11", "1.21.8", "1.21.5", "1.21.4", "1.21.1", "1.20.6", "1.20.4", "1.19.4", "1.18.2", "1.16.5", "1.12.2", "1.8.8"))

    private lateinit var app: Context
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val sched = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "core-sched").apply { isDaemon = true } }
    private val ansi = Regex("\u001B\\[[0-9;]*[A-Za-z]")

    private var wanted: Pair<Server, Account>? = null   // tidak null = pengguna ingin tersambung
    private var proc: Process? = null
    private var writer: BufferedWriter? = null
    private var gen = 0
    private var attempt = 0

    fun init(ctx: Context) {
        if (!::app.isInitialized) {
            app = ctx.applicationContext
            Modules.load(app)
        }
    }

    fun appLog(text: String) = addLog(text)

    private fun addLog(text: String) {
        val stamp = synchronized(timeFmt) { timeFmt.format(Date()) }
        synchronized(logs) { logs.value = (logs.value + "$stamp $text").takeLast(400) }
    }

    @Synchronized
    fun connect(sv: Server, acc: Account) {
        wanted = sv to acc
        attempt = 0
        BotService.start(app)
        launch(++gen)
    }

    @Synchronized
    fun disconnect() {
        wanted = null
        gen++
        killProc()
        status.value = "offline"
        addLog("diputus oleh pengguna")
        BotService.stop(app)
    }

    @Synchronized
    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        try {
            writer?.apply { write(JSONObject().put("t", "chat").put("v", t).toString()); newLine(); flush() }
        } catch (_: Throwable) { }
    }

    /** Kirim perubahan setelan modul ke inti yang sedang berjalan (kalau ada). */
    @Synchronized
    fun sendSetting(id: String, key: String, value: Any) {
        try {
            writer?.apply {
                write(JSONObject().put("t", "set").put("m", id).put("k", key).put("v", value).toString())
                newLine(); flush()
            }
        } catch (_: Throwable) { }
    }

    private fun killProc() {
        try { writer?.close() } catch (_: Throwable) { }
        proc?.destroy()
        proc = null
        writer = null
    }

    // dipanggil dalam keadaan terkunci
    private fun launch(g: Int) {
        val target = wanted ?: return
        killProc()
        status.value = if (attempt == 0) "connecting" else "reconnecting"
        Thread({ runBot(g, target.first, target.second) }, "bot-$g").start()
    }

    private fun runBot(g: Int, sv: Server, acc: Account) {
        val bin = File(app.applicationInfo.nativeLibraryDir, "libazalea.so")
        if (!bin.exists()) {
            addLog("GAGAL: libazalea.so tidak ada di ${bin.parent}")
            infoBad.value = true
            info.value = "Inti Azalea tidak ditemukan"
            synchronized(this) { if (g == gen) { wanted = null; status.value = "offline" } }
            return
        }
        // DNS dikerjakan di sini (Android punya DNS sendiri). Azalea tidak boleh memakai resolver-nya,
        // karena resolver itu butuh konteks JNI yang tidak ada di proses terpisah.
        var rhost = sv.host
        var rport = sv.port
        if (sv.port == 25565) ServerPing.srv(sv.host)?.let { rhost = it.first; rport = it.second }
        val ip: String? = try {
            java.net.InetAddress.getAllByName(rhost).sortedBy { it is java.net.Inet6Address }.firstOrNull()?.hostAddress
        } catch (_: Throwable) { null }
        if (ip == null) {
            addLog("gagal mencari alamat IP untuk $rhost (cek internet)")
            synchronized(this) { if (g == gen) { status.value = "offline"; scheduleReconnect(g) } }
            return
        }
        if (rhost != sv.host || rport != sv.port) addLog("SRV: ${sv.host} -> $rhost:$rport")
        val p: Process
        try {
            val pb = ProcessBuilder(bin.absolutePath).redirectErrorStream(true)
            pb.environment()["RUST_LOG"] = "azalea=info,warn"
            pb.environment()["RUST_BACKTRACE"] = "full"
            pb.environment()["HOME"] = app.filesDir.absolutePath
            pb.environment()["TMPDIR"] = app.cacheDir.absolutePath
            p = pb.start()
        } catch (e: Throwable) {
            addLog("gagal menjalankan inti: ${e.javaClass.simpleName}: ${e.message}")
            synchronized(this) { if (g == gen) { status.value = "offline"; scheduleReconnect(g) } }
            return
        }
        synchronized(this) {
            if (g != gen) { p.destroy(); return }
            proc = p
            writer = p.outputStream.bufferedWriter()
            val cfg = JSONObject().put("host", sv.host).put("port", sv.port)
                .put("username", acc.username).put("ip", ip).put("rport", rport)
                .put("modules", Store.modulesJson())
            try { writer?.apply { write(cfg.toString()); newLine(); flush() } } catch (_: Throwable) { }
        }
        addLog("menyambung ke ${sv.host}:${sv.port} sebagai ${acc.username}")
        try {
            p.inputStream.bufferedReader().forEachLine { handleLine(g, it) }
        } catch (_: Throwable) { }
        val code = try { p.waitFor() } catch (_: Throwable) { -1 }
        synchronized(this) {
            if (g != gen) return
            proc = null
            writer = null
            status.value = "offline"
            addLog("bot berhenti (kode $code)")
            scheduleReconnect(g)
        }
    }

    private fun handleLine(g: Int, raw: String) {
        val line = raw.replace(ansi, "").trimEnd()
        if (line.isEmpty()) return
        if (line.startsWith("{")) {
            try {
                val o = JSONObject(line)
                when (o.optString("t")) {
                    "status" -> synchronized(this) {
                        if (g == gen) {
                            val s = o.optString("v", "offline")
                            if (s == "online") attempt = 0
                            if (s != "offline") status.value = s   // "offline" diputuskan saat proses berhenti
                        }
                    }
                    "log" -> {
                        val t = o.optString("v")
                        addLog(t)
                    }
                    "chat" -> addLog(o.optString("v"))
                }
                return
            } catch (_: Throwable) { }
        }
        addLog(line)
    }

    // dipanggil dalam keadaan terkunci
    private fun scheduleReconnect(g: Int) {
        if (wanted == null) return
        if (!Modules.bool("relogin", "enabled", true)) {
            addLog("sambung ulang dimatikan (modul Relogin)")
            wanted = null
            BotService.stop(app)
            return
        }
        val minD = Modules.num("relogin", "min_delay", 5.0).toLong().coerceAtLeast(1L)
        val maxD = Modules.num("relogin", "max_delay", 60.0).toLong().coerceAtLeast(minD)
        val delay = minOf(minD shl minOf(attempt, 5), maxD)
        attempt++
        status.value = "reconnecting"
        addLog("menyambung ulang dalam $delay detik (percobaan $attempt)")
        sched.schedule(Runnable {
            synchronized(this) {
                if (g == gen && wanted != null) launch(++gen)
            }
        }, delay, TimeUnit.SECONDS)
    }
}
