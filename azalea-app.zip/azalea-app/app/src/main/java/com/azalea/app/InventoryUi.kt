package com.azalea.app

import android.content.Context
import android.webkit.JavascriptInterface
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private val CHIP_TO_SETTING = mapOf(
    "inv" to "show_inv",
    "status" to "show_status",
    "effects" to "show_effects",
    "boss" to "show_boss",
    "bar" to "show_bar",
    "title" to "show_title",
    "subtitle" to "show_subtitle",
    "icons" to "icons",
    "skin" to "skin",
)

/** Jembatan JS -> aplikasi untuk halaman inventory.html (tampilan Monitor lengkap). */
private class InvBridge(
    private val ctx: Context,
    private val pushCfg: () -> Unit,
) {
    @JavascriptInterface
    fun send(action: String, slot: Int, kind: String) {
        when (action) {
            "click" -> when (kind) {
                "left", "right", "shift", "middle", "drop1", "dropall", "offhand" -> Core.sendInv(kind, slot)
                else -> Core.appLog("aksi '$kind' belum dikenal")
            }
            "detail", "select", "use" -> Core.sendInv(action, slot)
            "close" -> Core.sendInv("close")
            "refresh" -> Core.sendInv("refresh")
            "clearFeed" -> Core.sendInv("clear_feed")
            "toggle" -> {
                val settingKey = CHIP_TO_SETTING[kind] ?: return
                val next = !Modules.bool("monitor", settingKey, true)
                Modules.set("monitor", settingKey, next)
                pushCfg()
                if (next) Core.sendInv("refresh")
            }
            else -> {}
        }
    }

    @JavascriptInterface
    fun copy(text: String) {
        copyText(ctx, "detail", text)
    }
}

private fun csv(s: String): JSONArray {
    val a = JSONArray()
    s.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { a.put(it) }
    return a
}

private fun cfgJson(): String {
    val name = Core.current()?.second?.username ?: ""
    val cfg = JSONObject()
        .put("inv", Modules.bool("monitor", "show_inv", true))
        .put("status", Modules.bool("monitor", "show_status", true))
        .put("effects", Modules.bool("monitor", "show_effects", true))
        .put("boss", Modules.bool("monitor", "show_boss", true))
        .put("bar", Modules.bool("monitor", "show_bar", true))
        .put("title", Modules.bool("monitor", "show_title", true))
        .put("subtitle", Modules.bool("monitor", "show_subtitle", true))
        .put("icons", Modules.bool("monitor", "icons", true))
        .put("skin", Modules.bool("monitor", "skin", true))
    return JSONObject()
        .put("type", "cfg")
        .put("cfg", cfg)
        .put("icons", Modules.bool("monitor", "icons", true))
        .put("iconSrc", csv(Modules.str("monitor", "icon_src")))
        .put("skinSrc", csv(Modules.str("monitor", "skin_src")))
        .put("dbl", Modules.str("monitor", "double_tap").ifBlank { "left" })
        .put("name", name)
        .toString()
}

@Composable
fun InventoryTab(online: Boolean) {
    if (!online) {
        Text("Konek ke server dulu.", Modifier.padding(16.dp))
        return
    }
    val ctx = LocalContext.current
    GlobalWebTab(
        channel = "monitor",
        url = "file:///android_asset/inventory.html",
        bridgeName = "Android",
        modifier = Modifier.fillMaxSize(),
        bridgeFactory = { push -> InvBridge(ctx) { push(cfgJson()) } },
        onSync = { push -> push(cfgJson()) },
        onResumeRefresh = { Core.sendInv("refresh") },
    )
}
