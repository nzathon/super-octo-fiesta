package com.azalea.app

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray
import org.json.JSONObject

/** Jembatan JS -> aplikasi untuk halaman inventory.html (tampilan inventory ala script Monitor lama). */
private class InvBridge(private val ctx: Context) {
    @JavascriptInterface
    fun send(action: String, slot: Int, kind: String) {
        when (action) {
            "click" -> when (kind) {
                "left", "right", "shift" -> Core.sendInv(kind, slot)
                else -> Core.appLog("aksi '$kind' belum didukung")
            }
            "detail", "select", "use" -> Core.sendInv(action, slot)
            "close" -> Core.sendInv("close")
            else -> {}   // "ready" dan lainnya diabaikan
        }
    }

    @JavascriptInterface
    fun copy(text: String) {
        copyText(ctx, "detail", text)
    }
}

private fun csv(s: String): JSONArray {
    val a = JSONArray()
    s.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { a.put(it) }
    return a
}

private fun cfgJson(): String {
    val name = Core.current()?.second?.username ?: ""
    return JSONObject()
        .put("type", "cfg")
        .put("icons", Modules.bool("monitor", "icons", true))
        .put("iconSrc", csv(Modules.str("monitor", "icon_src")))
        .put("skinSrc", csv(Modules.str("monitor", "skin_src")))
        .put("dbl", Modules.str("monitor", "double_tap").ifBlank { "left" })
        .put("name", name)
        .toString()
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun InventoryTab(online: Boolean) {
    if (!online) {
        Text("Konek ke server dulu.", Modifier.padding(16.dp))
        return
    }
    val ctx = LocalContext.current
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            WebView(c).apply {
                setBackgroundColor(0xFF15171C.toInt())
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                addJavascriptInterface(InvBridge(c), "Android")
                val web = this
                fun push(json: String) = web.post { web.evaluateJavascript("window.__tabMsg($json)", null) }
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        // halaman siap: kirim setelan, lalu data terakhir, lalu mulai teruskan data baru
                        push(cfgJson())
                        Core.lastInvJson?.let { push(it) }
                        Core.invListener = { push(it) }
                    }
                }
                loadUrl("file:///android_asset/inventory.html")
            }
        },
        onRelease = { w ->
            Core.invListener = null
            w.removeJavascriptInterface("Android")
            w.destroy()
        }
    )
}
