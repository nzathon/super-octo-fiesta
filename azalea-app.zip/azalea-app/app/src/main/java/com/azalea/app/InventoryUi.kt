package com.azalea.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun prettyName(n: String) = n.replace('_', ' ')

@Composable
private fun SlotCell(
    idx: Int, item: InvSlot?, held: Boolean, modifier: Modifier, onClick: (Int) -> Unit
) {
    val border = if (held) MaterialTheme.colorScheme.primary else Color(0xFF555555)
    Box(
        modifier
            .aspectRatio(1f)
            .padding(1.dp)
            .clip(MaterialTheme.shapes.extraSmall)
            .border(BorderStroke(if (held) 2.dp else 1.dp, border), MaterialTheme.shapes.extraSmall)
            .clickable { onClick(idx) }
    ) {
        if (item != null) {
            Text(
                prettyName(item.name), fontSize = 8.sp, lineHeight = 9.sp, maxLines = 3, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center).padding(2.dp)
            )
            if (item.count > 1) {
                Text(item.count.toString(), fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(2.dp))
            }
        }
    }
}

/** Baris-baris 9 kolom untuk slot [from, to). */
@Composable
private fun SlotRows(st: InvState, from: Int, to: Int, onClick: (Int) -> Unit) {
    var i = from
    while (i < to) {
        Row(Modifier.fillMaxWidth()) {
            for (c in 0 until 9) {
                val idx = i + c
                if (idx < to) {
                    val isHeld = idx >= st.hot && idx - st.hot == st.held
                    SlotCell(idx, st.slots.getOrNull(idx), isHeld, Modifier.weight(1f), onClick)
                } else Spacer(Modifier.weight(1f))
            }
        }
        i += 9
    }
}

@Composable
fun InventoryTab(online: Boolean) {
    val st by Core.inv.collectAsState()
    val detail by Core.detail.collectAsState()
    var picked by remember { mutableStateOf<Int?>(null) }
    var showDetail by remember { mutableStateOf(false) }
    val s = st

    if (!online || s == null) {
        Text(
            if (!online) "Konek ke server dulu." else "Belum ada data. Aktifkan modul Monitor lalu tunggu masuk dunia.",
            Modifier.padding(16.dp)
        )
        return
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (s.gui) Ansi.annotated(s.title) else androidx.compose.ui.text.AnnotatedString("Inventory"), fontSize = 16.sp)
                val cur = s.cursor
                Text(
                    "Di kursor: " + (cur?.let { "${prettyName(it.name)} x${it.count}" } ?: "kosong"),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (s.gui) OutlinedButton(onClick = { Core.sendInv("close") }) { Text("Tutup menu") }
        }
        Spacer(Modifier.height(8.dp))

        val tap: (Int) -> Unit = { picked = it }
        if (s.gui) {
            SlotRows(s, 0, s.inv, tap)
            Spacer(Modifier.height(8.dp))
        } else {
            // armor (5-8) dan tangan kiri (45) pada menu inventory pemain
            Text("Armor & tangan kiri", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth()) {
                for (idx in listOf(5, 6, 7, 8, 45)) SlotCell(idx, s.slots.getOrNull(idx), false, Modifier.weight(1f), tap)
                Spacer(Modifier.weight(4f))
            }
            Spacer(Modifier.height(8.dp))
        }
        Text("Tas", style = MaterialTheme.typography.bodySmall)
        SlotRows(s, s.inv, s.hot, tap)
        Spacer(Modifier.height(8.dp))
        Text("Hotbar", style = MaterialTheme.typography.bodySmall)
        SlotRows(s, s.hot, minOf(s.hot + 9, s.slots.size), tap)
    }

    val p = picked
    if (p != null) {
        val item = s.slots.getOrNull(p)
        val isHot = p >= s.hot && p < s.hot + 9
        AlertDialog(
            onDismissRequest = { picked = null },
            title = { Text(if (item != null) "${prettyName(item.name)} x${item.count}" else "Slot kosong") },
            text = { Text("Slot nomor $p") },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = { Core.sendInv("left", p); picked = null }) { Text("Klik kiri") }
                    TextButton(onClick = { Core.sendInv("right", p); picked = null }) { Text("Klik kanan") }
                    TextButton(onClick = { Core.sendInv("shift", p); picked = null }) { Text("Shift + klik") }
                    if (isHot && !s.gui) {
                        TextButton(onClick = { Core.sendInv("select", p - s.hot); picked = null }) { Text("Pegang item ini") }
                        TextButton(onClick = { Core.sendInv("use", p - s.hot); picked = null }) { Text("Pakai (klik kanan di dunia)") }
                    }
                    TextButton(onClick = { Core.detail.value = null; Core.sendInv("detail", p); showDetail = true; picked = null }) { Text("Detail") }
                }
            },
            dismissButton = { TextButton(onClick = { picked = null }) { Text("Batal") } }
        )
    }

    if (showDetail) {
        AlertDialog(
            onDismissRequest = { showDetail = false },
            title = { Text("Detail item") },
            text = {
                Text(
                    detail ?: "Memuat...",
                    fontFamily = FontFamily.Monospace, fontSize = 10.sp,
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            },
            confirmButton = { TextButton(onClick = { showDetail = false }) { Text("Tutup") } },
            dismissButton = {
                val ctx = androidx.compose.ui.platform.LocalContext.current
                TextButton(onClick = { copyText(ctx, "detail", detail ?: "") }) { Text("Salin") }
            }
        )
    }
}
