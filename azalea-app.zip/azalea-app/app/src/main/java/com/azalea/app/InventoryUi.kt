package com.azalea.app

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

private val CHIP_TO_SETTING = mapOf(
    "inv" to "show_inv",
    "status" to "show_status",
    "effects" to "show_effects",
    "boss" to "show_boss",
    "bar" to "show_bar",
    "title" to "show_title",
    "subtitle" to "show_subtitle",
    "icons" to "icons",
    "skin" to "skin",
)

/** Jembatan JS -> aplikasi untuk halaman inventory.html (tampilan Monitor lengkap). */
private class InvBridge(
    private val ctx: Context,
    private val pushCfg: () -> Unit,
) {
    @JavascriptInterface
    fun send(action: String, slot: Int, kind: String) {
        when (action) {
            "click" -> when (kind) {
                "left", "right", "shift", "middle", "drop1", "dropall", "offhand" -> Core.sendInv(kind, slot)
                else -> Core.appLog("aksi '$kind' belum dikenal")
            }
            "detail", "select", "use" -> Core.sendInv(action, slot)
            "close" -> Core.sendInv("close")
            "refresh" -> Core.sendInv("refresh")
            "clearFeed" -> Core.sendInv("clear_feed")
            "toggle" -> {
                val settingKey = CHIP_TO_SETTING[kind] ?: return
                val next = !Modules.bool("monitor", settingKey, true)
                Modules.set("monitor", settingKey, next)
                pushCfg()
                if (next) Core.sendInv("refresh")
            }
            else -> {}   // "ready" dan lainnya diabaikan
        }
    }

    @JavascriptInterface
    fun copy(text: String) {
        copyText(ctx, "detail", text)
    }
}

private fun csv(s: String): JSONArray {
    val a = JSONArray()
    s.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { a.put(it) }
    return a
}

private fun cfgJson(): String {
    val name = Core.current()?.second?.username ?: ""
    val cfg = JSONObject()
        .put("inv", Modules.bool("monitor", "show_inv", true))
        .put("status", Modules.bool("monitor", "show_status", true))
        .put("effects", Modules.bool("monitor", "show_effects", true))
        .put("boss", Modules.bool("monitor", "show_boss", true))
        .put("bar", Modules.bool("monitor", "show_bar", true))
        .put("title", Modules.bool("monitor", "show_title", true))
        .put("subtitle", Modules.bool("monitor", "show_subtitle", true))
        .put("icons", Modules.bool("monitor", "icons", true))
        .put("skin", Modules.bool("monitor", "skin", true))
    return JSONObject()
        .put("type", "cfg")
        .put("cfg", cfg)
        .put("icons", Modules.bool("monitor", "icons", true))
        .put("iconSrc", csv(Modules.str("monitor", "icon_src")))
        .put("skinSrc", csv(Modules.str("monitor", "skin_src")))
        .put("dbl", Modules.str("monitor", "double_tap").ifBlank { "left" })
        .put("name", name)
        .toString()
}

/**
 * Mengambil PNG dari Mojang texture CDN / mcasset.cloud lewat koneksi native Android + cache lokal,
 * lalu mengirimkannya dengan header CORS agar canvas WebView (3D player_head & tinting potion)
 * bisa membaca piksel tanpa SecurityError atau bergantung ke API pihak ketiga untuk player head.
 */
private fun fetchCorsPng(cacheDir: File, url: String): WebResourceResponse? {
    return try {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(url.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        if (!cacheDir.exists()) cacheDir.mkdirs()
        val cached = File(cacheDir, "$digest.png")
        val bytes = if (cached.exists() && cached.length() > 50) {
            cached.readBytes()
        } else {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "AzaleaApp/1.0")
            }
            try {
                if (conn.responseCode != 200) return null
                val data = conn.inputStream.use { it.readBytes() }
                if (data.size <= 50) return null
                try { cached.writeBytes(data) } catch (_: Throwable) { }
                data
            } finally {
                conn.disconnect()
            }
        }
        WebResourceResponse(
            "image/png",
            null,
            200,
            "OK",
            mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to "public, max-age=604800",
            ),
            ByteArrayInputStream(bytes)
        )
    } catch (_: Throwable) {
        null
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun InventoryTab(online: Boolean) {
    if (!online) {
        Text("Konek ke server dulu.", Modifier.padding(16.dp))
        return
    }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            val texCacheDir = File(c.cacheDir, "mc_tex_cache")
            WebView(c).apply {
                setBackgroundColor(0xFF15171C.toInt())
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                val web = this
                fun push(json: String) = web.post { web.evaluateJavascript("window.__tabMsg($json)", null) }
                addJavascriptInterface(InvBridge(c) { push(cfgJson()) }, "Android")
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val url = request?.url?.toString() ?: return null
                        if (request.method.equals("GET", ignoreCase = true) && (
                                url.startsWith("https://textures.minecraft.net/texture/") ||
                                url.startsWith("https://assets.mcasset.cloud/")
                            )
                        ) {
                            return fetchCorsPng(texCacheDir, url)
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        // halaman siap: kirim setelan, status/feed/inventory terakhir, lalu mulai teruskan data baru
                        push(cfgJson())
                        Core.lastMonStatusJson?.let { push(it) }
                        Core.lastMonFeedJson?.let { push(it) }
                        Core.lastInvJson?.let { push(it) }
                        Core.invListener = { push(it) }
                        Core.sendInv("refresh")
                    }
                }
                loadUrl("file:///android_asset/inventory.html")
            }
        },
        onRelease = { w ->
            Core.invListener = null
            w.removeJavascriptInterface("Android")
            w.destroy()
        }
    )
}
