package com.azalea.app

import android.content.Context
import android.webkit.JavascriptInterface
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

private val CHIP_TO_SETTING = mapOf(
    "inv" to "show_inv",
    "status" to "show_status",
    "effects" to "show_effects",
    "boss" to "show_boss",
    "bar" to "show_bar",
    "title" to "show_title",
    "subtitle" to "show_subtitle",
    "icons" to "icons",
    "skin" to "skin",
)

/** Jembatan JS -> aplikasi untuk halaman inventory.html (tampilan Monitor lengkap). */
private class InvBridge(
    private val ctx: Context,
    private val pushCfg: () -> Unit,
) {
    @JavascriptInterface
    fun send(action: String, slot: Int, kind: String) {
        when (action) {
            "click" -> when (kind) {
                "left", "right", "shift", "middle", "drop1", "dropall", "offhand" -> Core.sendInv(kind, slot)
                else -> Core.appLog("aksi '$kind' belum dikenal")
            }
            "detail", "select", "use", "hit", "crouch" -> Core.sendInv(action, slot)
            "look" -> {
                val parts = kind.split(",")
                val yaw = parts.getOrNull(0)?.trim()?.let { if (it == "keep" || it.isEmpty()) null else it.toDoubleOrNull() }
                val pitch = parts.getOrNull(1)?.trim()?.toDoubleOrNull() ?: 0.0
                Core.sendInvLook(yaw, pitch)
            }
            "look_step" -> {
                val parts = kind.split(",")
                val dyaw = parts.getOrNull(0)?.trim()?.toDoubleOrNull() ?: 0.0
                val dpitch = parts.getOrNull(1)?.trim()?.toDoubleOrNull() ?: 0.0
                Core.sendInvLookStep(dyaw, dpitch)
            }
            "close" -> Core.sendInv("close")
            "refresh" -> Core.sendInv("refresh")
            "clearFeed" -> Core.sendInv("clear_feed")
            "toggle" -> {
                val settingKey = CHIP_TO_SETTING[kind] ?: return
                val next = !Modules.bool("monitor", settingKey, true)
                Modules.set("monitor", settingKey, next)
                pushCfg()
                if (next) Core.sendInv("refresh")
            }
            else -> {}
        }
    }

    @JavascriptInterface
    fun copy(text: String) {
        copyText(ctx, "detail", text)
    }
}

/** Jembatan JS -> aplikasi untuk tab WebView dinamis milik modul Rust baru. */
private class DynamicWebBridge(
    private val ctx: Context,
    private val tab: WebTabDef,
    private val pushSync: () -> Unit,
) {
    @JavascriptInterface
    fun emit(action: String, payloadJson: String) {
        Core.sendWeb(tab.channel, action, payloadJson)
    }

    @JavascriptInterface
    fun refresh() {
        Core.sendWeb(tab.channel, "refresh", "{}")
    }

    @JavascriptInterface
    fun setSetting(moduleId: String, key: String, valueJson: String) {
        val parsed: Any = try {
            JSONTokener(valueJson).nextValue() ?: valueJson
        } catch (_: Throwable) {
            valueJson
        }
        Modules.set(moduleId, key, parsed)
        pushSync()
    }

    @JavascriptInterface
    fun copy(text: String) {
        copyText(ctx, tab.title, text)
    }
}

private fun csv(s: String): JSONArray {
    val a = JSONArray()
    s.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { a.put(it) }
    return a
}

private fun cfgJson(): String {
    val name = Core.current()?.second?.username ?: ""
    val cfg = JSONObject()
        .put("inv", Modules.bool("monitor", "show_inv", true))
        .put("status", Modules.bool("monitor", "show_status", true))
        .put("effects", Modules.bool("monitor", "show_effects", true))
        .put("boss", Modules.bool("monitor", "show_boss", true))
        .put("bar", Modules.bool("monitor", "show_bar", true))
        .put("title", Modules.bool("monitor", "show_title", true))
        .put("subtitle", Modules.bool("monitor", "show_subtitle", true))
        .put("icons", Modules.bool("monitor", "icons", true))
        .put("skin", Modules.bool("monitor", "skin", true))
    return JSONObject()
        .put("type", "cfg")
        .put("cfg", cfg)
        .put("icons", Modules.bool("monitor", "icons", true))
        .put("iconSrc", csv(Modules.str("monitor", "icon_src")))
        .put("skinSrc", csv(Modules.str("monitor", "skin_src")))
        .put("dbl", Modules.str("monitor", "double_tap").ifBlank { "left" })
        .put("name", name)
        .toString()
}

private fun dynamicSyncJson(): String {
    val name = Core.current()?.second?.username ?: ""
    return JSONObject()
        .put("type", "sync")
        .put("name", name)
        .put("modules", Store.modulesJson())
        .put("storage", ModStorage.all())
        .toString()
}

@Composable
fun InventoryTab(online: Boolean, visible: Boolean = true) {
    if (!online) {
        Text("Konek ke server dulu.", Modifier.padding(16.dp))
        return
    }
    val ctx = LocalContext.current
    GlobalWebTab(
        channel = "monitor",
        url = "${WEB_ORIGIN}inventory.html",
        bridgeName = "Android",
        modifier = Modifier.fillMaxSize(),
        visible = visible,
        bridgeFactory = { push -> InvBridge(ctx) { push(cfgJson()) } },
        onSync = { push -> push(cfgJson()) },
        onResumeRefresh = { Core.sendInv("refresh") },
    )
}

@Composable
fun DynamicWebTab(tab: WebTabDef, online: Boolean, visible: Boolean = true) {
    if (!online) {
        Text("Konek ke server dulu.", Modifier.padding(16.dp))
        return
    }
    val ctx = LocalContext.current
    val cleanHtml = tab.html.trimStart('/')
    GlobalWebTab(
        channel = tab.channel,
        url = "${WEB_ORIGIN}$cleanHtml",
        bridgeName = "Android",
        modifier = Modifier.fillMaxSize(),
        visible = visible,
        bridgeFactory = { push -> DynamicWebBridge(ctx, tab) { push(dynamicSyncJson()) } },
        onSync = { push -> push(dynamicSyncJson()) },
        onResumeRefresh = { Core.sendWeb(tab.channel, "refresh", "{}") },
    )
}
