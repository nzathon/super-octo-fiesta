package com.azalea.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Cache disk & memori bersama untuk tekstur PNG (Mojang / mcasset.cloud / head API untuk tab Pemain, Akun & Notifikasi).
 */
object TexCache {
    private val headCache = ConcurrentHashMap<String, ImageBitmap>()
    private val bmpCache = ConcurrentHashMap<String, Bitmap>()
    private val knownHashes = ConcurrentHashMap<String, String>()
    val hashVersion = MutableStateFlow(0)
    private val validMcName = Regex("^[A-Za-z0-9_]{1,16}$")

    fun rememberHashes(players: List<PlayerRow>) {
        var changed = false
        for (p in players) {
            val h = p.hash?.trim().orEmpty()
            val n = p.name.trim().lowercase()
            if (n.isNotEmpty() && h.isNotEmpty()) {
                val prev = knownHashes.put(n, h)
                if (prev != h) changed = true
            }
        }
        if (changed) hashVersion.value++
    }

    fun knownHashFor(name: String): String? =
        knownHashes[name.trim().lowercase()]

    fun fetchPngBytes(ctx: Context, url: String): ByteArray? {
        return try {
            val cacheDir = File(ctx.cacheDir, "mc_tex_cache")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(url.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
            val cached = File(cacheDir, "$digest.png")
            if (cached.exists() && cached.length() > 50) {
                return cached.readBytes()
            }
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "AzaleaApp/1.0")
            }
            try {
                if (conn.responseCode != 200) return null
                val data = conn.inputStream.use { it.readBytes() }
                if (data.size <= 50) return null
                try { cached.writeBytes(data) } catch (_: Throwable) { }
                data
            } finally {
                conn.disconnect()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun isLegacySolidBlackHat(skin: Bitmap): Boolean {
        if (skin.height != 32 || skin.width < 48) return false
        for (y in 8 until 16) {
            for (x in 40 until 48) {
                val px = skin.getPixel(x, y)
                val a = (px ushr 24) and 0xFF
                val rgb = px and 0x00FFFFFF
                if (a < 250 || rgb != 0) return false
            }
        }
        return true
    }

    private fun cropHeadBitmapFromSkin(bytes: ByteArray): Bitmap? {
        val skin = try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Throwable) {
            null
        } ?: return null
        return try {
            if (skin.width < 64 || skin.height < 32) return null
            val out = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
            val dst = Rect(0, 0, 8, 8)
            canvas.drawBitmap(skin, Rect(8, 8, 16, 16), dst, paint)
            if (!isLegacySolidBlackHat(skin)) {
                canvas.drawBitmap(skin, Rect(40, 8, 48, 16), dst, paint)
            }
            out
        } catch (_: Throwable) {
            null
        } finally {
            skin.recycle()
        }
    }

    private fun decodeAvatarBitmap(bytes: ByteArray): Bitmap? {
        return try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Throwable) {
            null
        }
    }

    private suspend fun resolveHeadBitmap(ctx: Context, name: String, hash: String?): Bitmap? {
        val h = hash?.trim().orEmpty().ifEmpty { knownHashFor(name).orEmpty() }
        val cleanName = name.trim()
        val cacheKey = if (h.isNotEmpty()) "hash:$h" else "api:${cleanName.lowercase()}"
        bmpCache[cacheKey]?.let { return it }
        return withContext(Dispatchers.IO) {
            bmpCache[cacheKey]?.let { return@withContext it }
            if (h.isNotEmpty()) {
                val bytes = fetchPngBytes(ctx, "https://textures.minecraft.net/texture/$h")
                val cropped = bytes?.let { cropHeadBitmapFromSkin(it) }
                if (cropped != null) {
                    bmpCache[cacheKey] = cropped
                    return@withContext cropped
                }
            }
            if (validMcName.matches(cleanName)) {
                val apiKey = "api:${cleanName.lowercase()}"
                bmpCache[apiKey]?.let { return@withContext it }
                val apiUrls = listOf(
                    "https://mc-heads.net/avatar/$cleanName/64",
                    "https://minotar.net/helm/$cleanName/64",
                )
                for (u in apiUrls) {
                    val bytes = fetchPngBytes(ctx, u) ?: continue
                    val bmp = decodeAvatarBitmap(bytes) ?: continue
                    bmpCache[apiKey] = bmp
                    if (h.isNotEmpty()) bmpCache[cacheKey] = bmp
                    return@withContext bmp
                }
            }
            null
        }
    }

    /**
     * Untuk Player List & menu Akun (mendukung hash SkinsRestorer maupun fallback username).
     */
    suspend fun loadPlayerHead(ctx: Context, name: String, hash: String?): ImageBitmap? {
        val h = hash?.trim().orEmpty().ifEmpty { knownHashFor(name).orEmpty() }
        val cleanName = name.trim()
        val cacheKey = if (h.isNotEmpty()) "hash:$h" else "api:${cleanName.lowercase()}"
        headCache[cacheKey]?.let { return it }
        val bmp = resolveHeadBitmap(ctx, name, hash) ?: return null
        val img = bmp.asImageBitmap()
        headCache[cacheKey] = img
        return img
    }

    /**
     * Untuk ikon notifikasi Android (di-scale dengan nearest-neighbor agar pixel head tetap tajam).
     */
    fun clearCache(ctx: Context): Int {
        headCache.clear()
        bmpCache.clear()
        var deleted = 0
        try {
            val dir = File(ctx.cacheDir, "mc_tex_cache")
            if (dir.exists()) {
                dir.listFiles()?.forEach { f ->
                    if (f.isFile && f.delete()) deleted++
                }
            }
        } catch (_: Throwable) { }
        hashVersion.value++
        return deleted
    }

    suspend fun loadPlayerHeadBitmap(ctx: Context, name: String, hash: String?, sizePx: Int = 96): Bitmap? {
        val raw = resolveHeadBitmap(ctx, name, hash) ?: return null
        return try {
            if (raw.width == sizePx && raw.height == sizePx) raw
            else Bitmap.createScaledBitmap(raw, sizePx, sizePx, false)
        } catch (_: Throwable) {
            raw
        }
    }
}
