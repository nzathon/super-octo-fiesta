package com.azalea.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Cache disk & memori bersama untuk tekstur PNG (Mojang / mcasset.cloud / head API untuk tab Pemain).
 */
object TexCache {
    private val headCache = ConcurrentHashMap<String, ImageBitmap>()
    private val validMcName = Regex("^[A-Za-z0-9_]{1,16}$")

    fun fetchPngBytes(ctx: Context, url: String): ByteArray? {
        return try {
            val cacheDir = File(ctx.cacheDir, "mc_tex_cache")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(url.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
            val cached = File(cacheDir, "$digest.png")
            if (cached.exists() && cached.length() > 50) {
                return cached.readBytes()
            }
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "AzaleaApp/1.0")
            }
            try {
                if (conn.responseCode != 200) return null
                val data = conn.inputStream.use { it.readBytes() }
                if (data.size <= 50) return null
                try { cached.writeBytes(data) } catch (_: Throwable) { }
                data
            } finally {
                conn.disconnect()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun isLegacySolidBlackHat(skin: Bitmap): Boolean {
        if (skin.height != 32 || skin.width < 48) return false
        for (y in 8 until 16) {
            for (x in 40 until 48) {
                val px = skin.getPixel(x, y)
                val a = (px ushr 24) and 0xFF
                val rgb = px and 0x00FFFFFF
                if (a < 250 || rgb != 0) return false
            }
        }
        return true
    }

    private fun cropHeadFromSkin(bytes: ByteArray): ImageBitmap? {
        val skin = try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Throwable) {
            null
        } ?: return null
        return try {
            if (skin.width < 64 || skin.height < 32) return null
            val out = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
            val dst = Rect(0, 0, 8, 8)
            canvas.drawBitmap(skin, Rect(8, 8, 16, 16), dst, paint)
            if (!isLegacySolidBlackHat(skin)) {
                canvas.drawBitmap(skin, Rect(40, 8, 48, 16), dst, paint)
            }
            out.asImageBitmap()
        } catch (_: Throwable) {
            null
        } finally {
            skin.recycle()
        }
    }

    private fun decodeAvatarPng(bytes: ByteArray): ImageBitmap? {
        return try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Untuk Player List (terutama server cracked/offline dengan SkinsRestorer):
     * 1) Jika server mengirim texture hash (mis. custom /skin dari SkinsRestorer), pakai Mojang CDN dulu.
     * 2) Jika tidak ada hash (atau gagal), ambil head via API (mc-heads.net -> minotar.net) berdasarkan username.
     */
    suspend fun loadPlayerHead(ctx: Context, name: String, hash: String?): ImageBitmap? {
        val h = hash?.trim().orEmpty()
        val cleanName = name.trim()
        val cacheKey = if (h.isNotEmpty()) "hash:$h" else "api:${cleanName.lowercase()}"
        headCache[cacheKey]?.let { return it }

        return withContext(Dispatchers.IO) {
            headCache[cacheKey]?.let { return@withContext it }

            if (h.isNotEmpty()) {
                val bytes = fetchPngBytes(ctx, "https://textures.minecraft.net/texture/$h")
                val cropped = bytes?.let { cropHeadFromSkin(it) }
                if (cropped != null) {
                    headCache[cacheKey] = cropped
                    return@withContext cropped
                }
            }

            if (validMcName.matches(cleanName)) {
                val apiKey = "api:${cleanName.lowercase()}"
                headCache[apiKey]?.let { return@withContext it }
                val apiUrls = listOf(
                    "https://mc-heads.net/avatar/$cleanName/64",
                    "https://minotar.net/helm/$cleanName/64",
                )
                for (u in apiUrls) {
                    val bytes = fetchPngBytes(ctx, u) ?: continue
                    val img = decodeAvatarPng(bytes) ?: continue
                    headCache[apiKey] = img
                    if (h.isNotEmpty()) headCache[cacheKey] = img
                    return@withContext img
                }
            }
            null
        }
    }
}
