package com.azalea.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Cache disk & memori bersama untuk tekstur resmi Mojang / mcasset.cloud.
 * Dipakai oleh GlobalWebTab (CORS proxy) dan PlayersTab (head pemain native Compose tanpa API pihak ke-3).
 */
object TexCache {
    private val headCache = ConcurrentHashMap<String, ImageBitmap>()

    fun fetchPngBytes(ctx: Context, url: String): ByteArray? {
        return try {
            val cacheDir = File(ctx.cacheDir, "mc_tex_cache")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(url.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
            val cached = File(cacheDir, "$digest.png")
            if (cached.exists() && cached.length() > 50) {
                return cached.readBytes()
            }
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "AzaleaApp/1.0")
            }
            try {
                if (conn.responseCode != 200) return null
                val data = conn.inputStream.use { it.readBytes() }
                if (data.size <= 50) return null
                try { cached.writeBytes(data) } catch (_: Throwable) { }
                data
            } finally {
                conn.disconnect()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun isLegacySolidBlackHat(skin: Bitmap): Boolean {
        if (skin.height != 32 || skin.width < 48) return false
        for (y in 8 until 16) {
            for (x in 40 until 48) {
                val px = skin.getPixel(x, y)
                val a = (px ushr 24) and 0xFF
                val rgb = px and 0x00FFFFFF
                if (a < 250 || rgb != 0) return false
            }
        }
        return true
    }

    suspend fun loadPlayerHead(ctx: Context, hash: String?): ImageBitmap? {
        val h = hash?.trim().orEmpty()
        if (h.isEmpty()) return null
        headCache[h]?.let { return it }
        return withContext(Dispatchers.IO) {
            headCache[h]?.let { return@withContext it }
            val bytes = fetchPngBytes(ctx, "https://textures.minecraft.net/texture/$h") ?: return@withContext null
            val skin = try {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (_: Throwable) {
                null
            } ?: return@withContext null
            try {
                if (skin.width < 64 || skin.height < 32) return@withContext null
                val out = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(out)
                val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
                val dst = Rect(0, 0, 8, 8)
                canvas.drawBitmap(skin, Rect(8, 8, 16, 16), dst, paint)
                if (!isLegacySolidBlackHat(skin)) {
                    canvas.drawBitmap(skin, Rect(40, 8, 48, 16), dst, paint)
                }
                val img = out.asImageBitmap()
                headCache[h] = img
                img
            } catch (_: Throwable) {
                null
            } finally {
                skin.recycle()
            }
        }
    }
}
