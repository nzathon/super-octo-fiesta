package com.azalea.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val DEFAULT_CHAT_MACROS = listOf("/home", "/spawn", "/bal", "/is", "/tpa ", "/msg ")

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
internal fun ChatTab(online: Boolean, serverKey: String, text: String, onTextChange: (String) -> Unit) {
    val lines by Core.chat.collectAsState()
    val comp by Core.completions.collectAsState()
    val allStorage by ModStorage.data.collectAsState()
    val modVer by Modules.version.collectAsState()
    val mods by Modules.list.collectAsState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var stickToBottom by remember { mutableStateOf(true) }
    val isAtBottom by remember { derivedStateOf { !listState.canScrollForward } }
    var tfv by remember { mutableStateOf(TextFieldValue(text, TextRange(text.length))) }
    var showFilterDialog by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val activeServerKey = Core.current()?.first?.let { "${it.host}:${it.port}" } ?: serverKey
    val blacklistMasterOn = remember(modVer, mods) { Modules.bool("chat", "blacklist", true) }
    val chatStorage = allStorage["chat"]
    val quickSendAll = remember(chatStorage) { chatStorage?.optBoolean("quick_send", false) == true }
    val blacklistRules = remember(chatStorage, activeServerKey) {
        parseChatBlacklistUiRules(chatStorage, activeServerKey)
    }
    val activeRuleCount = remember(blacklistRules) { blacklistRules.count { it.enabled } }
    val compiledBlacklist: List<(String) -> Boolean> = remember(blacklistMasterOn, blacklistRules) {
        if (!blacklistMasterOn) emptyList() else compileBlacklistMatchers(blacklistRules)
    }
    val visibleAfterBlacklist = remember(lines, compiledBlacklist) {
        if (compiledBlacklist.isEmpty()) lines
        else lines.filterNot { line ->
            val plain = Ansi.strip(line.text)
            compiledBlacklist.any { it(plain) }
        }
    }
    val hiddenCount = lines.size - visibleAfterBlacklist.size
    val visibleLines = remember(visibleAfterBlacklist, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) visibleAfterBlacklist
        else visibleAfterBlacklist.filter { Ansi.strip(it.text).contains(q, ignoreCase = true) }
    }

    LaunchedEffect(text) {
        if (text != tfv.text) {
            tfv = TextFieldValue(text, TextRange(text.length))
        }
    }
    LaunchedEffect(online, text) {
        if (!online || !text.startsWith("/")) {
            Core.clearCompletions()
        } else {
            kotlinx.coroutines.delay(90)
            Core.requestComplete(text)
        }
    }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
            .collect { (scrolling, canFwd) ->
                if (scrolling || !canFwd) stickToBottom = !canFwd
            }
    }
    LaunchedEffect(visibleLines.size, visibleLines.lastOrNull()?.id) {
        if (visibleLines.isNotEmpty() && stickToBottom) listState.scrollToItem(visibleLines.size - 1)
    }

    fun applySuggestion(s: TabSuggestion) {
        val st = comp.start.coerceIn(0, text.length)
        val en = comp.end.coerceIn(st, text.length)
        val next = text.substring(0, st) + s.text + text.substring(en)
        onTextChange(next)
    }

    Column(Modifier.fillMaxSize()) {
        // Toolbar mini rapi di atas chat (tidak menimpa pesan)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = AzaleaPalette.Surface,
        ) {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = buildString {
                        append("${visibleLines.size} pesan")
                        if (hiddenCount > 0) append(" · $hiddenCount disembunyikan")
                    },
                    modifier = Modifier.weight(1f),
                    fontSize = 11.sp,
                    color = if (hiddenCount > 0 && blacklistMasterOn) AzaleaPalette.Sky else AzaleaPalette.TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                IconButton(
                    onClick = { searchOpen = !searchOpen; if (!searchOpen) searchQuery = "" },
                    modifier = Modifier.size(34.dp),
                ) {
                    Icon(
                        AzaleaIcons.Search,
                        contentDescription = "Cari chat",
                        modifier = Modifier.size(17.dp),
                        tint = if (searchOpen) AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                    )
                }
                IconButton(
                    onClick = { Core.clearChat() },
                    modifier = Modifier.size(34.dp),
                ) {
                    Icon(
                        AzaleaIcons.Clear,
                        contentDescription = "Bersihkan chat",
                        modifier = Modifier.size(17.dp),
                        tint = AzaleaPalette.TextMuted,
                    )
                }
                IconButton(
                    onClick = { showFilterDialog = true },
                    modifier = Modifier.size(34.dp),
                ) {
                    Icon(
                        AzaleaIcons.Settings,
                        contentDescription = "Pengaturan & Blacklist Chat",
                        modifier = Modifier.size(18.dp),
                        tint = if (blacklistMasterOn && activeRuleCount > 0) AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                    )
                }
            }
        }
        HorizontalDivider(color = AzaleaPalette.Border)
        if (searchOpen) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Cari isi chat...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }

        var selectedChatId by remember { mutableStateOf<Long?>(null) }
        var copiedChatId by remember { mutableStateOf<Long?>(null) }
        val ctx = LocalContext.current

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 8.dp),
                contentPadding = PaddingValues(vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                state = listState,
            ) {
                if (lines.isEmpty()) item(key = "__empty__") {
                    Text(
                        "Belum ada chat. Pastikan modul Chat aktif.",
                        Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
                        color = AzaleaPalette.TextMuted,
                    )
                } else if (visibleLines.isEmpty()) item(key = "__all_filtered__") {
                    Text(
                        if (searchQuery.isNotBlank()) "Tidak ada chat yang cocok dengan \"$searchQuery\"."
                        else "Semua $hiddenCount pesan chat disembunyikan oleh filter blacklist.",
                        Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
                        color = AzaleaPalette.TextMuted,
                    )
                }
                items(visibleLines.size, key = { visibleLines[it].id }) { idx ->
                    val chatLine = visibleLines[idx]
                    val interactionSource = remember { MutableInteractionSource() }
                    val isPressed by interactionSource.collectIsPressedAsState()
                    val toggled = selectedChatId == chatLine.id
                    val highlighted = isPressed || toggled
                    val shape = RoundedCornerShape(8.dp)
                    val cardBg = if (highlighted) AzaleaPalette.CardSelected else Color.Transparent
                    val borderCol = if (highlighted) AzaleaPalette.BorderSelected else Color.Transparent
                    val quickCmds = remember(chatLine.id, toggled) {
                        if (toggled) extractChatCommands(chatLine) else emptyList()
                    }
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .combinedClickable(
                                interactionSource = interactionSource,
                                indication = null,
                                onClick = {
                                    selectedChatId = if (toggled) null else chatLine.id
                                    copiedChatId = null
                                },
                                onLongClick = {},
                            ),
                        shape = shape,
                        color = cardBg,
                        border = BorderStroke(1.dp, borderCol),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
                            Text(
                                Ansi.annotated(chatLine.text, invert = false),
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                color = AzaleaPalette.TextPrimary,
                            )
                            if (toggled) {
                                Spacer(Modifier.height(6.dp))
                                FlowRow(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    for (q in quickCmds) {
                                        val autoSend = q.run || quickSendAll
                                        val chipShape = RoundedCornerShape(10.dp)
                                        val chipBg = if (autoSend) AzaleaPalette.EmeraldDark else AzaleaPalette.CardAlt
                                        val chipFg = if (autoSend) AzaleaPalette.Emerald else AzaleaPalette.TextPrimary
                                        val chipBorder = if (autoSend) AzaleaPalette.Emerald else AzaleaPalette.Border
                                        Surface(
                                            modifier = Modifier
                                                .height(28.dp)
                                                .clip(chipShape)
                                                .combinedClickable(
                                                    onClick = {
                                                        selectedChatId = null
                                                        if (autoSend && online) Core.send(q.cmd)
                                                        else onTextChange(q.cmd)
                                                    },
                                                    onLongClick = {
                                                        selectedChatId = null
                                                        if (autoSend) onTextChange(q.cmd)
                                                        else if (online) Core.send(q.cmd)
                                                        else onTextChange(q.cmd)
                                                    },
                                                ),
                                            shape = chipShape,
                                            color = chipBg,
                                            border = BorderStroke(1.dp, chipBorder),
                                        ) {
                                            Box(
                                                Modifier.padding(horizontal = 10.dp),
                                                contentAlignment = Alignment.Center,
                                            ) {
                                                Text(
                                                    text = if (autoSend) "▶ ${q.cmd}" else q.cmd,
                                                    fontSize = 11.sp,
                                                    color = chipFg,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            copyText(ctx, "chat", Ansi.strip(chatLine.text))
                                            copiedChatId = chatLine.id
                                        },
                                        modifier = Modifier.height(28.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                        border = BorderStroke(1.dp, AzaleaPalette.Border),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AzaleaPalette.TextPrimary),
                                    ) {
                                        Text(if (copiedChatId == chatLine.id) "Tersalin" else "Salin", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            ScrollToBottomButton(
                visible = visibleLines.isNotEmpty() && !isAtBottom,
                onClick = {
                    stickToBottom = true
                    scope.launch { listState.animateScrollToItem(visibleLines.size - 1) }
                },
                modifier = Modifier.align(Alignment.BottomEnd),
            )
        }

        if (showFilterDialog) {
            ChatBlacklistDialog(
                serverKey = activeServerKey,
                masterEnabled = blacklistMasterOn,
                quickSendAll = quickSendAll,
                hiddenCount = hiddenCount,
                totalCount = lines.size,
                rules = blacklistRules,
                storageObj = chatStorage,
                onToggleMaster = { Modules.set("chat", "blacklist", it) },
                onToggleQuickSend = { setChatQuickSend(chatStorage, activeServerKey, it) },
                onDismiss = { showFilterDialog = false },
            )
        }

        // Command suggestion vertikal (atas ke bawah seperti chat Minecraft asli)
        if (online && comp.items.isNotEmpty() && text.isNotEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                shape = RoundedCornerShape(10.dp),
                color = AzaleaPalette.Card,
                border = BorderStroke(1.dp, AzaleaPalette.Border),
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 176.dp),
                    contentPadding = PaddingValues(vertical = 4.dp),
                ) {
                    items(comp.items.size) { idx ->
                        val item = comp.items[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { applySuggestion(item) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                item.text,
                                fontSize = 13.sp,
                                color = AzaleaPalette.TextPrimary,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f, fill = false),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (!item.tip.isNullOrBlank()) {
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    item.tip,
                                    fontSize = 11.sp,
                                    color = AzaleaPalette.TextMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                        if (idx + 1 < comp.items.size) {
                            HorizontalDivider(color = AzaleaPalette.Border)
                        }
                    }
                }
            }
        }

        // Quick macro bar (ketuk: isi ke kolom, tahan: langsung kirim jika lengkap)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            for (macro in DEFAULT_CHAT_MACROS) {
                val shape = RoundedCornerShape(8.dp)
                Surface(
                    modifier = Modifier
                        .clip(shape)
                        .combinedClickable(
                            onClick = { onTextChange(macro) },
                            onLongClick = {
                                if (online && !macro.endsWith(" ")) Core.send(macro)
                                else onTextChange(macro)
                            },
                        ),
                    shape = shape,
                    color = AzaleaPalette.CardAlt,
                    border = BorderStroke(1.dp, AzaleaPalette.Border),
                ) {
                    Text(
                        macro.trim(),
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        fontSize = 11.sp,
                        color = AzaleaPalette.TextMuted,
                    )
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = tfv,
                onValueChange = {
                    tfv = it
                    if (it.text != text) onTextChange(it.text)
                },
                singleLine = true,
                placeholder = { Text("Chat atau /perintah") },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(6.dp))
            OutlinedButton(
                enabled = online && text.isNotEmpty(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                onClick = {
                    if (comp.items.isNotEmpty()) applySuggestion(comp.items.first())
                    else Core.requestComplete(text, force = true)
                },
            ) {
                Icon(AzaleaIcons.TabComplete, contentDescription = "Lengkapi", modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(6.dp))
            Button(
                enabled = online && text.isNotBlank(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                onClick = { Core.send(text); onTextChange("") },
            ) {
                Icon(AzaleaIcons.Send, contentDescription = "Kirim", modifier = Modifier.size(18.dp))
            }
        }
    }
}

private val CHAT_URL_REGEX = Regex("https?://\\S+", RegexOption.IGNORE_CASE)
private val CHAT_QUOTED_CMD_REGEX = Regex("""[`"'\[\(]\s*(/[A-Za-z][A-Za-z0-9_:-]{0,31}(?:\s+[^\s`"'\)\]]{1,24}){0,2})\s*[`"'\)\]]""")
private val CHAT_INLINE_CMD_REGEX = Regex("""(?:^|[\s\[(<"'«:,|>\-])(/[A-Za-z][A-Za-z0-9_:-]{0,31})""")
private val CHAT_PROSE_STOPWORDS = setOf(
    "untuk", "atau", "dan", "agar", "biar", "karena", "lalu", "kemudian", "jika", "kalau",
    "saat", "ke", "di", "dari", "yang", "sekarang", "klik", "ketik", "tekan", "gunakan",
    "for", "to", "and", "or", "the", "if", "when", "then", "please", "click", "type", "use",
)

private fun trimQuotedCommandProse(rawCmd: String): String {
    val parts = rawCmd.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (parts.isEmpty()) return ""
    val out = ArrayList<String>(parts.size)
    out.add(parts[0])
    for (i in 1 until parts.size) {
        val tok = parts[i].trimEnd('.', ',', '!', '?', ';', ':')
        if (tok.isEmpty() || tok.lowercase() in CHAT_PROSE_STOPWORDS) break
        out.add(tok)
    }
    return out.joinToString(" ")
}

private fun extractChatCommands(line: ChatLine): List<ChatQuickCmd> {
    val out = ArrayList<ChatQuickCmd>()
    fun addCmd(raw: String, run: Boolean) {
        val cleaned = raw.trim().trimEnd('.', ',', '!', '?', ';')
        if (cleaned.isEmpty()) return
        val existingIdx = out.indexOfFirst { it.cmd.equals(cleaned, ignoreCase = true) }
        if (existingIdx >= 0) {
            if (run && !out[existingIdx].run) {
                out[existingIdx] = out[existingIdx].copy(run = true)
            }
            return
        }
        out.add(ChatQuickCmd(cleaned, run))
    }
    for (c in line.cmds) {
        addCmd(c.cmd, c.run)
    }
    val plain = Ansi.strip(line.text)
    val noUrls = plain.replace(CHAT_URL_REGEX, " ")
    for (m in CHAT_QUOTED_CMD_REGEX.findAll(noUrls)) {
        val phrase = trimQuotedCommandProse(m.groupValues[1])
        if (phrase.startsWith("/") && phrase.length > 1) {
            addCmd(phrase, false)
        }
    }
    for (m in CHAT_INLINE_CMD_REGEX.findAll(noUrls)) {
        val single = m.groupValues[1].trimEnd('.', ',', '!', '?', ';', ':')
        val alreadyCoveredByMulti = out.any {
            it.cmd.startsWith("$single ", ignoreCase = true) || it.cmd.equals(single, ignoreCase = true)
        }
        if (single.length > 1 && !alreadyCoveredByMulti) {
            addCmd(single, false)
        }
    }
    return out.take(6)
}

private data class ChatPatternEntry(
    val kind: String,
    val pattern: String,
    val caseSensitive: Boolean = false,
)

private data class ChatBlacklistRuleUi(
    val scope: String,
    val index: Int,
    val name: String,
    val entries: List<ChatPatternEntry>,
    val enabled: Boolean,
    val caseSensitive: Boolean,
)

private val RULE_KIND_MODES = listOf("regex", "match", "exact", "starts")
private val RULE_KIND_KEYWORDS = setOf("regex", "match", "contains", "exact", "starts", "prefix")

private fun normalizeRuleKind(raw: String): String = when (val k = raw.trim().lowercase()) {
    "regex", "match", "exact", "starts" -> k
    "prefix" -> "starts"
    "contains", "" -> "match"
    else -> k
}

private fun collectPatternEntries(
    raw: Any?,
    fallbackKind: String,
    defaultCs: Boolean,
    out: MutableList<ChatPatternEntry>,
) {
    when (raw) {
        is String -> if (raw.isNotEmpty()) out.add(ChatPatternEntry(fallbackKind, raw, defaultCs))
        is JSONArray -> {
            if (raw.length() >= 2 && raw.opt(0) is String && (raw.opt(1) is String || raw.opt(1) is JSONArray)) {
                val k = normalizeRuleKind(raw.optString(0, fallbackKind))
                val cs = raw.optBoolean(2, defaultCs)
                val second = raw.opt(1)
                if (second is String && second.isNotEmpty()) {
                    out.add(ChatPatternEntry(k, second, cs))
                } else if (second is JSONArray) {
                    for (j in 0 until second.length()) {
                        val s = second.optString(j)
                        if (s.isNotEmpty()) out.add(ChatPatternEntry(k, s, cs))
                    }
                }
            } else {
                for (i in 0 until raw.length()) {
                    val item = raw.opt(i)
                    if (item is String && item.isNotEmpty()) {
                        out.add(ChatPatternEntry(fallbackKind, item, defaultCs))
                    }
                }
            }
        }
        is JSONObject -> {
            val k = normalizeRuleKind(
                raw.optString("type").ifBlank { raw.optString("mode").ifBlank { raw.optString("kind") } }
                    .ifBlank { fallbackKind },
            )
            val cs = raw.optBoolean("case_sensitive", defaultCs)
            val pVal = raw.opt("pattern")
                ?: raw.opt("patterns")
                ?: raw.opt("text")
                ?: raw.opt("isi")
                ?: raw.opt("value")
            if (pVal is String && pVal.isNotEmpty()) {
                out.add(ChatPatternEntry(k, pVal, cs))
            } else if (pVal is JSONArray) {
                for (i in 0 until pVal.length()) {
                    val s = pVal.optString(i)
                    if (s.isNotEmpty()) out.add(ChatPatternEntry(k, s, cs))
                }
            }
        }
    }
}

private fun parseChatBlacklistRuleItem(scope: String, index: Int, raw: Any?): ChatBlacklistRuleUi? = when (raw) {
    is JSONObject -> {
        val enabled = if (raw.has("enable")) raw.optBoolean("enable", true) else raw.optBoolean("enabled", true)
        val explicitKind = raw.optString("type").ifBlank { raw.optString("mode").ifBlank { raw.optString("kind") } }
            .trim().lowercase()
        val fallbackKind = normalizeRuleKind(explicitKind)
        val defaultCs = raw.optBoolean("case_sensitive", false)
        val entries = ArrayList<ChatPatternEntry>()
        val patArr = raw.optJSONArray("patterns") ?: raw.optJSONArray("pattern")
        if (patArr != null) {
            var allStrings = true
            for (i in 0 until patArr.length()) {
                if (patArr.opt(i) !is String) {
                    allStrings = false
                    break
                }
            }
            val flatShorthand = explicitKind.isBlank() &&
                patArr.length() >= 2 &&
                allStrings &&
                patArr.optString(0).trim().lowercase() in RULE_KIND_KEYWORDS
            if (flatShorthand) {
                val k = normalizeRuleKind(patArr.optString(0))
                for (i in 1 until patArr.length()) {
                    val s = patArr.optString(i)
                    if (s.isNotEmpty()) entries.add(ChatPatternEntry(k, s, defaultCs))
                }
            } else {
                for (i in 0 until patArr.length()) {
                    collectPatternEntries(patArr.opt(i), fallbackKind, defaultCs, entries)
                }
            }
        } else {
            val single = raw.optString("pattern")
                .ifBlank { raw.optString("text") }
                .ifBlank { raw.optString("isi") }
                .ifBlank { raw.optString("value") }
            if (single.isNotEmpty()) entries.add(ChatPatternEntry(fallbackKind, single, defaultCs))
        }
        val label = raw.optString("name").ifBlank { raw.optString("nama") }.trim()
            .ifBlank { entries.firstOrNull()?.pattern?.take(24) ?: "Aturan #${index + 1}" }
        ChatBlacklistRuleUi(scope, index, label, entries, enabled, defaultCs)
    }
    is JSONArray -> {
        val entries = ArrayList<ChatPatternEntry>()
        collectPatternEntries(raw, "match", false, entries)
        if (entries.isEmpty()) null
        else {
            val label = entries.firstOrNull()?.pattern?.take(24) ?: "Aturan #${index + 1}"
            ChatBlacklistRuleUi(scope, index, label, entries, true, entries.first().caseSensitive)
        }
    }
    is String -> if (raw.isNotEmpty()) {
        ChatBlacklistRuleUi(scope, index, raw.take(24), listOf(ChatPatternEntry("match", raw, false)), true, false)
    } else null
    else -> null
}

private fun parseChatBlacklistSection(section: JSONObject?, scope: String): List<ChatBlacklistRuleUi> {
    if (section == null) return emptyList()
    val arr = section.optJSONArray("blacklist")
        ?: section.optJSONArray("filter")
        ?: section.optJSONArray("rules")
        ?: return emptyList()
    val out = ArrayList<ChatBlacklistRuleUi>()
    for (i in 0 until arr.length()) {
        parseChatBlacklistRuleItem(scope, i, arr.opt(i))?.let { out.add(it) }
    }
    return out
}

private fun parseChatBlacklistUiRules(storageObj: JSONObject?, serverKey: String): List<ChatBlacklistRuleUi> {
    val out = ArrayList<ChatBlacklistRuleUi>()
    val globalObj = storageObj?.optJSONObject("global")
    out.addAll(parseChatBlacklistSection(globalObj, "global"))
    if (serverKey.isNotBlank()) {
        val srvObj = storageObj?.optJSONObject("servers")?.optJSONObject(serverKey)
        out.addAll(parseChatBlacklistSection(srvObj, "server"))
    }
    return out
}

private fun compileBlacklistEntry(entry: ChatPatternEntry): ((String) -> Boolean)? {
    val pat = entry.pattern
    if (pat.isEmpty()) return null
    val cs = entry.caseSensitive
    return when (normalizeRuleKind(entry.kind)) {
        "regex" -> {
            val re = try {
                if (cs) Regex(pat) else Regex(pat, RegexOption.IGNORE_CASE)
            } catch (_: Throwable) {
                null
            }
            if (re == null) null else { plain -> re.containsMatchIn(plain) }
        }
        "exact" -> {
            val target = pat.trim()
            { plain -> plain.trim().equals(target, ignoreCase = !cs) }
        }
        "starts" -> {
            { plain -> plain.trimStart().startsWith(pat, ignoreCase = !cs) }
        }
        else -> {
            { plain -> plain.contains(pat, ignoreCase = !cs) }
        }
    }
}

private fun compileBlacklistMatchers(rules: List<ChatBlacklistRuleUi>): List<(String) -> Boolean> {
    val out = ArrayList<(String) -> Boolean>()
    for (r in rules) {
        if (!r.enabled) continue
        for (e in r.entries) {
            compileBlacklistEntry(e)?.let { out.add(it) }
        }
    }
    return out
}

private fun ensureChatStorageRoot(existing: JSONObject?, serverKey: String): JSONObject {
    val root = try {
        JSONObject(existing?.toString() ?: "{}")
    } catch (_: Throwable) {
        JSONObject()
    }
    val global = root.optJSONObject("global") ?: JSONObject().also { root.put("global", it) }
    if (global.optJSONArray("blacklist") == null) {
        global.put(
            "blacklist",
            JSONArray().put(
                JSONObject()
                    .put("name", "broadcast")
                    .put("patterns", JSONArray().put(JSONArray().put("regex").put("contoh regex broadcast")))
                    .put("enable", false)
                    .put("case_sensitive", false),
            ),
        )
    }
    if (global.optJSONArray("private_chat") == null) {
        global.put(
            "private_chat",
            JSONArray().put(
                JSONArray()
                    .put("regex")
                    .put("(?i)(?:^|\\s*)([a-zA-Z0-9_]{3,16})\\s*->\\s*me\\s*[:\\s]\\s*(.*)"),
            ),
        )
    }
    if (global.optString("reply_command", "").isBlank()) {
        global.put("reply_command", BotService.DEFAULT_REPLY_COMMAND)
    }
    val servers = root.optJSONObject("servers") ?: JSONObject().also { root.put("servers", it) }
    if (serverKey.isNotBlank()) {
        val srv = servers.optJSONObject(serverKey) ?: JSONObject().also { servers.put(serverKey, it) }
        if (srv.optJSONArray("blacklist") == null) srv.put("blacklist", JSONArray())
        if (srv.optJSONArray("private_chat") == null) srv.put("private_chat", JSONArray())
    }
    return root
}

private fun blacklistArrayForScope(root: JSONObject, serverKey: String, scope: String): JSONArray {
    val section = if (scope == "server" && serverKey.isNotBlank()) {
        val servers = root.optJSONObject("servers") ?: JSONObject().also { root.put("servers", it) }
        servers.optJSONObject(serverKey) ?: JSONObject().also { servers.put(serverKey, it) }
    } else {
        root.optJSONObject("global") ?: JSONObject().also { root.put("global", it) }
    }
    val existingArr = section.optJSONArray("blacklist")
        ?: section.optJSONArray("filter")
        ?: section.optJSONArray("rules")
    if (existingArr != null) {
        if (!section.has("blacklist")) section.put("blacklist", existingArr)
        return existingArr
    }
    return JSONArray().also { section.put("blacklist", it) }
}

private fun buildRuleJsonObject(
    name: String,
    entries: List<ChatPatternEntry>,
    enable: Boolean,
    caseSensitive: Boolean,
): JSONObject {
    val pats = JSONArray()
    for (e in entries) {
        val item = JSONArray().put(normalizeRuleKind(e.kind)).put(e.pattern)
        if (e.caseSensitive && e.caseSensitive != caseSensitive) {
            item.put(true)
        }
        pats.put(item)
    }
    return JSONObject()
        .put("name", name.trim())
        .put("patterns", pats)
        .put("enable", enable)
        .put("case_sensitive", caseSensitive)
}

private fun setChatQuickSend(existing: JSONObject?, serverKey: String, quickSend: Boolean) {
    val root = ensureChatStorageRoot(existing, serverKey)
    root.put("quick_send", quickSend)
    ModStorage.replace("chat", root, fromUser = true)
}

private fun setChatReplyCommand(existing: JSONObject?, serverKey: String, replyCommand: String) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val glb = root.getJSONObject("global")
    glb.put("reply_command", replyCommand.trim().ifEmpty { BotService.DEFAULT_REPLY_COMMAND })
    ModStorage.replace("chat", root, fromUser = true)
}

private fun setChatBlacklistRuleEnabled(
    existing: JSONObject?,
    serverKey: String,
    rule: ChatBlacklistRuleUi,
    enable: Boolean,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val arr = blacklistArrayForScope(root, serverKey, rule.scope)
    if (rule.index !in 0 until arr.length()) return
    val raw = arr.opt(rule.index)
    if (raw is JSONObject) {
        raw.put("enable", enable)
        raw.remove("enabled")
    } else {
        arr.put(rule.index, buildRuleJsonObject(rule.name, rule.entries, enable, rule.caseSensitive))
    }
    ModStorage.replace("chat", root, fromUser = true)
}

private fun saveChatBlacklistRule(
    existing: JSONObject?,
    serverKey: String,
    editing: ChatBlacklistRuleUi?,
    scope: String,
    name: String,
    entries: List<ChatPatternEntry>,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val targetScope = editing?.scope ?: scope
    val arr = blacklistArrayForScope(root, serverKey, targetScope)
    val obj = buildRuleJsonObject(
        name = name,
        entries = entries,
        enable = editing?.enabled ?: true,
        caseSensitive = editing?.caseSensitive ?: false,
    )
    if (editing != null && editing.index in 0 until arr.length()) {
        arr.put(editing.index, obj)
    } else {
        arr.put(obj)
    }
    ModStorage.replace("chat", root, fromUser = true)
}

private fun deleteChatBlacklistRule(
    existing: JSONObject?,
    serverKey: String,
    rule: ChatBlacklistRuleUi,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val arr = blacklistArrayForScope(root, serverKey, rule.scope)
    if (rule.index !in 0 until arr.length()) return
    val next = JSONArray()
    for (i in 0 until arr.length()) {
        if (i != rule.index) next.put(arr.opt(i))
    }
    val section = if (rule.scope == "server" && serverKey.isNotBlank()) {
        root.getJSONObject("servers").getJSONObject(serverKey)
    } else {
        root.getJSONObject("global")
    }
    section.put("blacklist", next)
    ModStorage.replace("chat", root, fromUser = true)
}

@Composable
private fun ChatBlacklistDialog(
    serverKey: String,
    masterEnabled: Boolean,
    quickSendAll: Boolean,
    hiddenCount: Int,
    totalCount: Int,
    rules: List<ChatBlacklistRuleUi>,
    storageObj: JSONObject?,
    onToggleMaster: (Boolean) -> Unit,
    onToggleQuickSend: (Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    var editingRule by remember { mutableStateOf<ChatBlacklistRuleUi?>(null) }
    var showForm by remember { mutableStateOf(false) }
    val savedReplyCmd = remember(storageObj) {
        storageObj?.optJSONObject("global")?.optString("reply_command", "")?.trim()
            ?.ifEmpty { BotService.DEFAULT_REPLY_COMMAND }
            ?: BotService.DEFAULT_REPLY_COMMAND
    }
    var replyCmdDraft by remember(savedReplyCmd) { mutableStateOf(savedReplyCmd) }
    var formName by remember { mutableStateOf("") }
    var formScope by remember { mutableStateOf("global") }
    var formPatterns by remember { mutableStateOf(listOf("regex" to "")) }
    val globalRules = remember(rules) { rules.filter { it.scope == "global" } }
    val serverRules = remember(rules) { rules.filter { it.scope == "server" } }

    fun openAddForm() {
        editingRule = null
        formName = ""
        formScope = "global"
        formPatterns = listOf("regex" to "")
        showForm = true
    }

    fun openEditForm(rule: ChatBlacklistRuleUi) {
        editingRule = rule
        formName = rule.name
        formScope = rule.scope
        formPatterns = rule.entries.map { it.kind to it.pattern }.ifEmpty { listOf("regex" to "") }
        showForm = true
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pengaturan & Filter Chat") },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Aktifkan Blacklist", style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (masterEnabled) "Live filter aktif ($hiddenCount dari $totalCount pesan disembunyikan)"
                            else "Filter nonaktif (semua $totalCount pesan ditampilkan)",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (masterEnabled && hiddenCount > 0) AzaleaPalette.Sky else AzaleaPalette.TextMuted,
                        )
                    }
                    Switch(checked = masterEnabled, onCheckedChange = onToggleMaster)
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Kirim langsung quick command", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Ketuk command di chat langsung kirim (tahan = isi kolom)",
                            style = MaterialTheme.typography.bodySmall,
                            color = AzaleaPalette.TextMuted,
                        )
                    }
                    Switch(checked = quickSendAll, onCheckedChange = onToggleQuickSend)
                }
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Command Balas Notif (Global)", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = replyCmdDraft,
                        onValueChange = {
                            replyCmdDraft = it
                            if (it.trim().isNotEmpty()) {
                                setChatReplyCommand(storageObj, serverKey, it)
                            }
                        },
                        singleLine = true,
                        placeholder = { Text(BotService.DEFAULT_REPLY_COMMAND) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (preset in listOf("/msg {nama} {pesan}", "/r {pesan}")) {
                            val active = replyCmdDraft.trim() == preset
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable {
                                        replyCmdDraft = preset
                                        setChatReplyCommand(storageObj, serverKey, preset)
                                    },
                                shape = RoundedCornerShape(6.dp),
                                color = if (active) AzaleaPalette.EmeraldDark else AzaleaPalette.CardAlt,
                                border = BorderStroke(1.dp, if (active) AzaleaPalette.Emerald else AzaleaPalette.Border),
                            ) {
                                Box(Modifier.padding(vertical = 5.dp, horizontal = 6.dp), contentAlignment = Alignment.Center) {
                                    Text(preset, fontSize = 10.sp, color = AzaleaPalette.TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                    Text(
                        "Bisa dioverride per-server di Storage -> servers -> reply_command",
                        style = MaterialTheme.typography.bodySmall,
                        color = AzaleaPalette.TextMuted,
                    )
                }
                HorizontalDivider(color = AzaleaPalette.Border)
                if (rules.isEmpty()) {
                    Text(
                        "Belum ada aturan blacklist. Tekan + Tambah Aturan atau atur di Modul -> Chat -> Storage.",
                        style = MaterialTheme.typography.bodySmall,
                        color = AzaleaPalette.TextMuted,
                    )
                } else {
                    if (globalRules.isNotEmpty()) {
                        Text("Blacklist Global", style = MaterialTheme.typography.labelMedium, color = AzaleaPalette.Sky)
                        for (r in globalRules) {
                            ChatBlacklistRuleRow(
                                rule = r,
                                onEdit = { openEditForm(r) },
                                onToggle = { en -> setChatBlacklistRuleEnabled(storageObj, serverKey, r, en) },
                                onDelete = {
                                    if (editingRule == r) showForm = false
                                    deleteChatBlacklistRule(storageObj, serverKey, r)
                                },
                            )
                        }
                    }
                    if (serverRules.isNotEmpty()) {
                        Text("Blacklist Server ($serverKey)", style = MaterialTheme.typography.labelMedium, color = AzaleaPalette.Emerald)
                        for (r in serverRules) {
                            ChatBlacklistRuleRow(
                                rule = r,
                                onEdit = { openEditForm(r) },
                                onToggle = { en -> setChatBlacklistRuleEnabled(storageObj, serverKey, r, en) },
                                onDelete = {
                                    if (editingRule == r) showForm = false
                                    deleteChatBlacklistRule(storageObj, serverKey, r)
                                },
                            )
                        }
                    }
                }
                if (showForm) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = AzaleaPalette.CardAlt,
                        border = BorderStroke(1.dp, AzaleaPalette.Border),
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                if (editingRule == null) "Aturan Baru" else "Ubah Aturan",
                                style = MaterialTheme.typography.labelLarge,
                                color = AzaleaPalette.Emerald,
                            )
                            OutlinedTextField(
                                value = formName,
                                onValueChange = { formName = it },
                                label = { Text("Nama aturan (mis. broadcast)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            if (editingRule == null && serverKey.isNotBlank()) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    for ((sc, lbl) in listOf("global" to "Global", "server" to "Server ini")) {
                                        val selected = formScope == sc
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(6.dp))
                                                .clickable { formScope = sc },
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (selected) AzaleaPalette.EmeraldDark else AzaleaPalette.Card,
                                            border = BorderStroke(1.dp, if (selected) AzaleaPalette.Emerald else AzaleaPalette.Border),
                                        ) {
                                            Box(Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                                Text(lbl, fontSize = 11.sp, color = AzaleaPalette.TextPrimary)
                                            }
                                        }
                                    }
                                }
                            }
                            Text(
                                "Pattern (tiap pattern bisa beda tipe):",
                                style = MaterialTheme.typography.bodySmall,
                                color = AzaleaPalette.TextMuted,
                            )
                            formPatterns.forEachIndexed { idx, (rowKind, rowPat) ->
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(6.dp),
                                    color = AzaleaPalette.Card,
                                    border = BorderStroke(1.dp, AzaleaPalette.Border),
                                ) {
                                    Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        ) {
                                            for (k in RULE_KIND_MODES) {
                                                val selected = rowKind == k
                                                Surface(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clip(RoundedCornerShape(5.dp))
                                                        .clickable {
                                                            formPatterns = formPatterns.toMutableList().also {
                                                                it[idx] = k to rowPat
                                                            }
                                                        },
                                                    shape = RoundedCornerShape(5.dp),
                                                    color = if (selected) AzaleaPalette.EmeraldDark else AzaleaPalette.CardAlt,
                                                    border = BorderStroke(1.dp, if (selected) AzaleaPalette.Emerald else AzaleaPalette.Border),
                                                ) {
                                                    Box(Modifier.padding(vertical = 5.dp), contentAlignment = Alignment.Center) {
                                                        Text(k, fontSize = 11.sp, color = AzaleaPalette.TextPrimary)
                                                    }
                                                }
                                            }
                                            if (formPatterns.size > 1) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(26.dp)
                                                        .clip(CircleShape)
                                                        .clickable {
                                                            formPatterns = formPatterns.toMutableList().also {
                                                                it.removeAt(idx)
                                                            }
                                                        },
                                                    contentAlignment = Alignment.Center,
                                                ) {
                                                    Icon(AzaleaIcons.Close, contentDescription = "Hapus pattern", modifier = Modifier.size(14.dp), tint = AzaleaPalette.Danger)
                                                }
                                            }
                                        }
                                        OutlinedTextField(
                                            value = rowPat,
                                            onValueChange = { v ->
                                                formPatterns = formPatterns.toMutableList().also {
                                                    it[idx] = rowKind to v
                                                }
                                            },
                                            label = { Text("Pattern #${idx + 1}") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth(),
                                        )
                                    }
                                }
                            }
                            TextButton(
                                onClick = { formPatterns = formPatterns + ("match" to "") },
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text("+ Tambah Pattern Lain")
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { showForm = false; editingRule = null }) { Text("Batal") }
                                val cleanEntries = formPatterns
                                    .mapNotNull { (k, p) ->
                                        val trimmed = p.trim()
                                        if (trimmed.isEmpty()) null else ChatPatternEntry(k, trimmed, false)
                                    }
                                Button(
                                    enabled = formName.isNotBlank() && cleanEntries.isNotEmpty(),
                                    onClick = {
                                        saveChatBlacklistRule(
                                            existing = storageObj,
                                            serverKey = serverKey,
                                            editing = editingRule,
                                            scope = formScope,
                                            name = formName,
                                            entries = cleanEntries,
                                        )
                                        showForm = false
                                        editingRule = null
                                    },
                                ) {
                                    Text("Simpan")
                                }
                            }
                        }
                    }
                } else {
                    OutlinedButton(
                        onClick = { openAddForm() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("+ Tambah Aturan Blacklist")
                    }
                }
                Text(
                    "Ketuk aturan untuk edit pattern/tipe. Edit JSON lengkap tersedia di Modul -> Chat -> Storage.",
                    style = MaterialTheme.typography.bodySmall,
                    color = AzaleaPalette.TextMuted,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
    )
}

@Composable
private fun ChatBlacklistRuleRow(
    rule: ChatBlacklistRuleUi,
    onEdit: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onEdit),
        shape = RoundedCornerShape(8.dp),
        color = AzaleaPalette.Card,
        border = BorderStroke(1.dp, AzaleaPalette.Border),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    rule.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val kinds = rule.entries.map { it.kind }.distinct().joinToString(", ").ifBlank { "match" }
                val preview = rule.entries.firstOrNull()?.pattern ?: "(kosong)"
                val countInfo = if (rule.entries.size > 1) " (${rule.entries.size} pola)" else ""
                Text(
                    "$kinds$countInfo · $preview",
                    style = MaterialTheme.typography.bodySmall,
                    color = AzaleaPalette.TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Box(
                modifier = Modifier
                    .padding(end = 6.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onDelete),
                contentAlignment = Alignment.Center,
            ) {
                Icon(AzaleaIcons.Close, contentDescription = "Hapus", modifier = Modifier.size(14.dp), tint = AzaleaPalette.Danger)
            }
            Switch(checked = rule.enabled, onCheckedChange = onToggle)
        }
    }
}
