package com.azalea.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
internal fun ChatTab(online: Boolean, serverKey: String, text: String, onTextChange: (String) -> Unit) {
    val lines by Core.chat.collectAsState()
    val comp by Core.completions.collectAsState()
    val players by Core.players.collectAsState()
    val hashVer by TexCache.hashVersion.collectAsState()
    val allStorage by ModStorage.data.collectAsState()
    val modVer by Modules.version.collectAsState()
    val mods by Modules.list.collectAsState()
    val appPrefs by Store.appPrefs.collectAsState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var stickToBottom by remember { mutableStateOf(true) }
    val isAtBottom by remember { derivedStateOf { !listState.canScrollForward } }
    var tfv by remember { mutableStateOf(TextFieldValue(text, TextRange(text.length))) }
    var settingsStartTab by remember { mutableStateOf<Int?>(null) }
    var showQuickEditor by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var activeChatTabId by remember { mutableStateOf("all") }
    val seenMaxIdByTab = remember { mutableStateMapOf<String, Long>() }

    val activeServerKey = Core.current()?.first?.let { "${it.host}:${it.port}" } ?: serverKey
    val blacklistMasterOn = remember(modVer, mods) { Modules.bool("chat", "blacklist", true) }
    val chatStorage = allStorage["chat"]
    val quickSendAll = remember(chatStorage) { chatStorage?.optBoolean("quick_send", false) == true }
    val blacklistRules = remember(chatStorage, activeServerKey) {
        parseChatBlacklistUiRules(chatStorage, activeServerKey)
    }
    val activeRuleCount = remember(blacklistRules) { blacklistRules.count { it.enabled } }
    val compiledGlobalBlacklist: List<(String) -> Boolean> = remember(blacklistMasterOn, blacklistRules) {
        if (!blacklistMasterOn) emptyList() else compileBlacklistMatchers(blacklistRules)
    }

    val customTabs = remember(chatStorage, activeServerKey) {
        parseCustomChatTabs(chatStorage, activeServerKey)
    }
    val enabledCustomTabs = remember(customTabs) { customTabs.filter { it.enabled } }
    LaunchedEffect(enabledCustomTabs) {
        if (activeChatTabId != "all" && enabledCustomTabs.none { it.id == activeChatTabId }) {
            activeChatTabId = "all"
        }
    }

    val compiledTabs = remember(enabledCustomTabs) {
        enabledCustomTabs.associate { tab ->
            tab.id to CompiledChatTab(
                tab = tab,
                whitelist = tab.whitelist.mapNotNull { compilePatternEntry(it) },
                blacklist = tab.blacklist.mapNotNull { compilePatternEntry(it) },
            )
        }
    }

    val plainById = remember(lines) {
        lines.associate { it.id to Ansi.strip(it.text) }
    }

    val globalPassLines = remember(lines, plainById, compiledGlobalBlacklist) {
        if (compiledGlobalBlacklist.isEmpty()) lines
        else lines.filterNot { line ->
            val plain = plainById[line.id] ?: ""
            compiledGlobalBlacklist.any { it(plain) }
        }
    }
    val globalHiddenCount = lines.size - globalPassLines.size

    fun linesForTab(tabId: String): List<ChatLine> {
        if (tabId == "all") return globalPassLines
        val ct = compiledTabs[tabId] ?: return globalPassLines
        val base = if (ct.tab.applyGlobalBlacklist && compiledGlobalBlacklist.isNotEmpty()) globalPassLines else lines
        return base.filter { line ->
            val plain = plainById[line.id] ?: ""
            val wlOk = if (ct.whitelist.isEmpty()) true else ct.whitelist.any { it(plain) }
            if (!wlOk) false
            else !ct.blacklist.any { it(plain) }
        }
    }

    val tabFilteredLines = remember(activeChatTabId, lines, globalPassLines, compiledTabs, compiledGlobalBlacklist) {
        linesForTab(activeChatTabId)
    }

    val unreadByTab = remember(activeChatTabId, lines, globalPassLines, compiledTabs, seenMaxIdByTab.toMap()) {
        val out = HashMap<String, Int>()
        val allIds = listOf("all") + enabledCustomTabs.map { it.id }
        for (tid in allIds) {
            if (tid == activeChatTabId) {
                out[tid] = 0
            } else {
                val seen = seenMaxIdByTab[tid] ?: 0L
                val matching = linesForTab(tid)
                out[tid] = matching.count { it.id > seen }
            }
        }
        out
    }

    LaunchedEffect(activeChatTabId, tabFilteredLines.lastOrNull()?.id) {
        val latest = tabFilteredLines.lastOrNull()?.id ?: 0L
        val cur = seenMaxIdByTab[activeChatTabId] ?: 0L
        if (latest > cur) seenMaxIdByTab[activeChatTabId] = latest
    }

    val visibleLines = remember(tabFilteredLines, searchQuery, plainById) {
        val q = searchQuery.trim()
        if (q.isEmpty()) tabFilteredLines
        else tabFilteredLines.filter { (plainById[it.id] ?: Ansi.strip(it.text)).contains(q, ignoreCase = true) }
    }

    val timeFmt = remember(appPrefs.chatShowSeconds) {
        SimpleDateFormat(if (appPrefs.chatShowSeconds) "HH:mm:ss" else "HH:mm", Locale.getDefault())
    }
    val playerHashMap = remember(players, hashVer) {
        players.associate { it.name.lowercase() to (it.name to it.hash) }
    }

    LaunchedEffect(text) {
        if (text != tfv.text) {
            tfv = TextFieldValue(text, TextRange(text.length))
        }
    }
    LaunchedEffect(online, text) {
        if (!online || !text.startsWith("/")) {
            Core.clearCompletions()
        } else {
            delay(90)
            Core.requestComplete(text)
        }
    }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
            .collect { (scrolling, canFwd) ->
                if (scrolling || !canFwd) stickToBottom = !canFwd
            }
    }
    LaunchedEffect(activeChatTabId, visibleLines.size, visibleLines.lastOrNull()?.id) {
        if (visibleLines.isNotEmpty() && stickToBottom) listState.scrollToItem(visibleLines.size - 1)
    }

    fun applySuggestion(s: TabSuggestion) {
        val st = comp.start.coerceIn(0, text.length)
        val en = comp.end.coerceIn(st, text.length)
        val next = text.substring(0, st) + s.text + text.substring(en)
        onTextChange(next)
    }

    Column(Modifier.fillMaxSize()) {
        // Toolbar mini rapi di atas chat
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = AzaleaPalette.Surface,
        ) {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = buildString {
                        append("${visibleLines.size} pesan")
                        if (activeChatTabId == "all" && globalHiddenCount > 0) {
                            append(" · $globalHiddenCount disembunyikan")
                        } else if (activeChatTabId != "all") {
                            val tabTitle = enabledCustomTabs.firstOrNull { it.id == activeChatTabId }?.name
                            if (!tabTitle.isNullOrBlank()) append(" · $tabTitle")
                        }
                    },
                    modifier = Modifier.weight(1f),
                    fontSize = 11.sp,
                    color = if (globalHiddenCount > 0 && blacklistMasterOn && activeChatTabId == "all") {
                        AzaleaPalette.Sky
                    } else {
                        AzaleaPalette.TextMuted
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                IconButton(
                    onClick = { searchOpen = !searchOpen; if (!searchOpen) searchQuery = "" },
                    modifier = Modifier.size(34.dp),
                ) {
                    Icon(
                        AzaleaIcons.Search,
                        contentDescription = "Cari chat",
                        modifier = Modifier.size(17.dp),
                        tint = if (searchOpen) AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                    )
                }
                IconButton(
                    onClick = { Core.clearChat() },
                    modifier = Modifier.size(34.dp),
                ) {
                    Icon(
                        AzaleaIcons.Clear,
                        contentDescription = "Bersihkan chat",
                        modifier = Modifier.size(17.dp),
                        tint = AzaleaPalette.TextMuted,
                    )
                }
                IconButton(
                    onClick = { settingsStartTab = 0 },
                    modifier = Modifier.size(34.dp),
                ) {
                    Icon(
                        AzaleaIcons.Settings,
                        contentDescription = "Pengaturan & Filter Chat",
                        modifier = Modifier.size(18.dp),
                        tint = if (enabledCustomTabs.isNotEmpty() || (blacklistMasterOn && activeRuleCount > 0)) {
                            AzaleaPalette.Emerald
                        } else {
                            AzaleaPalette.TextMuted
                        },
                    )
                }
            }
        }

        // Bar Sub-Tab Chat (ala AdvancedChatCore / AdvancedChatBox)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = AzaleaPalette.Surface,
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ChatSubTabChip(
                    label = "Semua",
                    unread = unreadByTab["all"] ?: 0,
                    selected = activeChatTabId == "all",
                    onClick = {
                        activeChatTabId = "all"
                        seenMaxIdByTab["all"] = linesForTab("all").lastOrNull()?.id ?: 0L
                        stickToBottom = true
                    },
                )
                for (tab in enabledCustomTabs) {
                    ChatSubTabChip(
                        label = tab.name,
                        unread = unreadByTab[tab.id] ?: 0,
                        selected = activeChatTabId == tab.id,
                        onClick = {
                            activeChatTabId = tab.id
                            seenMaxIdByTab[tab.id] = linesForTab(tab.id).lastOrNull()?.id ?: 0L
                            stickToBottom = true
                        },
                    )
                }
                Surface(
                    modifier = Modifier
                        .height(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { settingsStartTab = 1 },
                    shape = RoundedCornerShape(8.dp),
                    color = AzaleaPalette.Card,
                    border = BorderStroke(1.dp, AzaleaPalette.Border),
                ) {
                    Box(Modifier.padding(horizontal = 10.dp), contentAlignment = Alignment.Center) {
                        Text("+ Tab", fontSize = 11.sp, color = AzaleaPalette.TextMuted, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        HorizontalDivider(color = AzaleaPalette.Border)
        if (searchOpen) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Cari isi chat...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }

        var selectedChatId by remember { mutableStateOf<Long?>(null) }
        var copiedChatId by remember { mutableStateOf<Long?>(null) }
        val ctx = LocalContext.current

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 8.dp),
                contentPadding = PaddingValues(vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                state = listState,
            ) {
                if (lines.isEmpty()) item(key = "__empty__") {
                    Text(
                        "Belum ada chat. Pastikan modul Chat aktif.",
                        Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
                        color = AzaleaPalette.TextMuted,
                    )
                } else if (visibleLines.isEmpty()) item(key = "__all_filtered__") {
                    Text(
                        when {
                            searchQuery.isNotBlank() -> "Tidak ada chat yang cocok dengan \"$searchQuery\"."
                            activeChatTabId != "all" -> "Belum ada pesan yang cocok dengan filter tab ini."
                            else -> "Semua $globalHiddenCount pesan chat disembunyikan oleh filter blacklist."
                        },
                        Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
                        color = AzaleaPalette.TextMuted,
                    )
                }
                items(visibleLines.size, key = { visibleLines[it].id }) { idx ->
                    val chatLine = visibleLines[idx]
                    val interactionSource = remember { MutableInteractionSource() }
                    val isPressed by interactionSource.collectIsPressedAsState()
                    val toggled = selectedChatId == chatLine.id
                    val highlighted = isPressed || toggled
                    val shape = RoundedCornerShape(8.dp)
                    val cardBg = if (highlighted) AzaleaPalette.CardSelected else Color.Transparent
                    val borderCol = if (highlighted) AzaleaPalette.BorderSelected else Color.Transparent
                    val quickCmds = remember(chatLine.id, toggled) {
                        if (toggled) extractChatCommands(chatLine) else emptyList()
                    }
                    val plain = remember(chatLine.id, plainById) {
                        plainById[chatLine.id] ?: Ansi.strip(chatLine.text)
                    }
                    val speaker = remember(chatLine.id, plain, playerHashMap, appPrefs.chatShowHead) {
                        if (appPrefs.chatShowHead) detectChatSpeaker(plain, playerHashMap) else null
                    }
                    val msgAnnotated = remember(
                        chatLine.id,
                        appPrefs.chatShowTime,
                        appPrefs.chatShowSeconds,
                    ) {
                        val base = Ansi.annotated(chatLine.text, invert = false)
                        if (!appPrefs.chatShowTime) {
                            base
                        } else {
                            val stamp = synchronized(timeFmt) { timeFmt.format(Date(chatLine.timeMs)) }
                            buildAnnotatedString {
                                withStyle(
                                    SpanStyle(
                                        color = AzaleaPalette.TextMuted,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                    )
                                ) {
                                    append("[$stamp] ")
                                }
                                append(base)
                            }
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .combinedClickable(
                                interactionSource = interactionSource,
                                indication = null,
                                onClick = {
                                    selectedChatId = if (toggled) null else chatLine.id
                                    copiedChatId = null
                                },
                                onLongClick = {},
                            ),
                        shape = shape,
                        color = cardBg,
                        border = BorderStroke(1.dp, borderCol),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top,
                            ) {
                                if (speaker != null) {
                                    Box(Modifier.padding(top = 1.dp, end = 6.dp)) {
                                        PlayerHead(speaker.first, speaker.second, size = 18.dp)
                                    }
                                }
                                Text(
                                    text = msgAnnotated,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp,
                                    color = AzaleaPalette.TextPrimary,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            if (toggled) {
                                Spacer(Modifier.height(6.dp))
                                FlowRow(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    for (q in quickCmds) {
                                        val autoSend = q.run || quickSendAll
                                        val chipShape = RoundedCornerShape(10.dp)
                                        val chipBg = if (autoSend) AzaleaPalette.EmeraldDark else AzaleaPalette.CardAlt
                                        val chipFg = if (autoSend) AzaleaPalette.Emerald else AzaleaPalette.TextPrimary
                                        val chipBorder = if (autoSend) AzaleaPalette.Emerald else AzaleaPalette.Border
                                        Surface(
                                            modifier = Modifier
                                                .height(28.dp)
                                                .clip(chipShape)
                                                .combinedClickable(
                                                    onClick = {
                                                        selectedChatId = null
                                                        if (autoSend && online) Core.send(q.cmd)
                                                        else onTextChange(q.cmd)
                                                    },
                                                    onLongClick = {
                                                        selectedChatId = null
                                                        if (autoSend) onTextChange(q.cmd)
                                                        else if (online) Core.send(q.cmd)
                                                        else onTextChange(q.cmd)
                                                    },
                                                ),
                                            shape = chipShape,
                                            color = chipBg,
                                            border = BorderStroke(1.dp, chipBorder),
                                        ) {
                                            Box(
                                                Modifier.padding(horizontal = 10.dp),
                                                contentAlignment = Alignment.Center,
                                            ) {
                                                Text(
                                                    text = if (autoSend) "▶ ${q.cmd}" else q.cmd,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = chipFg,
                                                )
                                            }
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            copyText(ctx, "chat", Ansi.strip(chatLine.text))
                                            copiedChatId = chatLine.id
                                        },
                                        modifier = Modifier.height(28.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                        border = BorderStroke(1.dp, AzaleaPalette.Border),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AzaleaPalette.TextPrimary),
                                    ) {
                                        Text(if (copiedChatId == chatLine.id) "Tersalin" else "Salin", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            ScrollToBottomButton(
                visible = visibleLines.isNotEmpty() && !isAtBottom,
                onClick = {
                    stickToBottom = true
                    scope.launch { listState.animateScrollToItem(visibleLines.size - 1) }
                },
                modifier = Modifier.align(Alignment.BottomEnd),
            )
        }

        if (settingsStartTab != null) {
            ChatSettingsDialog(
                initialTab = settingsStartTab ?: 0,
                serverKey = activeServerKey,
                masterEnabled = blacklistMasterOn,
                quickSendAll = quickSendAll,
                hiddenCount = globalHiddenCount,
                totalCount = lines.size,
                blacklistRules = blacklistRules,
                customTabs = customTabs,
                storageObj = chatStorage,
                onToggleMaster = { Modules.set("chat", "blacklist", it) },
                onToggleQuickSend = { setChatQuickSend(chatStorage, activeServerKey, it) },
                onOpenQuickEditor = { showQuickEditor = true },
                onDismiss = { settingsStartTab = null },
            )
        }
        if (showQuickEditor) {
            QuickCmdEditorDialog(onDismiss = { showQuickEditor = false })
        }

        // Command suggestion vertikal (atas ke bawah seperti chat Minecraft asli)
        if (online && comp.items.isNotEmpty() && text.isNotEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                shape = RoundedCornerShape(10.dp),
                color = AzaleaPalette.Card,
                border = BorderStroke(1.dp, AzaleaPalette.Border),
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 176.dp),
                    contentPadding = PaddingValues(vertical = 4.dp),
                ) {
                    items(comp.items.size) { idx ->
                        val item = comp.items[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { applySuggestion(item) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                item.text,
                                fontSize = 13.sp,
                                color = AzaleaPalette.TextPrimary,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f, fill = false),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (!item.tip.isNullOrBlank()) {
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    item.tip,
                                    fontSize = 11.sp,
                                    color = AzaleaPalette.TextMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                        if (idx + 1 < comp.items.size) {
                            HorizontalDivider(color = AzaleaPalette.Border)
                        }
                    }
                }
            }
        }

        // Quick command bar (dapat diedit isinya dan disembunyikan/ditampilkan langsung)
        if (appPrefs.chatShowQuickCmd) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (q in appPrefs.chatQuickCmds) {
                    val shape = RoundedCornerShape(8.dp)
                    Surface(
                        modifier = Modifier
                            .clip(shape)
                            .combinedClickable(
                                onClick = {
                                    if (q.send && online) Core.send(q.cmd)
                                    else onTextChange(q.cmd)
                                },
                                onLongClick = {
                                    if (online && !q.cmd.endsWith(" ")) Core.send(q.cmd)
                                    else onTextChange(q.cmd)
                                },
                            ),
                        shape = shape,
                        color = if (q.send) AzaleaPalette.EmeraldDark else AzaleaPalette.CardAlt,
                        border = BorderStroke(1.dp, if (q.send) AzaleaPalette.Emerald else AzaleaPalette.Border),
                    ) {
                        Text(
                            if (q.send) "▶ ${q.label}" else q.label,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            fontSize = 11.sp,
                            color = if (q.send) AzaleaPalette.Emerald else AzaleaPalette.TextMuted,
                        )
                    }
                }
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showQuickEditor = true },
                    shape = RoundedCornerShape(8.dp),
                    color = AzaleaPalette.Card,
                    border = BorderStroke(1.dp, AzaleaPalette.Border),
                ) {
                    Text(
                        "Atur",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        fontSize = 11.sp,
                        color = AzaleaPalette.Sky,
                    )
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = tfv,
                onValueChange = {
                    tfv = it
                    if (it.text != text) onTextChange(it.text)
                },
                singleLine = true,
                placeholder = { Text("Chat atau /perintah") },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(6.dp))
            OutlinedButton(
                enabled = online && text.isNotEmpty(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                onClick = {
                    if (comp.items.isNotEmpty()) applySuggestion(comp.items.first())
                    else Core.requestComplete(text, force = true)
                },
            ) {
                Icon(AzaleaIcons.TabComplete, contentDescription = "Lengkapi", modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(6.dp))
            Button(
                enabled = online && text.isNotBlank(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                onClick = { Core.send(text); onTextChange("") },
            ) {
                Icon(AzaleaIcons.Send, contentDescription = "Kirim", modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun ChatSubTabChip(
    label: String,
    unread: Int,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(8.dp)
    Surface(
        modifier = Modifier
            .height(28.dp)
            .clip(shape)
            .clickable(onClick = onClick),
        shape = shape,
        color = if (selected) AzaleaPalette.EmeraldDark else AzaleaPalette.Card,
        border = BorderStroke(1.dp, if (selected) AzaleaPalette.Emerald else AzaleaPalette.Border),
    ) {
        Box(Modifier.padding(horizontal = 10.dp), contentAlignment = Alignment.Center) {
            Text(
                text = if (!selected && unread > 0) "$label ($unread)" else label,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                color = when {
                    selected -> AzaleaPalette.Emerald
                    unread > 0 -> AzaleaPalette.Sky
                    else -> AzaleaPalette.TextPrimary
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

private val CHAT_ANGLE_SPEAKER_REGEX = Regex("""^<([A-Za-z0-9_]{3,16})>\s""")
private val CHAT_PM_SPEAKER_REGEX = Regex("""^(?:\[[^\]]{1,24}\]\s*)*([A-Za-z0-9_]{3,16})\s*->\s*me\b""", RegexOption.IGNORE_CASE)
private val CHAT_HEADER_TOKEN_REGEX = Regex("""[A-Za-z0-9_]{3,16}""")

private fun detectChatSpeaker(plain: String, onlineMap: Map<String, Pair<String, String?>>): Pair<String, String?>? {
    if (plain.isBlank()) return null
    CHAT_ANGLE_SPEAKER_REGEX.find(plain)?.let { m ->
        val raw = m.groupValues[1]
        return onlineMap[raw.lowercase()] ?: (raw to TexCache.knownHashFor(raw))
    }
    CHAT_PM_SPEAKER_REGEX.find(plain)?.let { m ->
        val raw = m.groupValues[1]
        return onlineMap[raw.lowercase()] ?: (raw to TexCache.knownHashFor(raw))
    }
    if (onlineMap.isEmpty()) return null
    val sepIdx = listOf(
        plain.indexOf(':'),
        plain.indexOf('»'),
        plain.indexOf('›'),
        plain.indexOf('>'),
    ).filter { it in 2..64 }.minOrNull() ?: return null
    val header = plain.substring(0, sepIdx)
    val tokens = CHAT_HEADER_TOKEN_REGEX.findAll(header).toList()
    for (i in tokens.lastIndex downTo 0) {
        val tok = tokens[i].value.lowercase()
        val match = onlineMap[tok]
        if (match != null) return match
    }
    return null
}

private val CHAT_URL_REGEX = Regex("https?://\\S+", RegexOption.IGNORE_CASE)
private val CHAT_QUOTED_CMD_REGEX = Regex("""[`"'\[\(]\s*(/[A-Za-z][A-Za-z0-9_:-]{0,31}(?:\s+[^\s`"'\)\]]{1,24}){0,2})\s*[`"'\)\]]""")
private val CHAT_INLINE_CMD_REGEX = Regex("""(?:^|[\s\[(<"'«:,|>\-])(/[A-Za-z][A-Za-z0-9_:-]{0,31})""")
private val CHAT_PROSE_STOPWORDS = setOf(
    "untuk", "atau", "dan", "agar", "biar", "karena", "lalu", "kemudian", "jika", "kalau",
    "saat", "ke", "di", "dari", "yang", "sekarang", "klik", "ketik", "tekan", "gunakan",
    "for", "to", "and", "or", "the", "if", "when", "then", "please", "click", "type", "use",
)

private fun trimQuotedCommandProse(rawCmd: String): String {
    val parts = rawCmd.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (parts.isEmpty()) return ""
    val out = ArrayList<String>(parts.size)
    out.add(parts[0])
    for (i in 1 until parts.size) {
        val tok = parts[i].trimEnd('.', ',', '!', '?', ';', ':')
        if (tok.isEmpty() || tok.lowercase() in CHAT_PROSE_STOPWORDS) break
        out.add(tok)
    }
    return out.joinToString(" ")
}

private fun extractChatCommands(line: ChatLine): List<ChatQuickCmd> {
    val out = ArrayList<ChatQuickCmd>()
    fun addCmd(raw: String, run: Boolean) {
        val cleaned = raw.trim().trimEnd('.', ',', '!', '?', ';')
        if (cleaned.isEmpty()) return
        val existingIdx = out.indexOfFirst { it.cmd.equals(cleaned, ignoreCase = true) }
        if (existingIdx >= 0) {
            if (run && !out[existingIdx].run) {
                out[existingIdx] = out[existingIdx].copy(run = true)
            }
            return
        }
        out.add(ChatQuickCmd(cleaned, run))
    }
    for (c in line.cmds) {
        addCmd(c.cmd, c.run)
    }
    val plain = Ansi.strip(line.text)
    val noUrls = plain.replace(CHAT_URL_REGEX, " ")
    for (m in CHAT_QUOTED_CMD_REGEX.findAll(noUrls)) {
        val phrase = trimQuotedCommandProse(m.groupValues[1])
        if (phrase.startsWith("/") && phrase.length > 1) {
            addCmd(phrase, false)
        }
    }
    for (m in CHAT_INLINE_CMD_REGEX.findAll(noUrls)) {
        val single = m.groupValues[1].trimEnd('.', ',', '!', '?', ';', ':')
        val alreadyCoveredByMulti = out.any {
            it.cmd.startsWith("$single ", ignoreCase = true) || it.cmd.equals(single, ignoreCase = true)
        }
        if (single.length > 1 && !alreadyCoveredByMulti) {
            addCmd(single, false)
        }
    }
    return out.take(6)
}

private data class ChatPatternEntry(
    val kind: String,
    val pattern: String,
    val caseSensitive: Boolean = false,
)

private data class ChatBlacklistRuleUi(
    val scope: String,
    val index: Int,
    val name: String,
    val entries: List<ChatPatternEntry>,
    val enabled: Boolean,
    val caseSensitive: Boolean,
)

private data class ChatCustomTabDef(
    val id: String,
    val name: String,
    val scope: String,
    val enabled: Boolean,
    val applyGlobalBlacklist: Boolean,
    val whitelist: List<ChatPatternEntry>,
    val blacklist: List<ChatPatternEntry>,
)

private data class CompiledChatTab(
    val tab: ChatCustomTabDef,
    val whitelist: List<(String) -> Boolean>,
    val blacklist: List<(String) -> Boolean>,
)

private val RULE_KIND_MODES = listOf("regex", "match", "exact", "starts")
private val RULE_KIND_KEYWORDS = setOf("regex", "match", "contains", "exact", "starts", "prefix")

private fun normalizeRuleKind(raw: String): String = when (val k = raw.trim().lowercase()) {
    "regex", "match", "exact", "starts" -> k
    "prefix" -> "starts"
    "contains", "" -> "match"
    else -> k
}

private fun validateRegexError(pattern: String): String? {
    if (pattern.isEmpty()) return null
    return try {
        Regex(pattern)
        null
    } catch (e: Throwable) {
        e.message?.lineSequence()?.firstOrNull() ?: "Pola regex tidak valid"
    }
}

private fun collectPatternEntries(
    raw: Any?,
    fallbackKind: String,
    defaultCs: Boolean,
    out: MutableList<ChatPatternEntry>,
) {
    when (raw) {
        is String -> if (raw.isNotEmpty()) out.add(ChatPatternEntry(fallbackKind, raw, defaultCs))
        is JSONArray -> {
            if (raw.length() >= 2 && raw.opt(0) is String && (raw.opt(1) is String || raw.opt(1) is JSONArray)) {
                val k = normalizeRuleKind(raw.optString(0, fallbackKind))
                val cs = raw.optBoolean(2, defaultCs)
                val second = raw.opt(1)
                if (second is String && second.isNotEmpty()) {
                    out.add(ChatPatternEntry(k, second, cs))
                } else if (second is JSONArray) {
                    for (j in 0 until second.length()) {
                        val s = second.optString(j)
                        if (s.isNotEmpty()) out.add(ChatPatternEntry(k, s, cs))
                    }
                }
            } else {
                for (i in 0 until raw.length()) {
                    val item = raw.opt(i)
                    if (item is String && item.isNotEmpty()) {
                        out.add(ChatPatternEntry(fallbackKind, item, defaultCs))
                    }
                }
            }
        }
        is JSONObject -> {
            val k = normalizeRuleKind(
                raw.optString("type").ifBlank { raw.optString("mode").ifBlank { raw.optString("kind") } }
                    .ifBlank { fallbackKind },
            )
            val cs = raw.optBoolean("case_sensitive", defaultCs)
            val pVal = raw.opt("pattern")
                ?: raw.opt("patterns")
                ?: raw.opt("text")
                ?: raw.opt("isi")
                ?: raw.opt("value")
            if (pVal is String && pVal.isNotEmpty()) {
                out.add(ChatPatternEntry(k, pVal, cs))
            } else if (pVal is JSONArray) {
                for (i in 0 until pVal.length()) {
                    val s = pVal.optString(i)
                    if (s.isNotEmpty()) out.add(ChatPatternEntry(k, s, cs))
                }
            }
        }
    }
}

private fun parsePatternEntryArray(arr: JSONArray?): List<ChatPatternEntry> {
    if (arr == null) return emptyList()
    val out = ArrayList<ChatPatternEntry>()
    for (i in 0 until arr.length()) {
        collectPatternEntries(arr.opt(i), "match", false, out)
    }
    return out
}

private fun serializePatternEntries(list: List<ChatPatternEntry>): JSONArray {
    val arr = JSONArray()
    for (e in list) {
        if (e.pattern.isBlank()) continue
        val row = JSONArray().put(normalizeRuleKind(e.kind)).put(e.pattern)
        if (e.caseSensitive) row.put(true)
        arr.put(row)
    }
    return arr
}

private fun parseCustomChatTabs(storageObj: JSONObject?, serverKey: String): List<ChatCustomTabDef> {
    val arr = storageObj?.optJSONArray("tabs") ?: return emptyList()
    val out = ArrayList<ChatCustomTabDef>()
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val scope = o.optString("scope", "global").ifBlank { "global" }
        val srv = o.optString("server", "")
        if (scope == "server" && serverKey.isNotBlank() && srv.isNotBlank() && srv != serverKey) continue
        if (scope == "server" && serverKey.isBlank() && srv.isNotBlank()) continue
        val name = o.optString("name").trim()
        if (name.isEmpty()) continue
        out.add(
            ChatCustomTabDef(
                id = o.optString("id").ifBlank { "tab_$i" },
                name = name,
                scope = scope,
                enabled = o.optBoolean("enabled", true),
                applyGlobalBlacklist = o.optBoolean("apply_global_blacklist", true),
                whitelist = parsePatternEntryArray(o.optJSONArray("whitelist")),
                blacklist = parsePatternEntryArray(o.optJSONArray("blacklist")),
            )
        )
    }
    return out
}

private fun saveCustomChatTab(
    existing: JSONObject?,
    serverKey: String,
    tab: ChatCustomTabDef,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val arr = root.optJSONArray("tabs") ?: JSONArray().also { root.put("tabs", it) }
    val obj = JSONObject()
        .put("id", tab.id)
        .put("name", tab.name.trim())
        .put("scope", tab.scope)
        .put("server", if (tab.scope == "server") serverKey else "")
        .put("enabled", tab.enabled)
        .put("apply_global_blacklist", tab.applyGlobalBlacklist)
        .put("whitelist", serializePatternEntries(tab.whitelist))
        .put("blacklist", serializePatternEntries(tab.blacklist))
    var replaced = false
    for (i in 0 until arr.length()) {
        val cur = arr.optJSONObject(i) ?: continue
        if (cur.optString("id") == tab.id) {
            arr.put(i, obj)
            replaced = true
            break
        }
    }
    if (!replaced) arr.put(obj)
    ModStorage.replace("chat", root, fromUser = true)
}

private fun deleteCustomChatTab(existing: JSONObject?, serverKey: String, tabId: String) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val arr = root.optJSONArray("tabs") ?: return
    val next = JSONArray()
    for (i in 0 until arr.length()) {
        val cur = arr.optJSONObject(i) ?: continue
        if (cur.optString("id") != tabId) next.put(cur)
    }
    root.put("tabs", next)
    ModStorage.replace("chat", root, fromUser = true)
}

private fun parseChatBlacklistRuleItem(scope: String, index: Int, raw: Any?): ChatBlacklistRuleUi? = when (raw) {
    is JSONObject -> {
        val enabled = if (raw.has("enable")) raw.optBoolean("enable", true) else raw.optBoolean("enabled", true)
        val explicitKind = raw.optString("type").ifBlank { raw.optString("mode").ifBlank { raw.optString("kind") } }
            .trim().lowercase()
        val fallbackKind = normalizeRuleKind(explicitKind)
        val defaultCs = raw.optBoolean("case_sensitive", false)
        val entries = ArrayList<ChatPatternEntry>()
        val patArr = raw.optJSONArray("patterns") ?: raw.optJSONArray("pattern")
        if (patArr != null) {
            var allStrings = true
            for (i in 0 until patArr.length()) {
                if (patArr.opt(i) !is String) {
                    allStrings = false
                    break
                }
            }
            val flatShorthand = explicitKind.isBlank() &&
                patArr.length() >= 2 &&
                allStrings &&
                patArr.optString(0).trim().lowercase() in RULE_KIND_KEYWORDS
            if (flatShorthand) {
                val k = normalizeRuleKind(patArr.optString(0))
                for (i in 1 until patArr.length()) {
                    val s = patArr.optString(i)
                    if (s.isNotEmpty()) entries.add(ChatPatternEntry(k, s, defaultCs))
                }
            } else {
                for (i in 0 until patArr.length()) {
                    collectPatternEntries(patArr.opt(i), fallbackKind, defaultCs, entries)
                }
            }
        } else {
            val single = raw.optString("pattern")
                .ifBlank { raw.optString("text") }
                .ifBlank { raw.optString("isi") }
                .ifBlank { raw.optString("value") }
            if (single.isNotEmpty()) entries.add(ChatPatternEntry(fallbackKind, single, defaultCs))
        }
        val label = raw.optString("name").ifBlank { raw.optString("nama") }.trim()
            .ifBlank { entries.firstOrNull()?.pattern?.take(24) ?: "Aturan #${index + 1}" }
        ChatBlacklistRuleUi(scope, index, label, entries, enabled, defaultCs)
    }
    is JSONArray -> {
        val entries = ArrayList<ChatPatternEntry>()
        collectPatternEntries(raw, "match", false, entries)
        if (entries.isEmpty()) null
        else {
            val label = entries.firstOrNull()?.pattern?.take(24) ?: "Aturan #${index + 1}"
            ChatBlacklistRuleUi(scope, index, label, entries, true, entries.first().caseSensitive)
        }
    }
    is String -> if (raw.isNotEmpty()) {
        ChatBlacklistRuleUi(scope, index, raw.take(24), listOf(ChatPatternEntry("match", raw, false)), true, false)
    } else null
    else -> null
}

private fun parseChatBlacklistSection(section: JSONObject?, scope: String): List<ChatBlacklistRuleUi> {
    if (section == null) return emptyList()
    val arr = section.optJSONArray("blacklist")
        ?: section.optJSONArray("filter")
        ?: section.optJSONArray("rules")
        ?: return emptyList()
    val out = ArrayList<ChatBlacklistRuleUi>()
    for (i in 0 until arr.length()) {
        parseChatBlacklistRuleItem(scope, i, arr.opt(i))?.let { out.add(it) }
    }
    return out
}

private fun parseChatBlacklistUiRules(storageObj: JSONObject?, serverKey: String): List<ChatBlacklistRuleUi> {
    val out = ArrayList<ChatBlacklistRuleUi>()
    val globalObj = storageObj?.optJSONObject("global")
    out.addAll(parseChatBlacklistSection(globalObj, "global"))
    if (serverKey.isNotBlank()) {
        val srvObj = storageObj?.optJSONObject("servers")?.optJSONObject(serverKey)
        out.addAll(parseChatBlacklistSection(srvObj, "server"))
    }
    return out
}

private fun compilePatternEntry(entry: ChatPatternEntry): ((String) -> Boolean)? {
    val pat = entry.pattern
    if (pat.isEmpty()) return null
    val cs = entry.caseSensitive
    return when (normalizeRuleKind(entry.kind)) {
        "regex" -> {
            val re = try {
                if (cs) Regex(pat) else Regex(pat, RegexOption.IGNORE_CASE)
            } catch (_: Throwable) {
                null
            } ?: return null
            val fn: (String) -> Boolean = { plain -> re.containsMatchIn(plain) }
            fn
        }
        "exact" -> {
            val target = pat.trim()
            val fn: (String) -> Boolean = { plain -> plain.trim().equals(target, ignoreCase = !cs) }
            fn
        }
        "starts" -> {
            val fn: (String) -> Boolean = { plain -> plain.trimStart().startsWith(pat, ignoreCase = !cs) }
            fn
        }
        else -> {
            val fn: (String) -> Boolean = { plain -> plain.contains(pat, ignoreCase = !cs) }
            fn
        }
    }
}

private fun compileBlacklistMatchers(rules: List<ChatBlacklistRuleUi>): List<(String) -> Boolean> {
    val out = ArrayList<(String) -> Boolean>()
    for (r in rules) {
        if (!r.enabled) continue
        for (e in r.entries) {
            compilePatternEntry(e)?.let { out.add(it) }
        }
    }
    return out
}

private fun ensureChatStorageRoot(existing: JSONObject?, serverKey: String): JSONObject {
    val root = try {
        JSONObject(existing?.toString() ?: "{}")
    } catch (_: Throwable) {
        JSONObject()
    }
    val global = root.optJSONObject("global") ?: JSONObject().also { root.put("global", it) }
    if (global.optJSONArray("blacklist") == null) {
        global.put(
            "blacklist",
            JSONArray().put(
                JSONObject()
                    .put("name", "broadcast")
                    .put("patterns", JSONArray().put(JSONArray().put("regex").put("contoh regex broadcast")))
                    .put("enable", false)
                    .put("case_sensitive", false),
            ),
        )
    }
    if (global.optJSONArray("private_chat") == null) {
        global.put(
            "private_chat",
            JSONArray().put(JSONArray().put("regex").put("""(?i)(?:^|\s*)([a-zA-Z0-9_]{3,16})\s*->\s*me\s*[:\s]\s*(.*)""")),
        )
    }
    if (!global.has("reply_command")) {
        global.put("reply_command", BotService.DEFAULT_REPLY_COMMAND)
    }
    val servers = root.optJSONObject("servers") ?: JSONObject().also { root.put("servers", it) }
    if (serverKey.isNotBlank()) {
        val srv = servers.optJSONObject(serverKey) ?: JSONObject().also { servers.put(serverKey, it) }
        if (srv.optJSONArray("blacklist") == null) srv.put("blacklist", JSONArray())
        if (srv.optJSONArray("private_chat") == null) srv.put("private_chat", JSONArray())
    }
    return root
}

private fun blacklistArrayForScope(root: JSONObject, serverKey: String, scope: String): JSONArray {
    val section = if (scope == "server" && serverKey.isNotBlank()) {
        val servers = root.optJSONObject("servers") ?: JSONObject().also { root.put("servers", it) }
        servers.optJSONObject(serverKey) ?: JSONObject().also { servers.put(serverKey, it) }
    } else {
        root.optJSONObject("global") ?: JSONObject().also { root.put("global", it) }
    }
    val existingArr = section.optJSONArray("blacklist")
        ?: section.optJSONArray("filter")
        ?: section.optJSONArray("rules")
    if (existingArr != null) {
        if (!section.has("blacklist")) section.put("blacklist", existingArr)
        return existingArr
    }
    return JSONArray().also { section.put("blacklist", it) }
}

private fun buildRuleJsonObject(
    name: String,
    entries: List<ChatPatternEntry>,
    enable: Boolean,
    caseSensitive: Boolean,
): JSONObject {
    val pats = JSONArray()
    for (e in entries) {
        val item = JSONArray().put(normalizeRuleKind(e.kind)).put(e.pattern)
        if (e.caseSensitive && e.caseSensitive != caseSensitive) {
            item.put(true)
        }
        pats.put(item)
    }
    return JSONObject()
        .put("name", name.trim())
        .put("patterns", pats)
        .put("enable", enable)
        .put("case_sensitive", caseSensitive)
}

private fun setChatQuickSend(existing: JSONObject?, serverKey: String, quickSend: Boolean) {
    val root = ensureChatStorageRoot(existing, serverKey)
    root.put("quick_send", quickSend)
    ModStorage.replace("chat", root, fromUser = true)
}

private fun setChatReplyCommand(existing: JSONObject?, serverKey: String, replyCommand: String) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val glb = root.getJSONObject("global")
    glb.put("reply_command", replyCommand.trim().ifEmpty { BotService.DEFAULT_REPLY_COMMAND })
    ModStorage.replace("chat", root, fromUser = true)
}

private fun setChatBlacklistRuleEnabled(
    existing: JSONObject?,
    serverKey: String,
    rule: ChatBlacklistRuleUi,
    enable: Boolean,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val arr = blacklistArrayForScope(root, serverKey, rule.scope)
    if (rule.index !in 0 until arr.length()) return
    val raw = arr.opt(rule.index)
    if (raw is JSONObject) {
        raw.put("enable", enable)
        raw.remove("enabled")
    } else {
        arr.put(rule.index, buildRuleJsonObject(rule.name, rule.entries, enable, rule.caseSensitive))
    }
    ModStorage.replace("chat", root, fromUser = true)
}

private fun saveChatBlacklistRule(
    existing: JSONObject?,
    serverKey: String,
    editing: ChatBlacklistRuleUi?,
    scope: String,
    name: String,
    entries: List<ChatPatternEntry>,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val targetScope = editing?.scope ?: scope
    val arr = blacklistArrayForScope(root, serverKey, targetScope)
    val obj = buildRuleJsonObject(
        name = name,
        entries = entries,
        enable = editing?.enabled ?: true,
        caseSensitive = editing?.caseSensitive ?: false,
    )
    if (editing != null && editing.index in 0 until arr.length()) {
        arr.put(editing.index, obj)
    } else {
        arr.put(obj)
    }
    ModStorage.replace("chat", root, fromUser = true)
}

private fun deleteChatBlacklistRule(
    existing: JSONObject?,
    serverKey: String,
    rule: ChatBlacklistRuleUi,
) {
    val root = ensureChatStorageRoot(existing, serverKey)
    val arr = blacklistArrayForScope(root, serverKey, rule.scope)
    if (rule.index !in 0 until arr.length()) return
    val next = JSONArray()
    for (i in 0 until arr.length()) {
        if (i != rule.index) next.put(arr.opt(i))
    }
    val section = if (rule.scope == "server" && serverKey.isNotBlank()) {
        root.getJSONObject("servers").getJSONObject(serverKey)
    } else {
        root.getJSONObject("global")
    }
    section.put("blacklist", next)
    ModStorage.replace("chat", root, fromUser = true)
}

@Composable
private fun ChatSettingsDialog(
    initialTab: Int,
    serverKey: String,
    masterEnabled: Boolean,
    quickSendAll: Boolean,
    hiddenCount: Int,
    totalCount: Int,
    blacklistRules: List<ChatBlacklistRuleUi>,
    customTabs: List<ChatCustomTabDef>,
    storageObj: JSONObject?,
    onToggleMaster: (Boolean) -> Unit,
    onToggleQuickSend: (Boolean) -> Unit,
    onOpenQuickEditor: () -> Unit,
    onDismiss: () -> Unit,
) {
    var dlgTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 3)) }
    val appPrefs by Store.appPrefs.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pengaturan Chat") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                TabRow(selectedTabIndex = dlgTab, containerColor = AzaleaPalette.CardAlt) {
                    Tab(selected = dlgTab == 0, onClick = { dlgTab = 0 }, text = { Text("Tampilan", fontSize = 11.sp, maxLines = 1) })
                    Tab(selected = dlgTab == 1, onClick = { dlgTab = 1 }, text = { Text("Tab", fontSize = 11.sp, maxLines = 1) })
                    Tab(selected = dlgTab == 2, onClick = { dlgTab = 2 }, text = { Text("Blacklist", fontSize = 11.sp, maxLines = 1) })
                    Tab(selected = dlgTab == 3, onClick = { dlgTab = 3 }, text = { Text("Quick", fontSize = 11.sp, maxLines = 1) })
                }
                Spacer(Modifier.height(10.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = 390.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    when (dlgTab) {
                        0 -> ChatDisplaySettingsSection(
                            appPrefs = appPrefs,
                            quickSendAll = quickSendAll,
                            storageObj = storageObj,
                            serverKey = serverKey,
                            onToggleQuickSend = onToggleQuickSend,
                        )
                        1 -> ChatCustomTabsSection(
                            serverKey = serverKey,
                            customTabs = customTabs,
                            storageObj = storageObj,
                        )
                        2 -> ChatBlacklistSection(
                            serverKey = serverKey,
                            masterEnabled = masterEnabled,
                            hiddenCount = hiddenCount,
                            totalCount = totalCount,
                            rules = blacklistRules,
                            storageObj = storageObj,
                            onToggleMaster = onToggleMaster,
                        )
                        else -> ChatQuickCmdSettingsSection(
                            appPrefs = appPrefs,
                            onOpenFullEditor = onOpenQuickEditor,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
    )
}

@Composable
private fun ChatDisplaySettingsSection(
    appPrefs: AppPrefs,
    quickSendAll: Boolean,
    storageObj: JSONObject?,
    serverKey: String,
    onToggleQuickSend: (Boolean) -> Unit,
) {
    val savedReplyCmd = remember(storageObj) {
        storageObj?.optJSONObject("global")?.optString("reply_command", "")?.trim()
            ?.ifEmpty { BotService.DEFAULT_REPLY_COMMAND }
            ?: BotService.DEFAULT_REPLY_COMMAND
    }
    var replyCmdDraft by remember(savedReplyCmd) { mutableStateOf(savedReplyCmd) }

    SettingSwitchRow(
        title = "Tampilkan waktu pesan",
        subtitle = "Langsung muncul/hilang pada semua baris chat",
        checked = appPrefs.chatShowTime,
        onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowTime = v) } },
    )
    if (appPrefs.chatShowTime) {
        SettingSwitchRow(
            title = "Sertakan detik (HH:mm:ss)",
            subtitle = "Jika mati memakai format ringkas HH:mm",
            checked = appPrefs.chatShowSeconds,
            onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowSeconds = v) } },
        )
    }
    SettingSwitchRow(
        title = "Tampilkan PlayerHead",
        subtitle = "Menampilkan avatar pengirim pesan jika dikenali",
        checked = appPrefs.chatShowHead,
        onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowHead = v) } },
    )
    SettingSwitchRow(
        title = "Tampilkan Quick Command",
        subtitle = "Bar pintasan perintah cepat di atas kolom ketik",
        checked = appPrefs.chatShowQuickCmd,
        onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowQuickCmd = v) } },
    )
    SettingSwitchRow(
        title = "Tombol chat pesan langsung kirim",
        subtitle = "Berlaku saat mengetuk perintah di dalam isi pesan",
        checked = quickSendAll,
        onCheckedChange = onToggleQuickSend,
    )
    HorizontalDivider(color = AzaleaPalette.Border)
    Text("Perintah Balas Notifikasi PM", style = MaterialTheme.typography.titleSmall)
    Text(
        "Placeholder: {nama} dan {pesan}",
        style = MaterialTheme.typography.bodySmall,
        color = AzaleaPalette.TextMuted,
    )
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(
            value = replyCmdDraft,
            onValueChange = { replyCmdDraft = it },
            singleLine = true,
            modifier = Modifier.weight(1f),
        )
        Button(
            enabled = replyCmdDraft.isNotBlank() && replyCmdDraft.trim() != savedReplyCmd,
            onClick = { setChatReplyCommand(storageObj, serverKey, replyCmdDraft) },
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
        ) { Text("Simpan", fontSize = 12.sp) }
    }
}

@Composable
private fun ChatQuickCmdSettingsSection(
    appPrefs: AppPrefs,
    onOpenFullEditor: () -> Unit,
) {
    SettingSwitchRow(
        title = "Tampilkan bilah Quick Command",
        subtitle = "Sembunyikan jika ingin layar chat lebih lega",
        checked = appPrefs.chatShowQuickCmd,
        onCheckedChange = { v -> Store.updateAppPrefs { it.copy(chatShowQuickCmd = v) } },
    )
    HorizontalDivider(color = AzaleaPalette.Border)
    Text(
        "Daftar tombol aktif (${appPrefs.chatQuickCmds.size}):",
        style = MaterialTheme.typography.bodySmall,
        color = AzaleaPalette.TextMuted,
    )
    for (q in appPrefs.chatQuickCmds) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = AzaleaPalette.CardAlt,
            border = BorderStroke(1.dp, AzaleaPalette.Border),
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(q.label, fontWeight = FontWeight.Medium, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text(
                    q.cmd + if (q.send) " · kirim" else "",
                    fontSize = 11.sp,
                    color = AzaleaPalette.TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
    Button(
        onClick = onOpenFullEditor,
        modifier = Modifier.fillMaxWidth(),
    ) { Text("Edit / Tambah Quick Command") }
}

@Composable
private fun ChatCustomTabsSection(
    serverKey: String,
    customTabs: List<ChatCustomTabDef>,
    storageObj: JSONObject?,
) {
    var editingTab by remember { mutableStateOf<ChatCustomTabDef?>(null) }
    var showForm by remember { mutableStateOf(false) }

    Text(
        "Buat tab tambahan di dalam Chat dengan filter Whitelist, Blacklist, dan Regex sendiri (mirip AdvancedChatBox).",
        style = MaterialTheme.typography.bodySmall,
        color = AzaleaPalette.TextMuted,
    )

    if (customTabs.isEmpty() && !showForm) {
        Text(
            "Belum ada tab kustom. Contoh: buat tab \"Chat Pemain\" lalu isi Whitelist regex untuk memisahkan obrolan dari broadcast server.",
            style = MaterialTheme.typography.bodySmall,
            color = AzaleaPalette.Sky,
        )
    }

    for (tab in customTabs) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                    editingTab = tab
                    showForm = true
                },
            shape = RoundedCornerShape(8.dp),
            color = AzaleaPalette.Card,
            border = BorderStroke(1.dp, AzaleaPalette.Border),
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        tab.name + if (tab.scope == "server") " (Server)" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "Whitelist ${tab.whitelist.size} · Blacklist ${tab.blacklist.size}" +
                            if (tab.applyGlobalBlacklist) " · +Global BL" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = AzaleaPalette.TextMuted,
                    )
                }
                Box(
                    modifier = Modifier
                        .padding(end = 6.dp)
                        .size(28.dp)
                        .clip(CircleShape)
                        .clickable {
                            if (editingTab?.id == tab.id) showForm = false
                            deleteCustomChatTab(storageObj, serverKey, tab.id)
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(AzaleaIcons.Close, contentDescription = "Hapus tab", modifier = Modifier.size(14.dp), tint = AzaleaPalette.Danger)
                }
                Switch(
                    checked = tab.enabled,
                    onCheckedChange = { en -> saveCustomChatTab(storageObj, serverKey, tab.copy(enabled = en)) },
                )
            }
        }
    }

    if (showForm) {
        ChatCustomTabForm(
            initial = editingTab,
            serverKey = serverKey,
            onSave = { saved ->
                saveCustomChatTab(storageObj, serverKey, saved)
                showForm = false
                editingTab = null
            },
            onCancel = {
                showForm = false
                editingTab = null
            },
        )
    } else {
        OutlinedButton(
            onClick = {
                editingTab = null
                showForm = true
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Tambah Tab Chat Baru") }
    }
}

@Composable
private fun ChatCustomTabForm(
    initial: ChatCustomTabDef?,
    serverKey: String,
    onSave: (ChatCustomTabDef) -> Unit,
    onCancel: () -> Unit,
) {
    var name by remember(initial?.id) { mutableStateOf(initial?.name ?: "") }
    var scope by remember(initial?.id) { mutableStateOf(initial?.scope ?: "global") }
    var applyGlobalBl by remember(initial?.id) { mutableStateOf(initial?.applyGlobalBlacklist ?: true) }
    var wl by remember(initial?.id) { mutableStateOf(initial?.whitelist?.ifEmpty { emptyList() } ?: emptyList()) }
    var bl by remember(initial?.id) { mutableStateOf(initial?.blacklist?.ifEmpty { emptyList() } ?: emptyList()) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = AzaleaPalette.CardAlt,
        border = BorderStroke(1.dp, AzaleaPalette.BorderSelected),
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (initial == null) "Tab Chat Baru" else "Ubah Tab \"${initial.name}\"",
                style = MaterialTheme.typography.labelLarge,
                color = AzaleaPalette.Emerald,
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nama tab (mis. Pemain / Trade / PM)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            if (initial == null && serverKey.isNotBlank()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((sc, lbl) in listOf("global" to "Global", "server" to "Server ini")) {
                        val sel = scope == sc
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { scope = sc },
                            shape = RoundedCornerShape(6.dp),
                            color = if (sel) AzaleaPalette.EmeraldDark else AzaleaPalette.Card,
                            border = BorderStroke(1.dp, if (sel) AzaleaPalette.Emerald else AzaleaPalette.Border),
                        ) {
                            Box(Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                Text(lbl, fontSize = 11.sp, color = AzaleaPalette.TextPrimary)
                            }
                        }
                    }
                }
            }
            SettingSwitchRow(
                title = "Ikut blacklist global",
                subtitle = "Matikan jika tab ini boleh menangkap pesan yang diblokir global",
                checked = applyGlobalBl,
                onCheckedChange = { applyGlobalBl = it },
            )
            HorizontalDivider(color = AzaleaPalette.Border)
            PatternEntryListEditor(
                title = "Whitelist (pesan yang masuk ke tab ini)",
                emptyHint = "Kosong = semua pesan yang tidak kena blacklist akan masuk.",
                entries = wl,
                onChange = { wl = it },
            )
            HorizontalDivider(color = AzaleaPalette.Border)
            PatternEntryListEditor(
                title = "Blacklist khusus tab ini",
                emptyHint = "Kosong = tidak ada pengecualian tambahan.",
                entries = bl,
                onChange = { bl = it },
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onCancel) { Text("Batal") }
                Button(
                    enabled = name.isNotBlank(),
                    onClick = {
                        onSave(
                            ChatCustomTabDef(
                                id = initial?.id ?: UUID.randomUUID().toString(),
                                name = name.trim(),
                                scope = initial?.scope ?: scope,
                                enabled = initial?.enabled ?: true,
                                applyGlobalBlacklist = applyGlobalBl,
                                whitelist = wl.filter { it.pattern.isNotBlank() },
                                blacklist = bl.filter { it.pattern.isNotBlank() },
                            )
                        )
                    },
                ) { Text("Simpan Tab") }
            }
        }
    }
}

@Composable
private fun PatternEntryListEditor(
    title: String,
    emptyHint: String,
    entries: List<ChatPatternEntry>,
    onChange: (List<ChatPatternEntry>) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = AzaleaPalette.TextPrimary)
        if (entries.isEmpty()) {
            Text(emptyHint, style = MaterialTheme.typography.bodySmall, color = AzaleaPalette.TextMuted)
        }
        entries.forEachIndexed { idx, entry ->
            val regexErr = if (entry.kind == "regex") validateRegexError(entry.pattern) else null
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp),
                color = AzaleaPalette.Card,
                border = BorderStroke(1.dp, if (regexErr != null) AzaleaPalette.Danger else AzaleaPalette.Border),
            ) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        for (k in RULE_KIND_MODES) {
                            val selected = entry.kind == k
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(5.dp))
                                    .clickable {
                                        onChange(entries.toMutableList().also { it[idx] = entry.copy(kind = k) })
                                    },
                                shape = RoundedCornerShape(5.dp),
                                color = if (selected) AzaleaPalette.EmeraldDark else AzaleaPalette.CardAlt,
                                border = BorderStroke(1.dp, if (selected) AzaleaPalette.Emerald else AzaleaPalette.Border),
                            ) {
                                Box(Modifier.padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
                                    Text(k, fontSize = 11.sp, color = AzaleaPalette.TextPrimary)
                                }
                            }
                        }
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(5.dp))
                                .clickable {
                                    onChange(entries.toMutableList().also {
                                        it[idx] = entry.copy(caseSensitive = !entry.caseSensitive)
                                    })
                                },
                            shape = RoundedCornerShape(5.dp),
                            color = if (entry.caseSensitive) AzaleaPalette.EmeraldDark else AzaleaPalette.CardAlt,
                            border = BorderStroke(1.dp, if (entry.caseSensitive) AzaleaPalette.Emerald else AzaleaPalette.Border),
                        ) {
                            Box(Modifier.padding(horizontal = 7.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
                                Text("Aa", fontSize = 11.sp, color = AzaleaPalette.TextPrimary)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .clickable {
                                    onChange(entries.toMutableList().also { it.removeAt(idx) })
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(AzaleaIcons.Close, contentDescription = "Hapus", modifier = Modifier.size(13.dp), tint = AzaleaPalette.Danger)
                        }
                    }
                    OutlinedTextField(
                        value = entry.pattern,
                        onValueChange = { v ->
                            onChange(entries.toMutableList().also { it[idx] = entry.copy(pattern = v) })
                        },
                        label = { Text("Pola #${idx + 1}") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (regexErr != null) {
                        Text(regexErr, fontSize = 11.sp, color = AzaleaPalette.Danger)
                    }
                }
            }
        }
        TextButton(
            onClick = { onChange(entries + ChatPatternEntry("match", "", false)) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Tambah Pola") }
    }
}

@Composable
private fun ChatBlacklistSection(
    serverKey: String,
    masterEnabled: Boolean,
    hiddenCount: Int,
    totalCount: Int,
    rules: List<ChatBlacklistRuleUi>,
    storageObj: JSONObject?,
    onToggleMaster: (Boolean) -> Unit,
) {
    var editingRule by remember { mutableStateOf<ChatBlacklistRuleUi?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var formName by remember { mutableStateOf("") }
    var formScope by remember { mutableStateOf("global") }
    var formEntries by remember { mutableStateOf(listOf(ChatPatternEntry("regex", "", false))) }
    val globalRules = remember(rules) { rules.filter { it.scope == "global" } }
    val serverRules = remember(rules) { rules.filter { it.scope == "server" } }

    fun openAddForm() {
        editingRule = null
        formName = ""
        formScope = "global"
        formEntries = listOf(ChatPatternEntry("regex", "", false))
        showForm = true
    }

    fun openEditForm(rule: ChatBlacklistRuleUi) {
        editingRule = rule
        formName = rule.name
        formScope = rule.scope
        formEntries = rule.entries.ifEmpty { listOf(ChatPatternEntry("regex", "", false)) }
        showForm = true
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Aktifkan Blacklist", style = MaterialTheme.typography.titleSmall)
            Text(
                if (masterEnabled) "Live filter aktif ($hiddenCount dari $totalCount pesan disembunyikan)"
                else "Filter nonaktif (semua $totalCount pesan ditampilkan)",
                style = MaterialTheme.typography.bodySmall,
                color = if (masterEnabled && hiddenCount > 0) AzaleaPalette.Sky else AzaleaPalette.TextMuted,
            )
        }
        Switch(checked = masterEnabled, onCheckedChange = onToggleMaster)
    }
    HorizontalDivider(color = AzaleaPalette.Border)
    Text("Global (${globalRules.size})", style = MaterialTheme.typography.titleSmall, color = AzaleaPalette.Emerald)
    if (globalRules.isEmpty()) {
        Text("Belum ada aturan global.", style = MaterialTheme.typography.bodySmall, color = AzaleaPalette.TextMuted)
    } else {
        for (r in globalRules) {
            ChatBlacklistRuleRow(
                rule = r,
                onEdit = { openEditForm(r) },
                onToggle = { en -> setChatBlacklistRuleEnabled(storageObj, serverKey, r, en) },
                onDelete = {
                    if (editingRule == r) showForm = false
                    deleteChatBlacklistRule(storageObj, serverKey, r)
                },
            )
        }
    }
    if (serverKey.isNotBlank()) {
        Spacer(Modifier.height(2.dp))
        Text("Server: $serverKey (${serverRules.size})", style = MaterialTheme.typography.titleSmall, color = AzaleaPalette.Emerald)
        if (serverRules.isEmpty()) {
            Text("Belum ada aturan khusus server ini.", style = MaterialTheme.typography.bodySmall, color = AzaleaPalette.TextMuted)
        } else {
            for (r in serverRules) {
                ChatBlacklistRuleRow(
                    rule = r,
                    onEdit = { openEditForm(r) },
                    onToggle = { en -> setChatBlacklistRuleEnabled(storageObj, serverKey, r, en) },
                    onDelete = {
                        if (editingRule == r) showForm = false
                        deleteChatBlacklistRule(storageObj, serverKey, r)
                    },
                )
            }
        }
    }
    if (showForm) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = AzaleaPalette.CardAlt,
            border = BorderStroke(1.dp, AzaleaPalette.Border),
        ) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (editingRule == null) "Aturan Baru" else "Ubah Aturan",
                    style = MaterialTheme.typography.labelLarge,
                    color = AzaleaPalette.Emerald,
                )
                OutlinedTextField(
                    value = formName,
                    onValueChange = { formName = it },
                    label = { Text("Nama aturan (mis. broadcast)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (editingRule == null && serverKey.isNotBlank()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for ((sc, lbl) in listOf("global" to "Global", "server" to "Server ini")) {
                            val selected = formScope == sc
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { formScope = sc },
                                shape = RoundedCornerShape(6.dp),
                                color = if (selected) AzaleaPalette.EmeraldDark else AzaleaPalette.Card,
                                border = BorderStroke(1.dp, if (selected) AzaleaPalette.Emerald else AzaleaPalette.Border),
                            ) {
                                Box(Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                    Text(lbl, fontSize = 11.sp, color = AzaleaPalette.TextPrimary)
                                }
                            }
                        }
                    }
                }
                PatternEntryListEditor(
                    title = "Pola (tiap pola bisa beda tipe):",
                    emptyHint = "Tambah minimal 1 pola.",
                    entries = formEntries,
                    onChange = { formEntries = it },
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { showForm = false; editingRule = null }) { Text("Batal") }
                    val cleanEntries = formEntries.mapNotNull { e ->
                        val trimmed = e.pattern.trim()
                        if (trimmed.isEmpty()) null else e.copy(pattern = trimmed)
                    }
                    Button(
                        enabled = formName.isNotBlank() && cleanEntries.isNotEmpty(),
                        onClick = {
                            saveChatBlacklistRule(
                                existing = storageObj,
                                serverKey = serverKey,
                                editing = editingRule,
                                scope = formScope,
                                name = formName,
                                entries = cleanEntries,
                            )
                            showForm = false
                            editingRule = null
                        },
                    ) { Text("Simpan") }
                }
            }
        }
    } else {
        OutlinedButton(
            onClick = { openAddForm() },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Tambah Aturan Blacklist") }
    }
}

@Composable
private fun ChatBlacklistRuleRow(
    rule: ChatBlacklistRuleUi,
    onEdit: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onEdit),
        shape = RoundedCornerShape(8.dp),
        color = AzaleaPalette.Card,
        border = BorderStroke(1.dp, AzaleaPalette.Border),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    rule.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val kinds = rule.entries.map { it.kind }.distinct().joinToString(", ").ifBlank { "match" }
                val preview = rule.entries.firstOrNull()?.pattern ?: "(kosong)"
                val countInfo = if (rule.entries.size > 1) " (${rule.entries.size} pola)" else ""
                Text(
                    "$kinds$countInfo · $preview",
                    style = MaterialTheme.typography.bodySmall,
                    color = AzaleaPalette.TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Box(
                modifier = Modifier
                    .padding(end = 6.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onDelete),
                contentAlignment = Alignment.Center,
            ) {
                Icon(AzaleaIcons.Close, contentDescription = "Hapus", modifier = Modifier.size(14.dp), tint = AzaleaPalette.Danger)
            }
            Switch(checked = rule.enabled, onCheckedChange = onToggle)
        }
    }
}
