package com.azalea.app

import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Storage per modul (JSON bebas). Disimpan di HP, dikirim ke inti saat konek, dan dua arah selama konek. */
object ModStorage {
    val data = MutableStateFlow<Map<String, JSONObject>>(emptyMap())

    fun load() {
        val all = Store.storageAll()
        data.value = all.keys().asSequence().associateWith { all.optJSONObject(it) ?: JSONObject() }
    }

    fun all(): JSONObject {
        val o = JSONObject()
        for ((k, v) in data.value) o.put(k, v)
        return o
    }

    private fun copy(m: String) = JSONObject((data.value[m] ?: JSONObject()).toString())

    /** fromUser = true: kirim juga ke inti yang sedang berjalan. */
    @Synchronized
    fun replace(m: String, obj: JSONObject, fromUser: Boolean = true) {
        data.value = data.value + (m to obj)
        Store.storagePut(m, obj)
        if (fromUser) Core.sendStorage(m, obj)
    }

    private fun parentOf(root: JSONObject, path: List<Any>): Any? {
        var cur: Any? = root
        for (p in path.dropLast(1)) {
            cur = when (cur) {
                is JSONObject -> cur.opt(p as String)
                is JSONArray -> cur.opt(p as Int)
                else -> null
            }
        }
        return cur
    }

    fun set(m: String, path: List<Any>, value: Any) {
        if (path.isEmpty()) return
        val root = copy(m)
        when (val par = parentOf(root, path)) {
            is JSONObject -> par.put(path.last() as String, value)
            is JSONArray -> par.put(path.last() as Int, value)
            else -> return
        }
        replace(m, root)
    }

    fun delete(m: String, path: List<Any>) {
        if (path.isEmpty()) return
        val root = copy(m)
        when (val par = parentOf(root, path)) {
            is JSONObject -> par.remove(path.last() as String)
            is JSONArray -> par.remove(path.last() as Int)
            else -> return
        }
        replace(m, root)
    }
}
