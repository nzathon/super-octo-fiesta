package com.azalea.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle

/** Mengubah teks berkode warna ANSI (dari to_ansi() Azalea, termasuk warna hex 24-bit) jadi AnnotatedString. */
object Ansi {
    private val sgr = Regex("\u001B\\[([0-9;]*)m")
    private val anyCsi = Regex("\u001B\\[[0-9;]*[A-Za-z]")

    private val basic = listOf(
        0x3B3B3B, 0xAA0000, 0x00AA00, 0xFFAA00, 0x5555FF, 0xAA00AA, 0x00AAAA, 0xAAAAAA,
        0x555555, 0xFF5555, 0x55FF55, 0xFFFF55, 0x7777FF, 0xFF55FF, 0x55FFFF, 0xFFFFFF
    )

    fun strip(s: String): String = s.replace(anyCsi, "")

    private fun c(rgb: Int) = Color(0xFF000000.toInt() or rgb)

    private fun color256(n: Int): Color = when {
        n < 16 -> c(basic[n])
        n < 232 -> {
            val v = n - 16
            val lv = intArrayOf(0, 95, 135, 175, 215, 255)
            Color(lv[v / 36], lv[(v / 6) % 6], lv[v % 6])
        }
        else -> { val g = 8 + (n - 232) * 10; Color(g, g, g) }
    }

    fun annotated(input: String): AnnotatedString {
        val s = input.replace(Regex("\u001B\\[[0-9;]*[A-Za-ln-z]"), "")   // buang CSI selain "m"
        return buildAnnotatedString {
            var color: Color? = null
            var bold = false
            var italic = false
            var underline = false
            var strike = false
            fun seg(t: String) {
                if (t.isEmpty()) return
                val deco = when {
                    underline && strike -> TextDecoration.combine(listOf(TextDecoration.Underline, TextDecoration.LineThrough))
                    underline -> TextDecoration.Underline
                    strike -> TextDecoration.LineThrough
                    else -> null
                }
                withStyle(
                    SpanStyle(
                        color = color ?: Color.Unspecified,
                        fontWeight = if (bold) FontWeight.Bold else null,
                        fontStyle = if (italic) FontStyle.Italic else null,
                        textDecoration = deco
                    )
                ) { append(t) }
            }
            var last = 0
            for (m in sgr.findAll(s)) {
                seg(s.substring(last, m.range.first))
                last = m.range.last + 1
                val codes = m.groupValues[1].split(";").map { it.toIntOrNull() ?: 0 }.ifEmpty { listOf(0) }
                var i = 0
                while (i < codes.size) {
                    when (val k = codes[i]) {
                        0 -> { color = null; bold = false; italic = false; underline = false; strike = false }
                        1 -> bold = true
                        3 -> italic = true
                        4 -> underline = true
                        9 -> strike = true
                        22 -> bold = false
                        23 -> italic = false
                        24 -> underline = false
                        29 -> strike = false
                        39 -> color = null
                        in 30..37 -> color = c(basic[k - 30])
                        in 90..97 -> color = c(basic[k - 90 + 8])
                        38 -> {
                            if (codes.getOrNull(i + 1) == 2 && i + 4 < codes.size) {
                                color = Color(codes[i + 2].coerceIn(0, 255), codes[i + 3].coerceIn(0, 255), codes[i + 4].coerceIn(0, 255))
                                i += 4
                            } else if (codes.getOrNull(i + 1) == 5 && i + 2 < codes.size) {
                                color = color256(codes[i + 2].coerceIn(0, 255))
                                i += 2
                            }
                        }
                    }
                    i++
                }
            }
            seg(s.substring(last))
        }
    }
}
