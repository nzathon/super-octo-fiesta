package com.azalea.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Server(val id: String, val name: String, val host: String, val port: Int, val version: String)

data class Account(val id: String, val username: String)

fun readUriText(ctx: Context, uri: Uri): String {
    ctx.contentResolver.openInputStream(uri)?.use { ins ->
        return ins.bufferedReader(Charsets.UTF_8).readText()
    }
    throw IllegalStateException("Tidak bisa membuka file")
}

fun writeUriText(ctx: Context, uri: Uri, text: String) {
    ctx.contentResolver.openOutputStream(uri)?.use { out ->
        out.write(text.toByteArray(Charsets.UTF_8))
        out.flush()
        return
    }
    throw IllegalStateException("Tidak bisa menyimpan file")
}

/** Daftar server dan akun (username) yang terpisah, disimpan sebagai JSON di SharedPreferences. */
object Store {
    val revision = MutableStateFlow(0)
    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)
        prefs = p
        if (!p.contains("servers")) migrate(p)
    }

    /** Dari format lama (satu profil = server + username) ke server dan akun terpisah. */
    private fun migrate(p: SharedPreferences) {
        val servers = ArrayList<Server>()
        val accounts = ArrayList<Account>()
        try {
            val a = JSONArray(p.getString("list", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                servers.add(
                    Server(
                        o.optString("id").ifBlank { UUID.randomUUID().toString() }, o.optString("name"),
                        o.optString("host"), o.optInt("port", 25565), o.optString("version", "1.21.11")
                    )
                )
                val u = o.optString("username")
                if (u.isNotBlank() && accounts.none { it.username == u }) accounts.add(Account(UUID.randomUUID().toString(), u))
            }
        } catch (_: Throwable) { }
        saveServers(servers)
        saveAccounts(accounts)
        p.edit().putString("selected", accounts.firstOrNull()?.id ?: "").apply()
    }

    // ----- server -----
    fun servers(): List<Server> {
        val a = JSONArray(prefs?.getString("servers", "[]") ?: "[]")
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Server(o.optString("id"), o.optString("name"), o.optString("host"), o.optInt("port", 25565), o.optString("version", "1.21.11"))
        }
    }

    private fun saveServers(list: List<Server>) {
        val a = JSONArray()
        for (s in list) a.put(JSONObject().put("id", s.id).put("name", s.name).put("host", s.host).put("port", s.port).put("version", s.version))
        prefs?.edit()?.putString("servers", a.toString())?.apply()
    }

    fun upsertServer(s: Server): List<Server> {
        val l = servers().toMutableList()
        val i = l.indexOfFirst { it.id == s.id }
        if (i >= 0) l[i] = s else l.add(s)
        saveServers(l)
        return l
    }

    fun deleteServer(id: String): List<Server> {
        val l = servers().filter { it.id != id }
        saveServers(l)
        return l
    }

    // ----- setelan modul: {"<modul>": {"<kunci>": nilai}} -----
    private fun modules(): JSONObject = try {
        JSONObject(prefs?.getString("modules", "{}") ?: "{}")
    } catch (_: Throwable) { JSONObject() }

    fun modulesJson(): JSONObject = modules()

    fun moduleGet(id: String, key: String): Any? {
        val m = modules().optJSONObject(id) ?: return null
        return if (m.has(key) && !m.isNull(key)) m.get(key) else null
    }

    @Synchronized
    fun moduleSet(id: String, key: String, value: Any) {
        val o = modules()
        val m = o.optJSONObject(id) ?: JSONObject().also { o.put(id, it) }
        m.put(key, value)
        prefs?.edit()?.putString("modules", o.toString())?.apply()
    }

    @Synchronized
    fun moduleReplace(id: String, obj: JSONObject) {
        val o = modules()
        o.put(id, JSONObject(obj.toString()))
        prefs?.edit()?.putString("modules", o.toString())?.apply()
    }

    // ----- storage modul: {"<modul>": {...}} -----
    fun storageAll(): JSONObject = try {
        JSONObject(prefs?.getString("mstorage", "{}") ?: "{}")
    } catch (_: Throwable) { JSONObject() }

    @Synchronized
    fun storagePut(m: String, obj: JSONObject) {
        val o = storageAll()
        o.put(m, obj)
        prefs?.edit()?.putString("mstorage", o.toString())?.apply()
    }

    // ----- akun -----
    fun accounts(): List<Account> {
        val a = JSONArray(prefs?.getString("accounts", "[]") ?: "[]")
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Account(o.optString("id"), o.optString("username"))
        }
    }

    private fun saveAccounts(list: List<Account>) {
        val a = JSONArray()
        for (x in list) a.put(JSONObject().put("id", x.id).put("username", x.username))
        prefs?.edit()?.putString("accounts", a.toString())?.apply()
    }

    fun upsertAccount(x: Account): List<Account> {
        val l = accounts().toMutableList()
        val i = l.indexOfFirst { it.id == x.id }
        if (i >= 0) l[i] = x else l.add(x)
        saveAccounts(l)
        return l
    }

    fun deleteAccount(id: String): List<Account> {
        val l = accounts().filter { it.id != id }
        saveAccounts(l)
        return l
    }

    /** Akun yang dipilih; kalau yang tersimpan sudah tidak ada, pakai akun pertama. */
    fun selectedAccountId(): String {
        val all = accounts()
        val saved = prefs?.getString("selected", "") ?: ""
        return if (all.any { it.id == saved }) saved else (all.firstOrNull()?.id ?: "")
    }

    fun setSelectedAccount(id: String) {
        prefs?.edit()?.putString("selected", id)?.apply()
    }

    // ----- backup & restore penuh -----
    fun exportBackupJson(): String {
        val serversArr = JSONArray()
        for (s in servers()) {
            serversArr.put(
                JSONObject()
                    .put("id", s.id)
                    .put("name", s.name)
                    .put("host", s.host)
                    .put("port", s.port)
                    .put("version", s.version)
            )
        }
        val accountsArr = JSONArray()
        for (a in accounts()) {
            accountsArr.put(JSONObject().put("id", a.id).put("username", a.username))
        }
        return JSONObject()
            .put("type", "azalea_backup")
            .put("version", 1)
            .put("exported_at", System.currentTimeMillis())
            .put("servers", serversArr)
            .put("accounts", accountsArr)
            .put("selected", selectedAccountId())
            .put("modules", modulesJson())
            .put("storage", storageAll())
            .toString(2)
    }

    @Synchronized
    fun restoreBackupJson(raw: String): Result<String> {
        return try {
            val root = JSONObject(raw)
            val kind = root.optString("type", "")
            if (kind == "azalea_module_settings") {
                return Result.failure(IllegalArgumentException("Ini file setelan 1 modul. Import lewat tab Setelan modul terkait."))
            }
            if (kind == "azalea_module_storage") {
                return Result.failure(IllegalArgumentException("Ini file storage 1 modul. Import lewat tab Storage modul terkait."))
            }
            val hasKnownSection = kind == "azalea_backup" ||
                root.has("servers") || root.has("accounts") || root.has("modules") || root.has("storage")
            if (!hasKnownSection) {
                return Result.failure(IllegalArgumentException("Format file backup tidak dikenali."))
            }

            var svCount = 0
            var accCount = 0
            var modCount = 0
            var stCount = 0

            if (root.has("servers")) {
                val arr = root.optJSONArray("servers") ?: JSONArray()
                val next = ArrayList<Server>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val host = o.optString("host").trim()
                    if (host.isEmpty()) continue
                    next.add(
                        Server(
                            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                            name = o.optString("name").ifBlank { host },
                            host = host,
                            port = o.optInt("port", 25565),
                            version = o.optString("version", "auto").ifBlank { "auto" },
                        )
                    )
                }
                saveServers(next)
                svCount = next.size
            }

            if (root.has("accounts")) {
                val arr = root.optJSONArray("accounts") ?: JSONArray()
                val next = ArrayList<Account>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val user = o.optString("username").trim()
                    if (user.isEmpty()) continue
                    next.add(
                        Account(
                            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                            username = user,
                        )
                    )
                }
                saveAccounts(next)
                accCount = next.size
            }

            if (root.has("selected")) {
                setSelectedAccount(root.optString("selected", ""))
            } else if (root.has("accounts")) {
                setSelectedAccount(selectedAccountId())
            }

            if (root.has("modules")) {
                val modsObj = root.optJSONObject("modules") ?: JSONObject()
                val cleanMods = JSONObject()
                for (modId in modsObj.keys()) {
                    val mVal = modsObj.optJSONObject(modId) ?: continue
                    cleanMods.put(modId, JSONObject(mVal.toString()))
                    modCount++
                }
                prefs?.edit()?.putString("modules", cleanMods.toString())?.apply()
                for (modId in cleanMods.keys()) {
                    val mVal = cleanMods.optJSONObject(modId) ?: continue
                    for (k in mVal.keys()) {
                        val v = mVal.opt(k)
                        if (v != null && v != JSONObject.NULL) {
                            Core.sendSetting(modId, k, v)
                        }
                    }
                }
            }

            if (root.has("storage")) {
                val stObj = root.optJSONObject("storage") ?: JSONObject()
                val cleanSt = JSONObject()
                for (modId in stObj.keys()) {
                    val sVal = stObj.optJSONObject(modId) ?: continue
                    cleanSt.put(modId, JSONObject(sVal.toString()))
                    stCount++
                }
                prefs?.edit()?.putString("mstorage", cleanSt.toString())?.apply()
                ModStorage.load()
                for (modId in cleanSt.keys()) {
                    val sVal = cleanSt.optJSONObject(modId) ?: continue
                    Core.sendStorage(modId, sVal)
                }
            }

            Modules.notifyExternalReload()
            revision.value++
            Result.success("Backup dipulihkan ($svCount server, $accCount akun, $modCount setelan modul, $stCount storage)")
        } catch (e: Throwable) {
            Result.failure(IllegalArgumentException("Gagal membaca backup: ${e.message ?: e.javaClass.simpleName}"))
        }
    }
}
