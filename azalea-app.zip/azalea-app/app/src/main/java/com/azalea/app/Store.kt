package com.azalea.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Server(val id: String, val name: String, val host: String, val port: Int, val version: String)

data class Account(val id: String, val username: String, val password: String = "")

/** Daftar server dan akun (username) yang terpisah, disimpan sebagai JSON di SharedPreferences. */
object Store {
    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)
        prefs = p
        if (!p.contains("servers")) migrate(p)
    }

    /** Dari format lama (satu profil = server + username) ke server dan akun terpisah. */
    private fun migrate(p: SharedPreferences) {
        val servers = ArrayList<Server>()
        val accounts = ArrayList<Account>()
        try {
            val a = JSONArray(p.getString("list", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                servers.add(
                    Server(
                        o.optString("id").ifBlank { UUID.randomUUID().toString() }, o.optString("name"),
                        o.optString("host"), o.optInt("port", 25565), o.optString("version", "1.21.11")
                    )
                )
                val u = o.optString("username")
                if (u.isNotBlank() && accounts.none { it.username == u }) accounts.add(Account(UUID.randomUUID().toString(), u))
            }
        } catch (_: Throwable) { }
        if (servers.isEmpty()) servers.add(Server("crispy", "crispy", "play.crispymc.net", 25565, "1.21.11"))
        saveServers(servers)
        saveAccounts(accounts)
        p.edit().putString("selected", accounts.firstOrNull()?.id ?: "").apply()
    }

    // ----- server -----
    fun servers(): List<Server> {
        val a = JSONArray(prefs?.getString("servers", "[]") ?: "[]")
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Server(o.optString("id"), o.optString("name"), o.optString("host"), o.optInt("port", 25565), o.optString("version", "1.21.11"))
        }
    }

    private fun saveServers(list: List<Server>) {
        val a = JSONArray()
        for (s in list) a.put(JSONObject().put("id", s.id).put("name", s.name).put("host", s.host).put("port", s.port).put("version", s.version))
        prefs?.edit()?.putString("servers", a.toString())?.apply()
    }

    fun upsertServer(s: Server): List<Server> {
        val l = servers().toMutableList()
        val i = l.indexOfFirst { it.id == s.id }
        if (i >= 0) l[i] = s else l.add(s)
        saveServers(l)
        return l
    }

    fun deleteServer(id: String): List<Server> {
        val l = servers().filter { it.id != id }
        saveServers(l)
        return l
    }

    // ----- akun -----
    fun accounts(): List<Account> {
        val a = JSONArray(prefs?.getString("accounts", "[]") ?: "[]")
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Account(o.optString("id"), o.optString("username"), o.optString("password"))
        }
    }

    private fun saveAccounts(list: List<Account>) {
        val a = JSONArray()
        for (x in list) a.put(JSONObject().put("id", x.id).put("username", x.username).put("password", x.password))
        prefs?.edit()?.putString("accounts", a.toString())?.apply()
    }

    fun upsertAccount(x: Account): List<Account> {
        val l = accounts().toMutableList()
        val i = l.indexOfFirst { it.id == x.id }
        if (i >= 0) l[i] = x else l.add(x)
        saveAccounts(l)
        return l
    }

    fun deleteAccount(id: String): List<Account> {
        val l = accounts().filter { it.id != id }
        saveAccounts(l)
        return l
    }

    /** Akun yang dipilih; kalau yang tersimpan sudah tidak ada, pakai akun pertama. */
    fun selectedAccountId(): String {
        val all = accounts()
        val saved = prefs?.getString("selected", "") ?: ""
        return if (all.any { it.id == saved }) saved else (all.firstOrNull()?.id ?: "")
    }

    fun setSelectedAccount(id: String) {
        prefs?.edit()?.putString("selected", id)?.apply()
    }
}
