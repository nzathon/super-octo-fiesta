plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val runNumber: Int = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toIntOrNull() ?: 0

android {
    namespace = "com.azalea.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.azalea.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 100 + runNumber
        versionName = "0.1.$runNumber"
        ndk { abiFilters += listOf("arm64-v8a") }   // HP 64-bit saja; armeabi-v7a dibuang supaya APK lebih kecil
    }

    signingConfigs {
        create("blockchat") {
            storeFile = file("blockchat.keystore")
            storePassword = "blockchat"
            keyAlias = "blockchat"
            keyPassword = "blockchat"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("blockchat") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("blockchat")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }

    // libazalea.so (program Rust) dibuat oleh GitHub Actions ke app/src/main/jniLibs/arm64-v8a/
    packaging {
        jniLibs { useLegacyPackaging = true }
        resources {
            excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/*.kotlin_module")
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")   // WebSocket ke Node
}
