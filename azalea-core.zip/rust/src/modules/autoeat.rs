// Modul Auto Eat: otomatis memakan makanan di hotbar ketika bar lapar turun di bawah batas, lalu kembali ke slot semula.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use azalea_inventory::components::Food;
use azalea_inventory::ItemStack;
use azalea::prelude::*;
use serde_json::json;

use super::monitor::{handle_of, item_name, Soft};
use super::{Def, Setting};
use crate::settings;

const ID: &str = "autoeat";

static BUSY: AtomicBool = AtomicBool::new(false);
static GEN: AtomicU64 = AtomicU64::new(0);
static LAST_CHECK_AT: Mutex<Option<Instant>> = Mutex::new(None);
static LAST_WARN_AT: Mutex<Option<Instant>> = Mutex::new(None);

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Auto Eat",
        desc: "Otomatis memilih makanan di hotbar dan makan saat bar lapar di bawah batas, lalu mengembalikan slot sebelumnya.",
        enabled: false,
        settings: vec![
            Setting { key: "min_food", label: "Batas lapar mulai makan (1-19)", kind: "number", default: json!(14) },
            Setting { key: "delay_ms", label: "Jeda sebelum makan (ms)", kind: "number", default: json!(400) },
            Setting { key: "restore_slot", label: "Kembalikan ke slot semula", kind: "boolean", default: json!(true) },
            Setting { key: "allow_raw", label: "Izinkan makanan berisiko (daging busuk, dll)", kind: "boolean", default: json!(false) },
        ],
    }
}

fn is_risky_food(name: &str) -> bool {
    matches!(
        name,
        "rotten_flesh"
            | "spider_eye"
            | "poisonous_potato"
            | "pufferfish"
            | "suspicious_stew"
            | "chorus_fruit"
            | "chicken"
    )
}

fn is_known_food_name(name: &str) -> bool {
    matches!(
        name,
        "apple"
            | "baked_potato"
            | "beef"
            | "beetroot"
            | "beetroot_soup"
            | "bread"
            | "carrot"
            | "chicken"
            | "chorus_fruit"
            | "cod"
            | "cooked_beef"
            | "cooked_chicken"
            | "cooked_cod"
            | "cooked_mutton"
            | "cooked_porkchop"
            | "cooked_rabbit"
            | "cooked_salmon"
            | "cookie"
            | "dried_kelp"
            | "enchanted_golden_apple"
            | "glow_berries"
            | "golden_apple"
            | "golden_carrot"
            | "honey_bottle"
            | "melon_slice"
            | "mushroom_stew"
            | "mutton"
            | "poisonous_potato"
            | "porkchop"
            | "potato"
            | "pufferfish"
            | "pumpkin_pie"
            | "rabbit"
            | "rabbit_stew"
            | "rotten_flesh"
            | "salmon"
            | "spider_eye"
            | "suspicious_stew"
            | "sweet_berries"
            | "tropical_fish"
    )
}

fn food_score(item: &ItemStack, allow_raw: bool) -> Option<i32> {
    let ItemStack::Present(d) = item else { return None; };
    let name = item_name(item);
    let risky = is_risky_food(&name);
    if risky && !allow_raw {
        return None;
    }
    let comp_nutrition = d.get_component::<Food>().map(|f| f.nutrition);
    let nutrition = match comp_nutrition {
        Some(n) => n,
        None if is_known_food_name(&name) => 4,
        None => return None,
    };
    // Hindari memakan golden apple/enchanted golden apple duluan kalau ada makanan biasa
    let priority = if name == "enchanted_golden_apple" {
        -200
    } else if name == "golden_apple" {
        -100
    } else if risky {
        -50
    } else {
        nutrition
    };
    Some(priority)
}

fn find_best_food_hotbar(bot: &Client, allow_raw: bool) -> Option<(u8, String)> {
    let slots = handle_of(bot).and_then(|h| h.slots())?;
    let mut best: Option<(i32, u8, String)> = None;
    for hb in 0..9u8 {
        if let Some(item) = slots.get(36 + hb as usize) {
            if let Some(score) = food_score(item, allow_raw) {
                let take = best.as_ref().map(|(s, _, _)| score > *s).unwrap_or(true);
                if take {
                    best = Some((score, hb, item_name(item)));
                }
            }
        }
    }
    best.map(|(_, hb, name)| (hb, name))
}

fn warn_throttled(msg: &str) {
    let mut g = LAST_WARN_AT.lock().unwrap();
    if g.as_ref().map(|t| t.elapsed() < Duration::from_secs(20)).unwrap_or(false) {
        return;
    }
    *g = Some(Instant::now());
    crate::log(format!("autoeat: {msg}"));
}

fn reset_state() {
    GEN.fetch_add(1, Ordering::SeqCst);
    BUSY.store(false, Ordering::SeqCst);
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login | Event::Spawn => {
            reset_state();
        }
        Event::Tick => {
            if !settings::enabled(ID) {
                return;
            }
            if BUSY.load(Ordering::SeqCst) {
                return;
            }
            {
                let mut g = LAST_CHECK_AT.lock().unwrap();
                if g.as_ref().map(|t| t.elapsed() < Duration::from_millis(500)).unwrap_or(false) {
                    return;
                }
                *g = Some(Instant::now());
            }
            let Ok(hunger) = bot.hunger() else {
                return;
            };
            let min_food = settings::get_f64(ID, "min_food").clamp(1.0, 19.0) as u32;
            if hunger.food > min_food {
                return;
            }
            let allow_raw = settings::get_bool(ID, "allow_raw");
            let Some((food_slot, food_name)) = find_best_food_hotbar(bot, allow_raw) else {
                warn_throttled("lapar di bawah batas, tapi tidak ada makanan di hotbar");
                return;
            };
            if BUSY.swap(true, Ordering::SeqCst) {
                return;
            }
            let prev_slot = bot.selected_hotbar_slot().soft().unwrap_or(0).min(8) as u8;
            let delay_ms = settings::get_f64(ID, "delay_ms").clamp(0.0, 5000.0) as u64;
            let restore = settings::get_bool(ID, "restore_slot");
            let my_gen = GEN.load(Ordering::SeqCst);
            let b = bot.clone();

            tokio::spawn(async move {
                if delay_ms > 0 {
                    tokio::time::sleep(Duration::from_millis(delay_ms)).await;
                }
                if !settings::enabled(ID) || GEN.load(Ordering::SeqCst) != my_gen {
                    BUSY.store(false, Ordering::SeqCst);
                    return;
                }
                if prev_slot != food_slot {
                    let _ = b.set_selected_hotbar_slot(food_slot);
                    tokio::time::sleep(Duration::from_millis(160)).await;
                }
                let start_food = b.hunger().map(|h| h.food).unwrap_or(hunger.food);
                crate::log(format!("autoeat: makan {food_name} (lapar {start_food}/20)"));
                let _ = b.start_use_item();

                // Tunggu proses makan (vanilla ~1.6 detik), keluar lebih cepat bila lapar sudah naik
                for step in 0..14 {
                    tokio::time::sleep(Duration::from_millis(200)).await;
                    if !settings::enabled(ID) || GEN.load(Ordering::SeqCst) != my_gen {
                        break;
                    }
                    if step >= 7 {
                        if let Ok(cur) = b.hunger() {
                            if cur.food > start_food {
                                break;
                            }
                        }
                    }
                }
                if restore && prev_slot != food_slot && GEN.load(Ordering::SeqCst) == my_gen {
                    let _ = b.set_selected_hotbar_slot(prev_slot);
                }
                BUSY.store(false, Ordering::SeqCst);
            });
        }
        _ => {}
    }
}
