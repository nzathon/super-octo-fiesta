// Modul Auto Eat: otomatis memakan makanan atau Enchanted Golden Apple (egapp) terus-menerus
// serta auto refill/restock dari inventory utama ke hotbar agar tidak berhenti.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use azalea_inventory::components::Food;
use azalea_inventory::item::MaxStackSizeExt;
use azalea_inventory::ItemStack;
use azalea::prelude::*;
use serde_json::json;

use super::monitor::{handle_of, item_name, Soft};
use super::{Def, Setting};
use crate::settings;

const ID: &str = "autoeat";
const PLAYER_MENU_LEN: usize = 46;

static BUSY: AtomicBool = AtomicBool::new(false);
static GEN: AtomicU64 = AtomicU64::new(0);
static LAST_CHECK_AT: Mutex<Option<Instant>> = Mutex::new(None);
static LAST_WARN_AT: Mutex<Option<Instant>> = Mutex::new(None);
static LAST_EGAPP_AT: Mutex<Option<Instant>> = Mutex::new(None);
static LAST_FOOD_HB: Mutex<Option<u8>> = Mutex::new(None);

struct BusyGuard;
impl Drop for BusyGuard {
    fn drop(&mut self) {
        BUSY.store(false, Ordering::SeqCst);
    }
}

pub fn is_busy() -> bool {
    BUSY.load(Ordering::SeqCst)
}

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Auto Eat",
        desc: "Otomatis makan saat lapar atau makan Enchanted Golden Apple (egapp) terus-menerus tanpa melihat HP/lapar, dilengkapi auto refill dari tas ke hotbar.",
        enabled: false,
        settings: vec![
            Setting { key: "egapp_always", label: "Makan Egapp terus-menerus (abaikan HP/lapar)", kind: "boolean", default: json!(false) },
            Setting { key: "egapp_interval", label: "Jeda antar makan Egapp (detik, 0 = nonstop)", kind: "number", default: json!(0) },
            Setting { key: "auto_refill", label: "Auto refill/restock dari tas ke hotbar", kind: "boolean", default: json!(true) },
            Setting { key: "min_food", label: "Batas lapar mulai makan (1-19)", kind: "number", default: json!(14) },
            Setting { key: "delay_ms", label: "Jeda sebelum makan (ms)", kind: "number", default: json!(400) },
            Setting { key: "restore_slot", label: "Kembalikan ke slot semula", kind: "boolean", default: json!(true) },
            Setting { key: "allow_raw", label: "Izinkan makanan berisiko (daging busuk, dll)", kind: "boolean", default: json!(false) },
        ],
    }
}

fn is_risky_food(name: &str) -> bool {
    matches!(
        name,
        "rotten_flesh"
            | "spider_eye"
            | "poisonous_potato"
            | "pufferfish"
            | "suspicious_stew"
            | "chorus_fruit"
            | "chicken"
    )
}

fn is_known_food_name(name: &str) -> bool {
    matches!(
        name,
        "apple"
            | "baked_potato"
            | "beef"
            | "beetroot"
            | "beetroot_soup"
            | "bread"
            | "carrot"
            | "chicken"
            | "chorus_fruit"
            | "cod"
            | "cooked_beef"
            | "cooked_chicken"
            | "cooked_cod"
            | "cooked_mutton"
            | "cooked_porkchop"
            | "cooked_rabbit"
            | "cooked_salmon"
            | "cookie"
            | "dried_kelp"
            | "enchanted_golden_apple"
            | "glow_berries"
            | "golden_apple"
            | "golden_carrot"
            | "honey_bottle"
            | "melon_slice"
            | "mushroom_stew"
            | "mutton"
            | "poisonous_potato"
            | "porkchop"
            | "potato"
            | "pufferfish"
            | "pumpkin_pie"
            | "rabbit"
            | "rabbit_stew"
            | "rotten_flesh"
            | "salmon"
            | "spider_eye"
            | "suspicious_stew"
            | "sweet_berries"
            | "tropical_fish"
    )
}

fn food_score(item: &ItemStack, allow_raw: bool) -> Option<i32> {
    let ItemStack::Present(d) = item else { return None; };
    let name = item_name(item);
    let risky = is_risky_food(&name);
    if risky && !allow_raw {
        return None;
    }
    let comp_nutrition = d.get_component::<Food>().map(|f| f.nutrition);
    let nutrition = match comp_nutrition {
        Some(n) => n,
        None if is_known_food_name(&name) => 4,
        None => return None,
    };
    // Hindari memakan golden apple/enchanted golden apple duluan kalau ada makanan biasa saat mode lapar biasa
    let priority = if name == "enchanted_golden_apple" {
        -200
    } else if name == "golden_apple" {
        -100
    } else if risky {
        -50
    } else {
        nutrition
    };
    Some(priority)
}

fn find_egapp_hotbar(bot: &Client) -> Option<(u8, String)> {
    let h = handle_of(bot)?;
    if h.id() != 0 {
        return None;
    }
    let slots = h.slots()?;
    if slots.len() != PLAYER_MENU_LEN {
        return None;
    }
    let preferred = *LAST_FOOD_HB.lock().unwrap();
    if let Some(phb) = preferred {
        if let Some(item) = slots.get(36 + phb as usize) {
            if item.is_present() && item_name(item) == "enchanted_golden_apple" {
                return Some((phb, "enchanted_golden_apple".to_string()));
            }
        }
    }
    for hb in 0..9u8 {
        if let Some(item) = slots.get(36 + hb as usize) {
            if item.is_present() && item_name(item) == "enchanted_golden_apple" {
                return Some((hb, "enchanted_golden_apple".to_string()));
            }
        }
    }
    None
}

fn find_best_food_hotbar(bot: &Client, allow_raw: bool) -> Option<(u8, String)> {
    let h = handle_of(bot)?;
    if h.id() != 0 {
        return None;
    }
    let slots = h.slots()?;
    if slots.len() != PLAYER_MENU_LEN {
        return None;
    }
    let mut best: Option<(i32, u8, String)> = None;
    for hb in 0..9u8 {
        if let Some(item) = slots.get(36 + hb as usize) {
            if let Some(score) = food_score(item, allow_raw) {
                let take = best.as_ref().map(|(s, _, _)| score > *s).unwrap_or(true);
                if take {
                    best = Some((score, hb, item_name(item)));
                }
            }
        }
    }
    best.map(|(_, hb, name)| (hb, name))
}

fn find_refill_source_slot(slots: &[ItemStack], target_egapp: bool, allow_raw: bool) -> Option<(usize, String)> {
    if target_egapp {
        let mut best: Option<(i32, usize)> = None;
        for slot in 9..36usize {
            if let Some(item) = slots.get(slot) {
                if item.is_present() && item_name(item) == "enchanted_golden_apple" {
                    let cnt = item.count();
                    // Ambil tumpukan paling kecil dulu agar slot tas cepat rapi, atau yang pertama ketemu
                    if best.map(|(bc, _)| cnt < bc).unwrap_or(true) {
                        best = Some((cnt, slot));
                    }
                }
            }
        }
        return best.map(|(_, slot)| (slot, "enchanted_golden_apple".to_string()));
    }

    let mut best: Option<(i32, usize, String)> = None;
    for slot in 9..36usize {
        if let Some(item) = slots.get(slot) {
            if let Some(score) = food_score(item, allow_raw) {
                let take = best.as_ref().map(|(s, _, _)| score > *s).unwrap_or(true);
                if take {
                    best = Some((score, slot, item_name(item)));
                }
            }
        }
    }
    best.map(|(_, slot, name)| (slot, name))
}

fn has_refillable_food(bot: &Client, target_egapp: bool, allow_raw: bool) -> bool {
    let Some(h) = handle_of(bot) else {
        return false;
    };
    if h.id() != 0 {
        return false;
    }
    let Some(slots) = h.slots() else {
        return false;
    };
    if slots.len() != PLAYER_MENU_LEN {
        return false;
    }
    if find_refill_source_slot(&slots, target_egapp, allow_raw).is_some() {
        return true;
    }
    // Cek offhand (slot 45) hanya jika ada slot hotbar kosong agar tidak menukar alat ke offhand
    let has_empty_hb = (0..9usize).any(|hb| slots.get(36 + hb).map(|s| s.is_empty()).unwrap_or(false));
    if has_empty_hb {
        if let Some(off) = slots.get(45) {
            if off.is_present() {
                if target_egapp {
                    return item_name(off) == "enchanted_golden_apple";
                }
                return food_score(off, allow_raw).is_some();
            }
        }
    }
    false
}

async fn refill_food_to_hotbar(
    b: &Client,
    target_egapp: bool,
    allow_raw: bool,
    preferred_hb: Option<u8>,
    fallback_hb: u8,
    my_gen: u64,
) -> bool {
    let Some(h) = handle_of(b) else {
        return false;
    };
    if h.id() != 0 {
        return false;
    }
    let Some(slots) = h.slots() else {
        return false;
    };
    if slots.len() != PLAYER_MENU_LEN {
        return false;
    }

    let empty_hb = preferred_hb
        .filter(|&hb| slots.get(36 + hb as usize).map(|s| s.is_empty()).unwrap_or(false))
        .or_else(|| (0..9u8).find(|&hb| slots.get(36 + hb as usize).map(|s| s.is_empty()).unwrap_or(false)));

    let (inv_slot, moved_name) = if let Some(found) = find_refill_source_slot(&slots, target_egapp, allow_raw) {
        found
    } else if empty_hb.is_some() {
        if let Some(off) = slots.get(45) {
            let off_ok = off.is_present()
                && if target_egapp {
                    item_name(off) == "enchanted_golden_apple"
                } else {
                    food_score(off, allow_raw).is_some()
                };
            if off_ok {
                (45usize, item_name(off))
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else {
        return false;
    };

    let Some(src_data) = slots.get(inv_slot).and_then(|s| s.as_present()) else {
        return false;
    };

    // Prioritas 1: gabung ke slot hotbar yang sudah berisi item sama dan belum penuh
    let merge_hb = if inv_slot != 45 && src_data.kind.stackable() {
        let max_stack = src_data.kind.max_stack_size();
        (0..9u8).find(|&hb| {
            slots
                .get(36 + hb as usize)
                .and_then(|s| s.as_present())
                .is_some_and(|d| d.count < max_stack && d.is_same_item_and_components(src_data))
        })
    } else {
        None
    };

    let (target_hb, use_shift_merge, slot_is_empty) = if let Some(mhb) = merge_hb {
        (mhb, true, false)
    } else if let Some(ehb) = empty_hb {
        (ehb, false, true)
    } else if inv_slot != 45 {
        let thb = preferred_hb.unwrap_or(fallback_hb).min(8);
        (thb, false, false)
    } else {
        return false;
    };

    let Ok(Some(inv)) = b.open_inventory() else {
        return false;
    };

    if use_shift_merge {
        inv.shift_click(inv_slot);
    } else if slot_is_empty {
        inv.left_click(inv_slot);
        tokio::time::sleep(Duration::from_millis(70)).await;
        if GEN.load(Ordering::SeqCst) == my_gen {
            inv.left_click(36 + target_hb as usize);
        }
    } else {
        inv.left_click(inv_slot);
        tokio::time::sleep(Duration::from_millis(70)).await;
        if GEN.load(Ordering::SeqCst) == my_gen {
            inv.left_click(36 + target_hb as usize);
        }
        tokio::time::sleep(Duration::from_millis(70)).await;
        if GEN.load(Ordering::SeqCst) == my_gen {
            inv.left_click(inv_slot);
        }
    }

    drop(inv);
    tokio::time::sleep(Duration::from_millis(90)).await;

    if GEN.load(Ordering::SeqCst) != my_gen {
        return false;
    }

    *LAST_FOOD_HB.lock().unwrap() = Some(target_hb);
    crate::log(format!(
        "autoeat: restock {moved_name} ke hotbar {}",
        target_hb + 1
    ));
    true
}

fn slot_count_matching(bot: &Client, slot_idx: usize, expected_name: &str) -> i32 {
    let Some(h) = handle_of(bot) else {
        return 0;
    };
    if h.id() != 0 {
        return 0;
    }
    let Some(slots) = h.slots() else {
        return 0;
    };
    match slots.get(slot_idx) {
        Some(item) if item.is_present() && item_name(item) == expected_name => item.count(),
        _ => 0,
    }
}

fn warn_throttled(msg: &str) {
    let mut g = LAST_WARN_AT.lock().unwrap();
    if g.as_ref().map(|t| t.elapsed() < Duration::from_secs(20)).unwrap_or(false) {
        return;
    }
    *g = Some(Instant::now());
    crate::log(format!("autoeat: {msg}"));
}

fn reset_state() {
    GEN.fetch_add(1, Ordering::SeqCst);
    BUSY.store(false, Ordering::SeqCst);
    *LAST_EGAPP_AT.lock().unwrap() = None;
    *LAST_FOOD_HB.lock().unwrap() = None;
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login | Event::Spawn | Event::Disconnect(_) => {
            reset_state();
        }
        Event::Tick => {
            if !settings::enabled(ID) || BUSY.load(Ordering::SeqCst) {
                return;
            }
            {
                let mut g = LAST_CHECK_AT.lock().unwrap();
                if g.as_ref().map(|t| t.elapsed() < Duration::from_millis(250)).unwrap_or(false) {
                    return;
                }
                *g = Some(Instant::now());
            }
            let Some(h) = handle_of(bot) else {
                return;
            };
            if h.id() != 0 {
                return;
            }

            let egapp_always = settings::get_bool(ID, "egapp_always");
            let egapp_interval = settings::get_f64(ID, "egapp_interval").max(0.0);
            let auto_refill = settings::get_bool(ID, "auto_refill");
            let allow_raw = settings::get_bool(ID, "allow_raw");
            let min_food = settings::get_f64(ID, "min_food").clamp(1.0, 19.0) as u32;

            let mut want_egapp = false;
            if egapp_always {
                let interval_ok = if egapp_interval <= 0.0 {
                    true
                } else {
                    LAST_EGAPP_AT
                        .lock()
                        .unwrap()
                        .as_ref()
                        .map(|t| t.elapsed() >= Duration::from_secs_f64(egapp_interval))
                        .unwrap_or(true)
                };
                if interval_ok {
                    if find_egapp_hotbar(bot).is_some() || (auto_refill && has_refillable_food(bot, true, allow_raw)) {
                        want_egapp = true;
                    } else {
                        warn_throttled("mode egapp aktif, tapi stok enchanted_golden_apple habis");
                    }
                }
            }

            if !want_egapp {
                let Ok(hunger) = bot.hunger() else {
                    return;
                };
                if hunger.food > min_food {
                    return;
                }
                if find_best_food_hotbar(bot, allow_raw).is_none()
                    && !(auto_refill && has_refillable_food(bot, false, allow_raw))
                {
                    warn_throttled("lapar di bawah batas, tapi tidak ada makanan di hotbar/tas");
                    return;
                }
            }

            if BUSY.swap(true, Ordering::SeqCst) {
                return;
            }

            let delay_ms = settings::get_f64(ID, "delay_ms").clamp(0.0, 5000.0) as u64;
            let restore = settings::get_bool(ID, "restore_slot");
            let my_gen = GEN.load(Ordering::SeqCst);
            let b = bot.clone();

            tokio::spawn(async move {
                let _guard = BusyGuard;

                if delay_ms > 0 {
                    tokio::time::sleep(Duration::from_millis(delay_ms)).await;
                }
                if !settings::enabled(ID) || GEN.load(Ordering::SeqCst) != my_gen {
                    return;
                }
                if handle_of(&b).map(|h| h.id() != 0).unwrap_or(true) {
                    return;
                }

                let prev_slot = b.selected_hotbar_slot().soft().unwrap_or(0).min(8) as u8;
                let last_hb = *LAST_FOOD_HB.lock().unwrap();

                let found = if want_egapp {
                    find_egapp_hotbar(&b)
                } else {
                    find_best_food_hotbar(&b, allow_raw)
                };

                let (food_slot, food_name) = match found {
                    Some(v) => v,
                    None if auto_refill => {
                        if !refill_food_to_hotbar(&b, want_egapp, allow_raw, last_hb, prev_slot, my_gen).await {
                            return;
                        }
                        if !settings::enabled(ID) || GEN.load(Ordering::SeqCst) != my_gen {
                            return;
                        }
                        let after = if want_egapp {
                            find_egapp_hotbar(&b)
                        } else {
                            find_best_food_hotbar(&b, allow_raw)
                        };
                        let Some(v) = after else {
                            return;
                        };
                        v
                    }
                    None => return,
                };

                *LAST_FOOD_HB.lock().unwrap() = Some(food_slot);
                let start_count = slot_count_matching(&b, 36 + food_slot as usize, &food_name);
                if start_count <= 0 {
                    return;
                }

                if prev_slot != food_slot {
                    let _ = b.set_selected_hotbar_slot(food_slot);
                    tokio::time::sleep(Duration::from_millis(160)).await;
                    if !settings::enabled(ID) || GEN.load(Ordering::SeqCst) != my_gen {
                        if restore {
                            let _ = b.set_selected_hotbar_slot(prev_slot);
                        }
                        return;
                    }
                    if handle_of(&b).map(|h| h.id() != 0).unwrap_or(true) {
                        return;
                    }
                }

                let start_food = b.hunger().map(|h| h.food).unwrap_or(20);
                if want_egapp {
                    crate::log(format!("autoeat: makan {food_name} (mode egapp, stok slot {start_count})"));
                } else {
                    crate::log(format!("autoeat: makan {food_name} (lapar {start_food}/20)"));
                }

                let _ = b.start_use_item();

                // Tunggu proses makan (vanilla 32 tick / ~1.6 detik); deteksi selesai via jumlah stack berkurang atau bar lapar naik
                for step in 0..15 {
                    tokio::time::sleep(Duration::from_millis(200)).await;
                    if !settings::enabled(ID) || GEN.load(Ordering::SeqCst) != my_gen {
                        break;
                    }
                    if handle_of(&b).map(|h| h.id() != 0).unwrap_or(true) {
                        break;
                    }
                    if step >= 6 {
                        let cur_count = slot_count_matching(&b, 36 + food_slot as usize, &food_name);
                        if cur_count < start_count {
                            break;
                        }
                        if !want_egapp {
                            if let Ok(cur) = b.hunger() {
                                if cur.food > start_food {
                                    break;
                                }
                            }
                        }
                    }
                }

                if want_egapp || food_name == "enchanted_golden_apple" {
                    *LAST_EGAPP_AT.lock().unwrap() = Some(Instant::now());
                }

                // Auto restock langsung jika tumpukan di slot hotbar baru saja habis
                if auto_refill
                    && settings::enabled(ID)
                    && GEN.load(Ordering::SeqCst) == my_gen
                    && slot_count_matching(&b, 36 + food_slot as usize, &food_name) == 0
                {
                    let _ = refill_food_to_hotbar(&b, want_egapp, allow_raw, Some(food_slot), prev_slot, my_gen).await;
                }

                let skip_restore_nonstop = want_egapp
                    && egapp_interval <= 0.0
                    && delay_ms < 250
                    && find_egapp_hotbar(&b).is_some();

                if restore && prev_slot != food_slot && !skip_restore_nonstop && GEN.load(Ordering::SeqCst) == my_gen {
                    let _ = b.set_selected_hotbar_slot(prev_slot);
                }
            });
        }
        _ => {}
    }
}
