// Modul Auto Fish: otomatis menarik pancing saat terdengar suara cipratan (fishing_bobber.splash),
// lalu melempar ulang dengan jeda acak manusiawi serta menjaga durability pancingan.
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use azalea_inventory::components::{Damage, MaxDamage};
use azalea_inventory::ItemStack;
use azalea::prelude::*;
use azalea::protocol::packets::game::ClientboundGamePacket;
use azalea::registry::builtin::SoundEvent;
use azalea::registry::Holder;
use serde_json::json;
use super::monitor::Soft;
use super::{Def, Setting};
use crate::settings;

const ID: &str = "autofish";

static BUSY: AtomicBool = AtomicBool::new(false);
static CASTED: AtomicBool = AtomicBool::new(false);
static GEN: AtomicU64 = AtomicU64::new(0);
static LAST_CAST_AT: Mutex<Option<Instant>> = Mutex::new(None);
static LAST_WARN_AT: Mutex<Option<Instant>> = Mutex::new(None);

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Auto Fish",
        desc: "Memancing otomatis: mendeteksi suara cipratan bobber, menarik pancing dengan jeda acak, melempar ulang, dan menjaga durability pancingan agar tidak patah.",
        enabled: false,
        settings: vec![
            Setting { key: "react_min_ms", label: "Jeda reaksi min (ms)", kind: "number", default: json!(250) },
            Setting { key: "react_max_ms", label: "Jeda reaksi maks (ms)", kind: "number", default: json!(500) },
            Setting { key: "recast_delay", label: "Jeda lempar ulang (detik)", kind: "number", default: json!(0.8) },
            Setting { key: "idle_timeout", label: "Lempar ulang jika diam (detik, 0 = mati)", kind: "number", default: json!(45) },
            Setting { key: "min_durability", label: "Batas sisa durability (0 = abaikan)", kind: "number", default: json!(5) },
            Setting { key: "auto_swap_rod", label: "Ganti pancingan lain di hotbar", kind: "boolean", default: json!(true) },
        ],
    }
}

fn rand_between_ms(min_ms: u64, max_ms: u64) -> u64 {
    let lo = min_ms.min(max_ms);
    let hi = min_ms.max(max_ms);
    if lo == hi {
        return lo;
    }
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.subsec_nanos() as u64 ^ (d.as_secs().wrapping_mul(6364136223846793005)))
        .unwrap_or(1234567);
    lo + (nanos % (hi - lo + 1))
}

fn is_fishing_rod(item: &ItemStack) -> bool {
    item.is_present() && super::monitor::item_name(item) == "fishing_rod"
}

/// Sisa durability item (`None` jika item tidak punya komponen MaxDamage).
fn remaining_durability(item: &ItemStack) -> Option<i64> {
    let ItemStack::Present(d) = item else { return None; };
    let max = d.get_component::<MaxDamage>().map(|x| x.amount as i64).unwrap_or(64);
    let dmg = d.get_component::<Damage>().map(|x| x.amount as i64).unwrap_or(0);
    Some((max - dmg).max(0))
}

fn warn_throttled(msg: &str) {
    let mut g = LAST_WARN_AT.lock().unwrap();
    if g.as_ref().map(|t| t.elapsed() < Duration::from_secs(10)).unwrap_or(false) {
        return;
    }
    *g = Some(Instant::now());
    crate::log(format!("autofish: {msg}"));
}

/// Pastikan bot sedang memegang pancingan yang cukup kuat. Mengembalikan `true` jika siap dipakai.
fn ensure_ready_rod(bot: &Client) -> bool {
    let min_dur = settings::get_f64(ID, "min_durability").max(0.0) as i64;
    let Some(slots) = super::monitor::handle_of(bot).and_then(|h| h.slots()) else {
        return false;
    };
    let held_idx = bot.selected_hotbar_slot().soft().unwrap_or(0).min(8) as usize;
    if let Some(item) = slots.get(36 + held_idx) {
        if is_fishing_rod(item) {
            let rem = remaining_durability(item).unwrap_or(64);
            if min_dur == 0 || rem > min_dur {
                return true;
            }
        }
    }
    if !settings::get_bool(ID, "auto_swap_rod") {
        warn_throttled("tidak memegang pancingan atau durability hampir habis");
        return false;
    }
    // Cari pancingan lain di hotbar (slot 36..=44)
    for hb in 0..9 {
        if let Some(item) = slots.get(36 + hb) {
            if is_fishing_rod(item) {
                let rem = remaining_durability(item).unwrap_or(64);
                if min_dur == 0 || rem > min_dur {
                    let _ = bot.set_selected_hotbar_slot(hb as u8);
                    crate::log(format!("autofish: pindah ke pancingan di hotbar {}", hb + 1));
                    return true;
                }
            }
        }
    }
    warn_throttled("tidak ada pancingan aman di hotbar");
    false
}

fn is_splash_sound(sound: &Holder<SoundEvent, azalea::core::sound::CustomSound>) -> bool {
    match sound {
        Holder::Reference(s) => *s == SoundEvent::EntityFishingBobberSplash,
        Holder::Direct(c) => c.sound_id.to_string().contains("fishing_bobber.splash"),
    }
}

fn reset_state() {
    GEN.fetch_add(1, Ordering::SeqCst);
    BUSY.store(false, Ordering::SeqCst);
    CASTED.store(false, Ordering::SeqCst);
    *LAST_CAST_AT.lock().unwrap() = None;
}

pub fn on_packet(bot: &Client, packet: &ClientboundGamePacket) {
    if !settings::enabled(ID) || !CASTED.load(Ordering::SeqCst) {
        return;
    }
    let splash = match packet {
        ClientboundGamePacket::Sound(p) if is_splash_sound(&p.sound) => {
            // Cek jarak dari posisi bot (koordinat paket Sound dalam satuan 1/8 blok)
            if let Ok(pos) = bot.position() {
                let dx = (p.x as f64 / 8.0) - pos.x;
                let dy = (p.y as f64 / 8.0) - pos.y;
                let dz = (p.z as f64 / 8.0) - pos.z;
                dx * dx + dy * dy + dz * dz <= 24.0 * 24.0
            } else {
                true
            }
        }
        ClientboundGamePacket::SoundEntity(p) if is_splash_sound(&p.sound) => true,
        _ => false,
    };
    if !splash || BUSY.swap(true, Ordering::SeqCst) {
        return;
    }
    let my_gen = GEN.load(Ordering::SeqCst);
    let b = bot.clone();
    tokio::spawn(async move {
        let min_ms = settings::get_f64(ID, "react_min_ms").clamp(50.0, 3000.0) as u64;
        let max_ms = settings::get_f64(ID, "react_max_ms").clamp(50.0, 3000.0) as u64;
        let react = rand_between_ms(min_ms, max_ms);
        tokio::time::sleep(Duration::from_millis(react)).await;
        if !settings::enabled(ID) || GEN.load(Ordering::SeqCst) != my_gen {
            BUSY.store(false, Ordering::SeqCst);
            return;
        }
        // Tarik pancingan
        let _ = b.start_use_item();
        CASTED.store(false, Ordering::SeqCst);
        let recast_s = settings::get_f64(ID, "recast_delay").clamp(0.2, 10.0);
        let recast_ms = (recast_s * 1000.0) as u64 + rand_between_ms(0, 180);
        tokio::time::sleep(Duration::from_millis(recast_ms)).await;
        if settings::enabled(ID) && GEN.load(Ordering::SeqCst) == my_gen && ensure_ready_rod(&b) {
            let _ = b.start_use_item();
            CASTED.store(true, Ordering::SeqCst);
            *LAST_CAST_AT.lock().unwrap() = Some(Instant::now());
        }
        BUSY.store(false, Ordering::SeqCst);
    });
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login | Event::Spawn => {
            reset_state();
        }
        Event::Tick => {
            if !settings::enabled(ID) {
                if CASTED.load(Ordering::SeqCst) {
                    reset_state();
                }
                return;
            }
            if BUSY.load(Ordering::SeqCst) {
                return;
            }
            let cast_needed = if !CASTED.load(Ordering::SeqCst) {
                true
            } else {
                let timeout = settings::get_f64(ID, "idle_timeout").max(0.0);
                if timeout <= 0.0 {
                    false
                } else {
                    LAST_CAST_AT
                        .lock()
                        .unwrap()
                        .as_ref()
                        .map(|t| t.elapsed() >= Duration::from_secs_f64(timeout))
                        .unwrap_or(false)
                }
            };
            if !cast_needed {
                return;
            }
            if !ensure_ready_rod(bot) {
                return;
            }
            let was_casted = CASTED.load(Ordering::SeqCst);
            if was_casted {
                // Tarik dulu jika timeout diam tercapai, lalu lempar ulang
                if BUSY.swap(true, Ordering::SeqCst) {
                    return;
                }
                let my_gen = GEN.load(Ordering::SeqCst);
                let b = bot.clone();
                tokio::spawn(async move {
                    let _ = b.start_use_item();
                    CASTED.store(false, Ordering::SeqCst);
                    tokio::time::sleep(Duration::from_millis(700)).await;
                    if settings::enabled(ID) && GEN.load(Ordering::SeqCst) == my_gen && ensure_ready_rod(&b) {
                        let _ = b.start_use_item();
                        CASTED.store(true, Ordering::SeqCst);
                        *LAST_CAST_AT.lock().unwrap() = Some(Instant::now());
                    }
                    BUSY.store(false, Ordering::SeqCst);
                });
            } else {
                let _ = bot.start_use_item();
                CASTED.store(true, Ordering::SeqCst);
                *LAST_CAST_AT.lock().unwrap() = Some(Instant::now());
            }
        }
        _ => {}
    }
}
