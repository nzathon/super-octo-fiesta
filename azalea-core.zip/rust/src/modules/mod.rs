// Daftar modul. Menambah modul baru = buat file modul (contoh: chat.rs), lalu tambahkan
// 1 baris `pub mod`, 1 baris di `all()`, dan 1 baris di `dispatch()`.
// Jika modul butuh tab WebView sendiri, cukup daftarkan di `web_tabs()` + `dispatch_web()`
// dan taruh file HTML-nya di `app/src/main/assets/` (ikut terbawa di `azalea-core-pack`).
use azalea::prelude::*;
use serde_json::{json, Value};

use crate::settings;

pub mod autoclick;
pub mod autoeat;
pub mod autofish;
pub mod autorespawn;
pub mod chat;
pub mod monitor;
pub mod playerlist;
pub mod relogin;
pub mod shopscanner;

pub struct Setting {
    pub key: &'static str,
    pub label: &'static str,
    /// boolean | text | number | password
    pub kind: &'static str,
    pub default: Value,
}

pub struct Def {
    pub id: &'static str,
    pub title: &'static str,
    pub desc: &'static str,
    pub enabled: bool,
    pub settings: Vec<Setting>,
}

pub struct WebTab {
    pub id: &'static str,
    pub title: &'static str,
    pub html: &'static str,
    pub channel: &'static str,
    /// ID modul terkait (mis. "automine"). Jika diisi, tab otomatis tersembunyi saat modul dimatikan.
    pub module: &'static str,
}

pub fn all() -> Vec<Def> {
    vec![
        autoclick::def(),
        autofish::def(),
        autoeat::def(),
        autorespawn::def(),
        chat::def(),
        playerlist::def(),
        monitor::def(),
        relogin::def(),
        shopscanner::def(),
    ]
}

/// Tab WebView dinamis tambahan (di luar tab Monitor bawaan).
/// Modul Rust baru yang punya halaman HTML sendiri cukup didaftarkan di sini agar muncul
/// di layar Sesi tanpa perlu build ulang APK.
pub fn web_tabs() -> Vec<WebTab> {
    vec![WebTab {
        id: "shopscanner",
        title: "Shop",
        html: "shopscanner.html",
        channel: "shopscanner",
        module: "shopscanner",
    }]
}

/// Nilai awal setelan, dibuat sekali (dulu dibangun ulang tiap event sehingga tiap paket jadi mahal).
static DEFAULTS: std::sync::OnceLock<std::collections::HashMap<&'static str, std::collections::HashMap<&'static str, Value>>> =
    std::sync::OnceLock::new();

pub fn default_of(module: &str, key: &str) -> Value {
    let map = DEFAULTS.get_or_init(|| {
        let mut m: std::collections::HashMap<&'static str, std::collections::HashMap<&'static str, Value>> =
            std::collections::HashMap::new();
        for d in all() {
            let e = m.entry(d.id).or_default();
            e.insert("enabled", json!(d.enabled));
            for s in d.settings {
                e.insert(s.key, s.default);
            }
        }
        m
    });
    map.get(module).and_then(|e| e.get(key)).cloned().unwrap_or(Value::Null)
}

/// Skema yang dikirim ke aplikasi supaya layar Modul tergambar otomatis.
pub fn schema() -> Value {
    let list: Vec<Value> = all()
        .into_iter()
        .map(|d| {
            json!({
                "id": d.id, "title": d.title, "desc": d.desc, "enabled": d.enabled,
                "settings": d.settings.iter().map(|s| json!({
                    "key": s.key, "label": s.label, "type": s.kind, "default": s.default
                })).collect::<Vec<_>>()
            })
        })
        .collect();
    Value::Array(list)
}

/// Skema tab WebView dinamis tambahan untuk layar Sesi.
pub fn tabs_schema() -> Value {
    let list: Vec<Value> = web_tabs()
        .into_iter()
        .map(|t| {
            json!({
                "id": t.id,
                "title": t.title,
                "html": t.html,
                "channel": t.channel,
                "module": t.module,
            })
        })
        .collect();
    Value::Array(list)
}

/// Setiap event dari server diteruskan ke modul yang aktif.
pub async fn dispatch(bot: &Client, event: &Event) {
    // selalu dipanggil: perlu melepas klik kiri saat modul dimatikan
    autoclick::on_event(bot, event).await;
    autofish::on_event(bot, event).await;
    autoeat::on_event(bot, event).await;
    autorespawn::on_event(bot, event).await;
    shopscanner::on_event(bot, event).await;
    if settings::enabled("chat") {
        chat::on_event(bot, event).await;
    }
    if settings::enabled("playerlist") {
        playerlist::on_event(bot, event).await;
    }
    if settings::enabled("monitor") {
        monitor::on_event(bot, event).await;
    }
    if settings::enabled("relogin") {
        relogin::on_event(bot, event).await;
    }
}

/// Aksi dari tab WebView dinamis (`{"t":"web","ch":..,"a":..,"v":..}`) diteruskan ke modul terkait.
pub async fn dispatch_web(bot: &Client, channel: &str, action: &str, payload: &Value) {
    match channel {
        "shopscanner" => {
            if settings::enabled("shopscanner") {
                shopscanner::dispatch_web(bot, action, payload).await;
            }
        }
        _ => {}
    }
}
