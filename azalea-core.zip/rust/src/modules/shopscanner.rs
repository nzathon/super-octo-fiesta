// Modul Shop Scanner: memindai seluruh menu & sub-menu shop per server, menyimpan daftar item/harga
// ke Storage (per host:port), menyediakan pencarian instan & buka halaman item lewat tab WebView "Shop".
use std::collections::HashSet;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant};

use azalea::prelude::*;
use regex::Regex;
use serde_json::{json, Value};

use super::monitor::{
    extra_of, handle_of, item_name, now_epoch_ms, plain_of_spans, refresh_monitor_view,
    title_case_words,
};
use super::{Def, Setting};
use crate::{settings, storage};

const ID: &str = "shopscanner";
const PLAYER_MENU_LEN: usize = 46;

static SCANNING: AtomicBool = AtomicBool::new(false);
static SCAN_GEN: AtomicU64 = AtomicU64::new(0);
static PROGRESS: Mutex<Option<ScanProgress>> = Mutex::new(None);

#[derive(Clone, Default)]
struct ScanProgress {
    running: bool,
    phase: String,
    category: String,
    page: usize,
    cat_index: usize,
    cat_total: usize,
    found_count: usize,
    error: String,
}

impl ScanProgress {
    fn to_json(&self) -> Value {
        json!({
            "running": self.running,
            "phase": self.phase,
            "category": self.category,
            "page": self.page,
            "cat_index": self.cat_index,
            "cat_total": self.cat_total,
            "found_count": self.found_count,
            "error": self.error,
        })
    }
}

#[derive(Clone)]
struct ShopConfig {
    open_cmd: String,
    back_slot: i64,
    next_slot: i64,
    prev_slot: i64,
    category_slots: Vec<usize>,
    exclude_slots: Vec<usize>,
    click_delay_ms: u64,
    open_delay_ms: u64,
    max_pages: usize,
    skip_glass: bool,
}

impl Default for ShopConfig {
    fn default() -> Self {
        Self {
            open_cmd: "/shop".to_string(),
            back_slot: 49,
            next_slot: 53,
            prev_slot: 45,
            category_slots: Vec::new(),
            exclude_slots: Vec::new(),
            click_delay_ms: 700,
            open_delay_ms: 1200,
            max_pages: 15,
            skip_glass: true,
        }
    }
}

#[derive(Clone)]
struct TopSlot {
    slot: usize,
    id: String,
    count: i64,
    label: String,
    lore_lines: Vec<String>,
    ench_texts: Vec<String>,
    enchanted: bool,
    hash: Option<String>,
    pot: Option<String>,
    price_hint: String,
    buy_price: Option<f64>,
    sell_price: Option<f64>,
}

#[derive(Clone)]
struct TopMenu {
    title: String,
    top_len: usize,
    slots: Vec<Option<TopSlot>>,
    fingerprint: String,
}

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Shop Scanner",
        desc: "Memindai isi shop & sub-halaman per server (slot Back, Right/Next, Exclude), mencari item & harga di tab Shop, serta membuka halaman item langsung.",
        enabled: true,
        settings: vec![
            Setting {
                key: "default_open_cmd",
                label: "Perintah buka shop bawaan (untuk server baru)",
                kind: "text",
                default: json!("/shop"),
            },
            Setting {
                key: "default_click_delay_ms",
                label: "Jeda klik scan bawaan (ms, min 250)",
                kind: "number",
                default: json!(700),
            },
        ],
    }
}

fn server_key() -> String {
    let h = settings::host();
    if h.is_empty() {
        return String::new();
    }
    format!("{}:{}", h, settings::port())
}

fn format_slot_list(slots: &[usize]) -> String {
    slots
        .iter()
        .map(|s| s.to_string())
        .collect::<Vec<_>>()
        .join(",")
}

fn parse_slot_list(v: &Value) -> Vec<usize> {
    let mut out = Vec::new();
    match v {
        Value::Array(arr) => {
            for item in arr {
                if let Some(n) = item.as_u64() {
                    let s = n as usize;
                    if s < 54 && !out.contains(&s) {
                        out.push(s);
                    }
                }
            }
        }
        Value::String(s) => {
            for part in s.split(|c: char| c == ',' || c.is_whitespace()) {
                let t = part.trim();
                if t.is_empty() {
                    continue;
                }
                if let Ok(n) = t.parse::<usize>() {
                    if n < 54 && !out.contains(&n) {
                        out.push(n);
                    }
                }
            }
        }
        _ => {}
    }
    out
}

fn default_config_from_module_settings() -> ShopConfig {
    let mut cfg = ShopConfig::default();
    let cmd = settings::get_str(ID, "default_open_cmd").trim().to_string();
    if !cmd.is_empty() {
        cfg.open_cmd = cmd;
    }
    let delay = settings::get_f64(ID, "default_click_delay_ms");
    if delay >= 250.0 {
        cfg.click_delay_ms = (delay as u64).clamp(250, 5000);
    }
    cfg
}

fn config_to_json(c: &ShopConfig) -> Value {
    json!({
        "open_cmd": c.open_cmd,
        "back_slot": c.back_slot,
        "next_slot": c.next_slot,
        "prev_slot": c.prev_slot,
        "category_slots": format_slot_list(&c.category_slots),
        "exclude_slots": format_slot_list(&c.exclude_slots),
        "click_delay_ms": c.click_delay_ms,
        "open_delay_ms": c.open_delay_ms,
        "max_pages": c.max_pages,
        "skip_glass": c.skip_glass,
    })
}

fn parse_i64_field(v: &Value, key: &str, fallback: i64) -> i64 {
    match &v[key] {
        Value::Number(n) => n.as_i64().unwrap_or(fallback),
        Value::String(s) => s.trim().parse::<i64>().unwrap_or(fallback),
        _ => fallback,
    }
}

fn parse_u64_field(v: &Value, key: &str, fallback: u64) -> u64 {
    match &v[key] {
        Value::Number(n) => n.as_u64().unwrap_or(fallback),
        Value::String(s) => s.trim().parse::<u64>().unwrap_or(fallback),
        _ => fallback,
    }
}

fn parse_config(v: &Value, base: &ShopConfig) -> ShopConfig {
    if !v.is_object() {
        return base.clone();
    }
    let open_cmd = if v["open_cmd"].is_string() {
        v["open_cmd"].as_str().unwrap_or("").trim().to_string()
    } else {
        base.open_cmd.clone()
    };
    let back_slot = parse_i64_field(v, "back_slot", base.back_slot).clamp(-1, 53);
    let next_slot = parse_i64_field(v, "next_slot", base.next_slot).clamp(-1, 53);
    let prev_slot = parse_i64_field(v, "prev_slot", base.prev_slot).clamp(-1, 53);
    let category_slots = if !v["category_slots"].is_null() {
        parse_slot_list(&v["category_slots"])
    } else {
        base.category_slots.clone()
    };
    let exclude_slots = if !v["exclude_slots"].is_null() {
        parse_slot_list(&v["exclude_slots"])
    } else {
        base.exclude_slots.clone()
    };
    let click_delay_ms =
        parse_u64_field(v, "click_delay_ms", base.click_delay_ms).clamp(250, 5000);
    let open_delay_ms = parse_u64_field(v, "open_delay_ms", base.open_delay_ms).clamp(400, 8000);
    let max_pages = (parse_u64_field(v, "max_pages", base.max_pages as u64) as usize).clamp(1, 50);
    let skip_glass = v["skip_glass"].as_bool().unwrap_or(base.skip_glass);

    ShopConfig {
        open_cmd,
        back_slot,
        next_slot,
        prev_slot,
        category_slots,
        exclude_slots,
        click_delay_ms,
        open_delay_ms,
        max_pages,
        skip_glass,
    }
}

fn ensure_server_entry() {
    let k = server_key();
    if k.is_empty() {
        return;
    }
    let mut root = storage::get(ID);
    let mut changed = false;
    if !root["servers"].is_object() {
        root["servers"] = json!({});
        changed = true;
    }
    let def_cfg = default_config_from_module_settings();
    if !root["servers"][&k].is_object() {
        root["servers"][&k] = json!({
            "config": config_to_json(&def_cfg),
            "items": [],
            "last_scan_ms": 0,
            "categories_count": 0,
        });
        changed = true;
    } else {
        if !root["servers"][&k]["config"].is_object() {
            root["servers"][&k]["config"] = config_to_json(&def_cfg);
            changed = true;
        } else {
            let parsed = parse_config(&root["servers"][&k]["config"], &def_cfg);
            let normalized = config_to_json(&parsed);
            if root["servers"][&k]["config"] != normalized {
                root["servers"][&k]["config"] = normalized;
                changed = true;
            }
        }
        if !root["servers"][&k]["items"].is_array() {
            root["servers"][&k]["items"] = json!([]);
            changed = true;
        }
    }
    if changed {
        storage::save(ID, root);
    }
}

fn current_config() -> ShopConfig {
    let k = server_key();
    let def_cfg = default_config_from_module_settings();
    if k.is_empty() {
        return def_cfg;
    }
    let root = storage::get(ID);
    parse_config(&root["servers"][&k]["config"], &def_cfg)
}

fn update_config_from_json(v: &Value) -> ShopConfig {
    ensure_server_entry();
    let k = server_key();
    let base = current_config();
    let next = parse_config(v, &base);
    if !k.is_empty() {
        let mut root = storage::get(ID);
        root["servers"][&k]["config"] = config_to_json(&next);
        storage::save(ID, root);
    }
    next
}

fn emit_data() {
    ensure_server_entry();
    let k = server_key();
    let root = storage::get(ID);
    let srv = &root["servers"][&k];
    let cfg = config_to_json(&current_config());
    let items = if srv["items"].is_array() {
        srv["items"].clone()
    } else {
        json!([])
    };
    let last_scan_ms = srv["last_scan_ms"].as_u64().unwrap_or(0);
    let categories_count = srv["categories_count"].as_u64().unwrap_or(0);

    crate::web_emit(
        ID,
        "data",
        false,
        json!({
            "type": "data",
            "server": k,
            "config": cfg,
            "items": items,
            "last_scan_ms": last_scan_ms,
            "categories_count": categories_count,
        }),
    );
}

fn set_progress(p: ScanProgress) {
    {
        let mut g = PROGRESS.lock().unwrap();
        *g = Some(p.clone());
    }
    crate::web_emit(
        ID,
        "progress",
        false,
        json!({
            "type": "progress",
            "server": server_key(),
            "scan": p.to_json(),
        }),
    );
}

fn emit_progress() {
    let p = PROGRESS
        .lock()
        .unwrap()
        .clone()
        .unwrap_or_else(|| ScanProgress {
            running: SCANNING.load(Ordering::SeqCst),
            ..Default::default()
        });
    crate::web_emit(
        ID,
        "progress",
        false,
        json!({
            "type": "progress",
            "server": server_key(),
            "scan": p.to_json(),
        }),
    );
}

fn is_glass_or_filler(id: &str, label: &str, skip_glass: bool) -> bool {
    if !skip_glass {
        return false;
    }
    if id.ends_with("_stained_glass_pane") || id == "glass_pane" {
        return true;
    }
    if label.trim().is_empty()
        && (id.ends_with("_stained_glass")
            || id == "glass"
            || id == "gray_carpet"
            || id == "black_carpet"
            || id == "white_carpet")
    {
        return true;
    }
    false
}

fn is_nav_or_excluded(slot: usize, cfg: &ShopConfig) -> bool {
    if cfg.back_slot >= 0 && cfg.back_slot as usize == slot {
        return true;
    }
    if cfg.next_slot >= 0 && cfg.next_slot as usize == slot {
        return true;
    }
    if cfg.prev_slot >= 0 && cfg.prev_slot as usize == slot {
        return true;
    }
    cfg.exclude_slots.contains(&slot)
}

fn extract_price_hint(lore: &[String]) -> String {
    let mut hints = Vec::new();
    for line in lore {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        let lower = trimmed.to_ascii_lowercase();
        let matches_price = trimmed.contains('$')
            || lower.contains("rp")
            || lower.contains("coin")
            || lower.contains("money")
            || lower.contains("price")
            || lower.contains("harga")
            || lower.contains("buy")
            || lower.contains("beli")
            || lower.contains("sell")
            || lower.contains("jual")
            || lower.contains("cost")
            || lower.contains("worth")
            || lower.contains("token")
            || lower.contains("emerald");
        if matches_price {
            hints.push(trimmed.to_string());
            if hints.len() >= 2 {
                break;
            }
        }
    }
    hints.join(" · ")
}

fn kw_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r"(?i)\b(harga\s+beli|harga\s+jual|buy\s+price|sell\s+price|buy|purchase|beli|sell|jual|price|harga|cost|worth)\b")
            .unwrap()
    })
}

fn dis_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r"(?i)\b(disabled|n/a|none|not\s+buyable|cannot\s+buy|cannot\s+be\s+bought|tidak\s+bisa\s+dibeli|unbuyable|not\s+sellable|cannot\s+sell|cannot\s+be\s+sold|tidak\s+bisa\s+dijual|tidak\s+dapat\s+dijual|unsellable|non-sellable|tidak\s+ada)\b")
            .unwrap()
    })
}

fn num_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r"(?i)(\$|\brp\.?|\bidr\b|€|£|¥)?\s*([0-9][0-9.,]*)\s*(rb|ribu|jt|juta|miliar|k|m|b|t)?(\s*(?:\$|coins?|money|tokens?|emeralds?|xp|idr|x))?")
            .unwrap()
    })
}

fn parse_num_token(raw_num: &str, suf: &str) -> Option<f64> {
    let num_str = raw_num.trim_end_matches(|c| c == '.' || c == ',');
    if num_str.is_empty() {
        return None;
    }
    let mult = match suf.to_ascii_lowercase().as_str() {
        "" => 1.0,
        "k" | "rb" | "ribu" => 1_000.0,
        "m" | "jt" | "juta" => 1_000_000.0,
        "b" | "miliar" => 1_000_000_000.0,
        "t" => 1_000_000_000_000.0,
        _ => 1.0,
    };
    let has_dot = num_str.contains('.');
    let has_com = num_str.contains(',');
    let cleaned = if has_dot && has_com {
        let ld = num_str.rfind('.').unwrap_or(0);
        let lc = num_str.rfind(',').unwrap_or(0);
        if ld > lc && num_str.len() - ld - 1 <= 2 {
            num_str.replace(',', "")
        } else if lc > ld && num_str.len() - lc - 1 <= 2 {
            num_str.replace('.', "").replace(',', ".")
        } else {
            num_str.replace(['.', ','], "")
        }
    } else if has_com {
        let parts: Vec<&str> = num_str.split(',').collect();
        if parts.len() > 1 && parts[1..].iter().all(|p| p.len() == 3) && parts[0] != "0" {
            parts.concat()
        } else if parts.len() == 2 && parts[1].len() <= 2 {
            format!("{}.{}", parts[0], parts[1])
        } else {
            parts.concat()
        }
    } else if has_dot {
        let parts: Vec<&str> = num_str.split('.').collect();
        if parts.len() > 2 || (parts.len() == 2 && parts[1].len() == 3 && parts[0] != "0") {
            parts.concat()
        } else {
            num_str.to_string()
        }
    } else {
        num_str.to_string()
    };
    let val = cleaned.parse::<f64>().ok()? * mult;
    if val.is_finite() && val >= 0.0 {
        Some(val)
    } else {
        None
    }
}

fn extract_price_from_slice(sl: &str) -> Option<f64> {
    if dis_regex().is_match(sl) {
        return None;
    }
    let mut sub = sl;
    for sep in [":", "="] {
        if let Some((_, after)) = sl.split_once(sep) {
            if after.chars().any(|c| c.is_ascii_digit()) {
                sub = after;
                break;
            }
        }
    }
    let mut best: Option<f64> = None;
    let mut best_score: i32 = -1;
    for cap in num_regex().captures_iter(sub) {
        let pre = cap.get(1).is_some();
        let num_s = cap.get(2).map(|m| m.as_str()).unwrap_or("");
        let suf = cap.get(3).map(|m| m.as_str()).unwrap_or("");
        let post_trim = cap
            .get(4)
            .map(|m| m.as_str().trim().to_ascii_lowercase())
            .unwrap_or_default();
        if post_trim == "x" && !pre && suf.is_empty() {
            continue;
        }
        let Some(val) = parse_num_token(num_s, suf) else {
            continue;
        };
        let score = if pre || !suf.is_empty() || (!post_trim.is_empty() && post_trim != "x") {
            10
        } else {
            0
        };
        if score > best_score {
            best_score = score;
            best = Some(val);
        }
    }
    best
}

fn parse_buy_sell_prices(lore: &[String]) -> (Option<f64>, Option<f64>) {
    let mut buy: Option<f64> = None;
    let mut sell: Option<f64> = None;
    let mut generic: Option<f64> = None;
    let re = kw_regex();

    for line in lore {
        let matches: Vec<_> = re.find_iter(line).collect();
        if matches.is_empty() {
            continue;
        }
        for (idx, m) in matches.iter().enumerate() {
            let end = m.end();
            let nxt = matches.get(idx + 1).map(|n| n.start()).unwrap_or(line.len());
            let sl = &line[end..nxt];
            let kw = m.as_str().to_ascii_lowercase();
            let Some(val) = extract_price_from_slice(sl) else {
                continue;
            };
            if kw.contains("buy") || kw.contains("beli") || kw.contains("purchase") {
                if buy.is_none() {
                    buy = Some(val);
                }
            } else if kw.contains("sell") || kw.contains("jual") {
                if sell.is_none() {
                    sell = Some(val);
                }
            } else if generic.is_none() {
                generic = Some(val);
            }
        }
    }

    if buy.is_none() {
        buy = generic;
    }
    (buy, sell)
}

fn capture_top_menu(bot: &Client) -> Option<TopMenu> {
    let h = handle_of(bot)?;
    let all_slots = h.slots()?;
    let total = all_slots.len();
    if total == PLAYER_MENU_LEN || total < 37 {
        return None;
    }
    let top_len = total - 36;
    let title = h
        .title()
        .map(|t| crate::clean(&t.to_string()))
        .unwrap_or_default();

    let mut slots = Vec::with_capacity(top_len);
    let mut fp = format!("{top_len}|{title}|");

    for (i, item) in all_slots.iter().take(top_len).enumerate() {
        let Some(d) = item.as_present().filter(|_| item.is_present()) else {
            slots.push(None);
            continue;
        };
        let id = item_name(item);
        let x = extra_of(Some(bot), &id, d);
        let label = if x.label.trim().is_empty() {
            title_case_words(&id)
        } else {
            x.label.trim().to_string()
        };
        let lore_lines: Vec<String> = x
            .lore
            .iter()
            .map(|spans| plain_of_spans(spans).trim().to_string())
            .filter(|l| !l.is_empty())
            .collect();
        let ench_texts: Vec<String> = x
            .ench
            .iter()
            .map(|(n, lvl)| format!("{} {}", title_case_words(n), lvl))
            .collect();
        let price_hint = extract_price_hint(&lore_lines);
        let (buy_price, sell_price) = parse_buy_sell_prices(&lore_lines);
        let count = d.count as i64;

        fp.push_str(&format!("{i}:{id}:{count}:{label}:"));
        for l in &lore_lines {
            fp.push_str(l);
            fp.push(';');
        }
        fp.push('|');

        slots.push(Some(TopSlot {
            slot: i,
            id,
            count,
            label,
            lore_lines,
            ench_texts,
            enchanted: x.enchanted,
            hash: x.hash,
            pot: x.pot,
            price_hint,
            buy_price,
            sell_price,
        }));
    }

    Some(TopMenu {
        title,
        top_len,
        slots,
        fingerprint: fp,
    })
}

fn emit_open_menu(bot: &Client) {
    let cfg = current_config();
    let payload = match capture_top_menu(bot) {
        Some(m) => {
            let slots: Vec<Value> = m
                .slots
                .iter()
                .enumerate()
                .map(|(idx, opt)| match opt {
                    Some(s) => json!({
                        "slot": idx,
                        "id": s.id,
                        "count": s.count,
                        "label": s.label,
                        "filler": is_glass_or_filler(&s.id, &s.label, cfg.skip_glass),
                        "hash": s.hash,
                        "pot": s.pot,
                        "e": s.enchanted,
                    }),
                    None => Value::Null,
                })
                .collect();
            json!({
                "type": "menu",
                "open_menu": {
                    "gui": true,
                    "title": m.title,
                    "top_len": m.top_len,
                    "slots": slots,
                }
            })
        }
        None => json!({
            "type": "menu",
            "open_menu": { "gui": false }
        }),
    };
    crate::web_emit(ID, "menu", false, payload);
}

fn cancelled(gen: u64) -> bool {
    SCAN_GEN.load(Ordering::SeqCst) != gen
}

async fn wait_settle(bot: &Client, gen: u64) -> Option<TopMenu> {
    let mut prev = capture_top_menu(bot);
    for _ in 0..6 {
        if cancelled(gen) {
            return None;
        }
        tokio::time::sleep(Duration::from_millis(140)).await;
        let cur = capture_top_menu(bot);
        match (&prev, &cur) {
            (Some(a), Some(b)) if a.fingerprint == b.fingerprint => return cur,
            _ => prev = cur,
        }
    }
    prev
}

async fn open_main_menu(bot: &Client, cfg: &ShopConfig, gen: u64) -> Option<TopMenu> {
    if let Some(m) = capture_top_menu(bot) {
        return Some(m);
    }
    if cfg.open_cmd.trim().is_empty() {
        return None;
    }
    bot.chat(cfg.open_cmd.trim());
    tokio::time::sleep(Duration::from_millis(cfg.open_delay_ms)).await;
    let deadline = Instant::now() + Duration::from_millis(4000);
    while Instant::now() < deadline {
        if cancelled(gen) {
            return None;
        }
        if capture_top_menu(bot).is_some() {
            return wait_settle(bot, gen).await;
        }
        tokio::time::sleep(Duration::from_millis(150)).await;
    }
    None
}

async fn reopen_main_menu(bot: &Client, cfg: &ShopConfig, gen: u64) -> Option<TopMenu> {
    if let Some(h) = handle_of(bot) {
        if h.slots().map(|s| s.len() != PLAYER_MENU_LEN).unwrap_or(false) {
            h.close();
            tokio::time::sleep(Duration::from_millis(350)).await;
        }
    }
    if cfg.open_cmd.trim().is_empty() {
        return None;
    }
    bot.chat(cfg.open_cmd.trim());
    tokio::time::sleep(Duration::from_millis(cfg.open_delay_ms)).await;
    let deadline = Instant::now() + Duration::from_millis(4000);
    while Instant::now() < deadline {
        if cancelled(gen) {
            return None;
        }
        if capture_top_menu(bot).is_some() {
            return wait_settle(bot, gen).await;
        }
        tokio::time::sleep(Duration::from_millis(150)).await;
    }
    None
}

enum MenuChange {
    Changed(TopMenu),
    Unchanged,
    Closed,
    Cancelled,
}

async fn click_and_wait_change(
    bot: &Client,
    slot: usize,
    prev_fp: &str,
    delay_ms: u64,
    gen: u64,
) -> MenuChange {
    let Some(h) = handle_of(bot) else {
        return MenuChange::Closed;
    };
    h.left_click(slot);
    tokio::time::sleep(Duration::from_millis(delay_ms)).await;

    let deadline = Instant::now() + Duration::from_millis(2400);
    let mut none_since: Option<Instant> = None;

    while Instant::now() < deadline {
        if cancelled(gen) {
            return MenuChange::Cancelled;
        }
        match capture_top_menu(bot) {
            Some(m) => {
                none_since = None;
                if m.fingerprint != prev_fp {
                    return match wait_settle(bot, gen).await {
                        Some(settled) => MenuChange::Changed(settled),
                        None => MenuChange::Closed,
                    };
                }
            }
            None => {
                let first = *none_since.get_or_insert_with(Instant::now);
                if first.elapsed() >= Duration::from_millis(650) {
                    return MenuChange::Closed;
                }
            }
        }
        tokio::time::sleep(Duration::from_millis(110)).await;
    }

    match capture_top_menu(bot) {
        Some(m) if m.fingerprint != prev_fp => MenuChange::Changed(m),
        Some(_) => MenuChange::Unchanged,
        None => MenuChange::Closed,
    }
}

fn looks_like_root(cur: &TopMenu, root: &TopMenu, cfg: &ShopConfig) -> bool {
    if cur.fingerprint == root.fingerprint {
        return true;
    }
    if cur.top_len != root.top_len {
        return false;
    }
    let mut checks = 0usize;
    let mut matches = 0usize;
    for i in 0..root.top_len {
        if is_nav_or_excluded(i, cfg) {
            continue;
        }
        match (&root.slots[i], &cur.slots[i]) {
            (Some(a), Some(b)) if !is_glass_or_filler(&a.id, &a.label, cfg.skip_glass) => {
                checks += 1;
                if a.id == b.id {
                    matches += 1;
                }
            }
            (None, None) => {}
            _ => {
                checks += 1;
            }
        }
    }
    checks > 0 && matches * 10 >= checks * 7
}

fn slot_to_item_json(
    s: &TopSlot,
    category: &str,
    category_slot: i64,
    page: usize,
) -> Value {
    json!({
        "id": s.id,
        "label": s.label,
        "count": s.count,
        "category": category,
        "category_slot": category_slot,
        "page": page,
        "slot": s.slot,
        "price": s.price_hint,
        "buy_price": s.buy_price,
        "sell_price": s.sell_price,
        "lore": s.lore_lines,
        "ench": s.ench_texts,
        "e": s.enchanted,
        "hash": s.hash,
        "pot": s.pot,
    })
}

fn record_page_items(
    menu: &TopMenu,
    cfg: &ShopConfig,
    category: &str,
    category_slot: i64,
    page: usize,
    out: &mut Vec<Value>,
) {
    for opt in &menu.slots {
        let Some(s) = opt else { continue };
        if is_nav_or_excluded(s.slot, cfg) {
            continue;
        }
        if is_glass_or_filler(&s.id, &s.label, cfg.skip_glass) {
            continue;
        }
        out.push(slot_to_item_json(s, category, category_slot, page));
    }
}

async fn scan_current_pages(
    bot: &Client,
    cfg: &ShopConfig,
    gen: u64,
    initial_menu: TopMenu,
    category_name: &str,
    category_slot: i64,
    cat_index: usize,
    cat_total: usize,
    out: &mut Vec<Value>,
) -> bool {
    let mut cur = initial_menu;
    let mut seen_fps = HashSet::new();

    for page in 1..=cfg.max_pages {
        if cancelled(gen) {
            return false;
        }
        if !seen_fps.insert(cur.fingerprint.clone()) {
            break;
        }

        record_page_items(&cur, cfg, category_name, category_slot, page, out);
        set_progress(ScanProgress {
            running: true,
            phase: format!("Memindai {category_name} · Hal {page}"),
            category: category_name.to_string(),
            page,
            cat_index,
            cat_total,
            found_count: out.len(),
            error: String::new(),
        });

        let next_idx = if cfg.next_slot >= 0 {
            Some(cfg.next_slot as usize)
        } else {
            None
        };
        let Some(ns) = next_idx else { break };
        if ns >= cur.top_len {
            break;
        }
        let Some(nav_item) = cur.slots.get(ns).and_then(|x| x.as_ref()) else {
            break;
        };
        // Jika tombol Next ternyata kaca polos tanpa nama, biasanya artinya tidak ada halaman berikutnya.
        if nav_item.id.ends_with("_stained_glass_pane") && nav_item.label.trim().is_empty() {
            break;
        }

        match click_and_wait_change(bot, ns, &cur.fingerprint, cfg.click_delay_ms, gen).await {
            MenuChange::Changed(next_menu) => {
                if seen_fps.contains(&next_menu.fingerprint) {
                    break;
                }
                cur = next_menu;
            }
            MenuChange::Unchanged => break,
            MenuChange::Closed => break,
            MenuChange::Cancelled => return false,
        }
    }
    true
}

fn save_scan_items(items: Vec<Value>, categories_count: usize) {
    ensure_server_entry();
    let k = server_key();
    if k.is_empty() {
        return;
    }
    let mut root = storage::get(ID);
    root["servers"][&k]["items"] = Value::Array(items);
    root["servers"][&k]["last_scan_ms"] = json!(now_epoch_ms());
    root["servers"][&k]["categories_count"] = json!(categories_count);
    storage::save(ID, root);
}

async fn run_scan(bot: Client, gen: u64, mode: String) {
    struct Guard(u64);
    impl Drop for Guard {
        fn drop(&mut self) {
            if SCAN_GEN.load(Ordering::SeqCst) == self.0 {
                SCANNING.store(false, Ordering::SeqCst);
            }
        }
    }
    let _guard = Guard(gen);
    ensure_server_entry();
    let cfg = current_config();

    set_progress(ScanProgress {
        running: true,
        phase: "Membuka menu shop...".into(),
        ..Default::default()
    });

    let Some(root_menu) = open_main_menu(&bot, &cfg, gen).await else {
        set_progress(ScanProgress {
            running: false,
            phase: String::new(),
            error: if cfg.open_cmd.trim().is_empty() {
                "Tidak ada menu GUI terbuka. Buka shop dulu lewat Monitor atau isi perintah buka (mis. /shop).".into()
            } else {
                format!(
                    "Menu tidak terbuka setelah '{}'. Pastikan bot sudah login & posisi aman.",
                    cfg.open_cmd
                )
            },
            ..Default::default()
        });
        emit_open_menu(&bot);
        return;
    };

    if mode == "current" {
        let cat_name = if root_menu.title.trim().is_empty() {
            "Menu Terbuka".to_string()
        } else {
            root_menu.title.clone()
        };
        let mut new_items = Vec::new();
        let ok = scan_current_pages(
            &bot, &cfg, gen, root_menu, &cat_name, -1, 1, 1, &mut new_items,
        )
        .await;
        if !ok || cancelled(gen) {
            set_progress(ScanProgress {
                running: false,
                phase: "Scan dihentikan".into(),
                found_count: new_items.len(),
                ..Default::default()
            });
            return;
        }

        let k = server_key();
        let mut merged = Vec::new();
        let mut cat_names = HashSet::new();
        if !k.is_empty() {
            let root = storage::get(ID);
            if let Some(arr) = root["servers"][&k]["items"].as_array() {
                for it in arr {
                    if it["category"].as_str() != Some(cat_name.as_str()) {
                        if let Some(c) = it["category"].as_str() {
                            cat_names.insert(c.to_string());
                        }
                        merged.push(it.clone());
                    }
                }
            }
        }
        let added = new_items.len();
        if added > 0 {
            cat_names.insert(cat_name.clone());
        }
        merged.extend(new_items);
        save_scan_items(merged.clone(), cat_names.len());
        emit_data();
        emit_open_menu(&bot);
        set_progress(ScanProgress {
            running: false,
            phase: format!("Selesai (Menu Terbuka): {added} item dipindai (total tersimpan: {}).", merged.len()),
            found_count: merged.len(),
            ..Default::default()
        });
        crate::log(format!("shopscanner: scan menu terbuka selesai ({added} item)"));
        return;
    }

    // Mode "full": deteksi daftar slot kategori di menu utama
    let cat_slots: Vec<usize> = if !cfg.category_slots.is_empty() {
        cfg.category_slots
            .iter()
            .copied()
            .filter(|&s| s < root_menu.top_len && root_menu.slots.get(s).and_then(|x| x.as_ref()).is_some())
            .collect()
    } else {
        root_menu
            .slots
            .iter()
            .filter_map(|opt| opt.as_ref())
            .filter(|s| {
                !is_nav_or_excluded(s.slot, &cfg)
                    && !is_glass_or_filler(&s.id, &s.label, cfg.skip_glass)
            })
            .map(|s| s.slot)
            .collect()
    };

    if cat_slots.is_empty() {
        set_progress(ScanProgress {
            running: false,
            error: "Tidak ada slot kategori ditemukan di menu utama. Cek pengaturan Exclude / Slot Kategori.".into(),
            ..Default::default()
        });
        emit_open_menu(&bot);
        return;
    }

    let total_cats = cat_slots.len();
    let mut all_items = Vec::new();
    let mut cur_root = root_menu.clone();
    let mut scanned_cats = 0usize;

    for (idx, &cat_slot) in cat_slots.iter().enumerate() {
        if cancelled(gen) {
            break;
        }
        let cat_label = cur_root
            .slots
            .get(cat_slot)
            .and_then(|x| x.as_ref())
            .map(|s| s.label.clone())
            .unwrap_or_else(|| format!("Slot {cat_slot}"));

        set_progress(ScanProgress {
            running: true,
            phase: format!("Membuka kategori {}/{} ({cat_label})...", idx + 1, total_cats),
            category: cat_label.clone(),
            page: 0,
            cat_index: idx + 1,
            cat_total: total_cats,
            found_count: all_items.len(),
            error: String::new(),
        });

        let sub_menu = match click_and_wait_change(
            &bot,
            cat_slot,
            &cur_root.fingerprint,
            cfg.click_delay_ms,
            gen,
        )
        .await
        {
            MenuChange::Changed(m) => m,
            MenuChange::Unchanged => {
                continue;
            }
            MenuChange::Closed => {
                if let Some(reopened) = reopen_main_menu(&bot, &cfg, gen).await {
                    cur_root = reopened;
                }
                continue;
            }
            MenuChange::Cancelled => break,
        };

        scanned_cats += 1;

        let ok = scan_current_pages(
            &bot,
            &cfg,
            gen,
            sub_menu,
            &cat_label,
            cat_slot as i64,
            idx + 1,
            total_cats,
            &mut all_items,
        )
        .await;
        if !ok || cancelled(gen) {
            break;
        }

        // Kembali ke menu utama untuk kategori berikutnya
        if idx + 1 < total_cats {
            let mut back_ok = false;
            if cfg.back_slot >= 0 {
                if let Some(cur_now) = capture_top_menu(&bot) {
                    let bs = cfg.back_slot as usize;
                    if bs < cur_now.top_len && cur_now.slots.get(bs).and_then(|x| x.as_ref()).is_some() {
                        match click_and_wait_change(&bot, bs, &cur_now.fingerprint, cfg.click_delay_ms, gen).await {
                            MenuChange::Changed(m) if looks_like_root(&m, &cur_root, &cfg) => {
                                cur_root = m;
                                back_ok = true;
                            }
                            MenuChange::Changed(_) => {}
                            MenuChange::Unchanged => {}
                            MenuChange::Closed => {}
                            MenuChange::Cancelled => break,
                        }
                    }
                }
            }
            if !back_ok {
                if let Some(reopened) = reopen_main_menu(&bot, &cfg, gen).await {
                    cur_root = reopened;
                } else {
                    set_progress(ScanProgress {
                        running: false,
                        phase: String::new(),
                        cat_index: idx + 1,
                        cat_total: total_cats,
                        found_count: all_items.len(),
                        error: "Gagal kembali ke menu utama shop. Cek Slot Back atau Perintah Buka.".into(),
                        ..Default::default()
                    });
                    if !all_items.is_empty() {
                        save_scan_items(all_items.clone(), scanned_cats);
                        emit_data();
                    }
                    emit_open_menu(&bot);
                    return;
                }
            }
        }
    }

    if cancelled(gen) {
        if !all_items.is_empty() {
            save_scan_items(all_items.clone(), scanned_cats);
            emit_data();
        }
        set_progress(ScanProgress {
            running: false,
            phase: format!("Dihentikan ({} item sempat tersimpan)", all_items.len()),
            found_count: all_items.len(),
            ..Default::default()
        });
        emit_open_menu(&bot);
        return;
    }

    // Tutup menu di akhir agar bot rapi (opsional)
    if let Some(h) = handle_of(&bot) {
        if h.slots().map(|s| s.len() != PLAYER_MENU_LEN).unwrap_or(false) {
            h.close();
        }
    }

    let total_found = all_items.len();
    save_scan_items(all_items, scanned_cats);
    emit_data();
    refresh_monitor_view(&bot);
    emit_open_menu(&bot);
    set_progress(ScanProgress {
        running: false,
        phase: format!("Scan selesai: {total_found} item dari {scanned_cats} kategori tersimpan."),
        cat_index: total_cats,
        cat_total: total_cats,
        found_count: total_found,
        ..Default::default()
    });
    crate::log(format!("shopscanner: selesai memindai {total_found} item ({scanned_cats} kategori)"));
}

async fn open_target_page(
    bot: Client,
    gen: u64,
    cat_slot: i64,
    page: usize,
    target_slot: i64,
) {
    let cfg = current_config();
    set_progress(ScanProgress {
        running: false,
        phase: "Membuka halaman item di server...".into(),
        ..Default::default()
    });

    // Selalu mulai dari menu utama jika open_cmd tersedia
    let root = if !cfg.open_cmd.trim().is_empty() {
        reopen_main_menu(&bot, &cfg, gen).await
    } else {
        open_main_menu(&bot, &cfg, gen).await
    };
    let Some(mut cur) = root else {
        set_progress(ScanProgress {
            running: false,
            error: "Gagal membuka menu shop. Pastikan perintah buka (/shop) sesuai.".into(),
            ..Default::default()
        });
        return;
    };

    if cat_slot >= 0 {
        let cs = cat_slot as usize;
        if cs >= cur.top_len {
            set_progress(ScanProgress {
                running: false,
                error: format!("Slot kategori {cs} melebihi ukuran menu."),
                ..Default::default()
            });
            return;
        }
        match click_and_wait_change(&bot, cs, &cur.fingerprint, cfg.click_delay_ms, gen).await {
            MenuChange::Changed(next) => cur = next,
            _ => {
                set_progress(ScanProgress {
                    running: false,
                    error: format!("Kategori slot {cs} gagal dibuka."),
                    ..Default::default()
                });
                return;
            }
        }
    }

    if page > 1 {
        if cfg.next_slot < 0 {
            set_progress(ScanProgress {
                running: false,
                error: "Slot Right / Next belum diisi di setelan server.".into(),
                ..Default::default()
            });
            return;
        }
        let ns = cfg.next_slot as usize;
        for _ in 1..page {
            if cancelled(gen) {
                return;
            }
            if ns >= cur.top_len {
                break;
            }
            match click_and_wait_change(&bot, ns, &cur.fingerprint, cfg.click_delay_ms, gen).await {
                MenuChange::Changed(next) => cur = next,
                _ => break,
            }
        }
    }

    refresh_monitor_view(&bot);
    emit_open_menu(&bot);
    set_progress(ScanProgress {
        running: false,
        phase: if target_slot >= 0 {
            format!("Halaman {page} terbuka — lihat Slot #{target_slot} di tab Monitor!")
        } else {
            format!("Halaman {page} terbuka di tab Monitor!")
        },
        ..Default::default()
    });
}

pub async fn on_event(_bot: &Client, event: &Event) {
    match event {
        Event::Login => {
            if settings::enabled(ID) {
                ensure_server_entry();
                emit_data();
            }
        }
        Event::Disconnect(_) => {
            SCAN_GEN.fetch_add(1, Ordering::SeqCst);
            SCANNING.store(false, Ordering::SeqCst);
        }
        _ => {}
    }
}

pub async fn dispatch_web(bot: &Client, action: &str, payload: &Value) {
    match action {
        "refresh" => {
            ensure_server_entry();
            emit_data();
            emit_progress();
            emit_open_menu(bot);
        }
        "probe_menu" => {
            emit_open_menu(bot);
        }
        "save_config" => {
            update_config_from_json(payload);
            emit_data();
            emit_open_menu(bot);
        }
        "clear_cache" => {
            save_scan_items(Vec::new(), 0);
            emit_data();
            set_progress(ScanProgress {
                running: false,
                phase: "Cache item server ini dibersihkan.".into(),
                ..Default::default()
            });
        }
        "scan_stop" => {
            SCAN_GEN.fetch_add(1, Ordering::SeqCst);
            SCANNING.store(false, Ordering::SeqCst);
            set_progress(ScanProgress {
                running: false,
                phase: "Menghentikan scan...".into(),
                ..Default::default()
            });
        }
        "scan_start" => {
            if payload["config"].is_object() {
                update_config_from_json(&payload["config"]);
                emit_data();
            }
            if SCANNING.swap(true, Ordering::SeqCst) {
                emit_progress();
                return;
            }
            let mode = payload["mode"].as_str().unwrap_or("full").to_string();
            let gen = SCAN_GEN.fetch_add(1, Ordering::SeqCst) + 1;
            let b = bot.clone();
            tokio::spawn(async move {
                run_scan(b, gen, mode).await;
            });
        }
        "open_target" => {
            if SCANNING.load(Ordering::SeqCst) {
                set_progress(ScanProgress {
                    running: true,
                    error: "Tunggu atau hentikan scan dulu sebelum membuka item.".into(),
                    ..Default::default()
                });
                return;
            }
            let cat_slot = payload["category_slot"].as_i64().unwrap_or(-1);
            let page = payload["page"].as_u64().unwrap_or(1).max(1) as usize;
            let target_slot = payload["slot"].as_i64().unwrap_or(-1);
            let gen = SCAN_GEN.fetch_add(1, Ordering::SeqCst) + 1;
            let b = bot.clone();
            tokio::spawn(async move {
                open_target_page(b, gen, cat_slot, page, target_slot).await;
            });
        }
        _ => {}
    }
}
