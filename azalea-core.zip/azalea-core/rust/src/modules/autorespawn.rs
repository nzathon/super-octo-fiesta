// Modul Auto Respawn: otomatis menekan respawn saat bot mati, dan opsional mengirim perintah seperti /home.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::time::Duration;

use azalea::prelude::*;
use azalea::protocol::packets::game::s_client_command::{Action, ServerboundClientCommand};
use serde_json::json;

use super::{Def, Setting};
use crate::settings;

const ID: &str = "autorespawn";

static PENDING: AtomicBool = AtomicBool::new(false);
static GEN: AtomicU64 = AtomicU64::new(0);

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Auto Respawn",
        desc: "Otomatis respawn saat bot mati, dengan jeda yang bisa diatur serta perintah opsional setelah respawn.",
        enabled: false,
        settings: vec![
            Setting { key: "delay", label: "Jeda respawn (detik)", kind: "number", default: json!(1.5) },
            Setting { key: "post_cmd", label: "Perintah setelah respawn (opsional, mis. /home)", kind: "text", default: json!("") },
            Setting { key: "cmd_delay", label: "Jeda perintah setelah respawn (detik)", kind: "number", default: json!(1.5) },
        ],
    }
}

fn reset_state() {
    GEN.fetch_add(1, Ordering::SeqCst);
    PENDING.store(false, Ordering::SeqCst);
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login | Event::Spawn => {
            reset_state();
        }
        Event::Death(_) => {
            if !settings::enabled(ID) || PENDING.swap(true, Ordering::SeqCst) {
                return;
            }
            let my_gen = GEN.load(Ordering::SeqCst);
            let delay_s = settings::get_f64(ID, "delay").clamp(0.2, 30.0);
            let post_cmd = settings::get_str(ID, "post_cmd").trim().to_string();
            let cmd_delay_s = settings::get_f64(ID, "cmd_delay").clamp(0.2, 30.0);
            let b = bot.clone();

            tokio::spawn(async move {
                tokio::time::sleep(Duration::from_secs_f64(delay_s)).await;
                if !settings::enabled(ID) || GEN.load(Ordering::SeqCst) != my_gen {
                    PENDING.store(false, Ordering::SeqCst);
                    return;
                }
                b.write_packet(ServerboundClientCommand {
                    action: Action::PerformRespawn,
                });
                crate::log("autorespawn: permintaan respawn dikirim");

                if !post_cmd.is_empty() {
                    tokio::time::sleep(Duration::from_secs_f64(cmd_delay_s)).await;
                    if settings::enabled(ID) && GEN.load(Ordering::SeqCst) == my_gen {
                        super::relogin::on_outgoing(&post_cmd);
                        b.chat(post_cmd.as_str());
                        crate::log(format!("autorespawn: kirim '{post_cmd}'"));
                    }
                }
                PENDING.store(false, Ordering::SeqCst);
            });
        }
        _ => {}
    }
}
