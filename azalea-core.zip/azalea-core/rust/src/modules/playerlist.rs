// Modul Player List: daftar pemain online (nama tampilan berwarna + ping + hash skin Mojang) ke tab Pemain aplikasi,
// serta inisialisasi Storage quick-action (global & per-server) untuk dialog kartu pemain.
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use azalea::prelude::*;
use azalea::protocol::packets::game::ClientboundGamePacket;
use serde_json::{json, Value};

use super::{Def, Setting};
use crate::{settings, storage};

const ID: &str = "playerlist";

static PLAYERS: Mutex<Option<HashMap<String, Value>>> = Mutex::new(None);
static LISTED: Mutex<Option<HashMap<String, bool>>> = Mutex::new(None);
static LAST: Mutex<Option<Instant>> = Mutex::new(None);
static PENDING: AtomicBool = AtomicBool::new(false);
static STORAGE_READY: AtomicBool = AtomicBool::new(false);

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Player List",
        desc: "Menampilkan pemain online (tanpa NPC), avatar head, ping, serta tombol aksi cepat di Storage (global & per-server).",
        enabled: true,
        settings: vec![Setting {
            key: "interval",
            label: "Jeda pembaruan (detik)",
            kind: "number",
            default: json!(2),
        }],
    }
}

fn server_key() -> String {
    format!("{}:{}", settings::host(), settings::port())
}

fn ensure_storage() {
    let k = server_key();
    if k == ":25565" || settings::host().is_empty() {
        return;
    }
    let mut root = storage::get(ID);
    let mut changed = false;

    if !root["global"].is_array() {
        root["global"] = json!([
            { "label": "Message", "cmd": "/msg <name> " },
            { "label": "TPA", "cmd": "/tpa <name>", "send": true }
        ]);
        changed = true;
    }
    if !root["servers"].is_object() {
        root["servers"] = json!({});
        changed = true;
    }
    if !root["servers"][&k].is_array() {
        root["servers"][&k] = json!([]);
        changed = true;
    }

    if changed {
        storage::save(ID, root);
    }
    STORAGE_READY.store(true, Ordering::SeqCst);
}

fn is_npc_uuid_or_name(uuid_bytes: &[u8; 16], name: &str) -> bool {
    // Citizens v2 memakai UUID version 2; nama kosong atau CIT-* juga entri NPC/fake.
    let ver = uuid_bytes[6] >> 4;
    ver == 2 || name.trim().is_empty() || name.starts_with("CIT-")
}

/// Daftar nama pemain online saat ini (untuk tab completion).
pub fn online_names() -> Vec<String> {
    let g = PLAYERS.lock().unwrap();
    let l = LISTED.lock().unwrap();
    let mut names: Vec<String> = g
        .as_ref()
        .map(|m| {
            m.iter()
                .filter(|(id, v)| {
                    let is_listed = l.as_ref().and_then(|lm| lm.get(*id).copied()).unwrap_or(false);
                    let name = v["name"].as_str().unwrap_or("");
                    is_listed && !name.trim().is_empty() && !name.starts_with("CIT-")
                })
                .filter_map(|(_, v)| v["name"].as_str().map(|s| s.to_string()))
                .collect()
        })
        .unwrap_or_default();
    names.sort_by_key(|a| a.to_lowercase());
    names.dedup();
    names
}

fn emit_now() {
    let me = settings::username();
    let mut list: Vec<Value> = {
        let g = PLAYERS.lock().unwrap();
        let l = LISTED.lock().unwrap();
        g.as_ref()
            .map(|m| {
                m.iter()
                    .filter(|(id, v)| {
                        let is_listed = l.as_ref().and_then(|lm| lm.get(*id).copied()).unwrap_or(false);
                        let name = v["name"].as_str().unwrap_or("");
                        is_listed && !name.trim().is_empty() && !name.starts_with("CIT-")
                    })
                    .map(|(_, v)| v.clone())
                    .collect()
            })
            .unwrap_or_default()
    };
    for p in list.iter_mut() {
        let is_me = p["name"].as_str() == Some(me.as_str());
        p["self"] = json!(is_me);
    }
    list.sort_by(|a, b| {
        let (sa, sb) = (
            a["self"].as_bool().unwrap_or(false),
            b["self"].as_bool().unwrap_or(false),
        );
        sb.cmp(&sa).then_with(|| {
            a["name"]
                .as_str()
                .unwrap_or("")
                .to_lowercase()
                .cmp(&b["name"].as_str().unwrap_or("").to_lowercase())
        })
    });
    *LAST.lock().unwrap() = Some(Instant::now());
    crate::out(json!({"t": "players", "v": list}));
}

/// Dibatasi sesuai jeda; kalau tertahan, satu pembaruan susulan dijadwalkan supaya tidak ada yang basi.
fn push() {
    let every = Duration::from_millis((settings::get_f64(ID, "interval").max(0.5) * 1000.0) as u64);
    let wait = {
        let g = LAST.lock().unwrap();
        g.as_ref()
            .map(|t| every.saturating_sub(t.elapsed()))
            .unwrap_or(Duration::ZERO)
    };
    if wait.is_zero() {
        emit_now();
    } else if !PENDING.swap(true, Ordering::SeqCst) {
        tokio::spawn(async move {
            tokio::time::sleep(wait).await;
            PENDING.store(false, Ordering::SeqCst);
            emit_now();
        });
    }
}

pub fn on_packet(packet: &ClientboundGamePacket) {
    match packet {
        ClientboundGamePacket::StartConfiguration(_) | ClientboundGamePacket::Login(_) => {
            if let Some(m) = PLAYERS.lock().unwrap().as_mut() {
                m.clear();
            }
            if let Some(l) = LISTED.lock().unwrap().as_mut() {
                l.clear();
            }
            emit_now();
        }
        ClientboundGamePacket::PlayerInfoUpdate(p) => {
            let mut changed = false;
            {
                let mut listed = LISTED.lock().unwrap();
                let map = listed.get_or_insert_with(HashMap::new);
                for entry in &p.entries {
                    let key = entry.profile.uuid.to_string();
                    if p.actions.update_listed {
                        if map.insert(key, entry.listed) != Some(entry.listed) {
                            changed = true;
                        }
                    } else if p.actions.add_player {
                        // Di MC 1.19.3+, entri tanpa update_listed bernilai listed=false (NPC).
                        map.entry(key).or_insert(false);
                    }
                }
            }
            if changed {
                push();
            }
        }
        ClientboundGamePacket::PlayerInfoRemove(p) => {
            let mut changed = false;
            if let Some(map) = LISTED.lock().unwrap().as_mut() {
                for uuid in &p.profile_ids {
                    if map.remove(&uuid.to_string()).is_some() {
                        changed = true;
                    }
                }
            }
            if changed {
                push();
            }
        }
        _ => {}
    }
}

pub async fn on_event(_bot: &Client, event: &Event) {
    match event {
        Event::Login => {
            ensure_storage();
            if let Some(m) = PLAYERS.lock().unwrap().as_mut() {
                m.clear();
            }
            if let Some(l) = LISTED.lock().unwrap().as_mut() {
                l.clear();
            }
            emit_now();
        }
        Event::Tick => {
            if !STORAGE_READY.load(Ordering::SeqCst) {
                ensure_storage();
            }
        }
        Event::AddPlayer(info) | Event::UpdatePlayer(info) => {
            let uuid_key = info.uuid.to_string();
            let name = info.profile.name.clone();
            if is_npc_uuid_or_name(info.uuid.as_bytes(), &name) {
                return;
            }
            let hash = info
                .profile
                .properties
                .map
                .get("textures")
                .and_then(|p| super::monitor::extract_skin_hash_from_b64(&p.value));
            let v = json!({
                "id": uuid_key,
                "name": name,
                "display": info.display_name.as_ref().map(|d| d.to_ansi()),
                "ping": info.latency,
                "hash": hash,
            });
            PLAYERS
                .lock()
                .unwrap()
                .get_or_insert_with(HashMap::new)
                .insert(uuid_key, v);
            push();
        }
        Event::RemovePlayer(info) => {
            let uuid_key = info.uuid.to_string();
            if let Some(m) = PLAYERS.lock().unwrap().as_mut() {
                m.remove(&uuid_key);
            }
            if let Some(l) = LISTED.lock().unwrap().as_mut() {
                l.remove(&uuid_key);
            }
            push();
        }
        _ => {}
    }
}
