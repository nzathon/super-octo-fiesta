// Modul Chat: meneruskan chat server (berwarna, kode ANSI) ke layar Chat aplikasi,
// menyaring pesan blacklist berdasarkan Storage (global & per-server, format array [tipe, pola]),
// notifikasi pesan pribadi ke HP (Storage: private_chat global & override per-server),
// serta tab completion perintah dan nama pemain.
use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::Mutex;

use azalea::chat::style::{Ansi as ChatAnsi, ChatFormatting, Style as ChatStyle, TextColor};
use azalea::chat::translatable_component::{PrimitiveOrComponent, TranslatableComponent};
use azalea::chat::{FormattedText, DEFAULT_STYLE};
use azalea::client_chat::ChatPacket;
use azalea::prelude::*;
use azalea::protocol::packets::game::c_commands::{BrigadierParser, ClientboundCommands, NodeType};
use azalea::protocol::packets::game::s_command_suggestion::ServerboundCommandSuggestion;
use azalea::protocol::packets::game::ClientboundGamePacket;
use regex::{Regex, RegexBuilder};
use serde_json::{json, Value};

use super::{Def, Setting};
use crate::{settings, storage};

const ID: &str = "chat";

static STORAGE_READY: AtomicBool = AtomicBool::new(false);
static REGEX_CACHE: Mutex<Option<HashMap<String, Option<Regex>>>> = Mutex::new(None);
static COMMANDS_TREE: Mutex<Option<ClientboundCommands>> = Mutex::new(None);
static LAST_REQ_ID: AtomicU32 = AtomicU32::new(0);

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Chat",
        desc: "Menampilkan chat server berwarna di tab Chat, mendukung blacklist (Storage: global & per-server), notifikasi pesan pribadi, serta tab completion.",
        enabled: true,
        settings: vec![
            Setting {
                key: "filter_glyph",
                label: "Buang karakter glyph font kustom",
                kind: "boolean",
                default: json!(true),
            },
            Setting {
                key: "blacklist",
                label: "Blacklist (sembunyikan pesan sesuai daftar Storage)",
                kind: "boolean",
                default: json!(true),
            },
            Setting {
                key: "notify_pm",
                label: "Notifikasi pesan pribadi (sesuai aturan Storage)",
                kind: "boolean",
                default: json!(true),
            },
        ],
    }
}

fn server_key() -> String {
    format!("{}:{}", settings::host(), settings::port())
}

fn ensure_storage() {
    let k = server_key();
    if k == ":25565" || settings::host().is_empty() {
        return;
    }
    let mut root = storage::get(ID);
    let mut changed = false;

    if !root["global"].is_object() {
        root["global"] = json!({});
        changed = true;
    }
    if !root["global"]["blacklist"].is_array() {
        root["global"]["blacklist"] = json!([
            ["match", "Contoh teks broadcast yang disembunyikan"]
        ]);
        changed = true;
    }
    if !root["global"]["private_chat"].is_array() {
        root["global"]["private_chat"] = json!([
            ["regex", "(?i)(?:^|\\s*)([a-zA-Z0-9_]{3,16})\\s*->\\s*me\\s*[:\\s]\\s*(.*)"]
        ]);
        changed = true;
    }

    if !root["servers"].is_object() {
        root["servers"] = json!({});
        changed = true;
    }
    if !root["servers"][&k].is_object() {
        root["servers"][&k] = json!({
            "blacklist": [],
            "private_chat": []
        });
        changed = true;
    } else {
        if !root["servers"][&k]["blacklist"].is_array() {
            root["servers"][&k]["blacklist"] = json!([]);
            changed = true;
        }
        if !root["servers"][&k]["private_chat"].is_array() {
            root["servers"][&k]["private_chat"] = json!([]);
            changed = true;
        }
    }

    if changed {
        storage::save(ID, root);
    }
    STORAGE_READY.store(true, Ordering::SeqCst);
}

fn strip_ansi(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\u{001B}' && chars.peek() == Some(&'[') {
            chars.next();
            for n in chars.by_ref() {
                if n.is_ascii_alphabetic() {
                    break;
                }
            }
            continue;
        }
        out.push(c);
    }
    out
}

fn compile_regex_cached(pattern: &str, case_sensitive: bool) -> Option<Regex> {
    let cache_key = format!("{}:{}", if case_sensitive { 1 } else { 0 }, pattern);
    let mut guard = REGEX_CACHE.lock().unwrap();
    let map = guard.get_or_insert_with(HashMap::new);
    if let Some(hit) = map.get(&cache_key) {
        return hit.clone();
    }
    if map.len() >= 256 {
        map.clear();
    }
    let compiled = RegexBuilder::new(pattern)
        .case_insensitive(!case_sensitive)
        .build()
        .ok();
    map.insert(cache_key, compiled.clone());
    compiled
}

/// Mendukung berbagai format aturan:
/// - Array ringkas: `["match", "abc"]`, `["regex", "pola"]`
/// - Array multi-pola: `["match", ["abc", "def"]]`
/// - Objek lengkap: `{"type": "match", "pattern": "abc", "enabled": true}`
/// - String langsung: `"abc"` (dianggap tipe "match")
fn parse_rule(val: &Value) -> Option<(String, Vec<String>, bool)> {
    if let Some(arr) = val.as_array() {
        if arr.len() >= 2 {
            let kind = arr[0].as_str().unwrap_or("match").trim().to_ascii_lowercase();
            let mut patterns = Vec::new();
            if let Some(p_arr) = arr[1].as_array() {
                for p in p_arr {
                    if let Some(s) = p.as_str() {
                        if !s.is_empty() {
                            patterns.push(s.to_string());
                        }
                    }
                }
            } else if let Some(s) = arr[1].as_str() {
                if !s.is_empty() {
                    patterns.push(s.to_string());
                }
            }
            if !patterns.is_empty() {
                let case_sensitive = arr.get(2).and_then(|v| v.as_bool()).unwrap_or(false);
                return Some((kind, patterns, case_sensitive));
            }
        } else if let Some(s) = arr.first().and_then(|v| v.as_str()) {
            if !s.is_empty() {
                return Some(("match".to_string(), vec![s.to_string()], false));
            }
        }
    }
    if let Some(s) = val.as_str() {
        if !s.is_empty() {
            return Some(("match".to_string(), vec![s.to_string()], false));
        }
    }
    if let Some(obj) = val.as_object() {
        if obj.get("enabled").and_then(|v| v.as_bool()) == Some(false) {
            return None;
        }
        let kind = obj
            .get("type")
            .and_then(|v| v.as_str())
            .unwrap_or("match")
            .trim()
            .to_ascii_lowercase();
        let case_sensitive = obj
            .get("case_sensitive")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        let mut patterns = Vec::new();
        if let Some(p_arr) = obj
            .get("patterns")
            .or_else(|| obj.get("pattern"))
            .and_then(|v| v.as_array())
        {
            for p in p_arr {
                if let Some(s) = p.as_str() {
                    if !s.is_empty() {
                        patterns.push(s.to_string());
                    }
                }
            }
        } else if let Some(s) = obj
            .get("pattern")
            .or_else(|| obj.get("text"))
            .or_else(|| obj.get("isi"))
            .or_else(|| obj.get("value"))
            .and_then(|v| v.as_str())
        {
            if !s.is_empty() {
                patterns.push(s.to_string());
            }
        }
        if !patterns.is_empty() {
            return Some((kind, patterns, case_sensitive));
        }
    }
    None
}

fn check_rule_matches(kind: &str, patterns: &[String], case_sensitive: bool, plain: &str, plain_lower: &str) -> bool {
    for pat in patterns {
        let matched = match kind {
            "regex" => compile_regex_cached(pat, case_sensitive)
                .map(|re| re.is_match(plain))
                .unwrap_or(false),
            "exact" => {
                if case_sensitive {
                    plain.trim() == pat.trim()
                } else {
                    plain.trim().eq_ignore_ascii_case(pat.trim())
                }
            }
            "starts" | "prefix" => {
                if case_sensitive {
                    plain.trim_start().starts_with(pat)
                } else {
                    plain.trim_start().to_lowercase().starts_with(&pat.to_lowercase())
                }
            }
            _ => {
                // "match" / "contains"
                if case_sensitive {
                    plain.contains(pat)
                } else {
                    plain_lower.contains(&pat.to_lowercase())
                }
            }
        };
        if matched {
            return true;
        }
    }
    false
}

fn check_section_blacklist(section: &Value, plain: &str, plain_lower: &str) -> bool {
    let arr = section["blacklist"]
        .as_array()
        .or_else(|| section["filter"].as_array())
        .or_else(|| section["rules"].as_array());
    if let Some(items) = arr {
        for item in items {
            if let Some((kind, pats, cs)) = parse_rule(item) {
                if check_rule_matches(&kind, &pats, cs, plain, plain_lower) {
                    return true;
                }
            }
        }
    }
    false
}

fn is_blacklisted(ansi_text: &str) -> bool {
    let enabled = settings::get_bool(ID, "blacklist") || settings::get_bool(ID, "filter_enabled");
    if !enabled {
        return false;
    }
    if !STORAGE_READY.load(Ordering::SeqCst) {
        ensure_storage();
    }
    let root = storage::get(ID);
    let plain = strip_ansi(ansi_text);
    let plain_lower = plain.to_lowercase();

    if check_section_blacklist(&root["global"], &plain, &plain_lower) {
        return true;
    }
    let k = server_key();
    if check_section_blacklist(&root["servers"][&k], &plain, &plain_lower) {
        return true;
    }
    false
}

fn find_pm_in_rules(items: &[Value], plain: &str, plain_lower: &str) -> Option<(String, String)> {
    for item in items {
        let Some((kind, pats, cs)) = parse_rule(item) else {
            continue;
        };
        if kind == "regex" {
            for pat in &pats {
                if let Some(re) = compile_regex_cached(pat, cs) {
                    if let Some(caps) = re.captures(plain) {
                        let sender = caps.get(1).map(|m| m.as_str().trim().to_string()).unwrap_or_default();
                        let body = caps.get(2).map(|m| m.as_str().trim().to_string()).unwrap_or_else(|| plain.to_string());
                        let title = if !sender.is_empty() {
                            format!("Pesan dari {sender}")
                        } else {
                            "Pesan Pribadi".to_string()
                        };
                        return Some((title, body));
                    }
                }
            }
        } else if check_rule_matches(&kind, &pats, cs, plain, plain_lower) {
            return Some(("Pesan Pribadi".to_string(), plain.to_string()));
        }
    }
    None
}

/// Mengecek apakah pesan merupakan private message (server override global).
fn check_private_message(ansi_text: &str) -> Option<(String, String)> {
    if !STORAGE_READY.load(Ordering::SeqCst) {
        ensure_storage();
    }
    let root = storage::get(ID);
    let plain = strip_ansi(ansi_text);
    let plain_lower = plain.to_lowercase();
    let k = server_key();

    let srv_items = root["servers"][&k]["private_chat"]
        .as_array()
        .or_else(|| root["servers"][&k]["private_message"].as_array())
        .or_else(|| root["servers"][&k]["pm"].as_array());

    if let Some(items) = srv_items {
        if !items.is_empty() {
            return find_pm_in_rules(items, &plain, &plain_lower);
        }
    }

    let global_items = root["global"]["private_chat"]
        .as_array()
        .or_else(|| root["global"]["private_message"].as_array())
        .or_else(|| root["global"]["pm"].as_array());

    if let Some(items) = global_items {
        return find_pm_in_rules(items, &plain, &plain_lower);
    }
    None
}

// ---------- tab completion (ClientboundCommands + ServerboundCommandSuggestion) ----------

fn utf16_len(s: &str) -> usize {
    s.encode_utf16().count()
}

fn resolve_node_children(tree: &ClientboundCommands, start_idx: usize) -> Vec<usize> {
    let mut cur = start_idx;
    let mut visited = HashSet::new();
    for _ in 0..16 {
        if !visited.insert(cur) {
            break;
        }
        let Some(node) = tree.entries.get(cur) else {
            break;
        };
        if !node.children.is_empty() {
            return node.children.iter().map(|&c| c as usize).collect();
        }
        if let Some(redir) = node.redirect_node {
            cur = redir as usize;
        } else {
            break;
        }
    }
    Vec::new()
}

fn suggest_from_commands(text: &str) -> (usize, usize, Vec<(String, Option<String>)>) {
    let full_end = utf16_len(text);
    let Some(rest) = text.strip_prefix('/') else {
        return (full_end, full_end, Vec::new());
    };

    let ends_with_space = rest.ends_with(' ');
    let last_space_in_rest = rest.rfind(' ');
    let (completed_str, active_prefix, active_start_byte) = if ends_with_space {
        (rest.trim(), "", text.len())
    } else if let Some(pos) = last_space_in_rest {
        (&rest[..pos], &rest[pos + 1..], 1 + pos + 1)
    } else {
        ("", rest, 1)
    };

    let start_u16 = utf16_len(&text[..active_start_byte]);
    let prefix_lower = active_prefix.to_lowercase();

    let tree_opt = COMMANDS_TREE.lock().unwrap().clone();
    let Some(tree) = tree_opt else {
        return (start_u16, full_end, Vec::new());
    };
    let mut cur_idx = tree.root_index as usize;
    let completed_tokens: Vec<&str> = completed_str.split_whitespace().collect();

    for tok in completed_tokens {
        let children = resolve_node_children(&tree, cur_idx);
        let tok_lower = tok.to_lowercase();
        let mut next_idx: Option<usize> = None;

        for &c_idx in &children {
            if let Some(node) = tree.entries.get(c_idx) {
                if let NodeType::Literal { name } = &node.node_type {
                    if name.to_lowercase() == tok_lower {
                        next_idx = Some(c_idx);
                        break;
                    }
                }
            }
        }
        if next_idx.is_none() {
            for &c_idx in &children {
                if let Some(node) = tree.entries.get(c_idx) {
                    if matches!(node.node_type, NodeType::Argument { .. }) {
                        next_idx = Some(c_idx);
                        break;
                    }
                }
            }
        }
        let Some(ni) = next_idx else {
            return (start_u16, full_end, Vec::new());
        };
        cur_idx = ni;
    }

    let final_children = resolve_node_children(&tree, cur_idx);
    let mut out: Vec<(String, Option<String>)> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    let mut want_players = false;
    let mut player_tip: Option<String> = None;

    for c_idx in final_children {
        let Some(node) = tree.entries.get(c_idx) else {
            continue;
        };
        match &node.node_type {
            NodeType::Literal { name } => {
                if name.to_lowercase().starts_with(&prefix_lower) && seen.insert(name.clone()) {
                    out.push((name.clone(), None));
                }
            }
            NodeType::Argument { name, parser, .. } => {
                let name_low = name.to_lowercase();
                if matches!(parser, BrigadierParser::Entity(_) | BrigadierParser::GameProfile)
                    || name_low.contains("player")
                    || name_low.contains("target")
                    || name_low.contains("user")
                    || name_low.contains("pemain")
                {
                    want_players = true;
                    if player_tip.is_none() {
                        player_tip = Some(name.clone());
                    }
                }
            }
            NodeType::Root => {}
        }
    }

    if want_players {
        for pname in super::playerlist::online_names() {
            if pname.to_lowercase().starts_with(&prefix_lower) && seen.insert(pname.clone()) {
                out.push((pname, player_tip.clone()));
            }
        }
    }

    out.sort_by_key(|(t, _)| t.to_lowercase());
    out.truncate(40);
    (start_u16, full_end, out)
}

fn suggest_players_at_tail(text: &str) -> (usize, usize, Vec<(String, Option<String>)>) {
    let full_end = utf16_len(text);
    let last_space = text.rfind(' ');
    let (prefix, start_byte) = match last_space {
        Some(pos) => (&text[pos + 1..], pos + 1),
        None => (text, 0),
    };
    let start_u16 = utf16_len(&text[..start_byte]);
    let prefix_lower = prefix.to_lowercase();
    let mut out = Vec::new();
    for pname in super::playerlist::online_names() {
        if pname.to_lowercase().starts_with(&prefix_lower) {
            out.push((pname, None));
        }
    }
    out.truncate(30);
    (start_u16, full_end, out)
}

pub fn on_packet(packet: &ClientboundGamePacket) {
    match packet {
        ClientboundGamePacket::StartConfiguration(_) | ClientboundGamePacket::Login(_) => {
            *COMMANDS_TREE.lock().unwrap() = None;
            LAST_REQ_ID.store(0, Ordering::SeqCst);
        }
        ClientboundGamePacket::Commands(p) => {
            *COMMANDS_TREE.lock().unwrap() = Some(p.clone());
        }
        ClientboundGamePacket::CommandSuggestions(p) => {
            if p.id != LAST_REQ_ID.load(Ordering::SeqCst) {
                return;
            }
            let list = p.suggestions.list();
            if list.is_empty() {
                return;
            }
            let range = p.suggestions.range();
            let items: Vec<Value> = list
                .iter()
                .take(40)
                .map(|s| {
                    json!({
                        "text": s.text(),
                        "tip": s.tooltip
                    })
                })
                .collect();
            crate::out(json!({
                "t": "complete",
                "id": p.id,
                "start": range.start(),
                "end": range.end(),
                "items": items
            }));
        }
        _ => {}
    }
}

pub fn request_complete(bot: &Client, req_id: u32, text: &str, force: bool) {
    LAST_REQ_ID.store(req_id, Ordering::SeqCst);
    if text.starts_with('/') {
        let (st, en, items) = suggest_from_commands(text);
        let json_items: Vec<Value> = items
            .into_iter()
            .map(|(t, tip)| json!({ "text": t, "tip": tip }))
            .collect();
        crate::out(json!({
            "t": "complete",
            "id": req_id,
            "start": st,
            "end": en,
            "items": json_items
        }));
        bot.write_packet(ServerboundCommandSuggestion {
            id: req_id,
            command: text.to_string(),
        });
    } else if force {
        let (st, en, items) = suggest_players_at_tail(text);
        let json_items: Vec<Value> = items
            .into_iter()
            .map(|(t, tip)| json!({ "text": t, "tip": tip }))
            .collect();
        crate::out(json!({
            "t": "complete",
            "id": req_id,
            "start": st,
            "end": en,
            "items": json_items
        }));
        bot.write_packet(ServerboundCommandSuggestion {
            id: req_id,
            command: text.to_string(),
        });
    }
}

// ---------- pemformatan chat ANSI ----------

fn emit_segment(text: &str, style: &ChatStyle, running: &mut ChatStyle, out: &mut String) {
    if text.is_empty() {
        return;
    }
    let prefix = running.compare_ansi(style);
    out.push_str(&prefix);
    out.push_str(text);
    *running = style.clone();
}

fn legacy_formatting(code: char) -> Option<ChatFormatting> {
    Some(match code.to_ascii_lowercase() {
        '0' => ChatFormatting::Black,
        '1' => ChatFormatting::DarkBlue,
        '2' => ChatFormatting::DarkGreen,
        '3' => ChatFormatting::DarkAqua,
        '4' => ChatFormatting::DarkRed,
        '5' => ChatFormatting::DarkPurple,
        '6' => ChatFormatting::Gold,
        '7' => ChatFormatting::Gray,
        '8' => ChatFormatting::DarkGray,
        '9' => ChatFormatting::Blue,
        'a' => ChatFormatting::Green,
        'b' => ChatFormatting::Aqua,
        'c' => ChatFormatting::Red,
        'd' => ChatFormatting::LightPurple,
        'e' => ChatFormatting::Yellow,
        'f' => ChatFormatting::White,
        'k' => ChatFormatting::Obfuscated,
        'l' => ChatFormatting::Bold,
        'm' => ChatFormatting::Strikethrough,
        'n' => ChatFormatting::Underline,
        'o' => ChatFormatting::Italic,
        'r' => ChatFormatting::Reset,
        _ => return None,
    })
}

fn render_text_with_legacy(
    text: &str,
    base_style: &ChatStyle,
    running: &mut ChatStyle,
    out: &mut String,
) {
    let mut cur = base_style.clone();
    let mut buf = String::new();
    let chars: Vec<char> = text.chars().collect();
    let mut i = 0;

    while i < chars.len() {
        if chars[i] == '§' && i + 1 < chars.len() {
            let next = chars[i + 1];
            if (next == 'x' || next == 'X') && i + 13 < chars.len() {
                let mut hex = String::with_capacity(6);
                let mut ok = true;
                for k in 0..6 {
                    if chars[i + 2 + k * 2] != '§' {
                        ok = false;
                        break;
                    }
                    let d = chars[i + 3 + k * 2];
                    if !d.is_ascii_hexdigit() {
                        ok = false;
                        break;
                    }
                    hex.push(d);
                }
                if ok {
                    if let Ok(rgb) = u32::from_str_radix(&hex, 16) {
                        if !buf.is_empty() {
                            emit_segment(&buf, &cur, running, out);
                            buf.clear();
                        }
                        cur = base_style.clone();
                        // TextColor fields `value` dan `name` bersifat publik
                        cur.color = Some(TextColor { value: rgb, name: None });
                        i += 14;
                        continue;
                    }
                }
            }
            if next == '#' && i + 7 < chars.len() {
                let hex: String = chars[i + 2..i + 8].iter().collect();
                if hex.chars().all(|c| c.is_ascii_hexdigit()) {
                    if let Ok(rgb) = u32::from_str_radix(&hex, 16) {
                        if !buf.is_empty() {
                            emit_segment(&buf, &cur, running, out);
                            buf.clear();
                        }
                        cur = base_style.clone();
                        // TextColor fields `value` dan `name` bersifat publik
                        cur.color = Some(TextColor { value: rgb, name: None });
                        i += 8;
                        continue;
                    }
                }
            }
            if let Some(fmt) = legacy_formatting(next) {
                if !buf.is_empty() {
                    emit_segment(&buf, &cur, running, out);
                    buf.clear();
                }
                if fmt == ChatFormatting::Reset {
                    cur = base_style.clone();
                } else {
                    if !fmt.is_format() {
                        cur = base_style.clone();
                    }
                    cur.apply_formatting(&fmt);
                }
                i += 2;
                continue;
            }
        }
        buf.push(chars[i]);
        i += 1;
    }

    if !buf.is_empty() {
        emit_segment(&buf, &cur, running, out);
    }
}

fn strip_legacy_plain(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '§' && i + 1 < chars.len() {
            if (chars[i + 1] == 'x' || chars[i + 1] == 'X') && i + 13 < chars.len() {
                i += 14;
                continue;
            }
            if chars[i + 1] == '#' && i + 7 < chars.len() {
                i += 8;
                continue;
            }
            i += 2;
            continue;
        }
        out.push(chars[i]);
        i += 1;
    }
    out
}

fn arg_plain(arg: &PrimitiveOrComponent) -> String {
    match arg {
        PrimitiveOrComponent::FormattedText(ft) => strip_legacy_plain(&ft.to_string()),
        PrimitiveOrComponent::String(s) => strip_legacy_plain(s),
        other => strip_legacy_plain(&other.to_string()),
    }
}

fn render_arg(
    arg: &PrimitiveOrComponent,
    parent_style: &ChatStyle,
    running: &mut ChatStyle,
    out: &mut String,
) {
    match arg {
        PrimitiveOrComponent::FormattedText(ft) => render_formatted(ft, parent_style, running, out),
        PrimitiveOrComponent::String(s) => render_text_with_legacy(s, parent_style, running, out),
        other => emit_segment(&other.to_string(), parent_style, running, out),
    }
}

fn render_template_with_sentinels(
    text: &str,
    args: &[PrimitiveOrComponent],
    style: &ChatStyle,
    running: &mut ChatStyle,
    out: &mut String,
) {
    let mut rest = text;
    while let Some(start) = rest.find('\u{0001}') {
        let before = &rest[..start];
        if !before.is_empty() {
            render_text_with_legacy(before, style, running, out);
        }
        let after_start = &rest[start + 1..];
        if let Some(end) = after_start.find('\u{0002}') {
            let idx_str = &after_start[..end];
            if let Ok(idx) = idx_str.parse::<usize>() {
                if let Some(arg) = args.get(idx) {
                    render_arg(arg, style, running, out);
                }
                rest = &after_start[end + 1..];
                continue;
            }
        }
        render_text_with_legacy("\u{0001}", style, running, out);
        rest = after_start;
    }
    if !rest.is_empty() {
        render_text_with_legacy(rest, style, running, out);
    }
}

fn render_formatted(
    ft: &FormattedText,
    parent_style: &ChatStyle,
    running: &mut ChatStyle,
    out: &mut String,
) {
    let base = ft.get_base();
    let cur_style = parent_style.merged_with(&base.style);
    match ft {
        FormattedText::Text(c) => {
            if !c.text.is_empty() {
                render_text_with_legacy(&c.text, &cur_style, running, out);
            }
        }
        FormattedText::Translatable(c) => {
            if c.key.is_empty() && c.args.len() >= 2 {
                render_arg(&c.args[1], &cur_style, running, out);
                for sib in &base.siblings {
                    render_formatted(sib, &cur_style, running, out);
                }
                return;
            }
            if c.key == "chat.type.text" && c.args.len() >= 2 {
                let sender_plain = arg_plain(&c.args[0]);
                let msg_plain = arg_plain(&c.args[1]);
                let sender_token = sender_plain
                    .split_whitespace()
                    .last()
                    .unwrap_or("")
                    .trim_matches(|ch: char| !ch.is_alphanumeric() && ch != '_');
                let msg_prefix: String = msg_plain.chars().take(48).collect();
                let has_dup_sender = !sender_token.is_empty()
                    && msg_prefix
                        .to_ascii_lowercase()
                        .contains(&sender_token.to_ascii_lowercase());
                if has_dup_sender {
                    render_arg(&c.args[1], &cur_style, running, out);
                    for sib in &base.siblings {
                        render_formatted(sib, &cur_style, running, out);
                    }
                    return;
                }
            }
            let effective_key = c.key.clone();
            let placeholders: Vec<PrimitiveOrComponent> = (0..c.args.len())
                .map(|i| PrimitiveOrComponent::String(format!("\u{0001}{i}\u{0002}")))
                .collect();
            let probe = TranslatableComponent::with_fallback(
                effective_key,
                c.fallback.clone(),
                placeholders,
            );
            match probe.read() {
                Ok(resolved) => {
                    let resolved_style = cur_style.merged_with(&resolved.base.style);
                    if !resolved.text.is_empty() {
                        render_template_with_sentinels(
                            &resolved.text,
                            &c.args,
                            &resolved_style,
                            running,
                            out,
                        );
                    }
                    for sib in &resolved.base.siblings {
                        if let FormattedText::Text(tc) = sib {
                            let sib_style = resolved_style.merged_with(&tc.base.style);
                            render_template_with_sentinels(
                                &tc.text,
                                &c.args,
                                &sib_style,
                                running,
                                out,
                            );
                        } else {
                            render_formatted(sib, &resolved_style, running, out);
                        }
                    }
                }
                Err(_) => {
                    let fallback = c.fallback.as_deref().unwrap_or(&c.key);
                    render_text_with_legacy(fallback, &cur_style, running, out);
                }
            }
        }
    }
    for sib in &base.siblings {
        render_formatted(sib, &cur_style, running, out);
    }
}

fn formatted_to_ansi(ft: &FormattedText) -> String {
    let mut out = String::new();
    let mut running = ChatStyle::default();
    render_formatted(ft, &DEFAULT_STYLE, &mut running, &mut out);
    if !running.is_empty() {
        out.push_str(ChatAnsi::RESET);
    }
    out
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login => {
            ensure_storage();
        }
        Event::Tick => {
            if !STORAGE_READY.load(Ordering::SeqCst) {
                ensure_storage();
            }
        }
        Event::Chat(m) => {
            let msg = match m {
                ChatPacket::System(p) => p.content.clone(),
                ChatPacket::Player(p) => bot
                    .with_registry_holder(|reg| p.message_using_registries(reg))
                    .unwrap_or_else(|_| p.message()),
                ChatPacket::Disguised(p) => bot
                    .with_registry_holder(|reg| p.message_using_registries(reg))
                    .unwrap_or_else(|_| p.message()),
            };
            let raw = formatted_to_ansi(&msg);
            let t = if settings::get_bool(ID, "filter_glyph") {
                crate::clean(&raw)
            } else {
                raw
            };
            if !t.trim().is_empty() && !is_blacklisted(&t) {
                if settings::get_bool(ID, "notify_pm") {
                    if let Some((title, body)) = check_private_message(&t) {
                        crate::out(json!({"t": "notify", "title": title, "body": body}));
                    }
                }
                crate::out(json!({"t": "chat", "v": t}));
            }
        }
        _ => {}
    }
}
