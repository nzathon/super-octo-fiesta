// Modul Chat: meneruskan chat server (berwarna, kode ANSI) ke layar Chat aplikasi.
// Catatan: Azalea 0.16 membungkus Player/Disguised chat ke TranslatableComponent dan TranslatableComponent::read()
// mengonversi argumen FormattedText dengan `.to_string()`, yang menghapus semua warna JSON.
// Karena itu modul ini memformat FormattedText secara rekursif agar warna chat pemain & rank tetap utuh.
use azalea::chat::style::{Ansi as ChatAnsi, ChatFormatting, Style as ChatStyle, TextColor};
use azalea::chat::translatable_component::{PrimitiveOrComponent, TranslatableComponent};
use azalea::chat::{FormattedText, DEFAULT_STYLE};
use azalea::client_chat::ChatPacket;
use azalea::prelude::*;
use serde_json::json;

use super::{Def, Setting};
use crate::settings;

pub fn def() -> Def {
    Def {
        id: "chat",
        title: "Chat",
        desc: "Menampilkan chat server berwarna (termasuk warna hex) di tab Chat. Kotak kirim ada di tab yang sama.",
        enabled: true,
        settings: vec![Setting {
            key: "filter_glyph",
            label: "Buang karakter glyph font kustom",
            kind: "boolean",
            default: json!(true),
        }],
    }
}

fn emit_segment(text: &str, style: &ChatStyle, running: &mut ChatStyle, out: &mut String) {
    if text.is_empty() {
        return;
    }
    let prefix = running.compare_ansi(style);
    out.push_str(&prefix);
    out.push_str(text);
    *running = style.clone();
}

fn legacy_formatting(code: char) -> Option<ChatFormatting> {
    Some(match code.to_ascii_lowercase() {
        '0' => ChatFormatting::Black,
        '1' => ChatFormatting::DarkBlue,
        '2' => ChatFormatting::DarkGreen,
        '3' => ChatFormatting::DarkAqua,
        '4' => ChatFormatting::DarkRed,
        '5' => ChatFormatting::DarkPurple,
        '6' => ChatFormatting::Gold,
        '7' => ChatFormatting::Gray,
        '8' => ChatFormatting::DarkGray,
        '9' => ChatFormatting::Blue,
        'a' => ChatFormatting::Green,
        'b' => ChatFormatting::Aqua,
        'c' => ChatFormatting::Red,
        'd' => ChatFormatting::LightPurple,
        'e' => ChatFormatting::Yellow,
        'f' => ChatFormatting::White,
        'k' => ChatFormatting::Obfuscated,
        'l' => ChatFormatting::Bold,
        'm' => ChatFormatting::Strikethrough,
        'n' => ChatFormatting::Underline,
        'o' => ChatFormatting::Italic,
        'r' => ChatFormatting::Reset,
        _ => return None,
    })
}

fn render_text_with_legacy(
    text: &str,
    base_style: &ChatStyle,
    running: &mut ChatStyle,
    out: &mut String,
) {
    let mut cur = base_style.clone();
    let mut buf = String::new();
    let chars: Vec<char> = text.chars().collect();
    let mut i = 0;

    while i < chars.len() {
        if chars[i] == '§' && i + 1 < chars.len() {
            let next = chars[i + 1];
            // Format Spigot hex: §x§R§R§G§G§B§B
            if (next == 'x' || next == 'X') && i + 13 < chars.len() {
                let mut hex = String::with_capacity(7);
                hex.push('#');
                let mut ok = true;
                for j in 0..6 {
                    let p = i + 2 + j * 2;
                    if chars[p] != '§' || !chars[p + 1].is_ascii_hexdigit() {
                        ok = false;
                        break;
                    }
                    hex.push(chars[p + 1]);
                }
                if ok {
                    if let Some(col) = TextColor::parse(&hex) {
                        if !buf.is_empty() {
                            emit_segment(&buf, &cur, running, out);
                            buf.clear();
                        }
                        cur = base_style.clone();
                        cur.color = Some(col);
                        i += 14;
                        continue;
                    }
                }
            }
            // Format §#RRGGBB
            if next == '#' && i + 7 < chars.len() {
                let hex: String = chars[i + 1..i + 8].iter().collect();
                if hex[1..].chars().all(|c| c.is_ascii_hexdigit()) {
                    if let Some(col) = TextColor::parse(&hex) {
                        if !buf.is_empty() {
                            emit_segment(&buf, &cur, running, out);
                            buf.clear();
                        }
                        cur = base_style.clone();
                        cur.color = Some(col);
                        i += 8;
                        continue;
                    }
                }
            }
            if let Some(fmt) = legacy_formatting(next) {
                if !buf.is_empty() {
                    emit_segment(&buf, &cur, running, out);
                    buf.clear();
                }
                if fmt == ChatFormatting::Reset {
                    cur = base_style.clone();
                } else {
                    if !fmt.is_format() {
                        // Di Minecraft, kode warna me-reset bold/italic/dll dari legacy sebelumnya
                        cur = base_style.clone();
                    }
                    cur.apply_formatting(&fmt);
                }
                i += 2;
                continue;
            }
        }
        buf.push(chars[i]);
        i += 1;
    }
    if !buf.is_empty() {
        emit_segment(&buf, &cur, running, out);
    }
}

fn render_arg(
    arg: &PrimitiveOrComponent,
    parent_style: &ChatStyle,
    running: &mut ChatStyle,
    out: &mut String,
) {
    match arg {
        PrimitiveOrComponent::FormattedText(ft) => render_formatted(ft, parent_style, running, out),
        PrimitiveOrComponent::String(s) => render_text_with_legacy(s, parent_style, running, out),
        other => emit_segment(&other.to_string(), parent_style, running, out),
    }
}

fn render_template_with_sentinels(
    text: &str,
    args: &[PrimitiveOrComponent],
    style: &ChatStyle,
    running: &mut ChatStyle,
    out: &mut String,
) {
    let mut rest = text;
    while let Some(start) = rest.find('\u{0001}') {
        let before = &rest[..start];
        if !before.is_empty() {
            render_text_with_legacy(before, style, running, out);
        }
        let after_start = &rest[start + 1..];
        if let Some(end) = after_start.find('\u{0002}') {
            let idx_str = &after_start[..end];
            if let Ok(idx) = idx_str.parse::<usize>() {
                if let Some(arg) = args.get(idx) {
                    render_arg(arg, style, running, out);
                }
                rest = &after_start[end + 1..];
                continue;
            }
        }
        render_text_with_legacy("\u{0001}", style, running, out);
        rest = after_start;
    }
    if !rest.is_empty() {
        render_text_with_legacy(rest, style, running, out);
    }
}

fn render_formatted(
    ft: &FormattedText,
    parent_style: &ChatStyle,
    running: &mut ChatStyle,
    out: &mut String,
) {
    let base = ft.get_base();
    let cur_style = parent_style.merged_with(&base.style);

    match ft {
        FormattedText::Text(c) => {
            if !c.text.is_empty() {
                render_text_with_legacy(&c.text, &cur_style, running, out);
            }
        }
        FormattedText::Translatable(c) => {
            let effective_key = if c.key.is_empty() && c.args.len() >= 2 {
                "chat.type.text".to_string()
            } else {
                c.key.clone()
            };
            let placeholders: Vec<PrimitiveOrComponent> = (0..c.args.len())
                .map(|i| PrimitiveOrComponent::String(format!("\u{0001}{i}\u{0002}")))
                .collect();
            let probe = TranslatableComponent::with_fallback(
                effective_key,
                c.fallback.clone(),
                placeholders,
            );
            match probe.read() {
                Ok(resolved) => {
                    let resolved_style = cur_style.merged_with(&resolved.base.style);
                    if !resolved.text.is_empty() {
                        render_template_with_sentinels(
                            &resolved.text,
                            &c.args,
                            &resolved_style,
                            running,
                            out,
                        );
                    }
                    for sib in &resolved.base.siblings {
                        if let FormattedText::Text(tc) = sib {
                            let sib_style = resolved_style.merged_with(&tc.base.style);
                            render_template_with_sentinels(
                                &tc.text,
                                &c.args,
                                &sib_style,
                                running,
                                out,
                            );
                        } else {
                            render_formatted(sib, &resolved_style, running, out);
                        }
                    }
                }
                Err(_) => {
                    let fallback = c.fallback.as_deref().unwrap_or(&c.key);
                    render_text_with_legacy(fallback, &cur_style, running, out);
                }
            }
        }
    }

    for sib in &base.siblings {
        render_formatted(sib, &cur_style, running, out);
    }
}

fn formatted_to_ansi(ft: &FormattedText) -> String {
    let mut out = String::new();
    let mut running = ChatStyle::default();
    render_formatted(ft, &DEFAULT_STYLE, &mut running, &mut out);
    if !running.is_empty() {
        out.push_str(ChatAnsi::RESET);
    }
    out
}

pub async fn on_event(bot: &Client, event: &Event) {
    if let Event::Chat(m) = event {
        let msg = match m {
            ChatPacket::System(p) => p.content.clone(),
            ChatPacket::Player(p) => bot
                .with_registry_holder(|reg| p.message_using_registries(reg))
                .unwrap_or_else(|_| p.message()),
            ChatPacket::Disguised(p) => bot
                .with_registry_holder(|reg| p.message_using_registries(reg))
                .unwrap_or_else(|_| p.message()),
        };
        let raw = formatted_to_ansi(&msg);
        let t = if settings::get_bool("chat", "filter_glyph") {
            crate::clean(&raw)
        } else {
            raw
        };
        if !t.trim().is_empty() {
            crate::out(json!({"t": "chat", "v": t}));
        }
    }
}
