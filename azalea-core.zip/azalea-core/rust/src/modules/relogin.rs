// Modul Relogin: login otomatis, pindah server lewat item menu (1 atau multi-step),
// simpan password langsung dari /login manual, reset otomatis saat balik ke lobby,
// serta pengaturan sambung ulang otomatis (dibaca oleh Kotlin saat proses berhenti).
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::OnceLock;
use std::time::{Duration, Instant};
use azalea::inventory::ItemStack;
use azalea::prelude::*;
use serde_json::{json, Value};
use tokio::sync::Notify;
use super::{Def, Setting};
use crate::{settings, storage};

const ID: &str = "relogin";

static LOGIN_SENT: AtomicBool = AtomicBool::new(false);
static REGISTER_SENT: AtomicBool = AtomicBool::new(false);
static LOGGED_IN: AtomicBool = AtomicBool::new(false);
static LOGIN_PROMPTED: AtomicBool = AtomicBool::new(false);
static TRANSFER_STARTED: AtomicBool = AtomicBool::new(false);
static STORAGE_READY: AtomicBool = AtomicBool::new(false);
static LOGIN_NOTIFY: OnceLock<Notify> = OnceLock::new();

fn notify() -> &'static Notify {
    LOGIN_NOTIFY.get_or_init(Notify::new)
}

pub fn def() -> Def {
    Def {
        id: ID,
        title: "Relogin",
        desc: "Login otomatis memakai password yang tersimpan per server dan akun (tab Storage). Saat mengetik /login atau /register manual, password langsung disimpan. Mendukung pindah server multi-step & sambung ulang otomatis.",
        enabled: true,
        settings: vec![
            Setting { key: "auto_login", label: "Kirim perintah login otomatis", kind: "boolean", default: json!(true) },
            Setting { key: "login_delay", label: "Jeda sebelum kirim login (detik)", kind: "number", default: json!(2) },
            Setting { key: "login_command", label: "Perintah login ({password} {username})", kind: "text", default: json!("/login {password}") },
            Setting { key: "auto_save", label: "Simpan password langsung dari /login manual", kind: "boolean", default: json!(true) },
            Setting { key: "auto_register", label: "Register otomatis kalau diminta", kind: "boolean", default: json!(false) },
            Setting { key: "register_command", label: "Perintah register", kind: "text", default: json!("/register {password} {password}") },
            Setting { key: "auto_transfer", label: "Pindah server lewat item menu (diatur per server di Storage)", kind: "boolean", default: json!(true) },
            Setting { key: "transfer_delay", label: "Jeda sebelum pindah server (detik)", kind: "number", default: json!(3) },
            Setting { key: "auto_reconnect", label: "Sambung ulang otomatis", kind: "boolean", default: json!(true) },
            Setting { key: "reconnect_delay", label: "Jeda sambung ulang (detik, naik tiap gagal, maks 60)", kind: "number", default: json!(5) },
            Setting { key: "max_reconnect", label: "Batas percobaan (0 = tanpa batas)", kind: "number", default: json!(0) },
        ],
    }
}

// ---------- storage: {"host:port": {"akun": [{"username","password"}], "pindah": {...}, "patterns": {...}}} ----------

fn key() -> String {
    format!("{}:{}", settings::host(), settings::port())
}

fn same(a: &Value, user: &str) -> bool {
    a["username"].as_str().map(|u| u.eq_ignore_ascii_case(user)).unwrap_or(false)
}

/// Pastikan entri server, akun, dan blok "pindah" ada di Storage supaya bisa diisi lebih awal.
fn ensure_entry() {
    let k = key();
    if k == ":25565" || settings::host().is_empty() {
        return;
    }
    let mut root = storage::get(ID);
    let mut changed = false;
    if !root[&k].is_object() {
        root[&k] = json!({"akun": []});
        changed = true;
    }
    if !root[&k]["akun"].is_array() {
        root[&k]["akun"] = json!([]);
        changed = true;
    }
    let user = settings::username();
    let has = root[&k]["akun"].as_array().map(|a| a.iter().any(|x| same(x, &user))).unwrap_or(false);
    if !has {
        root[&k]["akun"].as_array_mut().unwrap().push(json!({"username": user, "password": ""}));
        changed = true;
        crate::log(format!("entri baru di Storage untuk {k}. Login manual sekali (/login ...), password akan tersimpan langsung."));
    }
    if !root[&k]["pindah"].is_object() {
        root[&k]["pindah"] = json!({
            "aktif": false,
            "slotHotbar": 1,
            "slotMenu": 0,
            "slotsMenu": [],
            "jedaKlik": 0.8
        });
        changed = true;
    } else {
        if !root[&k]["pindah"]["slotsMenu"].is_array() {
            root[&k]["pindah"]["slotsMenu"] = json!([]);
            changed = true;
        }
        if root[&k]["pindah"]["jedaKlik"].is_null() {
            root[&k]["pindah"]["jedaKlik"] = json!(0.8);
            changed = true;
        }
    }
    if !root["patterns"].is_object() {
        root["patterns"] = json!({
            "ok_words": [],
            "login_words": [],
            "fail_words": [],
            "lobby_words": []
        });
        changed = true;
    }
    if changed {
        storage::save(ID, root);
    }
    STORAGE_READY.store(true, Ordering::SeqCst);
}

fn password() -> Option<String> {
    let root = storage::get(ID);
    let user = settings::username();
    root[&key()]["akun"]
        .as_array()?
        .iter()
        .find(|a| same(a, &user))
        .and_then(|a| a["password"].as_str())
        .filter(|p| !p.is_empty())
        .map(|p| p.to_string())
}

fn save_password(pw: &str, why: &str) {
    ensure_entry();
    let mut root = storage::get(ID);
    let (k, user) = (key(), settings::username());
    if let Some(arr) = root[&k]["akun"].as_array_mut() {
        if let Some(a) = arr.iter_mut().find(|a| same(a, &user)) {
            if a["password"].as_str() == Some(pw) {
                return;
            }
            a["password"] = json!(pw);
        }
    }
    storage::save(ID, root);
    crate::log(format!("password untuk {user} disimpan di Storage ({why})"));
}

fn fill(tpl: &str, pw: &str) -> String {
    tpl.replace("{password}", pw).replace("{username}", &settings::username())
}

// ---------- pindah server lewat item menu (1-step & multi-step) ----------

struct PindahCfg {
    hb: usize,
    slots: Vec<usize>,
    step_delay: Duration,
}

fn pindah() -> Option<PindahCfg> {
    let root = storage::get(ID);
    let p = &root[&key()]["pindah"];
    if !p["aktif"].as_bool().unwrap_or(false) {
        return None;
    }
    let hb = p["slotHotbar"].as_u64().unwrap_or(1).clamp(1, 9) as usize - 1;
    let mut slots: Vec<usize> = p["slotsMenu"]
        .as_array()
        .map(|arr| arr.iter().filter_map(|v| v.as_u64().map(|n| n as usize)).collect())
        .unwrap_or_default();
    if slots.is_empty() {
        slots.push(p["slotMenu"].as_u64().unwrap_or(0) as usize);
    }
    let step_secs = p["jedaKlik"].as_f64().unwrap_or(0.8).clamp(0.1, 10.0);
    Some(PindahCfg {
        hb,
        slots,
        step_delay: Duration::from_secs_f64(step_secs),
    })
}

/// Jumlah slot menu yang sedang terbuka (46 = hanya inventory sendiri).
fn menu_slots(bot: &Client) -> Option<Vec<ItemStack>> {
    super::monitor::handle_of(bot)?.slots()
}

async fn transfer(bot: Client) {
    if !settings::get_bool(ID, "auto_transfer") {
        return;
    }
    let Some(cfg) = pindah() else { return };
    if TRANSFER_STARTED.swap(true, Ordering::SeqCst) {
        return;
    }
    let delay = settings::get_f64(ID, "transfer_delay").clamp(0.0, 60.0);
    tokio::time::sleep(Duration::from_millis((delay * 1000.0) as u64)).await;

    for attempt in 1..=3 {
        let held = menu_slots(&bot).and_then(|s| s.get(36 + cfg.hb).cloned());
        if !held.map(|i| i.is_present()).unwrap_or(false) {
            crate::log(format!("slot hotbar {} masih kosong (percobaan {attempt}), menunggu...", cfg.hb + 1));
            tokio::time::sleep(Duration::from_secs(2)).await;
            continue;
        }
        let _ = bot.set_selected_hotbar_slot(cfg.hb as u8);
        tokio::time::sleep(Duration::from_millis(300)).await;
        bot.start_use_item();

        let t0 = Instant::now();
        let mut opened = false;
        while t0.elapsed() < Duration::from_secs(6) {
            tokio::time::sleep(Duration::from_millis(200)).await;
            if menu_slots(&bot).map(|s| s.len() != 46).unwrap_or(false) {
                opened = true;
                break;
            }
        }
        if !opened {
            crate::log(format!("menu tidak terbuka (percobaan {attempt})"));
            tokio::time::sleep(Duration::from_secs(2)).await;
            continue;
        }

        crate::log("menu terbuka, menunggu isi menu");
        let mut all_ok = true;
        for (step_idx, &slot) in cfg.slots.iter().enumerate() {
            let t1 = Instant::now();
            let mut target: Option<ItemStack> = None;
            while t1.elapsed() < Duration::from_secs(5) {
                if let Some(it) = menu_slots(&bot).and_then(|s| s.get(slot).cloned()) {
                    if it.is_present() {
                        target = Some(it);
                        break;
                    }
                }
                tokio::time::sleep(Duration::from_millis(250)).await;
            }
            let Some(item) = target else {
                crate::log(format!("slot {slot} (langkah {}) kosong di menu itu (percobaan {attempt})", step_idx + 1));
                all_ok = false;
                break;
            };
            if let Some(h) = super::monitor::handle_of(&bot) {
                h.left_click(slot);
                crate::log(format!("klik slot {slot} ({})", super::monitor::item_name(&item)));
            }
            if step_idx + 1 < cfg.slots.len() {
                tokio::time::sleep(cfg.step_delay).await;
            }
        }

        if all_ok {
            return;
        }
        if let Some(h) = super::monitor::handle_of(&bot) {
            h.close();
        }
        tokio::time::sleep(Duration::from_millis(1500)).await;
    }
    crate::log("pindah server gagal setelah 3 percobaan (cek nomor slot di Storage)");
}

// ---------- pengenalan pesan server ----------

fn has_any(t: &str, words: &[&str]) -> bool {
    words.iter().any(|w| t.contains(w))
}

fn has_custom_word(t: &str, list_key: &str) -> bool {
    let root = storage::get(ID);
    let k = key();
    for src in [&root[&k]["patterns"][list_key], &root["patterns"][list_key]] {
        if let Some(arr) = src.as_array() {
            for item in arr {
                if let Some(w) = item.as_str() {
                    let clean = w.trim().to_lowercase();
                    if !clean.is_empty() && t.contains(&clean) {
                        return true;
                    }
                }
            }
        }
    }
    false
}

const OK: &[&str] = &[
    "logged in as", "welcome back", "berhasil login", "berhasil masuk", "successfully logged",
    "successfully authenticated", "login success", "login berhasil", "[ success ]",
    "you are now logged in", "authenticated",
];
const ALREADY: &[&str] = &["already logged", "session is already active", "sudah login"];
const LOGIN: &[&str] = &["/login", "please login", "please log in", "silakan login", "silakan masuk"];
const REGISTER: &[&str] = &["/register", "please register", "silakan daftar", "silakan register"];
const FAIL: &[&str] = &[
    "wrong", "incorrect", "invalid", "salah", "gagal", "failed", "not registered", "belum terdaftar", "tidak terdaftar",
];
const LOBBY_KICK: &[&str] = &[
    "kicked whilst connecting", "moved to lobby", "dipindahkan ke lobby", "server closed",
    "server is restarting", "sedang restart", "fallback server",
];

// ---------- aksi ----------

fn send_login(bot: &Client, why: &str) {
    if LOGIN_SENT.load(Ordering::SeqCst) || !settings::get_bool(ID, "auto_login") {
        return;
    }
    match password() {
        None => crate::log("password belum diisi di Storage, login tidak dikirim"),
        Some(pw) => {
            LOGIN_SENT.store(true, Ordering::SeqCst);
            LOGIN_PROMPTED.store(true, Ordering::SeqCst);
            bot.chat(fill(&settings::get_str(ID, "login_command"), &pw).as_str());
            crate::log(format!("login dikirim ({why})"));
        }
    }
}

fn send_register(bot: &Client) {
    if REGISTER_SENT.load(Ordering::SeqCst) || !settings::get_bool(ID, "auto_register") {
        return;
    }
    if let Some(pw) = password() {
        REGISTER_SENT.store(true, Ordering::SeqCst);
        LOGIN_PROMPTED.store(true, Ordering::SeqCst);
        bot.chat(fill(&settings::get_str(ID, "register_command"), &pw).as_str());
        crate::log("register dikirim");
    }
}

/// Dipanggil saat pengguna mengirim chat/perintah dari aplikasi: langsung simpan password dari /login dan /register manual.
pub fn on_outgoing(text: &str) {
    if !settings::get_bool(ID, "auto_save") {
        return;
    }
    let parts: Vec<&str> = text.trim().trim_start_matches('/').split_whitespace().collect();
    let cmd = parts.first().map(|c| c.to_lowercase()).unwrap_or_default();
    if !text.trim().starts_with('/') || !["login", "l", "log", "register", "reg"].contains(&cmd.as_str()) {
        return;
    }
    if let Some(pw) = parts.get(1) {
        save_password(pw, &format!("/{cmd} manual"));
    }
}

async fn after_login(bot: Client) {
    let delay = settings::get_f64(ID, "login_delay").clamp(0.0, 60.0);
    tokio::time::sleep(Duration::from_millis((delay * 1000.0) as u64)).await;
    let mut must_wait_login = false;
    if settings::get_bool(ID, "auto_login") {
        if password().is_none() {
            crate::log("belum ada password tersimpan: login manual sekali (/login ...), langsung tersimpan");
        } else {
            send_login(&bot, "terjadwal");
            must_wait_login = true;
        }
    }
    if must_wait_login || LOGIN_PROMPTED.load(Ordering::SeqCst) {
        let mut logged_wait_note = false;
        let t0 = Instant::now();
        while !LOGGED_IN.load(Ordering::SeqCst) {
            if !logged_wait_note && t0.elapsed() >= Duration::from_secs(10) {
                crate::log("menunggu konfirmasi login dari server sebelum pindah server...");
                logged_wait_note = true;
            }
            let _ = tokio::time::timeout(Duration::from_secs(2), notify().notified()).await;
        }
    }
    transfer(bot).await;
}

pub async fn on_event(bot: &Client, event: &Event) {
    match event {
        Event::Login => {
            LOGIN_SENT.store(false, Ordering::SeqCst);
            REGISTER_SENT.store(false, Ordering::SeqCst);
            LOGGED_IN.store(false, Ordering::SeqCst);
            LOGIN_PROMPTED.store(false, Ordering::SeqCst);
            TRANSFER_STARTED.store(false, Ordering::SeqCst);
            ensure_entry();
            let b = bot.clone();
            tokio::spawn(after_login(b));
        }
        Event::Tick => {
            if !STORAGE_READY.load(Ordering::SeqCst) {
                ensure_entry();
            }
        }
        Event::Chat(m) => {
            let t = m.message().to_string().to_lowercase();
            if LOGIN_SENT.load(Ordering::SeqCst)
                && !LOGGED_IN.load(Ordering::SeqCst)
                && (has_any(&t, FAIL) || has_custom_word(&t, "fail_words"))
            {
                crate::log("server menolak login dari password tersimpan; periksa password di Storage atau login manual lagi");
            }
            if has_any(&t, ALREADY) || has_any(&t, OK) || has_custom_word(&t, "ok_words") {
                LOGGED_IN.store(true, Ordering::SeqCst);
                notify().notify_waiters();
                let b = bot.clone();
                tokio::spawn(transfer(b));
            } else if has_any(&t, LOGIN) || has_custom_word(&t, "login_words") {
                LOGIN_PROMPTED.store(true, Ordering::SeqCst);
                send_login(bot, "diminta server");
            } else if has_any(&t, REGISTER) {
                LOGIN_PROMPTED.store(true, Ordering::SeqCst);
                send_register(bot);
            } else if TRANSFER_STARTED.load(Ordering::SeqCst)
                && (has_any(&t, LOBBY_KICK) || has_custom_word(&t, "lobby_words"))
            {
                crate::log("terdeteksi kembali ke lobby, menjadwalkan pindah server ulang...");
                TRANSFER_STARTED.store(false, Ordering::SeqCst);
                let b = bot.clone();
                tokio::spawn(async move {
                    tokio::time::sleep(Duration::from_secs(2)).await;
                    transfer(b).await;
                });
            }
        }
        _ => {}
    }
}
