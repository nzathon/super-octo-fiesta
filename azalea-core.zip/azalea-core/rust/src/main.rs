// Azalea - inti Azalea.
// Satu koneksi = satu proses. Aplikasi (Kotlin) menjalankan program ini, lalu berbicara lewat pipa:
//   stdin  (baris JSON): baris pertama = konfigurasi {"host","port","username","ip","rport","modules":{...}};
//                        berikutnya {"t":"chat","v":"teks atau /perintah"}, {"t":"inv","a":aksi,"slot":n},
//                        {"t":"web","ch":channel,"a":aksi,"v":{...}}, {"t":"set","m":modul,"k":kunci,"v":nilai},
//                        {"t":"storage","m":modul,"v":{...}} atau {"t":"quit"}
//   stdout (baris JSON): {"t":"status","v":"connecting|online|offline"}, {"t":"log","v":"..."},
//                        {"t":"chat","v":"..."}, {"t":"web","ch":channel,"k":key,"live":bool,"v":{...}}
// Teks lain di stdout/stderr (log azalea, panic) diteruskan aplikasi apa adanya ke Log.
// Tidak ada port jaringan. Kalau stdin ditutup (aplikasi mati), program ikut berhenti.

use std::net::{IpAddr, SocketAddr};
use std::sync::Mutex;
use std::time::Duration;

use azalea::prelude::*;
use azalea::JoinOpts;

mod modules;
mod settings;
mod storage;

use serde_json::{json, Value};
use tokio::io::{AsyncBufReadExt, BufReader};

static BOT: Mutex<Option<Client>> = Mutex::new(None);

pub fn out(v: Value) {
    println!("{v}");
}
pub fn status(s: &str) {
    out(json!({"t": "status", "v": s}));
}
pub fn log(t: impl AsRef<str>) {
    out(json!({"t": "log", "v": t.as_ref()}));
}
/// Kirim pembaruan ke tab WebView dinamis (`channel` sesuai `WebTab.channel`).
/// `live = true` mengirim langsung tanpa menyimpan snapshot (`emitLive`); `live = false` menyimpan snapshot per `key`.
#[allow(dead_code)]
pub fn web_emit(channel: &str, key: &str, live: bool, payload: Value) {
    out(json!({"t": "web", "ch": channel, "k": key, "live": live, "v": payload}));
}

pub fn clean(s: &str) -> String {
    // buang karakter glyph font kustom (private-use) dan karakter rusak
    s.chars().filter(|c| !('\u{E000}'..='\u{F8FF}').contains(c) && *c != '\u{FFFD}').collect()
}

#[derive(Default, Clone, Component)]
pub struct State;

async fn handle(bot: Client, event: Event, _state: State) -> anyhow::Result<()> {
    // Keep-alive dan chunk tidak dipakai modul mana pun. Dilewati lebih awal supaya antrean
    // event azalea tidak menumpuk (peringatan "Event channel has more than 1,000 items").
    if matches!(event, Event::KeepAlive(_) | Event::ReceiveChunk(_)) {
        return Ok(());
    }
    if let Event::Packet(packet) = &event {
        if settings::enabled("monitor") {
            modules::monitor::on_packet(&bot, packet);
        }
        if settings::enabled("playerlist") {
            modules::playerlist::on_packet(packet);
        }
        return Ok(());
    }
    match &event {
        Event::Login => {
            *BOT.lock().unwrap() = Some(bot.clone());
            status("online");
            log("masuk ke server");
        }
        Event::Disconnect(reason) => {
            let r = reason.as_ref().map(|r| clean(&r.to_string())).unwrap_or_else(|| "tanpa alasan".into());
            log(format!("terputus: {r}"));
            status("offline");
            tokio::time::sleep(Duration::from_millis(300)).await;
            std::process::exit(0);
        }
        _ => {}
    }
    modules::dispatch(&bot, &event).await;
    Ok(())
}

fn main() {
    // "azalea-core modules" = cetak daftar modul (skema setelan) + tab web dinamis lalu keluar.
    if std::env::args().nth(1).as_deref() == Some("modules") {
        println!(
            "{{\"t\":\"modules\",\"core_name\":{},\"core_version\":{},\"v\":{},\"tabs\":{}}}",
            json!(env!("CARGO_PKG_NAME")),
            json!(env!("CARGO_PKG_VERSION")),
            modules::schema(),
            modules::tabs_schema()
        );
        return;
    }
    let rt = tokio::runtime::Runtime::new().expect("tokio runtime");
    rt.block_on(run());
}

async fn run() {
    let mut lines = BufReader::new(tokio::io::stdin()).lines();
    let cfg: Value = match lines.next_line().await {
        Ok(Some(l)) => serde_json::from_str(&l).unwrap_or(Value::Null),
        _ => std::process::exit(2),
    };
    let host = cfg["host"].as_str().unwrap_or("").trim().to_string();
    let port = cfg["port"].as_u64().unwrap_or(25565);
    let user = cfg["username"].as_str().unwrap_or("").trim().to_string();
    settings::init(cfg["modules"].clone());
    storage::init(cfg["storage"].clone());
    settings::set_context(&host, port as u16, &user);
    if host.is_empty() || user.is_empty() {
        log("konfigurasi kosong (host/username)");
        std::process::exit(2);
    }

    // perintah dari aplikasi
    tokio::spawn(async move {
        while let Ok(Some(l)) = lines.next_line().await {
            let v: Value = match serde_json::from_str(&l) {
                Ok(v) => v,
                Err(_) => continue,
            };
            match v["t"].as_str() {
                Some("chat") => {
                    let text = v["v"].as_str().unwrap_or("").to_string();
                    let b = BOT.lock().unwrap().clone();
                    if let (Some(b), false) = (b, text.is_empty()) {
                        if settings::enabled("relogin") {
                            modules::relogin::on_outgoing(&text);
                        }
                        b.chat(text.as_str());
                    }
                }
                Some("inv") => {
                    let b = BOT.lock().unwrap().clone();
                    if let (Some(b), true) = (b, settings::enabled("monitor")) {
                        modules::monitor::on_action(&b, &v);
                    }
                }
                Some("web") => {
                    let ch = v["ch"].as_str().unwrap_or("");
                    let act = v["a"].as_str().unwrap_or("");
                    let b = BOT.lock().unwrap().clone();
                    if let Some(b) = b {
                        modules::dispatch_web(&b, ch, act, &v["v"]).await;
                    }
                }
                Some("set") => {
                    if let (Some(m), Some(k)) = (v["m"].as_str(), v["k"].as_str()) {
                        settings::set(m, k, v["v"].clone());
                    }
                }
                Some("storage") => {
                    if let Some(m) = v["m"].as_str() {
                        storage::replace_from_app(m, v["v"].clone());
                    }
                }
                Some("quit") => std::process::exit(0),
                _ => {}
            }
        }
        std::process::exit(0); // stdin tertutup = aplikasi sudah tidak ada
    });

    status("connecting");
    // Alamat untuk handshake = yang diketik pengguna. Alamat sambungan sebenarnya (IP, hasil DNS/SRV dari
    // Kotlin) diberikan langsung supaya resolver milik azalea (butuh JNI Android) tidak dipakai.
    let addr = format!("{host}:{port}");
    let mut opts = JoinOpts::default();
    let ip: Option<IpAddr> = cfg["ip"].as_str().and_then(|s| s.parse().ok());
    let rport = cfg["rport"].as_u64().unwrap_or(port) as u16;
    if let Some(ip) = ip {
        opts = opts.custom_socket_addr(SocketAddr::new(ip, rport));
    }
    let account = Account::offline(&user);
    let r = ClientBuilder::new().set_handler(handle).start_with_opts(account, addr, opts).await;
    log(format!("azalea berhenti: {r:?}"));
    status("offline");
    tokio::time::sleep(Duration::from_millis(300)).await;
    std::process::exit(1);
}
