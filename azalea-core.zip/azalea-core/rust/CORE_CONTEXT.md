# Azalea Core Pack — Konteks untuk AI

> File ini ikut dikemas ke dalam `azalea-core-pack.zip` agar AI bisa menambah/mengubah modul Rust maupun tab WebView **tanpa perlu mengubah, mem-build, atau meng-install ulang APK Android**.

## 1. Lingkungan & Aturan Kerja
- Target perangkat: HP Android 9 `arm64-v8a` (`aarch64-linux-android`). Pengguna bekerja dari HP dan membangun lewat GitHub Actions.
- Build **Core saja** memakai `.github/workflows/build-core.yml` (otomatis jalan saat `rust/**`, `app/src/main/assets/**`, atau `web/**` berubah) -> menghasilkan artefak `azalea-core-pack` yang diimpor langsung di tab/layar **Modul** -> **Import Core (.zip)**.
- **Jangan menebak API crate `azalea`**: periksa dokumentasi `https://azalea.rs/azalea/` atau cek source crate di `.cargo/git/checkouts/azalea-*`.
- Server target memakai anti-cheat, proxy + `/login` wajib tiap koneksi, kadang SRV record, dan plugin cracked/SkinsRestorer. Jangan buat perilaku bot yang tidak wajar; jangan simpan/cetak password ke log.
- Bahasa komunikasi dengan pengguna: Bahasa Indonesia santai dan ringkas. Bedakan mana yang sudah teruji/terbukti dan mana yang baru dugaan/belum di-compile.

## 2. Isi Bundel `azalea-core-pack.zip`
- `azalea-core` — binary ELF `aarch64-linux-android` hasil `cargo ndk -t arm64-v8a -P 26 build --release`. Dijalankan APK lewat `ProcessBuilder` dari `filesDir/core/azalea-core` (diizinkan SELinux karena APK memakai `targetSdk = 28`).
- `web/` — aset HTML/JS/CSS untuk tab WebView. File di sini meng-override `assets/` bawaan APK (termasuk `inventory.html` milik modul `monitor`) dan melayani tab WebView dinamis baru via origin `https://appassets.azalea.local/<nama_file>`.
- `manifest.json` — metadata build (`core_version`, `run_number`, `sha`).
- `CORE_CONTEXT.md` — file konteks ini.

## 3. Protokol Pipa `stdin` / `stdout` (`rust/src/main.rs`)
Aplikasi Android menjalankan `azalea-core` sebagai proses anak (1 koneksi = 1 proses).

### Mode Skema (`azalea-core modules`)
Saat aplikasi start atau setelah import core, APK menjalankan `azalea-core modules` (timeout 6 detik) dan membaca baris JSON:
```json
{
  "t": "modules",
  "core_version": "0.1.0",
  "v": [ /* hasil modules::schema() */ ],
  "tabs": [ /* hasil modules::tabs_schema() */ ]
}
```

### `stdin` (APK -> Rust, JSON per baris)
1. Baris pertama (konfigurasi awal):
   `{"host":"...","port":25565,"username":"...","ip":"1.2.3.4","rport":25565,"modules":{...},"storage":{...}}`
2. Perintah berjalan:
   - `{"t":"chat","v":"teks atau /perintah"}`
   - `{"t":"inv","a":"left|right|shift|middle|drop1|dropall|offhand|detail|select|use|close|refresh|clear_feed","slot":0}`
   - `{"t":"web","ch":"<channel>","a":"<action>","v":{...}}` -> diteruskan ke `modules::dispatch_web(&bot, ch, action, &v)`
   - `{"t":"set","m":"<module_id>","k":"<key>","v":<nilai>}` -> memperbarui `settings` live
   - `{"t":"storage","m":"<module_id>","v":{...}}` -> memperbarui `storage` dari UI
   - `{"t":"quit"}`

### `stdout` (Rust -> APK, JSON per baris)
- `{"t":"status","v":"connecting|online|offline"}` (`crate::status(...)`)
- `{"t":"log","v":"..."}` (`crate::log(...)`)
- `{"t":"chat","v":"<teks ANSI>"}`
- `{"t":"players","v":[{"id":"...","name":"...","display":"...","ping":50,"self":false,"hash":"..."}]}`
- `{"t":"inv" | "mon_status" | "mon_feed" | "detail", ...}` (khusus channel `"monitor"`)
- `{"t":"storage","m":"<module_id>","v":{...}}` (sinkronisasi storage persisten ke HP)
- `{"t":"web","ch":"<channel>","k":"<snapshot_key>","live":false,"v":{...}}` (`crate::web_emit(ch, key, live, payload)`)
  - `live = false`: APK menyimpan **snapshot terbaru** per `(ch, k)` dan menggabungkan kiriman cepat (`coalesce`), lalu mengirim 1x snapshot saat tab dibuka/resume (anti replay setelah AFK).
  - `live = true`: dikirim langsung jika tab sedang aktif & tampil, tanpa disimpan sebagai snapshot.

## 4. Cara Menambah Modul Rust Baru
1. Buat file `rust/src/modules/<nama>.rs` dengan `pub fn def() -> Def` dan `pub async fn on_event(bot: &Client, event: &Event)`.
2. Jenis setting yang didukung UI APK (`Setting.kind`): `"boolean"`, `"text"`, `"number"`, `"password"`.
3. Baca setting via `crate::settings::{enabled, bool, str, num}` dan baca/simpan data persisten per server/akun via `crate::storage::{get, set}`.
4. Daftarkan di `rust/src/modules/mod.rs`:
   - `pub mod <nama>;`
   - Tambahkan `<nama>::def()` di `all()`
   - Panggil `if settings::enabled("<id>") { <nama>::on_event(bot, event).await; }` di `dispatch()`
   - Jika butuh paket mentah sebelum di-drop, teruskan dari `handle()` di `main.rs` (`if let Event::Packet(packet) = &event`).
   - Pastikan `Event::KeepAlive(_) | Event::ReceiveChunk(_)` tetap ringan agar antrean event Azalea tidak menumpuk.

## 5. Cara Menambah Tab WebView Dinamis (Tanpa Ubah APK)
1. Tambahkan entry `WebTab` di `web_tabs()` pada `rust/src/modules/mod.rs`:
   ```rust
   WebTab {
       id: "automine",
       title: "AutoMine",
       html: "automine.html",
       channel: "automine",
       module: "automine", // kosong "" jika tab harus selalu tampil
   }
   ```
   > Jika `module` diisi, APK **otomatis menyembunyikan tab** saat modul tersebut dimatikan di menu **Modul**, dan otomatis memunculkannya kembali saat modul dinyalakan.
2. Buat file HTML-nya di `app/src/main/assets/automine.html` (atau folder `web/automine.html` di root repo — keduanya ikut masuk ke `web/` dalam `azalea-core-pack.zip`).
3. Tangani aksi dari HTML di `modules::dispatch_web()` pada `rust/src/modules/mod.rs` dan kirim state ke HTML pakai `crate::web_emit("automine", "state", false, json!({ ... }))`.
4. Di sisi HTML/JS:
   - Terima data dari APK/Rust lewat:
     ```js
     window.__tabMsg = function(msg) {
       // msg bisa berupa:
       // 1) {"type":"sync","name":"...","modules":{...},"storage":{...}} saat tab dibuka/resume
       // 2) {"t":"web","ch":"automine","k":"state","live":false,"v":{...}} dari web_emit()
     };
     ```
   - Kirim aksi ke Rust lewat global `window.Android`:
     - `Android.emit(action, JSON.stringify(payload))` -> masuk ke `dispatch_web()`
     - `Android.refresh()` -> mengirim aksi `"refresh"` ke `dispatch_web()`
     - `Android.setSetting(moduleId, key, JSON.stringify(value))` -> ubah setting modul & simpan ke Store
     - `Android.copy(text)` -> salin teks ke clipboard Android
   - Permintaan gambar ke `https://textures.minecraft.net/texture/...` dan `https://assets.mcasset.cloud/...` otomatis di-proxy dengan header CORS `*` dan di-cache ke disk oleh APK (`WebTabHost.kt` + `TexCache.kt`).


## 6. Format Blacklist & Quick Action Chat (`rust/src/modules/chat.rs`)
Storage modul `"chat"` menyimpan `global.blacklist` dan `servers["<host>:<port>"].blacklist` sebagai array objek bernama dengan tipe per-pattern:
```json
[
  {
    "name": "broadcast",
    "patterns": [
      ["regex", "pola1"],
      ["match", "pola2"]
    ],
    "enable": true,
    "case_sensitive": false
  }
]
```
- Mode tiap entry di `patterns`: `"regex"`, `"match"`, `"exact"`, `"starts"`. Juga mendukung entry objek `{"type": "regex", "pattern": "..."}`, ringkas `["regex", "pola1", "pola2"]`, maupun format lama.
- Tombol gear di pojok kanan atas tab Chat Android membaca dan memperbarui field `"enable"` dan `patterns` secara live lewat `ModStorage.replace("chat", ..., fromUser = true)`.
- Event `{"t": "chat", "v": "...", "cmds": [{"cmd": "/...", "run": true|false}]}` ikut mengirim `ClickEvent::RunCommand`/`SuggestCommand` ke tab Chat APK untuk quick action.
