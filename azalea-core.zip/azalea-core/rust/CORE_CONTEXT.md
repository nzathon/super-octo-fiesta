# Azalea Core Pack — Konteks untuk AI

> File ini ikut dikemas ke dalam `azalea-core-pack.zip` agar AI bisa menambah/mengubah modul Rust maupun tab WebView **tanpa perlu mengubah, mem-build, atau meng-install ulang APK Android**.

## 1. Lingkungan & Aturan Kerja
- Target perangkat: HP Android 9 `arm64-v8a` (`aarch64-linux-android`). Pengguna bekerja dari HP dan membangun lewat GitHub Actions.
- Build **Core saja** memakai `.github/workflows/build-core.yml` (otomatis jalan saat `rust/**`, `app/src/main/assets/**`, atau `web/**` berubah) -> menghasilkan artefak `azalea-core-pack` yang diimpor langsung di tab/layar **Modul** -> **Import Core (.zip)**.
- **Jangan menebak API crate `azalea`**: periksa dokumentasi `https://azalea.rs/azalea/` atau cek source crate di `.cargo/git/checkouts/azalea-*`.
- Server target memakai anti-cheat, proxy + `/login` wajib tiap koneksi, kadang SRV record, dan plugin cracked/SkinsRestorer. Jangan buat perilaku bot yang tidak wajar; jangan simpan/cetak password ke log.
- Bahasa komunikasi dengan pengguna: Bahasa Indonesia santai dan ringkas. Bedakan mana yang sudah teruji/terbukti dan mana yang baru dugaan/belum di-compile.

## 2. Isi Bundel `azalea-core-pack.zip`
- `azalea-core` — binary ELF `aarch64-linux-android` hasil `cargo ndk -t arm64-v8a -P 26 build --release`. Dijalankan APK lewat `ProcessBuilder` dari `filesDir/core/azalea-core` (diizinkan SELinux karena APK memakai `targetSdk = 28`).
- `web/` — aset HTML/JS/CSS untuk tab WebView. File di sini meng-override `assets/` bawaan APK (termasuk `inventory.html` milik tab **Monitor**) dan melayani tab WebView dinamis baru via origin `https://appassets.azalea.local/<nama_file>`.
- `manifest.json` — metadata build (`core_version`, `run_number`, `sha`).
- `CORE_CONTEXT.md` — file konteks ini.

## 3. Protokol Pipa `stdin` / `stdout` (`rust/src/main.rs`)
Aplikasi Android menjalankan `azalea-core` sebagai proses anak (1 koneksi = 1 proses).

### Mode Skema (`azalea-core modules`)
Saat aplikasi start atau setelah import core, APK menjalankan `azalea-core modules` (timeout 6 detik) dan membaca baris JSON:
```json
{
  "t": "modules",
  "core_name": "azalea-core",
  "core_version": "0.1.0",
  "mc_version": "26.2",
  "protocol": 776,
  "v": [ /* hasil modules::schema() */ ],
  "tabs": [ /* hasil modules::tabs_schema() */ ]
}
```

### `stdin` (APK -> Rust, JSON per baris)
1. Baris pertama (konfigurasi awal):
   `{"host":"...","port":25565,"username":"...","ip":"1.2.3.4","rport":25565,"modules":{...},"storage":{...}}`
2. Perintah berjalan:
   - `{"t":"chat","v":"teks atau /perintah"}`
   - `{"t":"inv","a":"left|right|shift|middle|drop1|dropall|offhand|detail|select|use|close|refresh|clear_feed","slot":0}`
   - `{"t":"web","ch":"<channel>","a":"<action>","v":{...}}` -> diteruskan ke `modules::dispatch_web(&bot, ch, action, &v)`
   - `{"t":"set","m":"<module_id>","k":"<key>","v":<nilai>}` -> memperbarui `settings` live
   - `{"t":"storage","m":"<module_id>","v":{...}}` -> memperbarui `storage` dari UI
   - `{"t":"quit"}`

### `stdout` (Rust -> APK, JSON per baris)
- `{"t":"status","v":"connecting|online|offline"}` (`crate::status(...)`)
- `{"t":"log","v":"..."}` (`crate::log(...)`)
- `{"t":"chat","v":"<teks ANSI>"}`
- `{"t":"players","v":[{"id":"...","name":"...","display":"...","ping":50,"self":false,"hash":"..."}]}`
- `{"t":"inv" | "mon_status" | "mon_feed" | "detail", ...}` (khusus channel `"monitor"`)
- `{"t":"storage","m":"<module_id>","v":{...}}` (sinkronisasi storage persisten ke HP)
- `{"t":"web","ch":"<channel>","k":"<snapshot_key>","live":false,"v":{...}}` (`crate::web_emit(ch, key, live, payload)`)

## 4. Daftar Modul Bawaan (`rust/src/modules/`)
- `autoclick` — tahan klik kiri / klik kanan berkala.
- `autofish` — memancing otomatis via deteksi suara `entity.fishing_bobber.splash`, jeda reaksi acak, timeout diam, batas durability, dan auto swap rod.
- `chat` — chat ANSI berwarna, blacklist live per-pattern, notifikasi PM + reply langsung, dan tab completion.
- `playerlist` — daftar pemain online (filter NPC), skin hash, ping, dan tombol aksi cepat.
- `monitor` — tab Monitor (`inventory.html`): inventory/menu, detail/lore, HP/lapar/XP/koordinat/ping, efek, bossbar, dan feed action bar/title.
- `relogin` — auto login/register, simpan password otomatis, pindah server menu (1-step & `slotsMenu` multi-step), deteksi balik ke lobby, dan auto reconnect.

## 5. Cara Menambah Modul Rust & Tab WebView Dinamis Baru
1. Buat `rust/src/modules/<nama>.rs` dengan `pub fn def() -> Def` dan `pub async fn on_event(bot: &Client, event: &Event)`.
2. Daftarkan di `rust/src/modules/mod.rs` (`pub mod`, `all()`, `dispatch()`).
3. Jika butuh tab WebView sendiri, daftarkan `WebTab` di `web_tabs()` + tangani di `dispatch_web()` dan taruh HTML-nya di `app/src/main/assets/` (atau `web/`).
